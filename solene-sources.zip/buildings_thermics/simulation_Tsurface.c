/*
 *  Copyright 2006-2010 Julien Bouyer (CERMA, UMR 1563 AAU, CNRS / 
 *                                  Ecole d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

// ==========================================================
// descriptif de la fonction
// ==========================================================
//
// developpe par Julien Bouyer
// mise a jour des fonctions utilisees dans these J.Bouyer
// derniere mise a jour : juillet 2010
//
// - permet de calculer les temperatures de surface d'une scene (.cir)
// maillee (triangulee) en fonction de la nature de ses surfaces
// (modeles d'amenagements possibles : batiment, sol, arbres),
// des conditions meteo, des conditions initiales sur unb pas de temps
// de reference dt
// - permet aussi de calculer le comportement thermique d'un batiment
// identifie dans la scene : calcul des temperatures internes et ou de
// la consommation energetique durant dt
// - peut etre couplee avec des outils de CFD (Saturne, Fluent)
// par interface python ou C
//
//
// ==========================================================
// bibliotheques
// ==========================================================

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <math.h>
//#include "F2CLIBS/f2c.h"		// Windows
//#include "BLAS/WRAP/cblas.h"	// Windows
//#include "clapack.h"			// Windows
#include <cblas.h>			// Linux
#include <clapack.h>			// Linux

// ==========================================================
// definitions constantes
// ==========================================================

#define PI (4.*atan(1.))
#define TAILLE_CHAINE_NOM_FICHIER 500

// ==========================================================
// definitions structures
// ==========================================================

typedef struct {
	double lambda_sol; // conductivite th. du sous sol
	double cp_sol; // capa. th. du sous sol
	double rho_sol; // masse vol. du sous sol
	double z_ref; // profondeur pour la condition limite de temperature
	int i_jour; // jour de simulation
	int i_jour_ref; // jour de l'annee de la plus basse temperature moyenne du site
	double moy_Tair; // moyenne de temperature annuelle du site
	double max_Tair; // temperature moy journaliere maximale du site sur l'annee
	double min_Tair; // temperature moy journaliere minimale du site sur l'annee
} prop_sol;

typedef struct {
	int classe; // 0 : murs ext , 1 : vitrage , 2 : toit , 3 : plancher int , 4 : plancher bas , 5 : parois int
	int id; // correspond au descripteur 'id_paroi' defini par l'utilisateur dans la geometrie
	int n; // nb de couches de materiau
	double *e; // epaisseur de la couche
	double *l; // lambda de la couche
	double *C; // Cp de la couche
	double *r; // rho de la couche
} paroi;

typedef struct {
	double R; // resistance thermique equivalente de la paroi
	double Ce; // capacite equivalente de surface exterieure
	double Ci; // capacite equivalente de surface interieure
} listeRCparoi;

typedef struct {
	double *SURFACE_CL;
	double *SURFACE_ID;
} Sniveau;

// ==========================================================
// procedures
// ==========================================================

// LISTE DES PROCEDURES :

/*

 Allocations d'espace memoire
 ----------- allocation_tableau_double
 ----------- allocation_tableau_int
 ----------- allocation_tableau_float (pour les fac. de forme)
 ----------- allocation_paroi


 Lecture de donnees/fichiers entree
 ----------- lecture_nb_paroi
 ----------- complement_extension
 ----------- lecture_donnees_paroi
 ----------- lecture_donnees_sol
 ----------- lecture_descripteur
 ----------- val_max_descripteur
 ----------- decompte_contours
 ----------- total_face
 ----------- analyse_face_contour
 ----------- lecture_fichier_T_noeuds_init
 ----------- lecture_ff


 Stockage donnees/fichier affichages ecran
 ----------- stocke_fichier_val
 ----------- stocke_fichier_T_noeuds_out
 ----------- vecteurT_vers_variablesT


 Tests et traitements divers
 ----------- utilisation
 ----------- test_tableau_val_positif
 ----------- remplissage_matrice_modele_batiment
 ----------- remplissage_vecteur_modele_batiment
 ----------- remplissage_matrice_modele_facetteBAT
 ----------- remplissage_vecteur_modele_facetteBAT
 ----------- remplissage_matrice_modele_sol
 ----------- remplissage_vecteur_modele_sol


 Calculs
 ----------- calcul_surfaces
 ----------- calcul_RCparoi_surfacique
 ----------- calcul_Rint_surfacique
 ----------- calcul_proprietes_sol
 ----------- calcul_proprietes_air_int
 ----------- calcul_flux_solaires_int
 ----------- calcul_flux_latent
 ----------- calcul_Tref_profondeur
 ----------- resolutionSystemeLineaire_LINUX
 ----------- resolutionSystemeLineaire_WINDOWS
 ----------- Teq_soleil
 ----------- IR_ciel
 ----------- radiog
 ----------- calc_flux_atm_intereflexion
 ----------- calc_GLO
 ----------- calcul_puissance_occupation
 ----------- calcul_HS
 ----------- calcul_HR
 ----------- bilan_vapeur_eau

 */

double *allocation_tableau_double(int dim)
//------------------------------------------------------------------------------------
// reserve une zone memoire de dim*(double) et initialize ses valeurs a 0
//------------------------------------------------------------------------------------
{
	double *tab = (double *) calloc(dim, sizeof(double));
	return tab;
}

int *allocation_tableau_int(int dim)
//------------------------------------------------------------------------------------
// reserve une zone memoire de dim*(int) et initialize ses valeurs a 0
//------------------------------------------------------------------------------------
{
	int *tab = (int *) calloc(dim, sizeof(int));
	return tab;
}

float *allocation_tableau_float(int dim)
//------------------------------------------------------------------------------------
// reserve une zone memoire de dim*(int) et initialize ses valeurs a 0
//------------------------------------------------------------------------------------
{
	float *tab = (float *) calloc(dim, sizeof(float));
	return tab;
}

paroi *allocation_struct_paroi(int n_paroi)
//------------------------------------------------------------------------------------
// reserve une zone memoire de dim (struct)*paroi et initialize par defaut
// definit la dimension des tableaux de prop. physiques en f de  n_couche
// reserve une zone memoire de n_couche*(double) et initialize ses valeurs a 0
//------------------------------------------------------------------------------------
{
	paroi *P = (paroi *) calloc(n_paroi, sizeof(paroi));
	return P;
}

void complement_extension(char *nom_fichier, char *argument, char *extension)
//------------------------------------------------------------------------------------
// complete le nom du fichier par l'extension desiree si elle n'est pas
// renseignee par defaut
//------------------------------------------------------------------------------------
{
	if (strcmp((argument + (strlen(argument) - 3)), extension)) {
		sprintf(nom_fichier, "%s.%s", argument, extension);
	} else {
		strcpy(nom_fichier, argument);
	}
}

int lecture_nb_paroi(char *nom_fichier)
//------------------------------------------------------------------------------------
// Lecture (dans nom_fichier.txt) et renvoi du nb de paroi differentes
//------------------------------------------------------------------------------------
{
	FILE *fparoi;
	int nb_paroi;

	//verification de l'existance du fichier lu
	if ((fparoi = fopen(nom_fichier, "r")) == NULL) // verification de l'emplacement memoire
	{
		printf("\n\n  ERREUR : Impossible d'ouvrir '%s'\n\n", nom_fichier);
		exit(0);
	}

	// lecture et stockage du nb total de parois differentes
	fscanf(fparoi, "%d", &nb_paroi); // lecture
	//printf("\nNombre de parois : %d",nb_paroi) ;		// impression ecran
	return nb_paroi;
}

void lecture_donnees_paroi(char *nom_fichier, paroi *tableau_paroi)
//------------------------------------------------------------------------------------
// Lecture du fichier 'nom_fichier.txt' contenant les proprietes thermiques
// des materiaux composant la paroi
// Remplissage en consequence de la structure 'paroi' dans code
//------------------------------------------------------------------------------------
{
	FILE *fparoi; // fichier lu
	int nb_paroi; // nb de parois

	char nom_paroi[32]; // nom de la paroi courante lue
	int *nb_couche; // tableau du nb de couche pour chaque paroi

	int Classe, ID; // tableau du nb de couche pour chaque paroi

	char materiau[32]; // nom du materiau de la couche courante
	double epaisseur, lambda, cp, rho; // prop physiques de la couche courante

	int i, j;

	//verification de l'existance du fichier lu
	if ((fparoi = fopen(nom_fichier, "r")) == NULL) {
		printf("\n\n  ERREUR : Impossible d'ouvrir '%s'\n\n", nom_fichier);
		exit(0);
	}

	fscanf(fparoi, "%d", &nb_paroi); // lecture du nombre total de parois differentes
	//printf("Nombre de parois : %d\n",nb_paroi) ;			// impression ecran

	nb_couche = allocation_tableau_int(nb_paroi); // allocation memoire tableau des nb_couche


	for (i = 0; i < nb_paroi; i++) {
		//printf("\nParoi [%d]\n",i+1) ;	printf("----------------------------------\n") ;

		fscanf(fparoi, "%s", nom_paroi); // lecture du nom de paroi (i)
		//printf("Nom paroi : %s    ",nom_paroi) ;						// impression ecran

		fscanf(fparoi, "%d", &Classe); // lecture du nombre de couches de la paroi (i)
		tableau_paroi[i].classe = Classe;
		//printf("Classe : %d   ",tableau_paroi[i].classe) ;			// impression ecran

		fscanf(fparoi, "%d", &ID); // lecture du nombre de couches de la paroi (i)
		tableau_paroi[i].id = ID;
		//printf("ID : %d\n",tableau_paroi[i].id) ;			// impression ecran

		fscanf(fparoi, "%d", &nb_couche[i]); // lecture du nombre de couches de la paroi (i)
		tableau_paroi[i].n = nb_couche[i];
		//printf("Nombre couches : %d\n",tableau_paroi[i].n) ;			// impression ecran

		tableau_paroi[i].e = allocation_tableau_double(nb_couche[i]);
		tableau_paroi[i].l = allocation_tableau_double(nb_couche[i]);
		tableau_paroi[i].C = allocation_tableau_double(nb_couche[i]);
		tableau_paroi[i].r = allocation_tableau_double(nb_couche[i]);

		for (j = 0; j < nb_couche[i]; j++) {
			//printf("Couche [%d]   ",j+1) ;

			fscanf(fparoi, "%s", materiau);
			//printf("Materiau : %s\t",materiau);

			fscanf(fparoi, "%lf", &epaisseur);
			tableau_paroi[i].e[j] = epaisseur;
			//printf("epaisseur [m] = %1.3f   ",tableau_paroi[i].e[j]);

			fscanf(fparoi, "%lf", &lambda);
			tableau_paroi[i].l[j] = lambda;
			//printf("lambda [SI] = %5.3f   ",tableau_paroi[i].l[j]);

			fscanf(fparoi, "%lf", &cp);
			tableau_paroi[i].C[j] = cp;
			//printf("Cp [SI] = %5f   ",tableau_paroi[i].C[j]);

			fscanf(fparoi, "%lf", &rho);
			tableau_paroi[i].r[j] = rho;
			//printf("rho [SI] = %5.2f\n",tableau_paroi[i].r[j]);
		}
		//printf("\n") ;
	}
	//printf("----------------------------------\n\n") ;
	fclose(fparoi);
}

void lecture_donnees_sol(char *nom_fichier, prop_sol *tableau_sol) {
	FILE *fic_sol; // fichier lu
	char nom_var[32]; // nomde la variable
	double val_var; // valeur de la variable
	int val_ind; // valeur de l'indice

	// verification de l'existance du fichier lu

	if ((fic_sol = fopen(nom_fichier, "r")) == NULL) {
		printf("\n\n  ERREUR : Impossible d'ouvrir '%s'\n\n", nom_fichier);
		exit(0);
	}

	// lecture des donnees

	fscanf(fic_sol, "%s %lf", nom_var, &val_var);
	tableau_sol->lambda_sol = val_var;
	printf("\nlambda sol : %f", val_var);
	printf("\nlambda sol : %f", tableau_sol->lambda_sol);

	fscanf(fic_sol, "%s %lf", nom_var, &val_var);
	tableau_sol->cp_sol = val_var;

	fscanf(fic_sol, "%s %lf", nom_var, &val_var);
	tableau_sol->rho_sol = val_var;

	fscanf(fic_sol, "%s %lf", nom_var, &val_var);
	tableau_sol->z_ref = val_var;

	fscanf(fic_sol, "%s %d", nom_var, &val_ind);
	tableau_sol->i_jour = val_ind;

	fscanf(fic_sol, "%s %d", nom_var, &val_ind);
	tableau_sol->i_jour_ref = val_ind;

	fscanf(fic_sol, "%s %lf", nom_var, &val_var);
	tableau_sol->moy_Tair = val_var;

	fscanf(fic_sol, "%s %lf", nom_var, &val_var);
	tableau_sol->max_Tair = val_var;

	fscanf(fic_sol, "%s %lf", nom_var, &val_var);
	tableau_sol->min_Tair = val_var;

	// fermeture du fichier

	fclose(fic_sol);
}

void lecture_descripteur(char *nom_fichier, double *valeur)
//------------------------------------------------------------------------------------
// Ouverture et lecture d'un fichier descripteur 'nom_fichier' (.val)
// et remplissage du tableau 'valeur'
//------------------------------------------------------------------------------------
{
	double val_min;
	double val_max;
	int num_cont, num_face, num_cont_liste;
	int nbfac, nomax;
	int nofac, nbcont_face;
	char c;
	FILE *pfic;

	// verification de l'emplacement memoire du fichier
	if ((pfic = fopen(nom_fichier, "r")) == NULL) {
		printf("\n\n  ERREUR : Impossible d'ouvrir '%s'\n\n", nom_fichier);
		exit(0);
	}

	// lecture des infos en premiere ligne du fichier
	fscanf(pfic, "%d %d %lf %lf", &nbfac, &nomax, &val_min, &val_max);

	// boucle sur les lignes de faces et de contours
	num_cont_liste = 0;
	for (num_face = 0; num_face < nbfac; num_face++) {
		fscanf(pfic, "\n%c%d%d\n", &c, &nofac, &nbcont_face);
		for (num_cont = 0; num_cont < nbcont_face; num_cont++) {
			fscanf(pfic, "%lf\n", valeur + num_cont_liste);
			num_cont_liste++;
		}
	}
	fclose(pfic);
}

double val_max_descripteur(char *nom_fichier)
//------------------------------------------------------------------------------------
// Ouverture et lecture de la premiere ligne d'un fichier descripteur
// pour trouver le max
//------------------------------------------------------------------------------------
{
	double val_min;
	double val_max;
	int nbfac, nomax;
	FILE *pfic;

	// verification de l'emplacement memoire du fichier
	if ((pfic = fopen(nom_fichier, "r")) == NULL) {
		printf("\n\n  ERREUR : Impossible d'ouvrir '%s'\n\n", nom_fichier);
		exit(0);
	}
	// lecture des infos en premiere ligne du fichier
	fscanf(pfic, "%d %d %lf %lf", &nbfac, &nomax, &val_min, &val_max);
	return val_max;
}

int total_face(char *nom_fichier)
//------------------------------------------------------------------------------------
// lecture du fichier "nom_fichier(.val)"pour evaluer le nombre total de faces
//------------------------------------------------------------------------------------
{
	int nb_F;
	int no_Fmax;
	double val_min, val_max;
	FILE *pfic;

	// verification de l'emplacement memoire du fichier
	if ((pfic = fopen(nom_fichier, "r")) == NULL) {
		printf("\n\n  ERREUR : Impossible d'ouvrir '%s'\n\n", nom_fichier);
		exit(0);
	}
	// lecture des infos en premiere ligne du fichier
	fscanf(pfic, "%d %d %lf %lf", &nb_F, &no_Fmax, &val_min, &val_max);
	// fermeture du fichier
	fclose(pfic);
	// mise a jour
	//printf("Nombre total de faces : %d\n", nb_F) ;
	return nb_F;
}

void analyse_face_contour(char *nom_fichier, int *no_face_max,
		int *nb_contour_total, int *tab_no_face, int *tab_nb_contour_face)
//------------------------------------------------------------------------------------
// lecture du fichier "nom_fichier(.val)" pour evaluer :
// - le nombre total de contours
// - le nombre total de faces
// - le n de la face max
// remplissage des tableau de n de face, et nb de contour par face correspondant
//------------------------------------------------------------------------------------
{
	int nb_F;
	int no_face;
	int no_Fmax;
	int nb_contour;
	int *tab_cf, *tab_no;
	double val_min, val_max;
	int i, j;
	char c; // pour la lecture du caractere f (identifiant face du fichier .val)
	double *auxiliaire; // adresse d'une var. aux. permettant de lire chq ligne portant la val numerique du descripteur
	FILE *pfic; // adresse du fichier

	// verification de l'emplacement memoire du fichier
	if ((pfic = fopen(nom_fichier, "r")) == NULL) {
		printf("\n\n  ERREUR : Impossible d'ouvrir '%s'\n\n", nom_fichier);
		exit(0);
	}
	// initialisation
	*nb_contour_total = 0;
	// lecture des infos en premiere ligne du fichier
	fscanf(pfic, "%d %d %lf %lf", &nb_F, &no_Fmax, &val_min, &val_max);
	// allocation memoire des tableaux de 'n de face' et de 'nb de contours par face'
	tab_no = allocation_tableau_int(nb_F);
	tab_cf = allocation_tableau_int(nb_F);
	// boucle sur les ligne du fichier
	//printf("Detail de la geometrie :\n");	
	for (i = 0; i < nb_F; i++) {
		fscanf(pfic, "\n%c%d%d\n", &c, &no_face, &nb_contour);
		//printf("----------------------\n");
		//printf("Face %d  :  %d contours\n", no_face, nb_contour) ;
		tab_no[i] = no_face;
		tab_cf[i] = nb_contour;
		*nb_contour_total += nb_contour;
		auxiliaire = (double *) malloc(nb_contour * sizeof(double));
		for (j = 0; j < nb_contour; j++) {
			fscanf(pfic, "%lf\n", auxiliaire + j); // lecture des lignes de descripteur sans rien stocker
			//printf("aux : %f\n",auxiliaire+j) ;	// test ????
		}
		free(auxiliaire);
	}
	//printf("----------------------\n");
	// fermeture du fichier
	fclose(pfic);
	// mise a jour des resultats
	*no_face_max = no_Fmax;
	//tab_no_face = allocation_tableau_int(nb_F) ;
	//tab_nb_contour_face = allocation_tableau_int(nb_F) ;
	for (i = 0; i < nb_F; i++) {
		tab_no_face[i] = tab_no[i];
		tab_nb_contour_face[i] = tab_cf[i];
	}
	// impression infos
	//printf("\nNombre total de contours : %d", *nb_contour_total) ;
	//printf("\nNombre total de faces : %d", nb_F) ;
	//printf("N de la face max : %d\n", *no_face_max) ;
	//for (i = 0; i < nb_F ; i++)	printf("\ni = %d    face%d :    %d contours",i, tab_no_face[i], tab_nb_contour_face[i]) ;
}

void lecture_fichier_T_noeuds_init(char *nom_fichier_matrice_noeuds_in,
		int nb_niv, double *T2init, double *T4init, double *T5init,
		double *T6init, double *T7init, double *T8init, double *T9init,
		double *T12init, double *Tsolinit, double *Tairinit)
//------------------------------------------------------------------------------------
// ouverture et lecture d'un fichier (.txt) de l'ensemble des valeurs
// de temperatures et puissances nodales par niveau (matrice de valeurs) et
// stockage des valeurs dans des vecteurs (de dimension niveau) de variables
// individuelles correspondants
//------------------------------------------------------------------------------------
{
	FILE *pfic = NULL;
	int i = 0;
	int X = 0;
	double buf1, buf2;

	// verification de l'emplacement memoire du fichier
	if ((pfic = fopen(nom_fichier_matrice_noeuds_in, "r")) == NULL) {
		printf("\n\n  ERREUR : Impossible d'ouvrir '%s'\n\n",
				nom_fichier_matrice_noeuds_in);
		exit(0);
	}

	while (X != EOF) {
		// verification du nombre d'etages (trop ?)
		if (i > nb_niv) {
			printf(
					"\n\n  ERREUR : Nb de lignes de '%s' superieur au nombre de niveaux \n\n",
					nom_fichier_matrice_noeuds_in);
			exit(0);
		}
		// lecture et stockage des valeurs
		X = fscanf(pfic, "%lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf",
				T2init + i, T4init + i, T5init + i, T6init + i, T7init + i,
				T8init + i, T9init + i, T12init + i, Tsolinit + i,
				Tairinit + i, &buf1, &buf2);
		i++;
	}

	// verification du nombre d'etages (pas assez ?)
	if (i < nb_niv) {
		printf(
				"\n\n  ERREUR : Nb de lignes de '%s' inferieur au nombre de niveaux \n\n",
				nom_fichier_matrice_noeuds_in);
		exit(0);
	}
}

int test_tableau_val_positif(double *tableau, int dim, double *val_min,
		int *nb_erreur)
//------------------------------------------------------------------------------------
// teste s'il y a des valeurs negatives dans un tableau de descripteurs
// renvoie 0 si au moins une des valeurs est <0
// renvoie 1 si toutes les valeurs sont >=0
// FORCE TOUTES LES VALEURS NEGATIVES A 0
// stocke la valeur la plus basse
//------------------------------------------------------------------------------------
{
	int test = 1;
	int i;
	int err = 0;

	*nb_erreur = 0;
	*val_min = tableau[0];
	for (i = 0; i < dim; i++) {
		if (tableau[i] < *val_min)
			*val_min = tableau[i];
		if (tableau[i] < 0) {
			tableau[i] = 0.0;
			err++;
			test = 0;
		}
	}
	*nb_erreur = err;
	return test;
}

int stocke_fichier_T_noeuds_out(char *nom_fichier_matrice_noeuds_out,
		int nb_niv, double *T2out, double *T4out, double *T5out, double *T6out,
		double *T7out, double *T8out, double *T9out, double *T12out,
		double *Tsolout, double *Tairout, double *Pconv, double *Plat)
//------------------------------------------------------------------------------------
// stockage des valeurs nodales (temperatures / puissances) calculees pour le
// modele de batiment dans un fichier .txt (matrice de valeurs par niveau)
//------------------------------------------------------------------------------------
{
	FILE *pf = NULL;
	int i = 0;
	int sauvOK = 1;

	if ((pf = fopen(nom_fichier_matrice_noeuds_out, "w")) == NULL) {
		sauvOK = 0;
	} else {
		for (i = 0; i < nb_niv; i++) {
			fprintf(pf, "%f %f %f %f %f %f %f %f %f %f %f %f\n", T2out[i],
					T4out[i], T5out[i], T6out[i], T7out[i], T8out[i], T9out[i],
					T12out[i], Tsolout[i], Tairout[i], Pconv[i], Plat[i]);
		}
		fclose(pf);
	}
	return sauvOK;
}

int stocke_fichier_val(char *nom_fichier, int nbfac, int nomax,
		int nb_contour_total, int *numero_face, int *nb_cont_face, double *tab)
//------------------------------------------------------------------------------------
// permet de generer un descripteur "nom_fichier(.val)" a partir d'un tableau
// de valeurs
//------------------------------------------------------------------------------------
{
	FILE *pf;
	double mini, maxi;
	int i, k, num;
	int sauvOK = 1;

	if ((pf = fopen(nom_fichier, "w")) == NULL)
		sauvOK = 0;
	else {
		mini = maxi = tab[0];
		for (i = 0; i < nb_contour_total; i++) {
			if (tab[i] < mini)
				mini = tab[i];
			if (tab[i] > maxi)
				maxi = tab[i];
		}

		fprintf(pf, "%5d %5d %8.3f %8.3f\n", nbfac, nomax, mini, maxi);

		num = 0;
		for (i = 0; i < nbfac; i++) {
			fprintf(pf, "f%d %d\n", numero_face[i], nb_cont_face[i]);
			for (k = 0; k < nb_cont_face[i]; k++) {
				fprintf(pf, "    %8.3f\n", tab[num]);
				num++;
			}
		}
		fclose(pf);
	}
	return sauvOK;
}

void calcul_surfaces(double *niveau, double *id_paroi, double *classe_paroi,
		Sniveau *Sniv, double *surface, int nb_niv, int nb_paroi,
		int nb_contour_total)
//------------------------------------------------------------------------------------
// permet de calculer les surfaces totales de murs ext, vitrage... par niveau
//------------------------------------------------------------------------------------
{
	int niv, id, cl, fac;
	double coef = 1;

	for (niv = 0; niv < nb_niv; niv++) {
		Sniv[niv].SURFACE_ID = allocation_tableau_double(nb_paroi);
		for (id = 0; id < nb_paroi; id++)
			for (fac = 0; fac < nb_contour_total; fac++)
				if (((int) niveau[fac] == niv) && (id_paroi[fac] == id))
					Sniv[niv].SURFACE_ID[id] = Sniv[niv].SURFACE_ID[id]
							+ surface[fac]; // surface indexee selon les descripteur 'id_paroi'
	}

	for (niv = 0; niv < nb_niv; niv++) {
		Sniv[niv].SURFACE_CL = allocation_tableau_double(6);
		for (cl = 0; cl < 6; cl++)
			for (fac = 0; fac < nb_contour_total; fac++)
				if (((int) niveau[fac] == niv) && ((int) classe_paroi[fac]
						== cl))
					Sniv[niv].SURFACE_CL[cl] = Sniv[niv].SURFACE_CL[cl]
							+ surface[fac]; // surface indexee selon les descripteur 'classe_paroi'
	}

	// ATTENTION : les relation (1) et (2) ne sont valables que pour les batiment de type prisme
	// (extrusions successives du niveau de base) sinon la valeur des planchers varie a chaque etage
	// prevoir une option de calcul pour les cas particuliers

	// ATTENTION : la relation (3) supose que la surface totale des paroi interieures est un multiple (coef)
	// des parois exterieures a l'etage courant

	for (niv = 0; niv < nb_niv; niv++) {
		// relation 1
		Sniv[niv].SURFACE_CL[3] = Sniv[nb_niv - 1].SURFACE_CL[2];
		// relation 2
		Sniv[niv].SURFACE_CL[4] = Sniv[nb_niv - 1].SURFACE_CL[2];
		// relation 3
		Sniv[niv].SURFACE_CL[5] = coef * (Sniv[niv].SURFACE_CL[0]
				+ Sniv[niv].SURFACE_CL[1]);
	}
}

void calcul_RCparoi_surfacique(paroi *P, listeRCparoi *RCparoi)
//------------------------------------------------------------------------------------
// permet de calculer les 3 parametres thermiques analogiques intrinseques (R , Ce , Ci)
// des differents types de parois d'un batiment (mur, vitrage, toit, plancher, plafond)
//------------------------------------------------------------------------------------
{
	// declaration variables
	int j; // compteur de couche
	int j_max = P->n; // nb max de couches

	double Rj; // variable de calcul (voir these)
	double Rj_1; // variable de calcul (voir these)
	double beta_j; // variable de calcul (voir these)

	double *R = allocation_tableau_double(j_max); // resistances thermiques pour chaque couche
	double *Ci = allocation_tableau_double(j_max); // capacites thermiques int pour chaque couche
	double *Ce = allocation_tableau_double(j_max); // capacites thermiques ext pour chaque couche

	double Req; // resistance thermique equivalente calculee
	double Ci_eq; // capacite de surface interieure calculee
	double Ce_eq; // capacite de surface exterieure calculee

	// determination de Req
	Req = 0;
	for (j = 0; j < j_max; j++) {
		R[j] = (P->e[j] / P->l[j]);
		Req = Req + R[j];
	}

	// determination de Ce et Ci
	Rj = 0;
	Rj_1 = 0;
	Ci_eq = 0;
	Ce_eq = 0;
	for (j = 0; j < j_max; j++) {
		Rj_1 = Rj;
		R[j] = (P->e[j] / P->l[j]);
		Rj = Rj + R[j];
		beta_j = 0.5 * (Rj + Rj_1) / Req; // beta_j corrige
		//beta_j = (0.5*Rj + Rj_1)/Req;		// beta_j version polycopie
		Ci[j] = P->r[j] * P->C[j] * P->e[j] * beta_j;
		Ce[j] = P->r[j] * P->C[j] * P->e[j] * (1 - beta_j);
		Ci_eq = Ci_eq + Ci[j];
		Ce_eq = Ce_eq + Ce[j];
	}

	// attribution des valeurs dans les structures R_entite et C_entite
	RCparoi->R = Req;
	RCparoi->Ci = Ci_eq;
	RCparoi->Ce = Ce_eq;
}

void calcul_Rint_surfacique(double hc_int, double hr_int, double *Rcv_i,
		double *Rrad_i)
//------------------------------------------------------------------------------------
// calcul des resistances convectives et radiatives en surface des parois
//------------------------------------------------------------------------------------
{
	// ATTENTION : adapter chaque coefficient avec sa classe de paroi
	*Rcv_i = 1 / hc_int;
	*Rrad_i = 1 / hr_int;
}

void calcul_proprietes_air_int(int nb_facette, int niv, double *niveau,
		double *in_air, double taux_occup, double debit_hyg_indiv, double Splc,
		double Hniv, double *Rra, double *Cai)
//------------------------------------------------------------------------------------
// calcul des proprietes resistives et capacitives de l'air au noeud
// de calcul 10 (bilan sur l'air interieur)
//------------------------------------------------------------------------------------
{
	double rho_air = 1.25; // masse vol air (kg/m3)
	double Cp_air = 1000; // capacite thermique massique  (J/K.kg)
	double qm_air_tot; // debit d'air neuf total d'etage
	int somme_in_air; // somme des entrees d'air sur 1 etage
	int i;

	// NB :
	// pour calculer la surface au sol exploitable ou le volume ventile, on pondere
	// la surface de plancher par 95% pour tenir compte de la surface
	// occupee par les refends et parois interieures


	// Calcul des Cai : inertie du volume d'air interne
	*Cai = rho_air * Cp_air * 0.95 * Splc * Hniv; // rho * C * volume

	// Calcul des Rra : renouvellement d'air
	somme_in_air = 0;
	qm_air_tot = taux_occup * debit_hyg_indiv * 0.95 * Splc * rho_air / 3600;

	for (i = 0; i < nb_facette; i++)
		if (((int) niveau[i] == niv) && ((int) in_air[i] == 1))
			somme_in_air++;

	qm_air_tot = qm_air_tot / somme_in_air; // repartition du debit total sur les differentes entrees

	for (i = 0; i < nb_facette; i++) {
		if (((int) niveau[i] == niv) && ((int) in_air[i] == 1)) {
			if (qm_air_tot != 0)
				Rra[i] = 1 / (Cp_air * qm_air_tot);
			else {
				Rra[i] = -1.0; // pas de ventilation (pas d'occupants)
				//printf("\nATTENTION : probleme de debit d'air neuf nul  -  Verifier le scenario d'occupation\n\n");
				//exit(0);
			}
		}
	}
}

void calcul_puissance_occupation(int saison, double surface, double taux_occup,
		double ps_equip, double *Ps_equip, double *Ps_occup, double *Pl_occup)
//------------------------------------------------------------------------------------
// calcul les puissances sensibles et latente
//------------------------------------------------------------------------------------
{
	double Adu = 1.8; // aire de Dubois (surface caorporelle) en m

	// puissance sensible et latentes d'un individu en ete
	// exprimees en W/m
	// conditions : activite 1.2 Met, Icl 0.5 clo, Top 25C, Vair 0.1 m/s
	double ps_indiv_ete = 47;
	double pl_indiv_ete = 21;

	// puissance sensible et latentes d'un individu en hiver
	// exprimees en W/m
	// conditions : activite 1.2 Met, Icl 1 clo, Top 20C, Vair 0.1 m/s
	double ps_indiv_hiver = 55;
	double pl_indiv_hiver = 23;

	int ete = 0;
	int hiver = 1;

	if (saison == ete) {
		*Ps_occup = surface * taux_occup * Adu * ps_indiv_ete;
		*Pl_occup = surface * taux_occup * Adu * pl_indiv_ete;
	} else if (saison == hiver) {
		*Ps_occup = surface * taux_occup * Adu * ps_indiv_hiver;
		*Pl_occup = surface * taux_occup * Adu * pl_indiv_hiver;
	} else {
		printf(
				"\nATTENTION : probleme au niveau de la definition de la saison : ete(0) hiver(1)\n\n");
		exit(0);
	}

	*Ps_equip = surface * ps_equip;
}

double calcul_HS(double Tair, double HR)
//------------------------------------------------------------------------------------
// calcul de l'humidite specifique en fonction de Tair et de l'humidite relative
//------------------------------------------------------------------------------------
{
	//double p_air = 101325 ;	// pression atmospherique (air ambiant)
	double p_sat; // pression de vapeur saturante
	double T_radian; // temperature en kelvin
	double HS; // humidite specifique en kg(eau)/kg(air)

	T_radian = Tair * PI / 180.0; // convertit en radians pour fonctions trigo
	p_sat = 610.7 * pow((1 + sqrt(2) * sin(T_radian / 3)), 8.827); // formule de Alt, cf. Guyot p.106
	HS = (0.622 * p_sat * HR) / (101325 - (0.378 * p_sat * HR));
	return HS;
}

double calcul_HR(double Tair, double HS)
//------------------------------------------------------------------------------------
// calcul de l'humidite relative en fonction de Tair et de l'humidite specifique
//------------------------------------------------------------------------------------
{
	double p_air = 101325; // pression atmospherique (air ambiant)
	double p_sat; // pression de vapeur saturante
	double T_radian; // temperature celsius -> radians
	double HR; // humidite relative

	T_radian = Tair * PI / 180.0; // convertit en radians pour fonctions trigo
	p_sat = 610.7 * pow((1 + sqrt(2) * sin(T_radian / 3)), 8.827); // formule de Alt, cf. Guyot p.106
	HR = HS * p_air / (p_sat * (0.622 + 0.378 * HS)); // inversion de la formule humid spe
	return HR;
}

double bilan_vapeur_eau(double Tair_int, double surface, double taux_occup,
		double debit_hyg_indiv, double Pl_occup, double w_ext)
//------------------------------------------------------------------------------------
// permet de faire le bilan de charge latente a l'interieur du local en
// fonction de la quantite d'humlidite entrante
//------------------------------------------------------------------------------------
{
	double Platent; // charge latente de conditionnement d'air (W)
	double Lv = 2420000; // chaleur latente de vaporisation de la vapeur d'eau (J/kg)
	double w_int; // consigne de masse de vapeur d'eau dans l'air interieur (kg_eau/kg_air)
	double rho_air = 1.25; // masse vol air (kg/m3)
	double qm_air_sec; // debit d'air sec dans le local (kg/s)
	double HR = 0.5; // 50% d'humidite relative (CONSIGNE IMPOSEE)

	w_int = calcul_HS(Tair_int, HR); // calcul de la masse d'humidite pour 50% d'humidite relative
	qm_air_sec = taux_occup * debit_hyg_indiv * surface * rho_air / 3600;
	Platent = (qm_air_sec * Lv * (w_int - w_ext)) - Pl_occup;
	return Platent;
}

void calcul_flux_solaires_int(Sniveau *Sniv, int nb_facette, int nb_niv,
		double *niveau, double *classe_paroi, double *flux_sol_dir,
		double *flux_sol_diff, double *transmission, double *surface,
		double abs_plc, double abs_vit, double *Ft_mur, double *Ft_vit,
		double *Ft_plc, double *Ft_plf, double *Ft_int)
//------------------------------------------------------------------------------------
// permet de calculer les flux solaires transmis a l'interieur du batiment
// et leur repartition sur les differentes parois
//------------------------------------------------------------------------------------
{
	int i, j, niv;
	double Stot;
	double *Fsdir_transmis = allocation_tableau_double(nb_niv);
	double *Fsdiff_transmis = allocation_tableau_double(nb_niv);

	for (i = 0; i < nb_niv; i++)
		for (j = 0; j < nb_facette; j++)
			if (((int) niveau[j] == i) && ((int) classe_paroi[j] == 1)) // cas d'une surface vitree au niveau courant
			{
				Fsdir_transmis[i] += transmission[j] * surface[j]
						* flux_sol_dir[j];
				Fsdiff_transmis[i] += transmission[j] * surface[j]
						* flux_sol_diff[j];
			}

	for (niv = 0; niv < nb_niv; niv++) {
		Stot = Sniv[niv].SURFACE_CL[0] + Sniv[niv].SURFACE_CL[1]
				+ Sniv[niv].SURFACE_CL[3] + Sniv[niv].SURFACE_CL[4] + (2
				* Sniv[niv].SURFACE_CL[5]);
		Ft_plc[niv] = (abs_plc * Fsdir_transmis[niv])
				+ (Sniv[niv].SURFACE_CL[3] / Stot) * (Fsdiff_transmis[niv] + (1
						- abs_plc) * Fsdir_transmis[niv]);
		Ft_vit[niv] = (abs_vit * Sniv[niv].SURFACE_CL[1] / Stot)
				* (Fsdiff_transmis[niv] + (1 - abs_plc) * Fsdir_transmis[niv]);
		Ft_mur[niv] = (Sniv[niv].SURFACE_CL[0] / Stot) * (Fsdiff_transmis[niv]
				+ (1 - abs_plc) * Fsdir_transmis[niv]);
		Ft_plf[niv] = (Sniv[niv].SURFACE_CL[4] / Stot) * (Fsdiff_transmis[niv]
				+ (1 - abs_plc) * Fsdir_transmis[niv]);
		Ft_int[niv] = (2 * Sniv[niv].SURFACE_CL[5] / Stot)
				* (Fsdiff_transmis[niv] + (1 - abs_plc) * Fsdir_transmis[niv]);
	}
}

void remplissage_matrice_modele_batiment(double *M, int dim, int nb_facette,
		int nb_niv, double *niveau, int nb_paroi, double *id_paroi,
		double *classe_paroi, double *surface, Sniveau *Sniv, double *in_air,
		double dt, int *alpha, double *hc_ext, listeRCparoi *RCmur,
		listeRCparoi *RCvit, listeRCparoi *RCtoit, listeRCparoi *RCplc_int,
		listeRCparoi *RCplc_bas, listeRCparoi *RCint, double *Rcv_i,
		double *Rrad_i, double *Rra, double *Cai, double Rsol, double Csol)
//------------------------------------------------------------------------------------
// remplit la matrice [A] de resolution du systeme lineaire en fonction
// des variables physiques du modele de batiment
// 2 valeurs de matrices : [A] en regime libre ou force :
// depend de la valeur de alpha regime force (alpha = 0) ou libre (alpha = 1)
//------------------------------------------------------------------------------------
{
	int i = 0, j = 0, n = 0; // indices de passage entre la notation M(i,j) a la notation M(n)
	int fac = 0; // compteur de facette
	int niv = 0; // compteur d'etage
	int id = 0; // indice de reperage du nID de facette

	int p, p_max, p_max_old; // compteurs de positionnement dans la matrice
	int offset_mur = 0, offset_vit = 0, offset_toit = 0, offset_niv = 0,
			offset_n5_RDC = 0; // compteurs de positionnement dans la matrice (debuts de blocs)
	double somme = 0; // variable intremediaire permettant de sommer des variables pour un type de facettes
	double Kc = 0, Kr = 0; // variables intermediaires mises pour choisir entre les resistances au noeud 5 ou 12


	// boucle sur le nb de niveaux, remplissage des coefs en incrementant le nb de lignes
	// on raisonne par bloc ("murs exterieurs", "vitrages", "noeuds internes")
	// les blocs  "sol" et "toiture" sont traites a l'ext de la boucle
	for (niv = 0; niv < nb_niv; niv++) {

		//===============================
		// BLOC MUR (1,1   1,2   ...   1,p   2)
		//===============================

		// interface exterieur (bloc diagonal)
		//--------------------------------------------

		// coefs successifs de la la digonale M( 1,p ; 1,p )
		p_max_old = i;
		offset_niv = p_max_old + 1;
		p = p_max_old;
		for (fac = 0; fac < nb_facette; fac++) {
			for (id = 0; id < nb_paroi; id++) {
				if (((int) niveau[fac] == niv)
						&& ((int) classe_paroi[fac] == 0)
						&& ((int) id_paroi[fac] == id)) {
					i = 1 + p;
					j = 1 + p;
					n = (i - 1) * dim + (j - 1);
					M[n] = surface[fac] * (hc_ext[fac] + (1 / RCmur[id].R)
							+ (RCmur[id].Ce / dt)); // termes de la la digonale M( 1,p ; 1,p )
					somme += surface[fac] * ((1 / RCmur[id].R) + (RCmur[id].Ci
							/ dt)); // terme de sommation du coef diagonal M(2;2)
					p++;
				}
			}
		}

		p_max = p;

		// offset de la colonne 2
		i = 1 + p_max;
		j = 1 + p_max;
		offset_mur = j;
		n = (i - 1) * dim + (j - 1);

		// coef diagonal complet M(2;2)
		M[n] = somme + Sniv[niv].SURFACE_CL[0] * ((1 / Rrad_i[0]) + (1
				/ Rcv_i[0]));
		somme = 0;

		// coefs de la ligne2 M(2;p) et la colonne2 M(p;2)
		p = p_max_old;
		for (fac = 0; fac < nb_facette; fac++) {
			for (id = 0; id < nb_paroi; id++) {
				if (((int) niveau[fac] == niv)
						&& ((int) classe_paroi[fac] == 0)
						&& ((int) id_paroi[fac] == id)) {
					i = 1 + p_max;
					j = 1 + p;
					n = (i - 1) * dim + (j - 1);
					M[n] = -surface[fac] * (1 / RCmur[id].R); // ligne 2
					n = (j - 1) * dim + (i - 1); // on inverse le i et le j
					M[n] = -surface[fac] * (1 / RCmur[id].R); // colonne 2
					p++;
				}
			}
		}

		//===============================
		// BLOC VITRAGE (3,1   3,2   ...   3,p   4)
		//===============================

		// interface exterieur (bloc diagonal)
		//--------------------------------------------

		// coefs successifs de la la digonale M( 3,p ; 3,p )
		p_max_old = p_max + 1;
		p = p_max_old;
		for (fac = 0; fac < nb_facette; fac++) {
			for (id = 0; id < nb_paroi; id++) {
				if (((int) niveau[fac] == niv)
						&& ((int) classe_paroi[fac] == 1)
						&& ((int) id_paroi[fac] == id)) {
					i = 1 + p;
					j = 1 + p;
					n = (i - 1) * dim + (j - 1);
					M[n] = surface[fac] * (hc_ext[fac] + (1 / RCvit[id].R)
							+ (RCvit[id].Ce / dt)); // termes de la la digonale M( 1,p ; 1,p )
					somme += surface[fac] * ((1 / RCvit[id].R) + (RCvit[id].Ci
							/ dt)); // terme de sommation du coef diagonal M(2;2)
					p++;
				}
			}
		}

		p_max = p;

		// offset de la colonne 4
		i = 1 + p_max;
		j = 1 + p_max;
		offset_vit = j;
		n = (i - 1) * dim + (j - 1);

		// coef diagonal complet M(4;4)
		M[n] = somme + Sniv[niv].SURFACE_CL[1] * ((1 / Rrad_i[1]) + (1
				/ Rcv_i[1]));
		somme = 0;

		// coefs de la ligne2 M(4;p) et la colonne2 M(p;4)
		p = p_max_old;
		for (fac = 0; fac < nb_facette; fac++) {
			for (id = 0; id < nb_paroi; id++) {
				if (((int) niveau[fac] == niv)
						&& ((int) classe_paroi[fac] == 1)
						&& ((int) id_paroi[fac] == id)) {
					i = 1 + p_max;
					j = 1 + p;
					n = (i - 1) * dim + (j - 1);
					M[n] = -surface[fac] * (1 / RCvit[id].R); // ligne 2
					n = (j - 1) * dim + (i - 1); // on inverse le i et le j
					M[n] = -surface[fac] * (1 / RCvit[id].R); // colonne 2
					p++;
				}
			}
		}

		//===============================
		// BLOC INTERACTION MUR/VITRAGE <-> NOEUD 9 ET 10
		//===============================

		// interaction avec noeud 9

		i = offset_mur;
		j = offset_vit + 5;
		n = (i - 1) * dim + (j - 1);
		M[n] = -Sniv[niv].SURFACE_CL[0] * (1 / Rrad_i[0]);

		i = offset_vit;
		j = offset_vit + 5;
		n = (i - 1) * dim + (j - 1);
		M[n] = -Sniv[niv].SURFACE_CL[1] * (1 / Rrad_i[1]);

		// interaction avec noeud 10

		i = offset_mur;
		j = offset_vit + 6;
		n = (i - 1) * dim + (j - 1);
		M[n] = -alpha[niv] * Sniv[niv].SURFACE_CL[0] * (1 / Rcv_i[0]);

		i = offset_vit;
		j = offset_vit + 6;
		n = (i - 1) * dim + (j - 1);
		M[n] = -alpha[niv] * Sniv[niv].SURFACE_CL[1] * (1 / Rcv_i[1]);

		//===============================
		// BLOC NOEUDS INTERIEURS (5, 6, 7, 8, 9, 10)
		//===============================

		p_max_old = p_max + 1;
		p = p_max_old;

		// LIGNE 5 : noeud du plafond (ou de sous plancher-bas RDC)
		//----------------------------------------
		i = 1 + p;
		if (niv == 0)
			offset_n5_RDC = i; //localisation du noeud 5 au RDC pour integrer en fin de matrice les coefs du noeud 5' (sous sol)

		// colonne 5 (plafond ou sol)
		j = i;
		n = (i - 1) * dim + (j - 1);
		if (niv == 0)
			M[n] = Sniv[niv].SURFACE_CL[3] * ((1 / Rsol) + (RCplc_bas->Ce / dt)
					+ (1 / RCplc_bas->R)); // cas du RDC
		else
			M[n] = Sniv[niv].SURFACE_CL[3] * ((1 / Rrad_i[4]) + (1 / Rcv_i[4])
					+ (RCplc_int->Ce / dt) + (1 / RCplc_int->R)); // cas d'un autre niveau
		// ATTENTION : les [RC]plf doivent etre pris au niveau N-1
		// si on change les caracteristiques des plancher a chaque etage
		// Ici : meme plancher pour chaque etage

		// colonne 6 (plancher)
		j = i + 1;
		n = (i - 1) * dim + (j - 1);
		if (niv == 0)
			M[n] = -Sniv[niv].SURFACE_CL[3] * (1 / RCplc_bas->R);
		else
			M[n] = -Sniv[niv].SURFACE_CL[3] * (1 / RCplc_int->R);

		if (niv != 0) {
			// colonne 9 (Tmr) DU NIVEAU N-1
			j = offset_niv - 2;
			n = (i - 1) * dim + (j - 1);
			M[n] = -Sniv[niv].SURFACE_CL[3] * (1 / Rrad_i[4]);
			// on revient sur le bloc du niveau precedent
			// colonne 5 NIVEAU N, ligne 9 NIVEAU N-1
			j = i;
			i = offset_niv - 2; // inversion du i et du j
			n = (i - 1) * dim + (j - 1);
			M[n] = -Sniv[niv].SURFACE_CL[3] * (1 / Rrad_i[4]);
			// SURFACE_CL[3] PARCE que Splc(N+1) = Splf(N)
			// ATTENTION : ici, meme qualite de plancher et meme Rrad pour chaque etage

			i = 1 + p;

			// colonne 10 (Tair) DU NIVEAU N-1
			j = offset_niv - 1;
			n = (i - 1) * dim + (j - 1);
			M[n] = -alpha[niv] * Sniv[niv].SURFACE_CL[3] * (1 / Rcv_i[4]);
			// on revient sur le bloc du niveau precedent
			// colonne 5 NIVEAU N, ligne 10 NIVEAU N-1
			j = i;
			i = offset_niv - 1; // inversion du i et du j
			n = (i - 1) * dim + (j - 1);
			M[n] = -Sniv[niv].SURFACE_CL[3] * (1 / Rcv_i[4]);
			// SURFACE_CL[3] : Splc(N+1) = Splf(N)
			// Attention : ici, meme qualite de plancher pour chaque etage et meme Rrad
		}
		i = 1 + p;

		// pour l'interaction avec le noeud 5' -> voir la derniere partie de la fonction


		// LIGNE 6 : noeud du plancher
		//----------------------------------------
		i++;

		// colonne 5 (plafond ou sol)
		j = i - 1;
		n = (i - 1) * dim + (j - 1);
		if (niv == 0)
			M[n] = -Sniv[niv].SURFACE_CL[3] * (1 / RCplc_bas->R);
		else
			M[n] = -Sniv[niv].SURFACE_CL[3] * (1 / RCplc_int->R);

		// colonne 6 (plancher)
		j = i;
		n = (i - 1) * dim + (j - 1);
		if (niv == 0)
			M[n] = Sniv[niv].SURFACE_CL[3] * ((1 / Rrad_i[3]) + (1 / Rcv_i[3])
					+ (RCplc_bas->Ci / dt) + (1 / RCplc_bas->R));
		else
			M[n] = Sniv[niv].SURFACE_CL[3] * ((1 / Rrad_i[3]) + (1 / Rcv_i[3])
					+ (RCplc_int->Ci / dt) + (1 / RCplc_int->R));

		// colonne 9 (Tmr)
		j = i + 3;
		n = (i - 1) * dim + (j - 1);
		M[n] = -Sniv[niv].SURFACE_CL[3] * (1 / Rrad_i[3]);

		// colonne 10 (Tair)
		j = i + 4;
		n = (i - 1) * dim + (j - 1);
		M[n] = -alpha[niv] * Sniv[niv].SURFACE_CL[3] * (1 / Rcv_i[3]);

		// LIGNE 7 : noeud interne des parois interieures
		//----------------------------------------
		i++;

		// colonne 7 (interieur des parois int)
		j = i;
		n = (i - 1) * dim + (j - 1);
		M[n] = Sniv[niv].SURFACE_CL[5] * ((RCint->Ci / dt) + (1 / RCint->R));

		// colonne 8 (surface des parois int)
		j = i + 1;
		n = (i - 1) * dim + (j - 1);
		M[n] = -Sniv[niv].SURFACE_CL[5] * (1 / RCint->R);

		// LIGNE  8 : noeud de surface des parois interieures
		//----------------------------------------
		i++;

		// colonne 7 (interieur des parois int)
		j = i - 1;
		n = (i - 1) * dim + (j - 1);
		M[n] = -Sniv[niv].SURFACE_CL[5] * (1 / RCint->R);

		// colonne 8 (surface des parois int)
		j = i;
		n = (i - 1) * dim + (j - 1);
		M[n] = Sniv[niv].SURFACE_CL[5] * ((1 / Rrad_i[5]) + (1 / Rcv_i[5]) + (1
				/ RCint->R));

		// colonne 9 (Tmr)
		j = i + 1;
		n = (i - 1) * dim + (j - 1);
		M[n] = -Sniv[niv].SURFACE_CL[5] * (1 / Rrad_i[5]);

		// colonne 10 (Tair)
		j = i + 2;
		n = (i - 1) * dim + (j - 1);
		M[n] = -alpha[niv] * Sniv[niv].SURFACE_CL[5] * (1 / Rcv_i[5]);

		// LIGNE 9 : noeud Tmr
		//------------------------------------
		i++;

		// colonne 2 (surface int des murs)
		j = offset_mur;
		n = (i - 1) * dim + (j - 1);
		M[n] = -Sniv[niv].SURFACE_CL[0] * (1 / Rrad_i[0]);

		// colonne 4 (surface int des vitrages)
		j = offset_vit;
		n = (i - 1) * dim + (j - 1);
		M[n] = -Sniv[niv].SURFACE_CL[1] * (1 / Rrad_i[1]);

		// colonne 6 (plancher)
		j = i - 3;
		n = (i - 1) * dim + (j - 1);
		M[n] = -Sniv[niv].SURFACE_CL[3] * (1 / Rrad_i[3]);

		// colonne 8 (paroi int)
		j = i - 1;
		n = (i - 1) * dim + (j - 1);
		M[n] = -Sniv[niv].SURFACE_CL[5] * (1 / Rrad_i[5]);

		// colonne 9 (Tmr)
		j = i;
		n = (i - 1) * dim + (j - 1);

		if (niv == nb_niv - 1)
			Kr = Sniv[niv].SURFACE_CL[2] / Rrad_i[2];
		else
			Kr = Sniv[niv].SURFACE_CL[4] / Rrad_i[4];

		M[n] = (Sniv[niv].SURFACE_CL[0] / Rrad_i[0]) + (Sniv[niv].SURFACE_CL[1]
				/ Rrad_i[1]) + Kr + (Sniv[niv].SURFACE_CL[3] / Rrad_i[3])
				+ (Sniv[niv].SURFACE_CL[5] / Rrad_i[5]);

		Kr = 0;

		// LIGNE 10 : noeud Tair int ou Pconv
		//------------------------------------
		i++;

		// colonne 2 (surface int des murs)
		j = offset_mur;
		n = (i - 1) * dim + (j - 1);
		M[n] = -Sniv[niv].SURFACE_CL[0] * (1 / Rcv_i[0]);

		// colonne 4 (surface int des vitrages)
		j = offset_vit;
		n = (i - 1) * dim + (j - 1);
		M[n] = -Sniv[niv].SURFACE_CL[1] * (1 / Rcv_i[1]);

		// colonne 6 (plancher)
		j = i - 4;
		n = (i - 1) * dim + (j - 1);
		M[n] = -Sniv[niv].SURFACE_CL[3] * (1 / Rcv_i[3]);

		// colonne 8 (parois int)
		j = i - 2;
		n = (i - 1) * dim + (j - 1);
		M[n] = -Sniv[niv].SURFACE_CL[5] * (1 / Rcv_i[5]);

		// colonne 10 (Tair)
		j = i;
		n = (i - 1) * dim + (j - 1);

		for (fac = 0; fac < nb_facette; fac++) {
			if (((int) niveau[fac] == niv) && ((int) in_air[fac] == 1)) {
				if (Rra[fac] > 0)
					somme = somme + (1 / Rra[fac]);
				else
					somme = 0;
				//{ printf("\n\n  ERREUR : Probleme au niveau du debit d'air (facette[%d] ; niveau[%d])\n\n",fac,niv) ; exit(0) ; }
			}
		}
		//if (somme == 0)	{ printf("\n\n  ERREUR : Pas d'entrees d'air au niveau %d - Verifier descripteur\n\n",niv) ; exit(0) ; }

		if (niv == nb_niv - 1)
			Kc = Sniv[niv].SURFACE_CL[2] / Rcv_i[2];
		else
			Kc = Sniv[niv].SURFACE_CL[4] / Rcv_i[4];

		M[n] = alpha[niv] * ((Sniv[niv].SURFACE_CL[0] / Rcv_i[0])
				+ (Sniv[niv].SURFACE_CL[1] / Rcv_i[1])
				+ (Sniv[niv].SURFACE_CL[3] / Rcv_i[3]) + Kc
				+ (Sniv[niv].SURFACE_CL[5] / Rcv_i[5]) + somme
				+ (Cai[niv] / dt)) - (1 - alpha[niv]);

		somme = 0;
		Kc = 0;

	} // fin de la boucle sur le nb de niveaux


	//===============================
	// BLOC TOITURE (11,1   11,2   ...   11,p   12)
	//===============================

	// interface exterieur (noeud 11) (bloc diagonal)
	//--------------------------------------------

	// coefs successifs de la la digonale M( 11,p ; 11,p )

	p_max_old = i;
	p = p_max_old;
	for (fac = 0; fac < nb_facette; fac++) {
		for (id = 0; id < nb_paroi; id++) {
			if (((int) classe_paroi[fac] == 2) && ((int) id_paroi[fac] == id)) {
				i = 1 + p;
				j = 1 + p;
				n = (i - 1) * dim + (j - 1);
				M[n] = surface[fac] * (hc_ext[fac] + (1 / RCtoit[id].R) + (1
						* RCtoit[id].Ce / dt)); // termes de la la digonale M( 1,p ; 1,p )
				somme += surface[fac] * ((1 / RCtoit[id].R) + (RCtoit[id].Ci
						/ dt)); // terme de sommation du coef diagonal M(2;2)
				p++;
			}
		}
	}

	p_max = p;

	// offset de la colonne 4
	i = 1 + p_max;
	j = 1 + p_max;
	offset_toit = j;
	n = (i - 1) * dim + (j - 1);

	// coef diagonal complet M(4;4)
	M[n] = somme + Sniv[nb_niv - 1].SURFACE_CL[2] * ((1 / Rrad_i[2]) + (1
			/ Rcv_i[2]));
	somme = 0;

	// coefs de la ligne2 M(4;p) et la colonne2 M(p;4)
	p = p_max_old;
	for (fac = 0; fac < nb_facette; fac++) {
		for (id = 0; id < nb_paroi; id++) {
			if (((int) classe_paroi[fac] == 2) && ((int) id_paroi[fac] == id)) {
				i = 1 + p_max;
				j = 1 + p;
				n = (i - 1) * dim + (j - 1);
				M[n] = -surface[fac] * (1 / RCtoit[id].R); // ligne 2
				n = (j - 1) * dim + (i - 1); // on inverse le i et le j
				M[n] = -surface[fac] * (1 / RCtoit[id].R); // colonne 2
				p++;
			}
		}
	}

	// interface interieur (interaction noeud 9 et 10)
	//--------------------------------------------

	// ligne 12

	// colonne 9 (Tmr)
	j = p_max_old - 1;
	n = (i - 1) * dim + (j - 1);
	M[n] = -Sniv[nb_niv - 1].SURFACE_CL[2] * (1 / Rrad_i[2]);
	// colonne 10 (Tair)
	j = p_max_old;
	n = (i - 1) * dim + (j - 1);
	//M[n] = -alpha[niv] * Sniv[nb_niv-1].SURFACE_CL[2] * (1 / Rcv_i[2]);
	M[n] = -alpha[nb_niv - 1] * Sniv[nb_niv - 1].SURFACE_CL[2] * (1 / Rcv_i[2]);

	// retour a la ligne 9, colonne 12
	i = p_max_old - 1;
	j = offset_toit;
	n = (i - 1) * dim + (j - 1);
	M[n] = -Sniv[nb_niv - 1].SURFACE_CL[2] * (1 / Rrad_i[2]);

	// retour a la ligne 10, colonne 12
	i = p_max_old;
	j = offset_toit;
	n = (i - 1) * dim + (j - 1);
	M[n] = -Sniv[nb_niv - 1].SURFACE_CL[2] * (1 / Rcv_i[2]);

	//===============================
	// neud 5' de la couche de sol (juste pour le niveau RDC)
	//===============================

	i = offset_toit + 1;

	// colonne 5 (T sous dalle)
	j = offset_n5_RDC;
	n = (i - 1) * dim + (j - 1);
	M[n] = -Sniv[0].SURFACE_CL[3] * (1 / Rsol);
	// derniere colonne (5' ->T'sol)
	j = i;
	n = (i - 1) * dim + (j - 1);
	M[n] = Sniv[0].SURFACE_CL[3] * ((2 / Rsol) + (Csol / dt));
	// retour a la ligne 5, derniere colonne (5')
	i = offset_n5_RDC;
	n = (i - 1) * dim + (j - 1);
	M[n] = -Sniv[0].SURFACE_CL[3] * (1 / Rsol);

}

void remplissage_vecteur_modele_batiment(double *V, int dim, int nb_facette,
		int nb_niv, double *niveau, double nb_paroi, double *id_paroi,
		double *classe_paroi, double *surface, Sniveau *Sniv, double *in_air,
		double dt, int *alpha, double *hc_ext, double *Text, double *TSext,
		double *T2, double *T4, double *T5, double *T6, double *T7, double *T8,
		double *T9, double T10consigne, double *T10air_init, double *T12,
		listeRCparoi *RCmur, listeRCparoi *RCvit, listeRCparoi *RCtoit,
		listeRCparoi *RCplc_int, listeRCparoi *RCplc_bas, listeRCparoi *RCint,
		double *Rcv_i, double *Rrad_i, double *Rra, double *Cai, double Rsol,
		double Csol, double Tsol, double *Tsol_bis, double *flux_sol_abs,
		double *GLO_Total_Net, double *Ft_mur, double *Ft_vit, double *Ft_plc,
		double *Ft_plf, double *Ft_int, double *Ps_equip, double *Ps_occup)
//------------------------------------------------------------------------------------
// remplit le vecteur [b] de resolution du systeme lineaire en fonction
// des variables physiques du modele de batiment
// 2 valeurs de vecteur : [b] en regime libre ou force :
// depend de la valeur de alpha regime force (alpha = 0) ou libre (alpha = 1)
//------------------------------------------------------------------------------------
{
	int i = 0; // indice de ligne du vecteur
	int niv = 0; // compteur de niveau
	int fac = 0; // compteur de facette
	int id = 0; // indice de reperage du nID de facette
	double somme = 0, somme2 = 0; // variables intermediaire permettant de sommer des variables pour un type de facettes
	double Kc = 0; // variable intermediaire mise pour choisir entre la resistance conv au noeud 5 ou 12


	// boucle sur le nb de niveaux, remplissage des lignes correspondant au noeuds de calcul
	// les noeuds  "sol" et "toiture" sont traites a l'ext de la boucle
	for (niv = 0; niv < nb_niv; niv++) {

		// LIGNES 1,p (facettes de mur)
		//--------------------------------------------
		for (fac = 0; fac < nb_facette; fac++)
			for (id = 0; id < nb_paroi; id++)
				if (((int) niveau[fac] == niv)
						&& ((int) classe_paroi[fac] == 0)
						&& ((int) id_paroi[fac] == id)) {
					V[i] = surface[fac] * (hc_ext[fac] * Text[fac]
							+ (RCmur[id].Ce / dt) * TSext[fac]
							+ flux_sol_abs[fac] - GLO_Total_Net[fac]);
					somme += surface[fac] * (RCmur[id].Ci / dt);
					i++;
				}

		// LIGNE 2 (noeud surf interne murs)
		//--------------------------------------------
		V[i] = somme * T2[niv] + Ft_mur[niv] + (1 - alpha[niv])
				* Sniv[niv].SURFACE_CL[0] * (1 / Rcv_i[0]) * T10consigne;
		i++;

		somme = 0;

		// LIGNE 3,p (facettes de vitrage)
		//--------------------------------------------
		for (fac = 0; fac < nb_facette; fac++)
			for (id = 0; id < nb_paroi; id++)
				if (((int) niveau[fac] == niv)
						&& ((int) classe_paroi[fac] == 1)
						&& ((int) id_paroi[fac] == id)) {
					V[i] = surface[fac] * (hc_ext[fac] * Text[fac]
							+ (RCvit[id].Ce / dt) * TSext[fac]
							+ flux_sol_abs[fac] - GLO_Total_Net[fac]);
					somme += surface[fac] * (RCvit[id].Ci / dt);
					i++;
				}

		// LIGNE 4 (noeud surf interne des vitrages)
		//--------------------------------------------
		V[i] = somme * T4[niv] + Ft_vit[niv] + (1 - alpha[niv])
				* Sniv[niv].SURFACE_CL[1] * (1 / Rcv_i[1]) * T10consigne;
		i++;
		somme = 0;

		// LIGNE 5 (noeud plafond (ou sous dalle plc pour RDC))
		//--------------------------------------------
		if (niv == 0)
			V[i] = Sniv[niv].SURFACE_CL[3] * (RCplc_bas->Ce / dt) * T5[niv]; // cas du RDC
		else
			V[i] = Sniv[niv].SURFACE_CL[3] * (RCplc_int->Ce / dt) * T5[niv]
					+ Ft_plf[niv - 1] + (1 - alpha[niv])
					* Sniv[niv].SURFACE_CL[3] * (1 / Rcv_i[4]) * T10consigne; // cas d'un autre niveau
		// ATTENTION : (Cplf->Ci)  et  (Ft_plf) pour le niveau N-1
		// ATTENTION : T10consigne pour le niveau N-1, si les consignes de chauff/clim sont differentes a chaque etage, ici T10consigne idem a chaque etage
		i++;

		// LIGNE 6 (noeud plancher)
		//--------------------------------------------
		if (niv == 0)
			V[i] = Sniv[niv].SURFACE_CL[3] * (RCplc_bas->Ci / dt) * T6[niv]
					+ Ft_plc[niv] + (1 - alpha[niv]) * Sniv[niv].SURFACE_CL[3]
					* (1 / Rcv_i[3]) * T10consigne;
		else
			V[i] = Sniv[niv].SURFACE_CL[3] * (RCplc_int->Ci / dt) * T6[niv]
					+ Ft_plc[niv] + (1 - alpha[niv]) * Sniv[niv].SURFACE_CL[3]
					* (1 / Rcv_i[3]) * T10consigne;
		i++;

		// LIGNE 7 (noeud int parois int)
		//--------------------------------------------
		V[i] = Sniv[niv].SURFACE_CL[5] * (RCint->Ci / dt) * T7[niv];
		i++;

		// LIGNE 8 (noeud ext parois int)
		//--------------------------------------------
		V[i] = Ft_int[niv] + (1 - alpha[niv]) * Sniv[niv].SURFACE_CL[5] * (1
				/ Rcv_i[5]) * T10consigne;
		i++;

		// LIGNE 9 (noeud Tmr)
		//--------------------------------------------
		//V[i] = 0 ; // toutes les puissances internes sur le noeud d'air
		V[i] = (0.5 * Ps_equip[niv]) + (0.5 * Ps_occup[niv]); // puissances internes reparties sur les noeuds Tmr et Tair
		i++;

		// LIGNE 10 : noeud Tair int ou Pconv
		//--------------------------------------------

		for (fac = 0; fac < nb_facette; fac++) {
			if (((int) niveau[fac] == niv) && ((int) in_air[fac] == 1)) {
				if (Rra[fac] > 0) {
					somme = somme + (1 / Rra[fac]);
					somme2 = somme2 + (Text[fac] / Rra[fac]);
				} else
					// pas de vetilation car pas d'occupants
					somme = 0;
				somme2 = 0;
				//{ printf("\n\n  ERREUR : Probleme au niveau du debit d'air (facette[%d] ; niveau[%d])\n\n",fac,niv) ; exit(0) ; }
			}
		}
		//if (somme == 0 || somme2 == 0)	{ printf("\n\n  ERREUR : Pas d'entrees d'air au niveau %d - Verifier descripteur\n\n",niv) ; exit(0) ; }

		if (niv == nb_niv - 1)
			Kc = Sniv[niv].SURFACE_CL[2] / Rcv_i[2];
		else
			Kc = Sniv[niv].SURFACE_CL[4] / Rcv_i[4];

		//V[i] = somme2 +  Ps_equip[niv] + Ps_occup[niv] + ((Cai[niv] / dt) * T10air_init[niv]) - (1 - alpha[niv])*T10consigne*((Sniv[niv].SURFACE_CL[0] / Rcv_i[0] ) + (Sniv[niv].SURFACE_CL[1] / Rcv_i[1] ) + (Sniv[niv].SURFACE_CL[3] / Rcv_i[3] ) + Kc + (Sniv[niv].SURFACE_CL[5] / Rcv_i[5] ) + (Cai[niv] / dt) + somme ) ; // toutes les puissances internes sur le noeud d'air
		V[i] = somme2 + (0.5 * Ps_equip[niv]) + (0.5 * Ps_occup[niv])
				+ ((Cai[niv] / dt) * T10air_init[niv]) - (1 - alpha[niv])
				* T10consigne * ((Sniv[niv].SURFACE_CL[0] / Rcv_i[0])
				+ (Sniv[niv].SURFACE_CL[1] / Rcv_i[1])
				+ (Sniv[niv].SURFACE_CL[3] / Rcv_i[3]) + Kc
				+ (Sniv[niv].SURFACE_CL[5] / Rcv_i[5]) + (Cai[niv] / dt)
				+ somme); // puissances internes reparties sur les noeuds Tmr et Tair
		i++;
		somme = 0;
		somme2 = 0;
		Kc = 0;

	} // fin de boucle sur les niveaux


	// LIGNES 11,p (facettes de toiture)
	//--------------------------------------------
	for (fac = 0; fac < nb_facette; fac++)
		for (id = 0; id < nb_paroi; id++)
			if (((int) classe_paroi[fac] == 2) && ((int) id_paroi[fac] == id)) {
				V[i] = surface[fac] * (hc_ext[fac] * Text[fac] + (RCtoit[id].Ce
						/ dt) * TSext[fac] + flux_sol_abs[fac]
						- GLO_Total_Net[fac]);
				somme += surface[fac] * (RCtoit[id].Ci / dt);
				i++;
			}

	// LIGNE 12 (noeud surf interne toiture)
	//--------------------------------------------
	//V[i] = somme*T12[nb_niv-1] + Ft_plf[nb_niv-1] + (1 - alpha[niv])*Sniv[nb_niv-1].SURFACE_CL[2]*( 1 / Rcv_i[2] )*T10consigne ;
	V[i] = somme * T12[nb_niv - 1] + Ft_plf[nb_niv - 1] + (1
			- alpha[nb_niv - 1]) * Sniv[nb_niv - 1].SURFACE_CL[2] * (1
			/ Rcv_i[2]) * T10consigne;
	i++;
	somme = 0;

	// LIGNE 5' (noeud Sol)
	//--------------------------------------------
	V[i] = Sniv[0].SURFACE_CL[3] * ((Tsol / Rsol) + (Csol * Tsol_bis[0] / dt));
}

void remplissage_matrice_modele_facetteBAT(double *M, int id,
		listeRCparoi *RCfacetteBAT, double hc_int, double hc_ext, double dt)
//------------------------------------------------------------------------------------
// remplit la matrice [A] de resolution du systeme lineaire en fonction
// des variables physiques du modele de facette d'enveloppe
// des batiments urbains
//------------------------------------------------------------------------------------
{
	M[0] = hc_ext + (1 / RCfacetteBAT[id].R) + (RCfacetteBAT[id].Ce / dt);
	M[1] = -(1 / RCfacetteBAT[id].R);
	M[2] = -(1 / RCfacetteBAT[id].R);
	M[3] = hc_int + (1 / RCfacetteBAT[id].R) + (RCfacetteBAT[id].Ci / dt);
}

void remplissage_vecteur_modele_facetteBAT(double *V, int id,
		listeRCparoi *RCfacetteBAT, double hc_int, double hc_ext, double dt,
		double Fsol, double Fglo, double Text, double TSext_old,
		double TSint_old, double Tint)
//------------------------------------------------------------------------------------
// remplit le vecteur [b] de resolution du systeme lineaire en fonction
// des variables physiques du modele de facette d'enveloppe
// des batiments urbains
//------------------------------------------------------------------------------------
{
	V[0] = Fsol - Fglo + (hc_ext * Text) + (TSext_old * RCfacetteBAT[id].Ce
			/ dt);
	V[1] = (hc_int * Tint) + (TSint_old * RCfacetteBAT[id].Ci / dt);
}

double calcul_Tref_profondeur(double z_ref, double j, double j_ref,
		double moy_Tair, double max_Tair, double min_Tair, double lambda_sol,
		double Cp_sol, double rho_sol)
//------------------------------------------------------------------------------------
// calcule une temperature souterraine de reference a une cote z donnee
// la temperature est consante pour un jour de ref et obeit a la loi de Kusuda et al.
// voir these J.Bouyer
//------------------------------------------------------------------------------------
{
	double alpha_sol;
	double T_ref;
	double A, B, C, D, frac1, frac2, frac3;

	alpha_sol = (lambda_sol / (rho_sol * Cp_sol)) * 24 * 3600; // diffusivite thermique en m2/jour

	A = moy_Tair;
	B = (max_Tair - min_Tair) / 2;
	frac1 = PI / (365 * alpha_sol);
	C = -z_ref * sqrt(frac1);
	frac2 = 2 * PI / 365;
	frac3 = 365 / (PI * alpha_sol);
	D = frac2 * (j - j_ref - (0.5 * z_ref * sqrt(frac3)));
	T_ref = A - (B * (exp(C)) * (cos(D)));

	return T_ref;
}

void calcul_proprietes_sol(double epaisseur, double rho, double Cp,
		double lambda, double *Rsol, double *Csol)
//------------------------------------------------------------------------------------
// calcul de la resistance , capacite , et temperature limite pour la couche de sol
//------------------------------------------------------------------------------------
{
	*Rsol = 0.5 * epaisseur / lambda; // la moitie de la resitance totale
	*Csol = rho * Cp * epaisseur;
}

void remplissage_matrice_modele_sol(double *M, int id, double hc_ext,
		listeRCparoi *RCsurf_sol, double Rsol, double Csol, double dt)
//------------------------------------------------------------------------------------
// remplit la matrice [A] de resolution du systeme lineaire en fonction
// des variables physiques du modele de facette de sol
// modele classique
//------------------------------------------------------------------------------------
{
	M[0] = hc_ext + (1 / (RCsurf_sol[id].R)) + ((RCsurf_sol[id].Ce) / dt);
	M[1] = -(1 / (RCsurf_sol[id].R));
	M[2] = 0;
	M[3] = -(1 / (RCsurf_sol[id].R));
	M[4] = (1 / (RCsurf_sol[id].R)) + (1 / Rsol) + ((RCsurf_sol[id].Ci) / dt);
	M[5] = -(1 / Rsol);
	M[6] = 0;
	M[7] = -(1 / Rsol);
	M[8] = (2 / Rsol) + (Csol / dt);
}

void remplissage_vecteur_modele_sol(double *V, int id, double TSext_old,
		double T2_old, double T3_old, double Text, double Tref, double FluxSol,
		double FluxGLONet, double Flatent, double hc_ext,
		listeRCparoi *RCsurf_sol, double Rsol, double Csol, double dt)
//------------------------------------------------------------------------------------
// remplit le vecteur [b] de resolution du systeme lineaire en fonction
// des variables physiques du modele de facette d'enveloppe
// des batiments urbains
//------------------------------------------------------------------------------------
{
	V[0] = Text * hc_ext + TSext_old * ((RCsurf_sol[id].Ce) / dt) + FluxSol
			- FluxGLONet - Flatent;
	V[1] = T2_old * ((RCsurf_sol[id].Ci) / dt);
	V[2] = Tref * (1 / Rsol) + T3_old * (Csol / dt);
}

double calcul_flux_latent(double FluxSol, double FluxGLONet, double Tair,
		double HS, double hc, double f)
//------------------------------------------------------------------------------------
// calcule du flux latent selon la methode de Penman-Monteith
//------------------------------------------------------------------------------------
{
	double Rnet; // rayonnement total (sol+IR) net echange
	double Ea; // pouvoir evaporant de l'air
	double e, e_sat; // tension de vapeur et tension de vapeur saturante de l'air
	double rho_air; // masse volumique de l'air
	double p_air, M_air, M_eau, cp_air, R_gaz, epsilon, Lv; // variables physiques air, eau
	double T_radian; // temperature celsius -> radians
	double HR; // humidite relative, specifique
	double v; // vitesse de l'air
	double fv; // fonction vitesse de l'air
	double h_veg; // hauteur de la v�g�tation (gazon)
	double r_aero, r_sto; // resistance stomatique et aerodynamique
	double delta; // pente de la courbe de saturation
	double gamma; // constante psychrometrique
	double resu;

	R_gaz = 8.314; // cte gaz parfaits
	p_air = 101325; // pression atmospherique
	M_air = 0.029; // masse molaire air
	M_eau = 0.018; // masse molaire eau
	epsilon = M_eau / M_air; // rapport des masses molaires
	cp_air = 1013; // capacite thermique de l'air a pression constante
	Lv = 2501000 - 2361 * Tair; // chaleur latente de vaporisation
	gamma = (cp_air * p_air) / (epsilon * Lv); // constante psychrometrique
	h_veg = 0.05; // 5 cm de gazon

	Rnet = FluxSol - FluxGLONet;

	v = ((hc - 5.85) / 1.7); // inversion de la relation de Jayamaha utilisee dans l'UDF de Fluent pour le flux convectif
	//r_aero = (208 / v) ;							// formulation these Oudin et FAO (pour Penman-Monteith) (h_ref gazon 12cm)
	//r_sto = 70 ;									// formulation these Oudin et FAO (pour Penman-Monteith) (h_ref gazon 12cm)
	r_aero = (log((2 - ((2 / 3) * h_veg)) / (0.123 * h_veg)) * log((2
			- ((2 / 3) * h_veg)) / (0.1 * 0.123 * h_veg)) / (0.41 * 0.41 * v)); // formulation FAO (pour Penman-Monteith)
	r_sto = (100 / (0.5 * 24 * h_veg)); // formulation FAO (pour Penman-Monteith)
	rho_air = ((M_air * p_air) / (R_gaz * (Tair + 273.15))); // cf. relation gaz parfaits
	//fv = 0.35*(0.5 + v) ;							// formulation de base Monteith
	fv = ((rho_air * cp_air) / (r_aero * gamma)); // formulation Penman-Monteith
	T_radian = Tair * PI / 180.0; // convertit en radians pour fonctions trigo
	e_sat = 610.7 * pow((1 + sqrt(2) * sin(T_radian / 3)), 8.827); // formule de Alt, cf. Guyot p.106
	HR = ((HS * p_air) / (e_sat * (0.622 + 0.378 * HS))); // inversion de la formule humid spe
	e = (HR * e_sat); // tension de vapeur
	Ea = fv * (e_sat - e);

	delta = (8.827 * 610.7 * sqrt(2) * ((1.0 / 3.0) * (PI / 180.0))) * cos(
			T_radian / 3) * pow((1 + sqrt(2) * sin(T_radian / 3)), 7.827); // derivation de la formule de Alt

	resu = f * (((Rnet * delta) + (gamma * Ea)) / (delta + (gamma * (1 + (r_sto
			/ r_aero)))));
	if (resu < 0.0) {
		resu = 0.0;
	}

	return resu;
}

void resolutionSystemeLineaire_LINUX(double *A, double *b, double *x, int n)
// COMPILATION : ACTIVER POUR LINUX - DESACTIVER POUR WINDOWS
//------------------------------------------------------------------------------------
// Utilisation des routines de la librairie LAPACK
// "clapack_dgesv" resoue un systeme lineaire [ mat(A) . vect(x) = vect(b) ] a (n) equations
// "dgesv" est basee sur BLAS de niveau 2 (operations matrices*vecteurs)
//		-> "man dgesv" pour plus de details
// vect(x) = vect(b) a la fin de l'operation
// cconservation des valeurs originales de mat(A) et vect(b)
//------------------------------------------------------------------------------------
{
	int nn = n * n;
	double *A_calcul = allocation_tableau_double(nn);
	double *b_calcul = allocation_tableau_double(n);
	int *pivots = allocation_tableau_int(n);

	memcpy(A_calcul, A, nn * sizeof(double));
	memcpy(b_calcul, b, n * sizeof(double));

	clapack_dgesv(CblasRowMajor, n, 1, A_calcul, n, pivots, b_calcul, n);

	memcpy(x, b_calcul, n * sizeof(double));

	free(A_calcul);
	free(b_calcul);
	free(pivots);
}

/*
 void resolutionSystemeLineaire_WINDOWS(double *A, double *B, double *X, int dim)
 // COMPILATION : ACTIVER POUR WINDOWS - DESACTIVER POUR LINUX
 //------------------------------------------------------------------------------------
 // Utilisation des routines de la librairie CLAPACK
 // "dgesv_" resoue un systeme lineaire [ mat(A) . vect(X) = vect(B) ] a (n) equations
 // "dgesv" est basee sur BLAS de niveau 2 (operations matrices*vecteurs)
 //------------------------------------------------------------------------------------
 {
 int n ;			// nb d'equations lineaires
 int nrhs ;		// nb de colonnes des matrices (vecteurs) B et X
 int lda ;		// dimension pricipale de la matrice A
 int ldb ;		// dimension pricipale de la matrice B
 int *ipiv ;		// vecteur des indices de pivots definissant la matrice de permutation
 int info ;		// variable d'info sur les calcul intermediaires, info doit etre =0

 int i, j, N, N_t, nn ;
 double *A_calcul, *B_calcul ;

 // initialisation des variables

 n = lda = ldb = dim ;
 nrhs = 1 ;
 nn = dim*dim ;
 A_calcul = allocation_tableau(nn) ;
 B_calcul = allocation_tableau(n) ;
 ipiv = allocation_tableau_int(n) ;

 // remplissage du vecteur de calcul
 memcpy(B_calcul, B, n * sizeof(double)) ;

 // transposition de la matrice de calcul au format FORTRAN : A(l,c) -> A(c,l)

 for (i = 0; i < dim; i++)
 for (j = 0; j < dim; j++)
 {
 N = i*dim + j ;
 N_t = j*dim + i ;
 A_calcul[N_t] = A[N] ;
 }

 // resolution syteme

 dgesv_(&n, &nrhs, A_calcul, &lda, ipiv, B_calcul, &ldb, &info) ;

 // remplissage du vecteur de destination

 memcpy(X, B_calcul, n * sizeof(double)) ;

 // desallocation memoire

 free(A_calcul) ;
 free(B_calcul) ;
 free(ipiv) ;
 }
 */

void vecteurT_vers_variablesT(double *V, int dim, int nb_facette, int nb_niv,
		double *niveau, double nb_paroi, double *id_paroi,
		double *classe_paroi, double *TSext, double *T2, double *T4,
		double *T5, double *T6, double *T7, double *T8, double *T9,
		double *inconnue_noeud_air_int, double *T12, double *Tsol_bis)
//------------------------------------------------------------------------------------
// permet de re-remplir les tableaux de temperatures de surfaces ext
// et les tableaux de temperatures de niveaux en fonction du vecteur
// resultat du calcul matriciel
//------------------------------------------------------------------------------------
{
	int i = 0; // indice de ligne du vecteur
	int niv = 0; // compteur de niveau
	int fac = 0; // compteur de facette
	int id = 0; // indice de reperage du n ID de facette


	for (niv = 0; niv < nb_niv; niv++) {

		// LIGNES 1,p (facettes de mur)
		//--------------------------------------------
		for (fac = 0; fac < nb_facette; fac++)
			for (id = 0; id < nb_paroi; id++)
				if (((int) niveau[fac] == niv)
						&& ((int) classe_paroi[fac] == 0)
						&& ((int) id_paroi[fac] == id)) {
					TSext[fac] = V[i];
					i++;
				}

		// LIGNE 2 (noeud surf interne murs)
		//--------------------------------------------
		T2[niv] = V[i];
		i++;

		// LIGNE 3,p (facettes de vitrage)
		//--------------------------------------------
		for (fac = 0; fac < nb_facette; fac++)
			for (id = 0; id < nb_paroi; id++)
				if (((int) niveau[fac] == niv)
						&& ((int) classe_paroi[fac] == 1)
						&& ((int) id_paroi[fac] == id)) {
					TSext[fac] = V[i];
					i++;
				}

		// LIGNE 4 (noeud surf interne des vitrages)
		//--------------------------------------------
		T4[niv] = V[i];
		i++;

		// LIGNE 5 (noeud plafond (ou sous dalle plc pour RDC))
		//--------------------------------------------
		T5[niv] = V[i];
		i++;

		// LIGNE 6 (noeud plancher)
		//--------------------------------------------
		T6[niv] = V[i];
		i++;

		// LIGNE 7 (noeud int parois int)
		//--------------------------------------------
		T7[niv] = V[i];
		i++;

		// LIGNE 8 (noeud ext parois int)
		//--------------------------------------------
		T8[niv] = V[i];
		i++;

		// LIGNE 9 (noeud Tmr)
		//--------------------------------------------
		T9[niv] = V[i];
		i++;

		// LIGNE 10 : noeud Tair int ou Pconv
		//--------------------------------------------
		inconnue_noeud_air_int[niv] = V[i];
		i++;

	} // fin de boucle sur les niveaux


	// LIGNES 11,p (facettes de toiture)
	//--------------------------------------------
	for (fac = 0; fac < nb_facette; fac++)
		for (id = 0; id < nb_paroi; id++)
			if (((int) classe_paroi[fac] == 2) && ((int) id_paroi[fac] == id)) {
				TSext[fac] = V[i];
				i++;
			}

	// LIGNE 12 (noeud surf interne toiture)
	//--------------------------------------------
	T12[nb_niv - 1] = V[i];
	i++;

	// LIGNE 5' (noeud Sol)
	//--------------------------------------------
	Tsol_bis[0] = V[i];

}

double Teq_soleil(paroi *tab_paroi, int no_paroi, double hc_ext, double Text,
		double TSinit, double flux_sol_abs)
//------------------------------------------------------------------------------------
// calcul des temperatures equivalentes au soleil pour l'initialisation
// des temperatures de surfaces
// extraite de 'transitoire_h_option2.c', modifiee par J.Bouyer, decembre 2006
//------------------------------------------------------------------------------------
{
	double epaisseur, lambda;
	double Dx; // pas d'espace
	double K; // conductance
	double temp_eq; // variable retournee

	// caracteristiques de la premiere couche
	epaisseur = tab_paroi[no_paroi].e[0];
	lambda = tab_paroi[no_paroi].l[0];

	Dx = epaisseur / 2;
	K = lambda / Dx;
	temp_eq = ((hc_ext * Text) + (K * TSinit) + flux_sol_abs) / (hc_ext + K);

	return temp_eq;
}

double IR_ciel(double Tair)
//------------------------------------------------------------------------------------
// cacul des flux IR en fonction de le temperature d'air
// si ces flux ne sont pas donnes en entree
// extraite de 'transitoire_h_option2.c', en l'etat
//------------------------------------------------------------------------------------
{
	// Calcul du flux IR maximum recu en provenance du ciel d'apres modele de Monteith (these J. Noilhan -> cf. these J.Vinet, CERMA)
	return (double) (5.5 * Tair + 213);
}

void lecture_ff(FILE *pf_fform, float *factf, int ii, int nb_contour_total)
//------------------------------------------------------------------------------------
// lecture des facteurs de forme dans un fichier
// extraite de 'transitoire_h_option2.c'
// modifiee par J.Bouyer, decembre 2006
//------------------------------------------------------------------------------------
{
	fseek(pf_fform, (ii * nb_contour_total) * sizeof(float), SEEK_SET);
	fread(factf, sizeof(float), nb_contour_total, pf_fform);
}

int radiog(int im, int *nb_cont_face, int *numero_face, int nbfac,
		int nb_contour_total, double *exitance_init, double *surf,
		double *reflex, FILE *pf_fform, float *fform, int flag_arret,
		double pourc, double *exitance)
//------------------------------------------------------------------------------------
// RADIOSITE GENERALISEE
// extraite de 'transitoire_h_options2.c', modifiee par J.Bouyer, janvier 2007
// Tableau d'entree: `exitance_init', tableau de sortie: 'exitance'
// Dans la bande solaire: mettre en entree la 1ere reflexion du flux solaire incident
// Dans l'IR: mettre en entree l'emission propre de chaque surface
// On recupere en sortie l'exitance (ou la radiosite) de chaque surface
// pour la bande du spectre consideree
//------------------------------------------------------------------------------------
{
	int face;
	int num_cont, contour;
	int iteration;
	int icont_liste_max = 0;
	int iface_max = 0;
	int icont_max = 0;
	double energie_totale;
	double a_distribuer;
	double a_distribuer_preced;
	double a_distribuer_max;
	double *delta_exitance;
	double fform_recip;
	double d_exitance;
	static int nb_iter_max_abs = 50000;
	int erreur = 0;

	// Allocation memoire dynamique
	delta_exitance = allocation_tableau_double(nb_contour_total);
	if (delta_exitance == NULL) {
		printf("*** Probleme allocation radiosite residuelle.\n");
		erreur = 1;
		return erreur;
	}

	// INITIALISATIONS

	//for(contour=0;contour<nb_contour_total;contour++)
	//exitance[contour] = delta_exitance[contour] = exitance_init[contour];

	memcpy(exitance, exitance_init, nb_contour_total * sizeof(double));
	memcpy(delta_exitance, exitance_init, nb_contour_total * sizeof(double));

	energie_totale = 0.0;
	for (contour = 0; contour < nb_contour_total; contour++)
		energie_totale += delta_exitance[contour] * surf[contour];

	printf("\nEnergie totale a distribuer (W) : %f\n", energie_totale);

	a_distribuer_preced = energie_totale;
	a_distribuer = energie_totale;

	// ITERATIONS

	iteration = 1;
	while (iteration < nb_iter_max_abs) {
		//printf("...iteration %d...\r",iteration); 

		// Recherche de l'element de flux maximal
		a_distribuer_max = 0.0;
		num_cont = 0;
		for (face = 0; face < nbfac; face++) {
			for (contour = 0; contour < nb_cont_face[face]; contour++) {
				if (delta_exitance[num_cont] * surf[num_cont]
						> a_distribuer_max) {
					a_distribuer_max = delta_exitance[num_cont]
							* surf[num_cont];
					iface_max = face;
					icont_max = contour + 1;
					icont_liste_max = num_cont;
				}
				num_cont++;
			}
		}

		if (im)
			printf(
					"\nFlux maxi (W) en provenance de la face %d, contour %d (no %d) : %5.2f\n",
					numero_face[iface_max], icont_max, icont_liste_max + 1,
					a_distribuer_max);

		// lecture des ff[ii]
		lecture_ff(pf_fform, fform, icont_liste_max, nb_contour_total);

		// contribution de l'element de flux maximal, a tous les autres
		for (num_cont = 0; num_cont < nb_contour_total; num_cont++) {

			fform_recip = fform[num_cont] * surf[icont_liste_max]
					/ surf[num_cont];
			//if(fform_recip>1.) fform_recip=1.; reprend modif realisee dans radiosite
			if (fform_recip > 1.) { // recipro=1.; VOIR note algo eclairement, et note Fernand 24 avril 2002
				printf("recipro = %f\n", fform_recip);
			}

			d_exitance = reflex[num_cont] * delta_exitance[icont_liste_max]
					* fform_recip;
			delta_exitance[num_cont] += d_exitance;
			exitance[num_cont] += d_exitance;
		}
		delta_exitance[icont_liste_max] = 0.0;

		a_distribuer = 0.0;
		for (num_cont = 0; num_cont < nb_contour_total; num_cont++)
			a_distribuer += delta_exitance[num_cont] * surf[num_cont];

		if (im)
			printf("Energie non distribuee (W) : %f\n", a_distribuer);

		// Sortie de boucle
		// Pas genial mais dependant des conventions adoptees dans versions precedentes
		// flag_arret = 2 impose en entree
		if ((flag_arret == 2)
				&& (a_distribuer < (pourc * energie_totale / 100)))
			break;

		a_distribuer_preced = a_distribuer;
		iteration++;
	}
	// fin de la boucle while
	// Les resultats a exploiter dans le corps du prog sont dans 'exitance'

	free(delta_exitance);
	printf("Energie non distribuee (W) : %f\n", a_distribuer);
	return erreur;
}

void calc_flux_atm_intereflexion(double flux_atmosphere, double *emissivite,
		double *surf, int nb_facette, int *nb_cont_face, int *numero_face,
		int nbfac, FILE *pf_fform, float *fform, double *fciel, double *resu)
//------------------------------------------------------------------------------------
// estime le flux IR atmospherique recu par une facette apres des
// intereflexion dans la scene
//------------------------------------------------------------------------------------
{
	double *reflectivite;
	int i;
	int calcul_radiosite;
	int im; // commande impression 0 : non / 1 : oui
	int test_erreur; // resultat de la commande 'radiog'
	double *exitance_init; // Exitances (ou radiosites) initiales
	double *exitance; // Exitances (ou radiosites) calculees
	int flag_arret = 2; // Arret quand moins de x% de l'energie initiale
	double pourc = 0.1; // Si flag_arret = 2, on s'arrete quand il reste moins de 0.1% de l'energie totale a distribuer

	reflectivite = allocation_tableau_double(nb_facette);
	exitance_init = allocation_tableau_double(nb_facette);
	exitance = allocation_tableau_double(nb_facette);

	// Initialisation densite de flux partant
	calcul_radiosite = 0;
	for (i = 0; i < nb_facette; i++) {
		reflectivite[i] = 1 - emissivite[i];
		exitance_init[i] = reflectivite[i] * fciel[i] * flux_atmosphere;
		if (exitance_init[i])
			calcul_radiosite = 1; // si la valeur d'exitance_init nest pas nulle, on peut lancer l'algo de radiosite
		exitance[i] = 0.0;
	}

	// Lancement iterations
	if (calcul_radiosite) {
		im = 0;
		test_erreur = radiog(im, nb_cont_face, numero_face, nbfac, nb_facette,
				exitance_init, surf, reflectivite, pf_fform, fform, flag_arret,
				pourc, exitance);
		// A ce stade : exitance = radiosite = densite de flux partant de chaque facette, dans la bande visible + PIR
		for (i = 0; i < nb_facette; i++) {
			if (reflectivite[i] > 0)
				resu[i] = ((1 / reflectivite[i]) - 1.0) * exitance[i];
			else // pas de reflexion sur cette facette
			{
				printf(
						"\n\n  ERREUR : Les emissivites ne peuvent pas etre egales a 1\n\t--> modifier le descripteur\n\n Calcul de radiosite interrompu");
				exit(0);
				//printf("\nFatm recu: %f",resu[i]); // TEST
			}
		}
	}

	else // alors, les emissivites de toutes les parois sont a 1, pas de calcul de radiosite
	{
		printf("\n\tATTENTION : Toutes les reflectivites IR sont nulles\n\n"); // TEST
		for (i = 0; i < nb_facette; i++) {
			resu[i] = emissivite[i] * fciel[i] * flux_atmosphere;
			// printf("\nFatm recu : %f",resu[i]); // TEST
		}
	}

	free(reflectivite);
	free(exitance_init);
	free(exitance);
}

double calc_GLO(int numero_contour_ref, int numero_contour_total, double fciel,
		double *Tse, FILE *pf_fform,
		float *fform,
		//double *surface,
		double *emissivite, double *GLO_Ciel_Emis, double *GLO_Ciel_Recu,
		double *GLO_Ciel_Net, double *GLO_Scene_Emis, double *GLO_Scene_Recu,
		double *GLO_Scene_Net, double *GLO_Total_Emis, double *GLO_Total_Recu)
//------------------------------------------------------------------------------------
// caclul du rayonement IR thermique net echange en fonction de toutes les
// Ts des facettes et de l'environnment construit et du ciel
// mise a jour : le 12/02/2005 on change les emissivites en emissivite[numero_contour_ref]
// mise a jour : juillet 2005 on calcule l'ensemble des flux GLO echanges (emis, recu, total avec le ciel, la scene, total
// extraite de 'transitoire_h_option2.c', en l'etat
// modifiee par J.Bouyer, decembre 2006
//------------------------------------------------------------------------------------
{
	const double stefan = 5.67e-8; // constante de stefan
	int num_contour; // pour boucler sur tous les contours
	double GLO_Total_Net; // variable retournee par la fonction
	double somme_ff; // somme des facteurs de forme avec la scene pour un contour

	// CALCUL DES FLUX GLO ECHANGES AVEC LE CIEL (GLO_Ciel_...)

	// ci-dessous : ancienne version, cas sans intereflexions IR
	//GLO_Ciel_Recu[numero_contour_ref] = fciel * emissivite[numero_contour_ref] * flux_atmosphere ;
	// maintenant le flux GLO_Ciel_Recu est calcule en externe
	// dans la procedure "calc_flux_atm_intereflexion" J.Bouyer et D.Groleau, 12/01/07

	GLO_Ciel_Emis[numero_contour_ref] = fciel * stefan
			* emissivite[numero_contour_ref] * pow((Tse[numero_contour_ref]
			+ 273.15), 4);
	GLO_Ciel_Net[numero_contour_ref] = GLO_Ciel_Emis[numero_contour_ref]
			- GLO_Ciel_Recu[numero_contour_ref];

	// CALCUL DES FLUX GLO ECHANGES AVEC LES AUTRES SURFACES URBAINES (GLO_Scene_...)

	GLO_Scene_Net[numero_contour_ref] = 0.0; // initialisation
	lecture_ff(pf_fform, fform, numero_contour_ref, numero_contour_total); // lecture des facteurs de forme avec le contour de reference
	fform[numero_contour_ref] = 0.0; // valeur du fform du contour sur lui-meme
	somme_ff = 0.0; // initialisation
	for (num_contour = 0; num_contour < numero_contour_total; num_contour++) // somme sur tous les contours
	{
		//GLO_Scene_Net[numero_contour_ref]  += stefan*fform[num_contour]*(emissivite[numero_contour_ref]*pow((Tse[numero_contour_ref]+273.15),4) - emissivite[num_contour]*pow((Tse[num_contour]+273.15),4)); // ancienne version
		GLO_Scene_Net[numero_contour_ref] += stefan * fform[num_contour]
				* (emissivite[numero_contour_ref] * pow(
						(Tse[numero_contour_ref] + 273.15), 4) - pow(
						(Tse[num_contour] + 273.15), 4)); // correction le 12/01/07 pour traiter approximativement les interreflexion IR (J.Bouyer et D.Groleau)
		//GLO_Scene_Net[numero_contour_ref]  += stefan * (1/surface[num_contour]) * fform[num_contour] * (surface[numero_contour_ref]*emissivite[numero_contour_ref]*pow((Tse[numero_contour_ref]+273.15),4) - surface[num_contour]*pow((Tse[num_contour]+273.15),4)); // modif J.Bouyer 26/10/07 pour rigoureusement prendre en compte les surfaces de facettes (tres heterogenes en maillage adaptatif !!!)
		somme_ff += fform[num_contour]; //
	}
	//GLO_Scene_Emis[numero_contour_ref] = stefan*emissivite[numero_contour_ref]*pow((Tse[numero_contour_ref]+273.15),4); // ancienne version
	GLO_Scene_Emis[numero_contour_ref] = somme_ff * stefan
			* emissivite[numero_contour_ref] * pow((Tse[numero_contour_ref]
			+ 273.15), 4); // correction le 12/01/07 (J.Bouyer et D.Groleau)
	GLO_Scene_Recu[numero_contour_ref] = GLO_Scene_Emis[numero_contour_ref]
			- GLO_Scene_Net[numero_contour_ref]; // correction le 12/01/07 (J.Bouyer et D.Groleau)

	// CALCUL DES FLUX GLO ECHANGES AVEC TOUT L'ENVIRONNEMENT (GLO_Total_...)

	GLO_Total_Emis[numero_contour_ref] = GLO_Ciel_Emis[numero_contour_ref]
			+ GLO_Scene_Emis[numero_contour_ref];
	GLO_Total_Recu[numero_contour_ref] = GLO_Ciel_Recu[numero_contour_ref]
			+ GLO_Scene_Recu[numero_contour_ref];
	GLO_Total_Net = GLO_Ciel_Net[numero_contour_ref]
			+ GLO_Scene_Net[numero_contour_ref];

	return GLO_Total_Net;
}

void utilisation(int argc)
//------------------------------------------------------------------------------------
// rapelle le format d'appel a la fonction a l'utilisateur s'il commet
// une erreur
//------------------------------------------------------------------------------------
{
	if (argc != 25) {
		printf("\nATTENTION : le nombre d'argument doit etre egal a 25 \n\n");
		printf("      FORMAT DE LA FONCTION :\n\n");
		printf("      0   nom de la fonction \n");
		printf("      1   pas de tps \n");
		printf("      2   surfaces facettes (.val) \n");
		printf("      3   facteurs de forme (.fac) \n");
		printf("      4   facteurs de vue du ciel (.val) \n");
		printf("      5   temperature de l'air exterieur (.val) \n");
		printf("      6   humidite de l'air exterieur (.val) \n");
		printf(
				"      7   coefficient d'echange superficiel convectif (hc)(.val) \n");
		printf("      8   flux IR atmospherique horizontal \n");
		printf("      9   flux solaires directs (.val) \n");
		printf("      10  flux solaires diffus (.val) \n");
		printf("      11  composition des materiaux de surface (.txt) \n");
		printf("      12  numero classe paroi (.val) \n");
		printf("      13  numero type paroi (.val) \n");
		printf("      14  albedo des facettes (.val) \n");
		printf("      15  emissivite des facettes (.val) \n");
		printf("      16  transmitivite des facettes (.val) \n");
		printf("      17  coefficient d'evaporation du sol (f) (.val)\n");
		printf("      18  conditions limites du sous-sol (1m) \n");
		printf(
				"      19  temperatures de surface exterieure initiales (.val) \n");
		printf(
				"      20  TN1 int initiales (noeud 1 pour les surfaces des batiments et sol) (.val)\n");
		printf("      21  TN2 int initiales (pour le sol) (.val)\n");
		printf(
				"      22  temperatures de surface exterieure calculees (.val) \n");
		printf(
				"      23  TN1 calculees (noeud 1 pour les surfaces des batiments et sol) (.val)\n");
		printf("      24  TN2 calculees (noeud 2 pour le sol) (.val)\n");
		printf("\n");
		exit(0);
	}
}

// ==========================================================
// programme principal
// ==========================================================
int main(int argc, char *argv[]) {

	// DECLARATION DES VARIABLES
	//##################################################################################################################

	// VARIABLES GEOMETRIQUES

	int nb_facette; // nb de contour total de la geometrie
	/*	int nb_facette_bat ;				// nb de contour du batiment d'etude
	 int nb_niv ; */
	// nombre de niveaux du batiment d'etude
	int nb_face, no_face_max; // nb de faces et n de la face max de la geometrie
	int *tab_no_face; // tableau des n de faces de la geometrie
	int *tab_nb_contour_face; // tableau des nb de contours par faces de la geometrie
	/*	int n ;								// nombre de noeuds de calcul pour le batiment d'etude
	 int nn ;							// n : dimension de la matrice batiment
	 double Hniv = 3 ;					// hauteur standard d'un niveau du bat d'etude
	 Sniveau *Sniv ;*/
	// surface des entites constructives par niveau du batiment d'etude

	// DONNEES D'ENTREE : NOMS FICHIERS & VARIABLES D'ACCUEIL

	char nom_fic_paroi[TAILLE_CHAINE_NOM_FICHIER]; // nom du fichier des caracteristiques de paroi
	int nb_paroi; // nb de parois
	paroi *tab_paroi; // tableau des differentes classes generales parois
	/*	paroi *mur ;						// tableau des differentes type de parois par classe : murs
	 paroi *vitrage ;					// ... : vitrages
	 paroi *toiture ;					// ... : parois
	 paroi *plancher_int ;				// ... : planchers intermediaires
	 paroi *plancher_bas ;				// ... : plancher bas RDC
	 paroi *interieur ; */
	// ... : parois interieures
	paroi *surf_bat; // tableau de la classe des autres enveloppes de batiment
	paroi *surf_sol; // tableau de la classe des sols

	char nom_fic_sol[TAILLE_CHAINE_NOM_FICHIER]; // nom du fichier des caracteristiques des sous sols
	prop_sol info_sol; // caracteristiques des sols
	int jour;
	int jour_ref;
	double moy_Tair;
	double max_Tair;
	double min_Tair;

	char nom_fic_surface[TAILLE_CHAINE_NOM_FICHIER]; // nom du fichier descripteur des surfaces
	double *surface; // tableau des surfaces

	char nom_fic_classe_paroi[TAILLE_CHAINE_NOM_FICHIER]; // nom du fichier descripteur de la classe de paroi
	double *classe_paroi; // tableau des classes de paroi

	char nom_fic_id_paroi[TAILLE_CHAINE_NOM_FICHIER]; // nom du fichier descripteur des nID de parois
	double *id_paroi; // tableau des identificateurs des n ID de parois ext (1 : murs / 2 : vitrages / 3 : toiture )

	char nom_fic_flux_sol_dir[TAILLE_CHAINE_NOM_FICHIER]; // nom du fichier descripteur des flux solaires directs incidents
	double *flux_sol_dir; // tableau des des flux solaires directs incidents

	char nom_fic_flux_sol_diff[TAILLE_CHAINE_NOM_FICHIER]; // nom du fichier descripteur des flux solaires diffus incidents
	double *flux_sol_diff; // tableau des des flux solaires diffus incidents

	char nom_fic_fciel[TAILLE_CHAINE_NOM_FICHIER]; // nom du fichier des facteurs de forme
	double *fciel; // valeur des facteurs de forme

	FILE *pf_fform; // pointeur du fichier des facteurs de forme
	char nom_fform[TAILLE_CHAINE_NOM_FICHIER]; // nom du fichier des facteurs de forme
	float *fform; // valeur des facteurs de forme

	char nom_fic_hc_ext[TAILLE_CHAINE_NOM_FICHIER]; // nom du fichier descripteur des h_conv
	double *hc_ext; // tableau des des h_conv
	/*
	 char nom_fic_in_air[TAILLE_CHAINE_NOM_FICHIER];			// nom du fichier descripteur des entrees d'air neuf dans le batiment de calcul
	 double *in_air;						// tableau des entrees d'air neuf dans le batiment de calcul

	 char nom_fic_niveau[TAILLE_CHAINE_NOM_FICHIER];			// nom du fichier descripteur des entrees d'air neuf dans le batiment de calcul
	 double *niveau;						// tableau des entrees d'air neuf dans le batiment de calcul
	 */
	char nom_fic_TSext_init[TAILLE_CHAINE_NOM_FICHIER]; // nom du fichier descripteur des temperature de surf exterieures init
	double *TSext_init; // temperature de surfaces des facettes init

	char nom_fic_TNint1_init[TAILLE_CHAINE_NOM_FICHIER]; // nom du fichier descripteur des temperatures interieures 1er noeud init
	double *TNint1_init; // temperature interieures 1er noeud des facettes init

	char nom_fic_TNint2_init[TAILLE_CHAINE_NOM_FICHIER]; // nom du fichier descripteur des temperatures 2e noeud init
	double *TNint2_init; // temperature interieures 2e noeud des facettes init
	/*
	 char nom_fic_Tnoeuds_init[TAILLE_CHAINE_NOM_FICHIER] ;		// nom du fichier contenant la matrice des temperatures nodales int du batiment de calcul
	 double *T2_init ; // temperature de niveau au noeud 2 initiale (murs)
	 double *T4_init ; // temperature de niveau au noeud 4 initiale (vitrages)
	 double *T5_init ; // temperature de niveau au noeud 5 initiale (plancher)
	 double *T6_init ; // temperature de niveau au noeud 6 initiale (plafond)
	 double *T7_init ; // temperature de niveau au noeud 7 initiale (surf paroi int)
	 double *T8_init ; // temperature de niveau au noeud 8 initiale (int paroi int)
	 double *T9_init ; // temperature de niveau au noeud 9 initiale (Tmr)
	 double *T10air_init ; // temperature de niveau au noeud 10 initiale (Tair)
	 double *T12_init ; // temperature de niveau au noeud 12 initiale (plafond sous toiture)
	 double *Tsol_bis_init ; // temperature de niveau au noeud 5bis initiale (milieu couche de sous-sol)
	 */
	char nom_fic_albedo[TAILLE_CHAINE_NOM_FICHIER]; // nom du fichier descripteur des albedo
	double *albedo; // tableau des des albedo

	char nom_fic_emissivite[TAILLE_CHAINE_NOM_FICHIER]; // nom du fichier descripteur des emissivites
	double *emissivite; // tableau des des emissivites

	char nom_fic_transmission[TAILLE_CHAINE_NOM_FICHIER]; // nom du fichier descripteur des transmitivites solaires (vitrages bat etude + arbres)
	double *transmission; // tableau des des transmitivites solaires (vitrages bat etude + arbres)

	char nom_fic_Text[TAILLE_CHAINE_NOM_FICHIER]; // nom du fichier descripteur de la temperature de l'air a proximite des facettes
	double *Text; // temperature de l'air a proximite des facettes

	char nom_fic_w_ext[TAILLE_CHAINE_NOM_FICHIER]; // nom du fichier descripteur de la masse de vapeur d'eau dans l'air a proximite des facettes
	double *w_ext; // masse de vapeur d'eau dans l'air a proximite des facettes

	char nom_fic_f_evap_sol[TAILLE_CHAINE_NOM_FICHIER]; // nom du fichier descripteur coefficient de potentiel evaporatif du sol
	double *f_evap_sol; // coefficient de potentiel evaporatif du sol

	double flux_atm; // flux IR atmospherique au pas de temps courant

	// DONNEES DE SORTIE : NOMS FICHIERS & VARIABLES D'ACCUEIL

	char nom_fic_TSext[TAILLE_CHAINE_NOM_FICHIER]; // nom du fichier descripteur des temperature de surf exterieures
	double *TSext; // temperature de surfaces des facettes

	char nom_fic_TNint1[TAILLE_CHAINE_NOM_FICHIER]; // nom du fichier descripteur des temperature interieures noeud 1
	double *TNint1; // temperature de interieures noeud 1 des facettes

	char nom_fic_TNint2[TAILLE_CHAINE_NOM_FICHIER]; // nom du fichier descripteur des temperature interieures noeud 2
	double *TNint2; // temperature de interieures noeud 2 des facettes

	/*	char nom_fic_Tnoeuds_out[TAILLE_CHAINE_NOM_FICHIER] ;
	 double *T2 ;
	 double *T4 ;
	 double *T5 ;
	 double *T6 ;
	 double *T7 ;
	 double *T8 ;
	 double *T9 ;
	 double *T10air ;
	 double *T12 ;
	 double *Tsol_bis ;
	 double *Pconv ;
	 double *Platent ;
	 */
	char nom_fic_Flux_Latent[TAILLE_CHAINE_NOM_FICHIER]; // nom du fichier des flux latents (pour les sols, utile pour couplage)
	double *Flux_Latent;

	char nom_fic_Flux_Rad_Net_Abs[TAILLE_CHAINE_NOM_FICHIER]; // nom du fichier des flux radiatifs net absorbes (pour les arbres, utile pour couplage)
	double *Flux_Rad_Net_Abs;

	char nom_fic_humidite_rel_air[TAILLE_CHAINE_NOM_FICHIER];
	double *humidite_rel_air; // humidite relative de l'air ext

	char *ext_tps_val; // contenu de l'extension horaire + extension .val a la fin des fichiers de resultat

	// variable intermediaire pour le calcul des puissances ou  de Tair au noeud 10

	/*double *inconnue ;*/// Pconv pour le regime force / T10 (air int) pour le regime libre

	// ensemble des flux Grandes Longueurs d'Ondes (GLO) calculees : (IR thermique)

	double *GLO_Ciel_Emis; // densites de flux GLO emis vers le ciel
	double *GLO_Ciel_Recu; // densites de flux GLO emis recu du ciel
	double *GLO_Ciel_Net; // densites de flux GLO total net echange avec le ciel
	double *GLO_Scene_Emis; // densites de flux GLO emis vers les surfaces urbaines
	double *GLO_Scene_Recu; // densites de flux GLO recu des surfaces urbaines
	double *GLO_Scene_Net; // densites de flux GLO total net echange avec les surfaces urbaines
	double *GLO_Total_Emis; // densites de flux GLO TOTAL emis
	double *GLO_Total_Recu; // densites de flux GLO TOTAL recu
	double *GLO_Total_Net; // densites de flux GLO TOTAL net echange

	// ensemble des flux Courtes Longueurs d'Ondes (CLO) calculees : (solaire = visible + IR solaire)
	double *flux_sol_abs; // flux solaire global absorbe par chaque facette (en W/m)
	double flux_min; // pour tester les flux d'entree
	int nb_err; // pour tester les flux d'entree
	int test_flux; // pour tester les flux d'entree

	// flux solaires transmis par les ouvertures et absorbe par les murs, vitrages, planchers, plafonds, parois int, pour chaque niveau
	/*double *Ft_mur, *Ft_vit, *Ft_plc, *Ft_plf, *Ft_int ;*/

	// VARIABLES PHYSIQUES DU BATIMENT
	/*
	 listeRCparoi *RCmur, *RCvit, *RCtoit, *RCplc_int, *RCplc_bas, *RCint ;		// listes de resistance thermique equivalentes et de capacites int/ext des parois du bat d'etude
	 double *Rcv_i, *Rrad_i;			// resistance convective et radiative interieure

	 double *hc_int ; // voir [Fraisse et Virgone p.9] : plancher (1.6 W/m.K), plafond (6.1 W/m.K), murs (4.1 W/m.K) > moyenne hc_int = 4 / attribution des valeurs dans le main
	 double hr_int = 5 ;		// on retrouve bien h_int(global) biblio d'environ 9 W/m.K avec h_int = hr_int + hc_int moyen !!!

	 double abs_plc = 0.4 ;	// absorptivite solaire des planchers (couleur gris clair)  (cf. E.Mazria : Le guide de la maison solaire)
	 double abs_vit = 0.13 ;	// absorptivite solaire des vitrages (cote interieur) (cf. Memento St Gobain "CLIMAPLUS N" p.286)

	 double *Cai ;			// capacite de la masse d'air du niveau
	 double *Rra ;			// resistance de la masse d'air du niveau

	 double T10consigne ; 			// temperature de consigne interieure
	 double Tc_occup_ete = 26.0 ; 	// temperature de consigne ete/occupation (cf. These S.Filfli)
	 double Tc_occup_hiv = 19.0 ; 	// temperature de consigne hiver/occupation (cf. These S.Filfli)
	 double Tc_inoccup_hiv = 15.0 ; 	// temperature de consigne hiver/occupation (cf. These S.Filfli)

	 double ps_equip ;				// charges sensibles dues aux equipements(eclairage, bureautique), ramene au m de plancher
	 double *Ps_equip ;				// charges sensibles dues aux equipements(eclairage, bureautique) (W)
	 double *Ps_occup ;				// charges sensibles dues aux occupants (W)
	 double *Pl_occup ;				// charges latentes dues aux occupants (W)
	 double taux_occup ;				// taux d'occuation d'un etage de batiment (occupant / m)
	 double taux_occup_max = 0.064 ;	// taux d'occuation maximum pour definir le debit courant de ventilation (celui du bat bureau "BEETHOVEN") independemment de l'occupation reelle au tps courant
	 double debit_hyg_indiv = 15 ;	// debit hygienique de ventilation (m3 / occupant.m) (cf. NF EN ISO 13790)
	 int saison ;					// ete (0) / hiver (1)

	 int *alpha ;			// alpha = indicateur du regime de simulation : Force (0), Libre (1), Mixte (2)
	 int alpha_arg ;			// alpha lu en argument
	 */
	// VARIABLES PHYSIQUES AMENAGEMENT

	listeRCparoi *RCsurf_bat; // listes de Rthermique equivalentes et de C int/ext des autres enveloppes de bat
	listeRCparoi *RCsurf_sol; // listes de Rthermique equivalentes et de C int/ext des sols

	double h_int_bat = 9; // pour les amenagements types "enveloppes autres batiments"

	double z_ref; // profondeur de reference ou le flux de conduction est nul
	double Tsol_ref; // condition limite de temperature a la profondeur z_ref dans le sol
	double Rsol; // resistance thermique du sol (pour epaisseur = z_ref)
	double Csol; // capacite equivalente du sol (pour epaisseur = z_ref)

	double lambda_sol; // conductivite th du sol
	double Cp_sol; // capacite thermique du sol
	double rho_sol; // masse volumique du sol

	// OUTILS DE RESOLUTION

	// pour le calcul matriciel
	/*	double *A ;						// matrice de resolution bat etude
	 double *b ;						// vecteur de resolution bat etude
	 double *T ;						// vecteur des temperatures inconnues bat etude
	 */
	double *matBAT; // matrice de resolution autres bat
	double *vecBAT_in; // vecteur de resolution autres bat
	double *vecBAT_out; // vecteur des temperatures inconnues autres bat

	double *matSOL; // matrice de resolution sols
	double *vecSOL_in; // vecteur de resolution sols
	double *vecSOL_out; // vecteur des temperatures inconnues sols

	// pour les iterations
	double *TSext_old_1, *TSext_old_2; // vecteur des temperatures inconnues aux 2 pas de calcul precedent
	double *TNint1_TEMP; // pour stocker les TNint1 du sol et des parois pdt les iterations
	double *TNint2_TEMP; // pour stocker les TNint2 du sol et des parois pdt les iterations

	double deltaT; // vecteur des differences de temperature entre T et Told
	double somme_deltaT; // somme des differences de temperature entre T et Told

	// VARIABLES PROPRES A L'ALGORITHME

	double dt; // pas de temps de simulation (sec)

	int i, j; // compteurs
	int iter; // compteur des iterations de calcul
	double eps1, eps2; // critere du test de convergence (ecart max, moyenne des ecarts)
	int ratio_face_non_cv; // pourcentage acceptable de face non convergees
	int n_face_non_cv_old_1, n_face_non_cv_old_2; // nb de faces non convergee aux deux pas de temps precedents
	double lambda_relax; // coef de sous relaxation pour la convergence des TSext
	int test_Ts; // valeur entiere du test de convergence de Ts
	/*int test_Tconsigne ;				// valeur entiere du test de comparaison entre Tair(niv) et Tconsigne*/

	clock_t dateDebut, dateFin; // date de declenchement et d'arret du chronometre


	// LECTURE DES ENTREES
	//##################################################################################################################

	printf("\n[ DEBUT EXECUTION ]\n");
	//------------------------------------------------------------------------------------

	utilisation(argc); // test sur le nombre d'arguments & format de l'appel a la fonction


	printf("\n[ LECTURE DES ENTREES ]\n");
	//------------------------------------------------------------------------------------

	// PAS DE TEMPS (nombre entier)
	dt = atof(argv[1]);
	printf("\nPas de temps de simulation : %f s", dt);

	// lecture du 1er descripteur(.val) pour obtenir les elements geometriques necessaires
	complement_extension(nom_fic_surface, argv[2], "val");
	printf("\nFichier de base de calcul des contours : %s", nom_fic_surface);
	// lecture du nombre de faces dans descripteur
	nb_face = total_face(nom_fic_surface);
	printf("\n     # Nombre de faces : %d", nb_face);
	// allocation du tableau de n de face
	tab_no_face = allocation_tableau_int(nb_face);
	// allocation du tableau de nb de contours par face
	tab_nb_contour_face = allocation_tableau_int(nb_face);
	// analyse geometrique complete	
	analyse_face_contour(nom_fic_surface, &no_face_max, &nb_facette,
			tab_no_face, tab_nb_contour_face);
	printf("\n     # Nombre total de contours : %d", nb_facette);

	// SURFACES DES CONTOURS (*.val)
	surface = allocation_tableau_double(nb_facette);
	complement_extension(nom_fic_surface, argv[2], "val");
	printf("\nFichier descripteur de surface : %s", nom_fic_surface);
	lecture_descripteur(nom_fic_surface, surface);

	// FACTEUR DE FORME AVEC LA SCENE (*.fac)
	complement_extension(nom_fform, argv[3], "fac");
	printf("\nFichier des facteurs de forme: %s", nom_fform);
	fform = allocation_tableau_float(nb_facette);

	// FACTEUR VUE DU CIEL (*.val)
	fciel = allocation_tableau_double(nb_facette);
	complement_extension(nom_fic_fciel, argv[4], "val");
	printf("\nFichier descripteur des facteurs d'ouverture au ciel : %s",
			nom_fic_fciel);
	lecture_descripteur(nom_fic_fciel, fciel);

	// TEMPERATURE D'AIR EXT (*.val)
	Text = allocation_tableau_double(nb_facette);
	complement_extension(nom_fic_Text, argv[5], "val");
	printf(
			"\nFichier descripteur des temperatures d'air proche des parois : %s",
			nom_fic_Text);
	lecture_descripteur(nom_fic_Text, Text);

	// CHARGE D'HUMIDITE DE L'AIR EXTERIEUR (caractere)
	w_ext = allocation_tableau_double(nb_facette);
	complement_extension(nom_fic_w_ext, argv[6], "val");
	printf(
			"\nFichier descripteur de la charge d'humidite de l'air exterieur : %s",
			nom_fic_w_ext);
	lecture_descripteur(nom_fic_w_ext, w_ext);

	// COEF DE CONVECTION EXTERIEUR (*.val)
	hc_ext = allocation_tableau_double(nb_facette);
	complement_extension(nom_fic_hc_ext, argv[7], "val");
	printf("\nFichier descripteur des hc : %s", nom_fic_hc_ext);
	lecture_descripteur(nom_fic_hc_ext, hc_ext);

	// FLUX IR ATMOSPHERIQUE (scalaire)
	flux_atm = atof(argv[8]);
	printf("\nFlux IR atmospherique : %f", flux_atm);

	// FLUX SOLAIRE DIRECT (*.val)
	flux_sol_dir = allocation_tableau_double(nb_facette);
	complement_extension(nom_fic_flux_sol_dir, argv[9], "val");
	printf("\nFichier descripteur des flux solaires directs incidents : %s",
			nom_fic_flux_sol_dir);
	lecture_descripteur(nom_fic_flux_sol_dir, flux_sol_dir);

	// FLUX SOLAIRE DIFFUS (*.val)
	flux_sol_diff = allocation_tableau_double(nb_facette);
	complement_extension(nom_fic_flux_sol_diff, argv[10], "val");
	printf("\nFichier descripteur des flux solaires diffus incidents : %s",
			nom_fic_flux_sol_diff);
	lecture_descripteur(nom_fic_flux_sol_diff, flux_sol_diff);

	// COMPOSITION DES SURFACES (*.txt)
	complement_extension(nom_fic_paroi, argv[11], "txt");
	printf("\nFichier des proprietes des parois : %s", nom_fic_paroi);
	nb_paroi = lecture_nb_paroi(nom_fic_paroi);
	printf("\n     # Nombre de paroi : %d", nb_paroi);
	tab_paroi = allocation_struct_paroi(nb_paroi);
	lecture_donnees_paroi(nom_fic_paroi, tab_paroi);

	// CLASSE DES SURFACES (*.val)
	classe_paroi = allocation_tableau_double(nb_facette);
	complement_extension(nom_fic_classe_paroi, argv[12], "val");
	printf("\nFichier descripteur des classes de parois : %s",
			nom_fic_classe_paroi);
	lecture_descripteur(nom_fic_classe_paroi, classe_paroi);

	// IDENTIFICATEUR DES SURFACES (*.val)
	id_paroi = allocation_tableau_double(nb_facette);
	complement_extension(nom_fic_id_paroi, argv[13], "val");
	printf("\nFichier descripteur des identifiants de parois : %s",
			nom_fic_id_paroi);
	lecture_descripteur(nom_fic_id_paroi, id_paroi);

	// ALBEDOS (*.val)
	albedo = allocation_tableau_double(nb_facette);
	complement_extension(nom_fic_albedo, argv[14], "val");
	printf("\nFichier descripteur des albedos : %s", nom_fic_albedo);
	lecture_descripteur(nom_fic_albedo, albedo);

	// EMISSIVITES (*.val)
	emissivite = allocation_tableau_double(nb_facette);
	complement_extension(nom_fic_emissivite, argv[15], "val");
	printf("\nFichier descripteur des emissivites IR : %s", nom_fic_emissivite);
	lecture_descripteur(nom_fic_emissivite, emissivite);

	// TRANSMITIVITES (*.val)
	transmission = allocation_tableau_double(nb_facette);
	complement_extension(nom_fic_transmission, argv[16], "val");
	printf(
			"\nFichier descripteur des coefficients de transmission solaire : %s",
			nom_fic_transmission);
	lecture_descripteur(nom_fic_transmission, transmission);

	// COEFFICIENT D'EVAPORATION DES SOLS (*.val)
	f_evap_sol = allocation_tableau_double(nb_facette);
	complement_extension(nom_fic_f_evap_sol, argv[17], "val");
	printf("\nFichier descripteur des coefficients d'evaporation du sol : %s",
			nom_fic_f_evap_sol);
	lecture_descripteur(nom_fic_f_evap_sol, f_evap_sol);

	// CONDITIONS LIMITES DANS LE SOL
	complement_extension(nom_fic_sol, argv[18], "txt");
	printf("\nFichier des proprietes du sous sol (physique et meteo) : %s",
			nom_fic_sol);
	lecture_donnees_sol(nom_fic_sol, &info_sol);

	// TEMPERATURES DE SURFACE INITIALES(*.val)
	TSext_init = allocation_tableau_double(nb_facette);
	complement_extension(nom_fic_TSext_init, argv[19], "val");
	printf("\nFichier descripteur des Tsurface ext init : %s",
			nom_fic_TSext_init);
	lecture_descripteur(nom_fic_TSext_init, TSext_init);

	// TEMPERATURES NODALES INTERIEURES 1 INITIALES POUR LES SURFACES DE BATIMENTS ET LES SOLS (*.val)
	TNint1_init = allocation_tableau_double(nb_facette);
	complement_extension(nom_fic_TNint1_init, argv[20], "val");
	printf(
			"\nFichier descripteur des Tnodales 1 initiales des batiments et sols : %s\n\n",
			nom_fic_TNint1_init);
	lecture_descripteur(nom_fic_TNint1_init, TNint1_init);

	// TEMPERATURES NODALES INTERIEURES 2 INITIALES POUR LES SURFACES DE BATIMENTS ET LES SOLS (*.val)
	TNint2_init = allocation_tableau_double(nb_facette);
	complement_extension(nom_fic_TNint2_init, argv[21], "val");
	printf(
			"\nFichier descripteur des Tnodales 2 initiales des batiments et sols : %s\n\n",
			nom_fic_TNint2_init);
	lecture_descripteur(nom_fic_TNint2_init, TNint2_init);

	// PRETRAITEMENT
	//##################################################################################################################


	printf(
			"\n[ INITIALISATION DES VARIABLES THERMO-PHYSIQUES ASSOCIEES AUX SURFACES D'AMENAGEMENTS ]\n");
	//===============================================================================================================

	// CATEGORIE SURFACES GENERIQUES DE BATIMENTS (numero classe : 6)
	//------------------------------------------------------------------------------------

	printf("\nInitialisation des surfaces generiques de batiments");

	// allocation memoire de la structure de donnees de paroi correspondante
	surf_bat = allocation_struct_paroi(nb_paroi);

	// attribution des caracteristiques du fichier de paroi a la structure de paroi correspondante
	for (i = 0; i < nb_paroi; i++) {
		switch (tab_paroi[i].classe) {
		case 6:
			surf_bat[tab_paroi[i].id] = tab_paroi[i];
			break;
		default:
			break; // correspond aux autres types de facettes (batiment d'etude, sol, arbres, eau, ...)
		}
	}

	// allocation memoire de la structure de resitances & capacites
	RCsurf_bat = (listeRCparoi*) calloc(nb_paroi, sizeof(listeRCparoi));

	// calcul des resistances thermiques equivalentes et capacites int/ext surfaciques des parois
	for (i = 0; i < nb_paroi; i++) {
		calcul_RCparoi_surfacique(&surf_bat[i], &RCsurf_bat[i]);
	}
	free(surf_bat);

	// CATEGORIE SURFACE DE SOL (numero classe : 7)
	//------------------------------------------------------------------------------------

	printf("\nInitialisation des surfaces de sols");

	// calcul humidite relative
	humidite_rel_air = allocation_tableau_double(nb_facette);
	for (i = 0; i < nb_facette; i++)
		humidite_rel_air[i] = calcul_HR(Text[i], w_ext[i]);

	// proprietes du sous-sol
	lambda_sol = info_sol.lambda_sol;
	Cp_sol = info_sol.cp_sol;
	rho_sol = info_sol.rho_sol;
	z_ref = info_sol.z_ref;

	// proprietes meteo du modele de sol
	jour = info_sol.i_jour;
	jour_ref = info_sol.i_jour_ref;
	moy_Tair = info_sol.moy_Tair;
	max_Tair = info_sol.max_Tair;
	min_Tair = info_sol.min_Tair;

	// calculs
	calcul_proprietes_sol(z_ref, rho_sol, Cp_sol, lambda_sol, &Rsol, &Csol); // proprietes de la couche profonde sous le revetement (amenagement)
	Tsol_ref = calcul_Tref_profondeur(z_ref, jour, jour_ref, moy_Tair,
			max_Tair, min_Tair, lambda_sol, Cp_sol, rho_sol);
	printf("\n\tTemperature de reference sous sol (profondeur %2.2f m) : %f\n",
			z_ref, Tsol_ref);

	// allocation memoire des structures (paroi) de sol
	surf_sol = allocation_struct_paroi(nb_paroi);

	// attribution des caracteristiques du fichier paroi a la structure de paroi correspondante
	for (i = 0; i < nb_paroi; i++)
		switch (tab_paroi[i].classe) {
		case 7:
			surf_sol[tab_paroi[i].id] = tab_paroi[i];
			break;
		default:
			break; // correspond aux autres types de facettes (bat etude, autres batiments, eau, arbres)
		}

	// allocation memoire de la structure de resitances & capacites
	RCsurf_sol = (listeRCparoi*) calloc(nb_paroi, sizeof(listeRCparoi));

	// calcul des resistances thermiques equivalentes et capacites int/ext surfaciques des parois
	for (i = 0; i < nb_paroi; i++)
		calcul_RCparoi_surfacique(&surf_sol[i], &RCsurf_sol[i]);
	free(surf_sol);

	// allocation des variables de sortie utilisees pour le couplage
	Flux_Latent = allocation_tableau_double(nb_facette); // flux latent evacue par les sols humides


	// CATEGORIE "ARBRES" (numero classe : 8)
	//------------------------------------------------------------------------------------

	// on initialise simplement les temperatures de feuillages a Tair
	// dans la partie "INITIALISATION DES TEMPERATURES DE FACETTES"

	// ALLOCATION DES VARIABLES DE SORTIE UTILISEES POUR LE COUPLAGE
	Flux_Rad_Net_Abs = allocation_tableau_double(nb_facette); // flux radiatif total net absorbe par les feuillages d'arbres


	// CATEGORIE "ETENDUES D'EAU" (numero classe : 9)
	//------------------------------------------------------------------------------------

	// pas de modele de bassin d'eau pour l'instant
	// voir pour fixer une condition de temperature de surface
	// (Tair au pire des cas, ou mieux Teau provenant de fichiers meteo type RT2005)
	// dans la partie "INITIALISATION DES TEMPERATURES DE FACETTES


	// CATEGORIE "????" (autres amenagements)(numero classe : ?)
	//------------------------------------------------------------------------------------

	// pas d'autres modeles d'amenagements pour l'instant

	/*
	 printf("\n[ INITIALISATION DES VARIABLES THERMO-PHYSIQUES ASSOCIEES AU BATIMENT D'ETUDE ENERGETIQUE ]\n");
	 //===============================================================================================================

	 // allocation memoire des structures de paroi
	 mur = allocation_paroi(nb_paroi) ;
	 vitrage = allocation_paroi(nb_paroi) ;
	 toiture = allocation_paroi(nb_paroi) ;
	 plancher_int = allocation_paroi(1) ;
	 plancher_bas = allocation_paroi(1) ;
	 interieur = allocation_paroi(1) ;

	 // attribution des donnees du fichier_paroi aux structures_paroi correspondantes
	 for(i=0 ; i<nb_paroi ; i++)
	 switch (tab_paroi[i].classe) // test a choix multiple sur la classe de surface
	 {
	 case 0 : mur[tab_paroi[i].id] = tab_paroi[i] ; break ;
	 case 1 : vitrage[tab_paroi[i].id] = tab_paroi[i] ; break ;
	 case 2 : toiture [tab_paroi[i].id] = tab_paroi[i] ; break ;
	 case 3 : plancher_int = &tab_paroi[3] ; break ;	// ATTENTION : ne fonctionne que si le descripteur id_paroi est fixe a 3
	 case 4 : plancher_bas = &tab_paroi[4] ; break ;	// ATTENTION : ne fonctionne que si le descripteur id_paroi est fixe a 4
	 case 5 : interieur = &tab_paroi[5] ; break ;	// ATTENTION : ne fonctionne que si le descripteur id_paroi est fixe a 5
	 default : break ; // corrEsepond aux autres batiments (classe > 5)
	 }

	 // allocation memoire des structures de resitances & capacites du batiment d'etude
	 RCmur = (listeRCparoi*) calloc(nb_paroi, sizeof(listeRCparoi)) ;		// nb type de mur ext / vitrages / toiture = nb_paroi
	 RCvit = (listeRCparoi*) calloc(nb_paroi, sizeof(listeRCparoi)) ;
	 RCtoit = (listeRCparoi*) calloc(nb_paroi, sizeof(listeRCparoi)) ;
	 RCplc_int = (listeRCparoi*) calloc(1, sizeof(listeRCparoi)) ;		// nb type de plancher int / plancher bas / paroi int = 1 (reference)
	 RCplc_bas = (listeRCparoi*) calloc(1, sizeof(listeRCparoi)) ;
	 RCint = (listeRCparoi*) calloc(1, sizeof(listeRCparoi)) ;

	 // calcul des resistances thermiques equivalentes et capacites int/ext surfaciques des parois
	 for(i=0 ; i<nb_paroi ; i++)
	 {
	 calcul_RCparoi_surfacique(&mur[i], &RCmur[i]) ;
	 calcul_RCparoi_surfacique(&vitrage[i], &RCvit[i]) ;
	 calcul_RCparoi_surfacique(&toiture[i], &RCtoit[i]) ;
	 calcul_RCparoi_surfacique(plancher_int, RCplc_int) ;
	 calcul_RCparoi_surfacique(plancher_bas, RCplc_bas) ;
	 calcul_RCparoi_surfacique(interieur, RCint) ;
	 }
	 free(mur) ;
	 free(vitrage) ;
	 free(toiture) ;
	 // pas de free() pour plancher_int , plancher_bas et interieur car
	 // les tableaux de struct a 1 element le free() ne fonctionne alors pas bien

	 // calcul des resistances convectives et radiatives surfaciques interieures
	 Rcv_i = allocation_tableau(6) ;
	 Rrad_i = allocation_tableau(6) ;
	 hc_int = allocation_tableau(6) ;
	 // Attribution des coefs conv. int. selon [Fraisse et Virgone p.9]
	 hc_int[0] = 4.1 ; // murs
	 hc_int[1] = 4.1 ; // vitrage = coef theo pour les murs
	 hc_int[2] = 6.1 ; // toiture = coef theo pour les plafonds
	 hc_int[3] = 1.6 ; // plancher : attention � l'indice
	 hc_int[4] = 6.1 ; // plafond : attention � l'indice
	 hc_int[5] = 4.1 ; // paroi int. = coef theo pour les murs

	 for(i=0 ; i<6 ; i++)
	 calcul_Rint_surfacique(hc_int[i], hr_int, &Rcv_i[i], &Rrad_i[i]) ;

	 // calcul des surfaces totales des differents "id" & "classes" de parois par niveau
	 Sniv = (Sniveau *) calloc(nb_niv, sizeof(Sniveau)) ;
	 calcul_surfaces(niveau, id_paroi, classe_paroi, Sniv, surface, nb_niv, nb_paroi, nb_facette) ;

	 // calcul des variables physiques de l'air interieur (au noeud 10)
	 Cai = allocation_tableau(nb_niv);
	 Rra = allocation_tableau(nb_facette);
	 for (i = 0 ; i < nb_niv ; i++){
	 calcul_proprietes_air_int(nb_facette, i, niveau, in_air, taux_occup_max, debit_hyg_indiv, Sniv[i].SURFACE_CL[3], Hniv, Rra, &Cai[i]) ;
	 }

	 // calcul des charges internes
	 Ps_equip = allocation_tableau(nb_niv) ;
	 Ps_occup = allocation_tableau(nb_niv) ;
	 Pl_occup = allocation_tableau(nb_niv) ;
	 for (i = 0 ; i < nb_niv ; i++){
	 calcul_puissance_occupation(saison, Sniv[i].SURFACE_CL[3], taux_occup, ps_equip, &Ps_equip[i], &Ps_occup[i], &Pl_occup[i]) ;
	 }
	 */

	printf(
			"\n[ CALCUL DES FLUX SOLAIRES EXTERIEURS ABSORBES PAR TOUTES LES FACETTES DE LA GEOMETRIE ]\n");
	//===============================================================================================================

	// (1) tester si les flux solaires ont des valeurs negatives (validite
	// des donnees d'entree) et forcage des valeurs negatives a zero

	// (1.1) flux directs
	test_flux = test_tableau_val_positif(flux_sol_dir, nb_facette, &flux_min,
			&nb_err);
	if (!test_flux)
		printf(
				"\nAttention :\n\tTest des flux direct : %d valeurs negatives forcees a 0 (Fdir min =  %f)\n\t--> Calcul poursuivi\n",
				nb_err, flux_min);

	// (1.2) flux diffus
	test_flux = test_tableau_val_positif(flux_sol_diff, nb_facette, &flux_min,
			&nb_err);
	if (!test_flux)
		printf(
				"\nAttention :\n\tTest des flux diffus : %d valeurs negatives forcees a 0 (Fdiff min =  %f)\n\t--> Calcul poursuivi\n",
				nb_err, flux_min);

	// (2) calcul des valeurs

	flux_sol_abs = allocation_tableau_double(nb_facette);
	for (i = 0; i < nb_facette; i++) {
		flux_sol_abs[i] = (1.0 - albedo[i]) * (flux_sol_dir[i]
				+ flux_sol_diff[i]);
	}

	/*
	 printf("\n[ CALCUL DES FLUX SOLAIRES TRANSMIS DANS LE BATIMENT D'ETUDE ]\n");
	 //===============================================================================================================

	 // gestion des flux solaires transmis a l'interieur du(des) batiment(s) d'etude
	 // # attention (a voir ulterieurement) :
	 // pour une simulation avec plusieurs batiments etudies energetiquement	faire
	 // en sorte d'avoir des vecteurs flux transmis a l'interieur

	 Ft_mur = allocation_tableau(nb_niv) ;
	 Ft_vit = allocation_tableau(nb_niv) ;
	 Ft_plc = allocation_tableau(nb_niv) ;
	 Ft_plf = allocation_tableau(nb_niv) ;
	 Ft_int = allocation_tableau(nb_niv) ;

	 calcul_flux_solaires_int(Sniv, nb_facette, nb_niv, niveau, classe_paroi, flux_sol_dir, flux_sol_diff, transmission, surface, abs_plc, abs_vit, Ft_mur, Ft_vit, Ft_plc, Ft_plf, Ft_int) ; // f traitant uniquement les vitrages (classe 1) du batiment d'etude
	 */

	printf(
			"\n[ INITIALISATION DES TEMPERATURES DE TOUTES LES FACETTES EXTERIEURES ]\n");
	//===============================================================================================================

	// INITIALISATION DES TEMPERATURES DE SURFACE (ET DES NOEUDS DE "SOUS-FACE") DES FACETTES DE LA GEOMETRIE

	// (1) preambule, initialisation

	TSext = allocation_tableau_double(nb_facette); // temperature de surface des parois
	TNint1 = allocation_tableau_double(nb_facette); // temperature nodales int 1 des batiments et sols (hors batiment d'etude)
	TNint2 = allocation_tableau_double(nb_facette); // temperature nodales int 2 des batiments et sols (hors batiment d'etude)
	for (i = 0; i < nb_facette; i++) {
		TSext[i] = TSext_init[i];
		TNint1[i] = TNint1_init[i];
		TNint2[i] = TNint2_init[i];
	}
	free(TSext_init);
	free(TNint1_init);
	free(TNint2_init);

	// (2) re-initialisation des Tsurface de facettes (TSext) a la valeur T equivalente au soleil
	// Interet : meilleure initialisation du flux GLO, convergence des TSext plus rapide,
	// moins d'iterations

	for (i = 0; i < nb_facette; i++) {
		if ((int) (classe_paroi[i]) == 8) // ARBRES
		{
			TSext[i] = Text[i]; // temperature d'air
		} else // BATIMENTS(etude ou autres), SOLS
		{
			j = (int) id_paroi[i]; // pour selectionner les 1eres couches de materiaux des struct de parois corespondantes
			TSext[i] = Teq_soleil(tab_paroi, j, hc_ext[i], Text[i], TSext[i],
					flux_sol_abs[i]);
		}
	}
	free(tab_paroi); // ATTENTION :  si tab_paroi concerne les autres amenagements que les batiments

	/*
	 printf("\n[ INITIALISATION DES TEMPERATURES NODALES DU BATIMENT D'ETUDE ENERGETIQUE ]\n");
	 //===============================================================================================================

	 // INITIALISATION DES TEMPERATURES NODALES DU(DES) BATIMENT(S) D'ETUDE
	 // ATTENTION (A voir ulterieurement) :
	 //	# pour une simulation avec plusieurs batiments etudies energetiquement
	 //	# faire en sorte d'avoir des vecteurs de temperatures nodales pour chaque batiment

	 T2 = allocation_tableau(nb_niv) ;
	 T4 = allocation_tableau(nb_niv) ;
	 T5 = allocation_tableau(nb_niv) ;
	 T6 = allocation_tableau(nb_niv) ;
	 T7 = allocation_tableau(nb_niv) ;
	 T8 = allocation_tableau(nb_niv) ;
	 T9 = allocation_tableau(nb_niv) ;
	 T12 = allocation_tableau(nb_niv) ;
	 Tsol_bis = allocation_tableau(nb_niv) ;
	 inconnue = allocation_tableau(nb_niv) ;
	 T10air = allocation_tableau(nb_niv) ;
	 Pconv = allocation_tableau(nb_niv) ;

	 for (i = 0; i < nb_niv ; i++)
	 {
	 T2[i] = T2_init[i] ;
	 T4[i] = T4_init[i] ;
	 T5[i] = T5_init[i] ;
	 T6[i] = T6_init[i] ;
	 T7[i] = T7_init[i] ;
	 T8[i] = T8_init[i] ;
	 T9[i] = T9_init[i] ;
	 T10air[i] = T10air_init[i] ;
	 //Pconv[i] = 0 ;
	 }
	 T12[nb_niv-1] = T12_init[nb_niv-1] ;	// T12 calculee seulement avec les variables du dernier etage
	 Tsol_bis[0] = Tsol_bis_init[0] ;		// Tsol_bis calculee seulement avec les variables du RDC
	 */

	// CALCUL PRINCIPAL
	//##################################################################################################################

	printf(
			"\n[ CALCUL DES TEMPERATURES SURFACIQUES EXTERIEURES ET NODALES - BILAN DE PUISSANCE SENSIBLE ]\n");
	//===============================================================================================================

	// PREAMBULE : GESTION DES VARIABLES CALCULATOIRES
	//------------------------------------------------------------------------------------

	// OUVERTURE DU FICHIER DES FACTEURS DE FORME

	if ((pf_fform = fopen(nom_fform, "rb")) == NULL) {
		printf("\n  Impossible d'ouvrir '%s'\n\n", nom_fform);
		exit(0);
	}

	// ALLOCATIONS MEMOIRE VARIABLES DIVERSES

	// variables flux GLO

	GLO_Ciel_Emis = allocation_tableau_double(nb_facette);
	GLO_Ciel_Recu = allocation_tableau_double(nb_facette);
	GLO_Ciel_Net = allocation_tableau_double(nb_facette);
	GLO_Scene_Emis = allocation_tableau_double(nb_facette);
	GLO_Scene_Recu = allocation_tableau_double(nb_facette);
	GLO_Scene_Net = allocation_tableau_double(nb_facette);
	GLO_Total_Emis = allocation_tableau_double(nb_facette);
	GLO_Total_Recu = allocation_tableau_double(nb_facette);
	GLO_Total_Net = allocation_tableau_double(nb_facette);

	// pre-traitement du flux IR atmospherique recu (apres intereflexions)

	printf("\nBilan du flux meteo atomspherique IR :");
	calc_flux_atm_intereflexion(flux_atm, emissivite, surface, nb_facette,
			tab_nb_contour_face, tab_no_face, nb_face, pf_fform, fform, fciel,
			GLO_Ciel_Recu); // GLO_Ciel calcule en preambule -> seul flux GLO independant des iterations
	/*
	 // si batiment en site isole, pas d'intereflexions IR dans la scene
	 for (i = 0 ; i<nb_facette ; i++)
	 GLO_Ciel_Recu[i] = emissivite[i] * fciel[i] * flux_atm ;
	 */

	// variables tampons pour toutes les surfaces de la geometrie

	TSext_old_1 = allocation_tableau_double(nb_facette);
	TSext_old_2 = allocation_tableau_double(nb_facette);
	TNint1_TEMP = allocation_tableau_double(nb_facette);
	TNint2_TEMP = allocation_tableau_double(nb_facette);

	// allocations matrices/vecteurs pour calcul surfaces batiments generiques

	matBAT = allocation_tableau_double(4);
	vecBAT_in = allocation_tableau_double(2);
	vecBAT_out = allocation_tableau_double(2);

	// allocations matrices/vecteurs pour calcul surfaces sols

	matSOL = allocation_tableau_double(9);
	vecSOL_in = allocation_tableau_double(3);
	vecSOL_out = allocation_tableau_double(3);

	// pas d'allocation pour les arbres et pour les autres amenagements

	// allocation memoire des matrices et vecteurs de resolution pour batiment de calcul energetique
	/*
	 // calcul du nombre de facettes du batiment d'etude :
	 // tests comparatifs entre descripteur de classe associee (1)
	 // et descripteur de murs+vitrages+toiture (2) niveaux
	 // (attention !!! rajouter un test pour savoir s'il y a bien un batiment d'etude)

	 nb_facette_bat = 0 ;
	 j = 0 ;
	 for (i = 0; i < nb_facette ; i++){
	 //calcul avec les niveaux
	 if((niveau[i] >= 0) && (niveau[i] < nb_niv)){
	 j++ ;
	 }
	 // calcul avec les classes de parois
	 switch ((int)(classe_paroi[i])){
	 case 0 : nb_facette_bat++ ; break ;
	 case 1 : nb_facette_bat++ ; break ;
	 case 2 : nb_facette_bat++ ; break ;
	 default : break ;
	 }
	 }
	 // comparaison
	 if (nb_facette_bat != j)
	 {
	 printf("\n\tATTENTION, probleme dans le calcul des facettes de batiment d'etude...") ;
	 printf("\n\tVerifier les descripteurs de niveaux et de classes\n\n") ;
	 exit(0) ;
	 }
	 j = 0 ;
	 printf("\n\nCaracteristiques du batiment d'etude :") ;
	 printf("\nNombre de facettes correspondant au batiment d'etude : %d", nb_facette_bat) ;

	 n = nb_facette_bat + nb_niv * 8 + 2 ; // nb de noeuds de calcul
	 nn = n*n ; // dim de la matrice batiment
	 A = allocation_tableau(nn); // matrice de calcul batiment
	 b = allocation_tableau(n); // vecteur de calcul batiment
	 T = allocation_tableau(n) ; // vecteur resultat batiment
	 alpha = allocation_tableau_int(nb_niv);	// indicateur de regime
	 */

	// BOUCLE DE CALCUL DES TEMPERATURES INCONNUES (surfaces geometrie et noeuds batiment) ET DE LA PUISSANCE CONVECTIVE
	//##################################################################################################################

	// demarrage chronometre
	dateDebut = clock();

	// def criteres d'arret de la boucle ((2))
	iter = 0; // initialisation nb iterations
	eps1 = 0.20; // ecart max autorise
	eps2 = 0.05; // moyenne max des ecart autorisee
	ratio_face_non_cv = (int) (0.005 * nb_facette); // nb max de face non conv apres 30 iterations (0.5% du total de facettes)
	n_face_non_cv_old_1 = 0; // nb facettes non CV, iteration courante
	n_face_non_cv_old_2 = 0; // nb facettes non CV, iteration precedente
	/*
	 // gestion du regime thermique du batiment de calcul (libre/force/mixte)
	 switch (alpha_arg)
	 {
	 case 0 : // regime force (T10air = Tconsigne utilisateur)
	 for (i = 0; i < nb_niv ; i++)
	 alpha[i] = 0 ;
	 break ;
	 case 1 : // regime libre (T10air en evolution libre, Pconv = 0)
	 for (i = 0; i < nb_niv ; i++)
	 alpha[i] = 1 ;
	 break ;
	 case 2 : // regime mixte (on part a priori sur une simulation en evolution libre avant d'imposer chauff ou clim)
	 for (i = 0; i < nb_niv ; i++)
	 alpha[i] = 1 ;
	 break ;
	 }
	 */
	// boucle ((1)) sur le critere de respect des temperature de consignes Tair(niv) si regime force 
	//##################################################################################################################
	/*
	 do
	 {
	 // affichage regime de simulation batiment
	 printf("\nRegime thermique du batiment (force[0], libre[1], mixte[2]) : %d", alpha_arg) ;

	 // remplissage de la matrice de resolution en fonction du alpha
	 remplissage_matrice_modele_batiment(A, n, nb_facette, nb_niv, niveau, nb_paroi, id_paroi, classe_paroi, surface, Sniv, in_air, dt, alpha, hc_ext, RCmur, RCvit, RCtoit, RCplc_int, RCplc_bas, RCint, Rcv_i, Rrad_i, Rra, Cai, Rsol, Csol);


	 // boucle ((2)) sur le(s) critere(s) d'arret (eps1 & eps2) pour la convergence des temperatures de surface
	 //##################################################################################################################

	 printf("\n\nDEBUT DU CALCUL ITERATIF :\n") ;
	 */
	do {
		// affichage iteration courante
		printf("\n\n-------------\niteration %d", iter);

		// MISE A JOUR DES VARIABLES DE CALCUL DES TEMPERATURES DE SURFACE
		//------------------------------------------------------------------------------------

		printf("\n\tMise a jour des temperatures de surface de la scene");

		for (i = 0; i < nb_facette; i++) {
			// MAJ temperature avant derniere iteration
			if (iter == 0)
				TSext_old_2[i] = TSext[i];
			else
				TSext_old_2[i] = TSext_old_1[i];

			// MAJ temperature derniere iteration
			TSext_old_1[i] = TSext[i];

			// MAJ des coefficients de sous relaxation
			// solution sous-relax 1
			lambda_relax = 1;
			if (iter > 10)
				lambda_relax = 0.8;
			if (iter > 20)
				lambda_relax = 0.7;
			if (iter > 30)
				lambda_relax = 0.6;
			if (iter > 40)
				lambda_relax = 0.5;

			// solution sous-relax 2
			//lambda_relax = 1 ;
			//if((iter > 2)&&((n_face_non_cv_old_2 - n_face_non_cv_old_1) < 100)) lambda_relax = 0.75 ;
			//if((iter > 2)&&((n_face_non_cv_old_2 - n_face_non_cv_old_1) < 10)) lambda_relax = 0.5 ;

			// solution sous-relax 3
			//if(iter <= 10) lambda_relax = 1 ;
			//if((iter > 10)&&(iter <= 50)) lambda_relax = 1.125 - (0.5/40)*iter ;
			//if(iter > 50) lambda_relax = 0.5 ;

			// MAJ temperature de surface courante
			TSext[i] = (lambda_relax * TSext_old_1[i]) + ((1 - lambda_relax)
					* TSext_old_2[i]);
		}

		// CALCUL DES FLUX GLO_TOTAL_NET ECHANGES (GLOBAL ET DETAIL AVEC LES AUTRES SURFACES ET AVEC LE CIEL)
		//------------------------------------------------------------------------------------

		printf("\n\tBilan des flux radiatifs GLO");

		for (i = 0; i < nb_facette; i++) {
			GLO_Total_Net[i] = calc_GLO(i, nb_facette, fciel[i], TSext,
					pf_fform, fform, emissivite, GLO_Ciel_Emis, GLO_Ciel_Recu,
					GLO_Ciel_Net, GLO_Scene_Emis, GLO_Scene_Recu,
					GLO_Scene_Net, GLO_Total_Emis, GLO_Total_Recu);
		}

		// CALCULS CONCERNANT LES SURFACES DES AMENAGEMENTS (modeles "facettes independantes")
		//------------------------------------------------------------------------------------

		printf(
				"\n\tCalcul des TSext des batiments / sols / arbres / autres amenagements");

		for (i = 0; i < nb_facette; i++) {

			// FACETTES DE BATIMENTS GENERIQUES

			if ((int) classe_paroi[i] == 6) {
				// generation des matrices et vecteurs de calcul
				remplissage_matrice_modele_facetteBAT(matBAT, id_paroi[i],
						RCsurf_bat, h_int_bat, hc_ext[i], dt);
				remplissage_vecteur_modele_facetteBAT(vecBAT_in, id_paroi[i],
						RCsurf_bat, h_int_bat, hc_ext[i], dt, flux_sol_abs[i],
						GLO_Total_Net[i], Text[i], TSext[i], TNint1[i],
						TNint2[i]);

				// resolution
				resolutionSystemeLineaire_LINUX(matBAT, vecBAT_in, vecBAT_out,
						2); // LINUX
				//resolutionSystemeLineaire_WINDOWS(matBAT, vecBAT_in, vecBAT_out, 2); // WINDOWS

				// mise a jour des solutions
				TSext[i] = vecBAT_out[0];
				TNint1_TEMP[i] = vecBAT_out[1]; // copie des temperatures nodales face interieure des batiments dans un vecteur tampon
				// TNint2 ne sont pas modifiees car correspondent a la temperature de consigne
				// interieure fixee par l'utilisateur
			}

			// FACETTES DE SOLS

			if ((int) classe_paroi[i] == 7) {
				// calcul du flux latent
				Flux_Latent[i] = calcul_flux_latent(flux_sol_abs[i],
						GLO_Total_Net[i], Text[i], w_ext[i], hc_ext[i],
						f_evap_sol[i]);

				// generation des matrice et vecteur de calcul
				remplissage_matrice_modele_sol(matSOL, id_paroi[i], hc_ext[i],
						RCsurf_sol, Rsol, Csol, dt);
				remplissage_vecteur_modele_sol(vecSOL_in, id_paroi[i],
						TSext[i], TNint1[i], TNint2[i], Text[i], Tsol_ref,
						flux_sol_abs[i], GLO_Total_Net[i], Flux_Latent[i],
						hc_ext[i], RCsurf_sol, Rsol, Csol, dt);

				// resolution
				resolutionSystemeLineaire_LINUX(matSOL, vecSOL_in, vecSOL_out,
						3); // LINUX
				//resolutionSystemeLineaire_WINDOWS(matSOL, vecSOL_in, vecSOL_out, 3); // WINDOWS

				// mise a jour des solutions
				TSext[i] = vecSOL_out[0];
				TNint1_TEMP[i] = vecSOL_out[1]; // copie des temperatures nodales 1 dans un vecteur tampon
				TNint2_TEMP[i] = vecSOL_out[2]; // copie des temperatures nodales 2 dans un vecteur tampon
			}

			// FACETTES DES ARBRES

			// le modele thermoradiatif ne modifie par les temperatures de surface des arbres
			// la temperture de surface des arbres est la temperature d'air exterieure meteo (ou issue du couplage)
			// en mode couplage la temperature de feuillage est calculee dans Fluent durant les iterations
			// et assimilee a une temperature d'air

			// calcul specifique du flux radiatif total absorbe par le feuillage pour sortie couplage (donnee entree CFD)
			if ((int) classe_paroi[i] == 8) {
				Flux_Rad_Net_Abs[i] = ((1.0 - albedo[i] - transmission[i])
						* flux_sol_dir[i]) + ((1.0 - albedo[i])
						* flux_sol_diff[i]) - GLO_Total_Net[i];
			}

			// FACETTES DES AUTRES AMENAGEMENTS (EAU...)

			// pour l'instant pas d'autres modeles

		}
		/*
		 // CALCULS CONCERNANT LE BATIMENT D'ETUDE ENERGETIQUE
		 //------------------------------------------------------------------------------------

		 printf("\n\tCalcul des TSext du batiment de calcul energetique") ;

		 // remplissage du vecteur du syseme lineaire POUR LE BAT D'ETUDE (varie a chaque pas de calcul)
		 remplissage_vecteur_modele_batiment(b, n, nb_facette, nb_niv, niveau, nb_paroi, id_paroi, classe_paroi, surface, Sniv, in_air, dt, alpha, hc_ext, Text, TSext, T2, T4, T5, T6, T7, T8, T9, T10consigne, T10air, T12, RCmur, RCvit, RCtoit, RCplc_int, RCplc_bas, RCint, Rcv_i, Rrad_i, Rra, Cai, Rsol, Csol, Tsol_ref, Tsol_bis, flux_sol_abs, GLO_Total_Net, Ft_mur, Ft_vit, Ft_plc, Ft_plf, Ft_int, Ps_equip, Ps_occup);

		 // resolution Systeme Lineaire
		 resolutionSystemeLineaire_LINUX(A, b, T, n); // LINUX
		 //resolutionSystemeLineaire_WINDOWS(A, b, T, n); // WINDOWS

		 // mise a jour des temperatures de surfaces iterees (TSext) a partir du vecteur T resolu
		 // ATTENTION : les Tniv_init servent ici de "tampon" pour ne pas ecraser les Tniv
		 // elles prennent la valeur des temperatures calculees a l'iteration courante (modification uniquement des TSext)
		 vecteurT_vers_variablesT(T, n, nb_facette, nb_niv, niveau, nb_paroi, id_paroi, classe_paroi, TSext, T2_init, T4_init, T5_init, T6_init, T7_init, T8_init, T9_init, T10air_init, T12_init, Tsol_bis_init) ;
		 */
		// TEST DE CONVERGENCE DES TEMPERATURE DE SURFACE
		//------------------------------------------------------------------------------------

		printf("\n\tTest de convergence des TSext");

		test_Ts = 0;
		somme_deltaT = 0;
		n_face_non_cv_old_2 = n_face_non_cv_old_1;
		for (i = 0; i < nb_facette; i++) {
			deltaT = fabs(TSext[i] - TSext_old_1[i]);
			if (deltaT > eps1)
				test_Ts++; // on rajoute 1 au test si l'ecart indiv depasse eps1
			somme_deltaT += deltaT;
		}
		n_face_non_cv_old_1 = test_Ts;
		somme_deltaT = somme_deltaT / nb_facette;
		if (somme_deltaT > eps2)
			test_Ts++; // on rajoute 1 au test si l'ecart global moyen depasse eps2

		printf("\n\t-------------");
		printf("\n\tNombre de TSext non convergees : %d [sur %d]",
				n_face_non_cv_old_1, nb_facette);
		printf("\n\tMoyenne des ecarts de TSext : %.4f", somme_deltaT); // TEST

		// TEST DE LA DERNIERE CHANCE !!! (FORCAGE)
		//------------------------------------------------------------------------------------

		if (iter > 49) // FORCAGE : on ne va pas au dela de 50 iterations
		{
			if (test_Ts < ratio_face_non_cv) // si seulement 0.5% des facettes reste non convergee
			{
				printf(
						"\nPlus de 99.5% des TSext convergees au bout de 50 iter : simulation stopee",
						'%');
				break;
			} else {
				printf(
						"\nSimulation stopee au bout de 50 iterations sans convergence stricte");
				break;
			}
		}
		iter++;
	} while (test_Ts); // rebouclage tant que test_Ts n'est pas =0

	//##################################################################################################################
	// fin de boucle(2)

	/*
	 // TEST POUR CHANGER DE REGIME (LIBRE --> FORCE) EN FONCTION DE LA VALEUR DE TEMPERATURE OBTENUE AU NOEUD 10
	 //------------------------------------------------------------------------------------

	 test_Tconsigne = 0 ;
	 switch (alpha_arg)
	 {
	 case 0 : // regime FORCE (T10air = Tconsigne utilisateur)
	 break ;
	 case 1 : // regime LIBRE (T10air en evolution libre, Pconv = 0)
	 break ;
	 case 2 : // regime MIXTE (on choisi entre libre et force en fonction d'un test entre Tair et Tconsigne)
	 // on teste alors la valeur de ce qu'il y a dans la variable
	 // T10air_init "tampon" (cf. mise a jour des temperatures de surfaces iterees TSext)
	 switch (saison)
	 {
	 case 0 : // cas ETE
	 if (taux_occup == 0.0)		// innoccupation : Tair flottante (pas de test)
	 break ;
	 else	// occupation : Tair doit etre =< a la consigne clim
	 {
	 for (i = 0 ; i < nb_niv ; i++)
	 {
	 if ((alpha[i] == 1) && (T10air_init[i] > Tc_occup_ete))
	 {
	 printf("\nTair Niveau%d = %f --> Besoin CLIM", i, T10air_init[i]) ;
	 test_Tconsigne++ ;
	 alpha[i] = 0 ;					// declencher la clim a cet etage
	 T10consigne = Tc_occup_ete ;	// definir la consigne associee
	 }
	 }
	 }
	 break ;
	 case 1 : // cas HIVER
	 if (taux_occup == 0.0)		//  innoccupation : Tair doit etre >= a la consigne chauff nuit
	 {
	 for (i = 0 ; i < nb_niv ; i++)
	 if ((alpha[i] == 1) && (T10air_init[i] < Tc_inoccup_hiv))
	 {
	 printf("\nTair Niveau%d = %f --> Besoin CHAUF (N)", i, T10air_init[i]) ;
	 test_Tconsigne++ ;
	 alpha[i] = 0 ;					// declencher le chauff a cet etage
	 T10consigne = Tc_inoccup_hiv ;	// definir la consigne associee
	 }
	 }
	 else	// occupation : Tair doit etre >= a la consigne chauff jour
	 {
	 for (i = 0 ; i < nb_niv ; i++)
	 if ((alpha[i] == 1) && (T10air_init[i] < Tc_occup_hiv))
	 {
	 printf("\nTair Niveau%d = %f --> Besoin CHAUF (J)", i, T10air_init[i]) ;
	 test_Tconsigne++ ;
	 alpha[i] = 0 ;					// declencher le chauff a cet etage
	 T10consigne = Tc_occup_hiv ;	// definir la consigne associee
	 }
	 }
	 break ;
	 }
	 }
	 }
	 while (test_Tconsigne) ; // rebouclage tant que test_Tconsigne n'est pas =0

	 //##################################################################################################################
	 // fin de boucle(1)
	 */
	// RAPPORT D'EXECUTION DU CALCUL ITERATIF

	dateFin = clock(); // arret chronometre
	printf("\n----------------------");
	printf("\nRAPPORT FINAL :");
	printf("\n%d iterations", (iter - 1));
	printf("\nMoyenne des ecarts de Ts(exterieures) : %f", somme_deltaT);
	printf("\n----------------------\n");

	printf("\n[ MISE A JOUR DES RESULTATS ]\n");
	//------------------------------------------------------------------------------------

	// MISE A JOUR DES TEMPERATURES COURANTES A PARTIR DU VECTEURS RESULTATS

	// parois des batiments

	for (i = 0; i < nb_facette; i++)
		if ((int) classe_paroi[i] == 6) {
			// la temperature de surface TSext[i] est deja attribuee dans la boucle de calcul,
			// il reste uniquement a renseigner les temperatures nodales
			TNint1[i] = TNint1_TEMP[i];
		}

	// sols

	for (i = 0; i < nb_facette; i++)
		if ((int) classe_paroi[i] == 7) {
			// la temperature de surface TSext[i] est deja attribuee dans la boucle de calcul,
			// il reste uniquement a renseigner les temperatures nodales
			TNint1[i] = TNint1_TEMP[i];
			TNint2[i] = TNint2_TEMP[i];
		}

	// arbres

	// pas de temperature nodales pour les arbres


	// autres amenagements

	// pour l'instant pas d'autres modeles d'amenagement supplementaires


	// batiment d'etude
	/*
	 // mise a jour des temperatures et de la puissance convective
	 vecteurT_vers_variablesT(T, n, nb_facette, nb_niv, niveau, nb_paroi, id_paroi, classe_paroi, TSext, T2, T4, T5, T6, T7, T8, T9, inconnue, T12, Tsol_bis) ;
	 for (i = 0; i < nb_niv ; i++)
	 {
	 switch (alpha[i])
	 {
	 case 0 : // regime force (T10air = Tconsigne)
	 T10air[i] = T10consigne ;
	 Pconv[i] = inconnue[i] ;
	 break ;
	 case 1 : // regime libre (T10air en evolution libre, Pconv = 0)
	 T10air[i] = inconnue[i] ;
	 Pconv[i] = 0 ;
	 break ;
	 }
	 }
	 // bilan de puissance latente
	 Platent = allocation_tableau(nb_niv) ;
	 for (i = 0 ; i < nb_niv ; i++){
	 Platent[i] = bilan_vapeur_eau(T10air[i], Sniv[i].SURFACE_CL[3], taux_occup_max, debit_hyg_indiv, Pl_occup[i], w_ext[i]) ;
	 }
	 */
	// DESALLOCATION MEMOIRE DES VARIABLES DE CALCUL
	//------------------------------------------------------------------------------------

	// description de la geometrie
	fclose(pf_fform); // fermeture du fichier des facteurs de forme .fac
	free(fform);
	free(fciel);
	free(surface);
	free(id_paroi);
	free(classe_paroi);
	/*	free(in_air) ;
	 free(niveau) ;
	 free(Sniv) ; */

	// variables et parametres physiques d'entree
	free(hc_ext);
	free(f_evap_sol);
	free(emissivite);
	free(albedo);
	free(transmission);
	free(flux_sol_dir);
	free(flux_sol_diff);
	/*	free(Ft_mur) ;
	 free(Ft_vit) ;
	 free(Ft_plc) ;
	 free(Ft_plf) ;
	 free(Ft_int) ;
	 free(RCmur) ;
	 free(RCvit) ;
	 free(RCtoit) ;
	 free(RCplc_int) ;
	 free(RCplc_bas) ;
	 free(RCint) ;
	 free(Rcv_i) ;
	 free(Rrad_i) ;
	 free(Cai) ;
	 free(Rra) ;*/

	// outils maths
	/*	free(A) ;
	 free(b) ;
	 free(T) ;*/
	free(matBAT);
	free(vecBAT_in);
	free(vecBAT_out);
	free(matSOL);
	free(vecSOL_in);
	free(vecSOL_out);

	// temperatures
	free(Text);
	free(TSext_old_1);
	free(TSext_old_2);
	free(TNint1_TEMP);
	free(TNint2_TEMP);
	/*	free(inconnue) ;
	 free(T10air_init) ;
	 free(T2_init) ;
	 free(T4_init) ;
	 free(T5_init) ;
	 free(T6_init) ;
	 free(T7_init) ;
	 free(T8_init) ;
	 free(T9_init) ;
	 free(T12_init) ;
	 free(Tsol_bis_init) ; */

	printf("\n[ STOCKAGE DES RESULTATS ]\n");
	//------------------------------------------------------------------------------------

	// TEMPERATURES DE SURFACES EXT CALCULEES
	complement_extension(nom_fic_TSext, argv[22], "val");
	stocke_fichier_val(nom_fic_TSext, nb_face, no_face_max, nb_facette,
			tab_no_face, tab_nb_contour_face, TSext);
	free(TSext);
	ext_tps_val = nom_fic_TSext + (strlen(nom_fic_TSext) - 14);

	// TEMPERATURES NODALES INT 1 CALCULEES
	complement_extension(nom_fic_TNint1, argv[23], "val");
	stocke_fichier_val(nom_fic_TNint1, nb_face, no_face_max, nb_facette,
			tab_no_face, tab_nb_contour_face, TNint1);
	free(TNint1);

	// TEMPERATURES NODALES INT 2 CALCULEES
	complement_extension(nom_fic_TNint2, argv[24], "val");
	stocke_fichier_val(nom_fic_TNint2, nb_face, no_face_max, nb_facette,
			tab_no_face, tab_nb_contour_face, TNint2);
	free(TNint2);

	// STOCKAGE DES FICHIERS OPTIONNELS
	//------------------------------------------------------------------------------------

	// variables necessaires pour le couplage

	sprintf(nom_fic_Flux_Latent, "flux_latent%s", ext_tps_val);
	stocke_fichier_val(nom_fic_Flux_Latent, nb_face, no_face_max, nb_facette,
			tab_no_face, tab_nb_contour_face, Flux_Latent);
	free(Flux_Latent);

	sprintf(nom_fic_Flux_Rad_Net_Abs, "flux_rad_arbre%s", ext_tps_val);
	stocke_fichier_val(nom_fic_Flux_Rad_Net_Abs, nb_face, no_face_max,
			nb_facette, tab_no_face, tab_nb_contour_face, Flux_Rad_Net_Abs);
	free(Flux_Rad_Net_Abs);

	// variables supplementaires pour analyse : flux GLO, flux solaires, humidite relative...

	sprintf(nom_fic_humidite_rel_air, "humidite_relative%s", ext_tps_val);
	stocke_fichier_val(nom_fic_humidite_rel_air, nb_face, no_face_max,
			nb_facette, tab_no_face, tab_nb_contour_face, humidite_rel_air);
	free(humidite_rel_air);

	// DESALLOCATION DES VARIABLES OPTIONELLES NON STOCKEES
	//------------------------------------------------------------------------------------

	free(GLO_Ciel_Emis);
	free(GLO_Ciel_Recu);
	free(GLO_Ciel_Net);
	free(GLO_Scene_Emis);
	free(GLO_Scene_Recu);
	free(GLO_Scene_Net);
	free(GLO_Total_Emis);
	free(GLO_Total_Recu);
	free(GLO_Total_Net);

	free(flux_sol_abs);

	free(tab_no_face);
	free(tab_nb_contour_face);

	// FIN
	//------------------------------------------------------------------------------------

	// chronometre
	printf("\n----------------------");
	printf("\nDuree totale de traitement %5.3f secondes", (double) (dateFin
			- dateDebut) / (double) CLOCKS_PER_SEC);
	printf("\n----------------------\n");

	// fin
	printf("\n[ EXECUTION OK ]\n\n");
	return EXIT_SUCCESS;
}


/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/*
cc inverse_normale.c solutile.o  geomutile.o lib_solene_94.o -o inverse_normale -lm
*/

/*
Inversion de la normale des faces selectionnees d'un fichier .cir
*/

#include<solene.h>
#include<ctype.h>
#include <stdlib.h>
#include <sys/stat.h>

int numax;
FILE *pf1;
int nbf1;
struct modelisation_face *f1;
char buf[512];
/*_________________________________________________________________*/
main(argc,argv) 
int argc;char **argv;
{int k,i,j;
 int deb,fin;
 double englob[10];
 char s1[10],s2[10],*s,*ch,*s_dir;
 struct contour *pcont;
 struct circuit *pcir;

 if(argc<4)format_entree_inverse_normale_fic();

	s_dir=(char *)getenv("PWD");


   printf("\n INVERSION DES NORMALES D'UN FICIHIER \n");

  compose_nom_complet(buf,s_dir,argv[1],"cir");
  if((pf1=fopen(buf,"r"))==NULL)
      { printf("\n impossible ouvrir %s\n",buf); exit(0);
      }
  printf(" %s \n",buf);

  /* realise traitement */

  lit_en_tete(pf1,&nbf1,&numax,englob);
  f1=alloue_face(nbf1,35);
  lit_fic_cir3d(pf1,nbf1,f1);
  fclose(pf1);

        /* lit les no et inverse les normales */
    i=2;
    do
      { i++; *s1=0; *s2=0;
        s=s1;ch=argv[i];
	if(*ch!='-'|| *(ch+1)!='n')
         {while(*ch)
           {if(*ch=='-'){*s=0; s=s2;}
            else {*s=*ch;s++;}
            ch++;
           }
         *s=0;
         sscanf(s1,"%d",&deb);
         if(*s2)sscanf(s2,"%d",&fin);
         else fin=deb;

         /*printf("\n deb = %d fin = %d ",deb,fin);*/
        }
	else {deb=0; fin=numax;}

printf("\n");
        for(k=deb;k<=fin;k++)
           {for(j=0;j<nbf1;j++){if(f1[j].nofac_fichier==k)break;}
     /* on suppose que le sens du citcuit est en accord avec la normale */

	    if(j!=nbf1)
              { /*printf("face no %d\n",k);*/
	       f1[j].vnorm[0]=-f1[j].vnorm[0];
               f1[j].vnorm[1]=-f1[j].vnorm[1];
               f1[j].vnorm[2]=-f1[j].vnorm[2];
	       pcont=f1[j].debut_projete;
	       while(pcont)
		{pcir=pcont->debut_support;
                 invsens(pcir);
		 pcir=pcont->debut_interieur;
	         while(pcir)
			{invsens(pcir);
			 pcir=pcir->suc;
			}
		 pcont=pcont->suc;
		}
	      }
           }
      }while(i!=argc-1);

/* stocke le fichier */
 compose_nom_complet(buf,s_dir,argv[2],"cir");
   pf1=fopen(buf,"w");
    if(pf1==NULL) 
	{ printf("impossible creer %s\n",buf);
	  exit(0);
	}
   ecrit_en_tete(pf1,nbf1,numax,englob);
   output_face_sur_fichier(f1,nbf1,1,0,pf1,&k,&numax);
  fclose(pf1); 
   desalloue_fface(f1,nbf1); 

   creer_OK_Solene();
   printf("\n");

}
/*_________________________________________________________________*/
int format_entree_inverse_normale_fic()
{
     printf("\n *inverse_normale* fichier_in(.cir) fichier_out(.cir) no1|no1-no2 ----- [-n]\n");

     printf("\n -n : inversion de tout le fichier \n");

  exit(0);
}

/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/* l_descendant.c :



 D. GROLEAU dec 2003




ENERGIE atmosph�rique L descendant GLO RECUE DU CIEL 
en tenant compte de valeurs de r�f�rences L descendant atmospherique relev�es in situ sur un plan horizontal
et des facteurs de ciel des �l�ments de la g�om�trie

  L_descendant = Fciel * Flux_atmosph�rique_descendant_m�t�o

*/

#include<solene.h>



// DECLARE FUNCTIONS



void calcul_min_max();
int lit_fic_meteo();
float lit_val_meteo();
void met_extension();
void test_min_max();
void usage();

// EN GLOBAL

#define HMAX 288  // donnees meteo entrees par pas de 5 minutes au maximum


/*_________________________________________________________________*/
main(argc,argv) 
int argc;char **argv;
{
	int nofac,nbcont;

 	char nom_facciel[256],nom_out[256],buf[256];
	char *s_dir,c;
 	FILE *fpval1,*fp_out,*fpmeteo;

	int hh1,hh2,pas,minute,temps;
	char extension[16];

	int		nb_val_meteo;
	int		meteo_temps[HMAX];
	float	meteo_flux_hor[HMAX];
	int		h_trans;

    int 	i,j,gk;
	float	vmin_gen,vmax_gen,valeur,val_meteo;
	double	fciel;

	int		nb_pas;
	float	xh_heure;
	int		h_heure,m_minute;

 printf("\nCommande Solene :  l_descendant\n");
 printf("\nL_descendant = Fciel * Flux_atmosph�rique_descendant_m�t�o\n\n");
	s_dir=(char *)getenv("PWD");

 if(argc != 7 && argc != 8) usage();
 
// lecture parametres commande 

//ouvre fichier Facteurs de ciel
compose_nom_complet(nom_facciel,s_dir,argv[1],"val");  
printf("  facteurs de ciel: %s \n", nom_facciel);
if((fpval1=fopen(nom_facciel,"r"))==NULL)
        { printf("\n impossible ouvrir %s\n",nom_facciel); 
          exit(0);
        }

//  heure debut et fin ; pas

    sscanf(argv[2],"%d%c%d",&hh1,&c,&minute);
    printf("evalue de  %dH%d",hh1,minute);
    hh1=hh1*60+minute;
    sscanf(argv[3],"%d%c%d",&hh2,&c,&minute); 
    printf(" a  %dH%d",hh2,minute);
    hh2=hh2*60+minute;
    sscanf(argv[4],"%d%c%d",&pas,&c,&minute);
    printf(" par pas de  %dH%d\n",pas,minute);
    pas=pas*60+minute;

    // calcul du nbre de pas
    nb_pas=1;
    i=hh1;
    while(i<hh2)
    { nb_pas++;
      i=i+pas;
    }
    printf("nb de pas %d\n",nb_pas);

   if(nb_pas > HMAX)
	{ printf("trop de fichiers en sortie max %d\n",HMAX);
	  exit(0);
	}

// fichier de donn�es METEO : heure minute flux_atmospherique_au_sol

   compose_nom_complet(buf,s_dir,argv[5],"txt");
   printf("  fichier meteo : %s \n", buf);
   if((fpmeteo=fopen(buf,"r"))==NULL)
        { printf("\n impossible ouvrir %s\n",buf); 
          exit(0);
        }
   nb_val_meteo = lit_fic_meteo(fpmeteo,meteo_temps,meteo_flux_hor);
   fclose(fpmeteo);

   if(nb_val_meteo ==0)
    { printf("fichier meteo vide \n");
       exit(0) ;
    }

// translation en heure en sortie
    h_trans=0;
    if(argc ==8)
     {  sscanf(argv[7],"%d",&h_trans);
     }

/* constitue le fichier .val L_descendant */
/* avec les valeurs en fonction du temps */

 printf(" Cree les fichiers de Descripteur resultat  : \n");

  temps=hh1;
   for(i=0;i<nb_pas;i++)
   { 
	xh_heure= (float)temps/60;
	h_heure= (int) xh_heure;
	m_minute= temps-h_heure*60;
	printf(" heure_minute %d H %d\n",h_heure,m_minute);

      // cherche_valeur meteo
    val_meteo=lit_val_meteo(temps,nb_val_meteo,meteo_temps,meteo_flux_hor);
	printf("valeur meteo Ldescendant : %f\n",val_meteo);

	// appel extension avec decalage
	met_extension(temps+h_trans*60,extension);

	// ouvre val resultat en Output
	sprintf(nom_out,"%s%s",argv[6],extension);

    compose_nom_complet(buf,s_dir,nom_out,"val");
    printf("			descripteur val resultat : %s \n", nom_out);

    if ((fp_out=fopen(buf,"w"))==NULL)
      { printf("\n  impossible ouvrir %s\n\n", buf); 
	    exit(0);
      }
      
      // Lit en effectuant l'op�ration et �crit le resultat
          fscanf(fpval1,"%d %d %f %f",&nbfac,&nomax,&vmin_gen,&vmax_gen);	
          fprintf(fp_out,"%6d %6d %15.4f %15.4f\n",nbfac,nomax,vmin_gen,vmax_gen);	
	// calcule min_max pour le pas   
            vmin_gen=10000000.; vmax_gen=-vmin_gen;

      for(j=0;j<nbfac;j++)
      { 
        fscanf(fpval1,"\n%c%d%d\n",&c,&nofac,&nbcont);
	    fprintf(fp_out,"f%d %d\n",nofac,nbcont);

	    for(gk=0;gk<nbcont;gk++) 
         { fscanf(fpval1,"%lf\n",&fciel);
           // calcule valeur
           valeur = (float)(val_meteo * fciel);
	       calcul_min_max(valeur,&vmin_gen,&vmax_gen);
           // enregistre valeur
           fprintf(fp_out,"%12.4f\n",valeur);
		}
	  }

     rewind(fpval1);
     rewind(fp_out);
     fprintf(fp_out,"%6d %6d %15.4f %15.4f\n",nbfac,nomax,vmin_gen,vmax_gen);	
     fclose(fp_out);

     temps+=pas;

  }  // fin for i (nb de pas)


	creer_OK_Solene();

 printf("\n\nFin du traitement l_descendant\n");
 exit(0);
}



/*_________________________________________________________________*/
void calcul_min_max(valeur,val_min,val_max)
float valeur;
float *val_min,*val_max;

{ if(valeur<*val_min) *val_min= (float) valeur;
  if(valeur>*val_max) *val_max= (float) valeur;
}

/*------------------------------------------------------------*/
float lit_val_meteo(temps,nb_val_meteo,meteo_temps,meteo_val)
int		temps, nb_val_meteo;
int		*meteo_temps;
float	*meteo_val;
{
  int i, ecart_t, delta_t;
  float ecart_v, valeur;

  // soit trouve la valeur au temps (en minutes) exact, soit interpole entre 2 valeurs encadrant le temps choisi
   //printf("lit_val pour %d H %d\n",heure,minute);

	for (i=0;i<nb_val_meteo;i++)
	{
	  if(temps == meteo_temps[i]) return(meteo_val[i]);
	  if(temps < meteo_temps[i])
	  { if (i ==0) return(meteo_val[0]);
	    else
		{ ecart_t = meteo_temps[i] - meteo_temps[i-1];
		  delta_t = temps - meteo_temps[i-1];
		  ecart_v = meteo_val[i] - meteo_val[i-1];
		  valeur = meteo_val[i-1] + (ecart_v * delta_t)/ecart_t;
		  return(valeur);
		}
	  }
	}
	return(meteo_val[nb_val_meteo-1]);
}

/*------------------------------------------------------------*/

int lit_fic_meteo(fp,meteo_temps,meteo_valeur)
FILE	*fp;
int		*meteo_temps;
float	*meteo_valeur;
{
int i,id, hh, mm;
	i=0;
	while(1)
	{ if (i > HMAX)
		{ printf("trop de lignes dans le fichier meteo (max %d)\n\n",HMAX);
		  exit(0);
		}
	  id= fscanf(fp,"%d %d %f", &hh,&mm,meteo_valeur+i);
	  if(id==EOF) break;
	  //printf("i =%d %d %d %f \n",i,hh,mm,meteo_valeur[i] );

	  meteo_temps[i]= 60*hh + mm;
	  i++;
	}
	printf("	nombre de lignes lues dans le fichier de meteo : %d\n",i);
	return(i);
}

//_____________________________________________________

void met_extension (temps,extension)
int temps;
char *extension;
{
	float xh_heure;
	int h_heure, m_minute;
		xh_heure= (float)temps/60;
		h_heure= (int) xh_heure;
		m_minute= temps-h_heure*60;
		//printf(" heure_minute %d H %d\n",h_heure,m_minute);
		//construit extension pour fichier val heure
		if(h_heure>=10 && m_minute >=10)
		{
		 sprintf(extension,"_%dH%d",h_heure,m_minute);
		}
		else if(h_heure>=10 && m_minute <10)
		{
		 sprintf(extension,"_%dH0%d",h_heure,m_minute);
		} 
		else if(h_heure<10 && m_minute >=10)
		{
	     sprintf(extension,"_0%dH%d",h_heure,m_minute);
		} 
		else if(h_heure <10 && m_minute <10)
		{
		 sprintf(extension,"_0%dH0%d",h_heure,m_minute);
		} 
		//printf("extension %s\n",extension);
}

/*_________________________________________________________________*/
/* Format de la fonction l_descendant */
void usage ()
{
 printf("\n   l_descendant\n");

 printf("\n      la fonction a comme parametre en ENTREE :\n\n");
 printf("\t fac_ciel_de_la_geometrie (.val)\n"); 
 printf("\t hh1:mn1\n");
 printf("\t hh2:mn2\n");
 printf("\t pas(hh:mn)\n");
 printf("\t fichier_donnees_meteo_l_descendant(.txt)\n");

 printf("\n           comme parametres en SORTIE, \n\n");   
 printf("\t l_descendant_de_la_geometrie(.val)\n");

 printf("\n           comme parametres FACULTATIF:\n\n");
 printf("\t translation_en_heure\n");

 printf("\nNOTA: le programme ajoute une extension _hhHmm au nom de fichier correspondant � l'heure du calcul\n");
 printf("\nNOTA: en tenant compte d'une translation en heures si souhaitee\n");
 printf("\nNOTA: fichier meteo sous la forme d'une liste de lignes \n");
 printf("				heure minute l_descendant_sol\n");
 printf("				heure minute l_descendant_sol\n");
 printf("				.......\n");
 printf("\nNOTA:  L_descendant = Fciel * Flux_atmosph�rique_descendant_m�t�o\n");
exit(0);
}



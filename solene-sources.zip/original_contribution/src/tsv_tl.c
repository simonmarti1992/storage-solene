/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/***********************************************************/
/*	CONVERSION HEURE SOLAIRE VRAIE -> HEURE LEGALE     */
/*                                               	   */
/***********************************************************/		 

/*
cc tsv_tl.c geomutile.o solutile.o lib_solene_94.o -o tsv_tl -lm
*/

#include <solene.h>
   
/*  PROTOTYPES DE FONCTIONS  */ 
int jdate ();  
double ajust (); 
double declin ();   
double alt ();
double azim ();         
double gmt ();       
double exentr ();    
double airmass ();

int mois, jour, jd;
double latit, longit, merid, meridh, heure,pi;
double sd, st, stl, ete, az, lever, coucher;


/*____________________________________________*/

int main (argc,argv)
int argc;
char *argv[];
	{
	double  h, E0, M,hm;


 printf("Fonction Solene: tsv_tl\n\n");
      	if(argc<7||argc>8) usage_heure();

	/*  DONNEES  */	
	sscanf (argv[1], "%lf", &latit);      /* en degr�s */
	sscanf (argv[2], "%lf", &longit);     /*     "     */
	sscanf (argv[3], "%lf", &meridh);      /*     "     */    
	sscanf (argv[4], "%d", &jour);
	sscanf (argv[5], "%d", &mois);
	sscanf (argv[6], "%lf", &heure);      /* heure.minute */

	if(jour<1||jour>31)
		{ printf("\ncorriger le jour !\n\n"); exit(0); }
	if(mois<1||mois>12) 
		{ printf("\ncorriger le mois !\n\n"); exit(0); }
	if(heure<0||heure>24) 
		{ printf("\ncorriger l'heure !\n\n"); exit(0); }

	ete=0;
	if(argc==8)  
		sscanf (argv[7], "%lf", &ete); /* heure ��t� */

	/*  CALCULS SOLAIRES  */
	pi=4*atan(1.);
	merid=(-15)*(floor(meridh)+(meridh - floor(meridh))*100/60);
	hm=heure;
	heure= floor(heure)+(heure - floor(heure))*100/60;
	jd = jdate(mois, jour);
	sd = declin(jd);
	st = heure;
	stl = ete + heure - ajust(jd);
	h = alt (sd, st);
	az = azim (sd, st);	

	/*  EXENTRICITE */

	E0 = 1.00011 + 0.034221*cos(2*pi*(jd-1)/365) + 0.00128*sin(2*pi*(jd-1)/365)
		 + 0.000719*cos(2*2*pi*(jd-1)/365)+0.000077*sin(2*2*pi*(jd-1)/365);
	
	/* MASSE D'AIR OPTIQUE */

	M = 1. / (sin(h) + 0.15*pow(h*180./pi+3.885,-1.253));

	lever = ete+merid/(-15)+gmt(longit, latit, -1);
	coucher = ete+merid/(-15)+gmt(longit, latit, 1);              
	
/*  RESUME DES DONNEES  */
	printf("\n\n"); 
	printf("    Latitude      %+4.2f  \n", latit);       
	printf("    Longitude     %+4.2f  \n", longit);             
	if(meridh-floor(meridh)==0) printf("    Time Zone     %+2.0f h",floor(meridh));
	else  printf("    Time Zone     %+2.0f h %2.0f mn",
				floor(meridh), (meridh-floor(meridh))*100);
	printf("   (Meridien %+4.2f)\n",merid);      
	printf("    Date (j/m)    %d/%d   \n", jour, mois);    
       	if(ete) {
		if(ete-floor(ete)==0)  
			printf("    Heure d'ete   %+2.0f h\n\n",floor(ete));
		else printf("    Heure d'ete   %+2.0f h %2.0f mn\n\n", 
					floor(ete), (ete-floor(ete))*100);
		}  
	else printf("    Heure d'ete   non\n\n");


	printf(" **  Heure solaire   %2.0f h %2.0f mn  **\n", floor(hm),
						 (hm - floor(hm))*100);  
	if(stl-floor(stl)>0.99) stl=floor(stl)+1;     
	printf(" **  Heure legale    %2.0f h %2.0f mn  **\n\n",floor(stl),
							(stl-floor(stl))*60);
	printf("    Hauteur solaire       %+4.2f\n", h*180/pi); 
	printf("    Declinaison solaire   %+4.2f\n", sd*180/pi);    
	printf("    Azimut solaire        %+4.2f\n\n", az*180/pi);  
	printf("    x: %5.5f    y: %5.5f    z: %5.5f\n\n", -sin(az)*cos(h),
							-cos(az)*cos(h), sin(h));   
	printf("    Correction d'excentricit�e   %6.5f\n", E0);       
	printf("    Masse d'air optique         %6.5f\n\n", M);   
	
	if (latit < 65)
		{
		printf("En heure l�gale:\n");
		if(lever-floor(lever)>0.99) lever=floor(lever)+1;
		printf("    Lever du soleil     %2.0f h %2.0f mn\n", 
				floor(lever), (lever - floor(lever))*60); 
		if(coucher-floor(coucher)>0.99) coucher=floor(coucher)+1;
		printf("    Coucher du soleil   %2.0f h %2.0f mn\n\n\n", 
				floor(coucher), (coucher - floor(coucher))*60); 
		}

	//system("cat /dev/null >OK_SOLENE");		
	exit(0);
	}


		/********************************/
		/*      Calculs solaires        */
		/********************************/

/*__________________________________________________________*/
/* nume�ro du jour dans l'anne�e */
int jdate (mois,jour) 
int mois,jour;
	{
	static short jm[12] = {0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334};
	return (jm[mois - 1] + jour);
	}

/*__________________________________________________________*/
/* Ajustement du temps solaire */
double ajust (jd)                   
int jd;
	{
	return (0.17 * sin ((4*pi/373) * (jd - 80)) - 
			0.129 * sin ((2*pi/355) * (jd - 8)) +
			12 * (merid - longit) / 180.);
	}

/*__________________________________________________________*/
/* De�clinaison solaire */
double declin (jd)                   
int jd;
	{
	return (0.4093 * sin ((2*pi/368) * (jd - 81))); 
	}

/*__________________________________________________________*/
/* Altitude solaire h */
double alt (sd, st)          /* Altitude solaire h */
double sd,st;
	{
	return (asin (sin (latit*pi/180.) * sin (sd) - 
		cos (latit*pi/180.) * cos (sd) * cos (st*pi/12.)));  
	}

/*__________________________________________________________*/
double azim (sd, st)         /* Azimut solaire */ 
double sd,st; 
	{                          
	return (-atan2 (cos(sd) * sin (st*pi/12.),
		-cos (latit*pi/180.) * sin (sd) -
		sin (latit*pi/180.) * cos (sd) * cos (st*pi/12.)));            
	}

/*__________________________________________________________*/
double gmt(x1, y1, eps)
int eps;
double x1,y1;
	{
	float Et, t, delta;

	t = 0.988 * (jour + 30.3 * (mois-1));
	delta = 23.5 * cos((t+10)*pi/180.);
	Et = 0.123 * cos((t+87)*pi/180.) - 1./6. * sin(2*(t+10)*pi/180.);
	return (12 - Et + (x1 + eps*180./pi*
		acos(tan(delta*pi/180.)*tan(y1*pi/180.)))/15);
	}


/*__________________________________________________________*/
/* Format de la fonction HEURE */
int usage_heure()
	{
	printf("\n   *tsv_tl* lat long merid jour mois heure [heure_ete]\n\n");
	printf("\t\t- latitude en degres decimaux\n");
	printf("\t\t- longitude en degres decimaux (- a l'est de Greenwich)\n");
	printf("\t\t- meridien en heure.minute (+ ou - par rapport a GMT)\n");
	printf("\t\t- jour\n");
	printf("\t\t- mois\n");
	printf("\t\t- heure solaire vraie en heure.minute\n");
	printf("\t\t- [heure_ete] en heure (option, 0 par default)\n");
	exit(0);                                         
	}

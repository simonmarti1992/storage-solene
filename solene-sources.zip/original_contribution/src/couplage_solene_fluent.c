/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

//  couplage_solene_fluent


// D.GROLEAU dec 2003
// modifi� M. Robitu
// 29 avril 2004
#include<solene.h>


// DECLARE FUNCTIONS

void format_entree();
int lecture_analyse_ecart();
int lit_ligne_commande();
void met_extension ();
void test_min_max();
void touch();



// en GLOBAL

// CONVENTIONS dans les commandes
/*
solene_val_to_fluent

	geometrie_tr(.cir)		= geom_tr
	temperature_ext(.val)	= tse_01		(+ l'extension .H.)
	tri(.val)				= tri
	tri(.txt)				= tri
	profil_temperature		= x		(pour fluent)

solene_val_vol_to_fluent

	geometrie_tr(.cir)		= geom_tr		(toute la geometrie)
	flux_GLO(.val)			= farbre_01		(+ l'extension .H.)
	f_ap_face_element(.txt) = f_ap_arbre
	flux_arbre(.dat)		= y		(pour fluent)

fluent_val_to_solene 

	geometrie_tr(.cir)		= geom_tr		(toute la geometrie)
	profil_fluent(.dat)		=
							  flatent		(noms  Fluent )
						ou	  tf			
						ou	  fconv			
						ou	  hc			
	
	descripteur(.val)		=
							  flatent		flux latent 
						ou	  tf			tfix�e pour arbre
						ou	  fconv			flux conv 
						ou	  hc			h conv 

*/

/*_________________________________________________________________*/
main(argc,argv) 
int argc;char **argv;

{
FILE	*fp_solene, *fpval;
  FILE *fd ;
  FILE *fx;

char	buf[512],buf1[512],cm_transitoire_bassin_rad[256],*s_dir,c;
int		hh1,hh2,pas,minute;
int		i,temps,iter;

float	xh_heure;
int		h_heure,m_minute ,nb_pas;
char	extension[32];
fd= fopen("xresu_couplage.txt","w");

if (fd != NULL) {
 if(argc != 5 ) { format_entree(); exit(0); }

	s_dir=(char *)getenv("PWD");

fprintf(fd,"Commande : couplage_solene_fluent\n\n");
fflush(fd);
		
//  heures debut et fin , pas
         sscanf(argv[1],"%d%c%d",&hh1,&c,&minute);
		 fprintf(fd,"de %s ",argv[1]);
		 fflush(fd);
         hh1=hh1*60+minute;
         sscanf(argv[2],"%d%c%d",&hh2,&c,&minute); 
		 fprintf(fd,"� %s ",argv[2]);
		 fflush(fd);
         hh2=hh2*60+minute;
         sscanf(argv[3],"%d%c%d",&pas,&c,&minute);
		 fprintf(fd,"par pas de %s \n",argv[3]);
		 fflush(fd);
         pas=pas*60+minute;
         //printf("de hh1 %d a hh2 %d par pas de %d\n",hh1,hh2,pas);

// calcul du nombre de pas 
   nb_pas=1;
   i=hh1;
   while(i<hh2)
    { nb_pas++;
      i=i+pas;
    }
 fprintf(fd,"nb de pas %d\n",nb_pas);
 fflush(fd);


 // ouvre fichier de commande_solene transitoire_...
    compose_nom_complet(cm_transitoire_bassin_rad,s_dir,argv[4],"bat");
	fprintf(fd,"fichier de commande solene : %s\n",cm_transitoire_bassin_rad);
	fflush(fd);
	if ((fp_solene=fopen(cm_transitoire_bassin_rad,"r"))==NULL)
            { printf("\n  impossible ouvrir %s\n\n", cm_transitoire_bassin_rad); 
			  exit(0);
            }

 fprintf(fd,"\nLance le traitement  : \n");
 fflush(fd);

 temps=hh1;
 for(i=0;i<nb_pas;i++)
   { 
	 xh_heure= (float)temps/60;
	 h_heure= (int) xh_heure;
	 m_minute= temps-h_heure*60;
	 fprintf(fd," A %dH%d\n",h_heure,m_minute);
	 fflush(fd);

	 // appel extension 
	 met_extension(temps,extension);

	 // lit la commande SOLENE � partir de la commande du fichier.bat : transitoire_h_....

	 iter=0;
	 // cr�e fichier Calcul solaire =1 ou 0 pas de calcul
	 fx= fopen("XCALCULSOL.txt","w");
	 fprintf(fx,"1");
	 fclose(fx);

	 if(lit_ligne_commande(fp_solene,buf1))
	 {
	   while(1)   // couplage it�ratif entre Solene et Fluent
				  // A METTRE EN COMMENTAIRE pour un seul couplage Solene Fluent
		{
	     // LANCE la commande Solene transitoire...
		  fprintf(fd,"commande = %s \n",buf1);
		  fflush(fd);
	      system(buf1);



		 // TEST d'ARRET : si les temp�ratures de surface n'ont pas chang� par rapport � l'it�ration couplage pr�c�dent
		 if(iter)
		 { // compare les temp�ratures obtenues avec celle de l'it�ration pr�c�dente
	       sprintf(buf,"val_op_val tse_01%s - tse_t_precedent xecart >xresu_val_op_val.txt",extension);
	       // LANCE la commande val_op_val
	       system(buf);

		 //copy xecart
		 sprintf(buf,"copy xecart.val xecart%s_%d.val >xresu_copy_xecart.txt",extension,iter);
	     fprintf(fd,"commande = %s\n",buf);
		 fflush(fd);
	     // LANCE la commande copy
	     system(buf);
		 sprintf(buf,"xecart%s_%d.val",extension,iter);
		 touch(buf);


		   // analyse le r�sultat
		   compose_nom_complet(buf,s_dir,"xecart","val");
           printf("	  compare �cart : %s \n", buf);
		   if(lecture_analyse_ecart(buf,fd))break; // Lecture, analyse des �carts de temperature, test ARRET
		 }

		 iter++;
		 fprintf(fd,"     It�ration %d\n",iter);
		 fflush(fd);

		 	 // cr�e fichier Calcul solaire = 0 pas de calcul
	 fx= fopen("XCALCULSOL.txt","w");
	 fprintf(fx,"0");
	 fclose(fx);


		 	   	  // donnees de flux solaire net stocke dans flux solaire incident 
	     sprintf(buf,"copy fsnet_01%s.val fs.val >xresu_copy_fs.txt",extension);
	     fprintf(fd,"commande = %s\n",buf);
		 fflush(fd);
	     // LANCE la commande copy
	     system(buf);
		 touch("fs.val");

		 		 // resu transitoire 
	     sprintf(buf,"copy xresu_01%s.txt xresu_01%s_%d.txt >xresu_copy_xresu_trans.txt",extension,extension,iter);
	     fprintf(fd,"commande = %s\n",buf);
		 fflush(fd);
	     // LANCE la commande copy
	     system(buf);
		 sprintf(buf,"xresu_01%s_%d.txt",extension,iter);
		 touch(buf);		

		 // Sauve les Temp�ratures ext�rieures pour cette it�ration
	     sprintf(buf,"copy tse_01%s.val tse_t_precedent.val >xresu_copy_temp.txt",extension);
		 fprintf(fd,"commande = %s\n",buf);
		 fflush(fd);
	     // LANCE la commande de copy
	     system(buf);
		 touch("tse_t_precedent.val");

		 // transformer les temp�ratures en Kelvin
	     sprintf(buf,"val_op_val tse_01%s + 273 x1 >xresu_kelvin.txt",extension);
	     fprintf(fd,"commande = %s\n",buf);
		 fflush(fd);
	     // LANCE la commande Solene val_op_val
	     system(buf);

		 		 // transformer les temp�ratures en Kelvin
	     sprintf(buf,"copy tmeteo%s.txt t_entree.txt >xresu_t_entree.txt",extension);
	     fprintf(fd,"commande = %s\n",buf);
		 fflush(fd);
	     // LANCE la commande Solene val_op_val
	     system(buf);
		 touch("t_entree.txt");


	     // fait les transferts de donn�es de temp�ratures pour Fluent
	     sprintf(buf,"solene_val_to_fluent geom_tr x1 tri tri x >xresu_sol_val_fluent_x.txt");
	     fprintf(fd,"commande = %s\n",buf);
		 fflush(fd);
	     // LANCE la commande Solene solene_val_fluent
	     system(buf);

		 // calculer le rayonemment net surfacique pour l'arbre
	     sprintf(buf,"val_op_val fsnet_01%s - glo_01%s farbre_01%s >xresu_farbre.txt",extension,extension,extension);
	     fprintf(fd,"commande = %s\n",buf);
		 fflush(fd);
	     // LANCE la commande Solene val_op_val
	     system(buf);


	     // fait les transferts de donn�es du rayonemment net surfacique de l'arbre pour Fluent
	     sprintf(buf,"solene_val_vol_to_fluent geom_tr farbre_01%s f_ap_arbre y >xresu_sol_val_vol_fluent_y.txt",extension);
	     fprintf(fd,"commande = %s\n",buf);
		 fflush(fd);
	     // LANCE la commande Solene solene_val_vol_to_fluent
	     system(buf);


	     // LANCE Fluent en batch
	     sprintf(buf,"fluent 3d -g -i journal.jou >xresu_fluent.txt");
	     fprintf(fd,"commande = %s\n",buf);
		 fflush(fd);
	     system(buf);

		 // Verifier que bien termin� avant de poursuivre en testant existence d'un fichier cr�e � cet effet
		 // fin_fluent.dat
		 
         while(1)
		 { 	if ((fpval=fopen("fin_fluent.dat","r"))!=NULL)
			{ fclose(fpval);
              break;
			}
		 }
		 
		 // Sauve les .cas et .data sous autres noms
	     sprintf(buf,"copy toto.cas test_sensib.cas  >xresu_rename_case.txt");
	     fprintf(fd,"commande = %s\n",buf);
		 fflush(fd);
	     system(buf);
		 touch("test_sensib.cas");

	     sprintf(buf,"copy toto.dat test_sensib.dat  >xresu_rename_data.txt");
	     fprintf(fd,"commande = %s\n",buf);
		 fflush(fd);
	     system(buf);
		 touch("test_sensib.dat");


		 // Rennomme les .cas et .data
	     sprintf(buf,"copy toto.cas test_sensib%s.cas  >xresu_rename_case.txt",extension);
	     fprintf(fd,"commande = %s\n",buf);
		 fflush(fd);
	     system(buf);
	     sprintf(buf,"test_sensib%s.cas",extension);
		 touch(buf);

	     sprintf(buf,"copy toto.dat test_sensib%s.dat  >xresu_rename_data.txt",extension);
	     fprintf(fd,"commande = %s\n",buf);
		 fflush(fd);
	     system(buf);
		 sprintf(buf,"test_sensib%s.dat",extension);
		 touch(buf);


		  // efface le fichier toto.cas et .dat 
	     sprintf(buf,"del toto.cas >xresu_del.txt");
	     fprintf(fd,"commande = %s\n",buf);
		 fflush(fd);
	     // LANCE la commande del
	     system(buf);

		 sprintf(buf,"del toto.dat >xresu_del.txt");
	     fprintf(fd,"commande = %s\n",buf);
		 fflush(fd);
	     // LANCE la commande del
	     system(buf);

		 // R�cup�re les donn�es Fluent dans Solene

	     // donnees de Chaleur latente
	     sprintf(buf,"fluent_val_to_solene geom_tr flatent flatent >xresu_fluent_val_solene_flatent.txt");
	     fprintf(fd,"commande = %s\n",buf);
		 fflush(fd);
	     // LANCE la commande Solene fluent_val_to_solene
	     system(buf);

		 	     // donnees de Chaleur latente
	     sprintf(buf,"copy flatent.val flatent%s_%d.val >xresu_fluent_val_solene_flatent.txt",extension,iter);
	     fprintf(fd,"commande = %s\n",buf);
		 fflush(fd);
	     // LANCE la commande copy
	     system(buf);
	     sprintf(buf,"flatent%s_%d.val",extension,iter);
		 touch(buf);

	     // donnees de temperature
	     sprintf(buf,"fluent_val_to_solene geom_tr tf tf1 >xresu_fluent_val_solene_tf.txt");
	     fprintf(fd,"commande = %s\n",buf);
		 fflush(fd);
	     // LANCE la commande Solene fluent_val_to_solene
	     system(buf);

		 // transformer en celsius
	     sprintf(buf,"val_op_val tf1 - 273 tf >xresu_celsius_tf.txt");
	     fprintf(fd,"commande = %s\n",buf);
		 fflush(fd);
	     // LANCE la commande Solene val_op_val
	     system(buf);


		  // donnees de flux convectifs
	     sprintf(buf,"copy tf.val tf%s.val >xresu_copy_tf.txt",extension);
	     fprintf(fd,"commande = %s\n",buf);
		 fflush(fd);
	     // LANCE la commande copy
	     system(buf);
	     sprintf(buf,"tf%s.val",extension);
		 touch(buf);

	     // donnees de flux convectifs
	     sprintf(buf,"fluent_val_to_solene geom_tr fconv fconv >xresu_fluent_val_solene_fconv.txt");
	     fprintf(fd,"commande = %s\n",buf);
		 fflush(fd);
	     // LANCE la commande Solene fluent_val_to_solene
	     system(buf);

		  // donnees de flux convectifs
	     sprintf(buf,"copy fconv.val fconv%s_%d.val >xresu_copy_fconv.txt",extension,iter);
	     fprintf(fd,"commande = %s\n",buf);
		 fflush(fd);
	     // LANCE la commande copy
	     system(buf);
	     sprintf(buf,"fconv%s_%d.val",extension,iter);
		 touch(buf);

	   // donnees de h convectifs
	     sprintf(buf,"fluent_val_to_solene geom_tr hc hc >xresu_fluent_val_solene_hc.txt");
	     fprintf(fd,"commande = %s\n",buf);
		 fflush(fd);
	     // LANCE la commande Solene fluent_val_to_solene
	     system(buf);

		 // donnees de h convectifs
	     sprintf(buf,"copy hc.val hc%s.val >xresu_copy_hc.txt",extension);
	     fprintf(fd,"commande = %s\n",buf);
		 fflush(fd);
	     // LANCE la commande copy
	     system(buf);
	     sprintf(buf,"hc%s.val",extension);
		 touch(buf);

		  // donnees de h convectifs
	     sprintf(buf,"copy Nb_iteration.dat Nb_iteration%s_%d.dat >xresu_copy_nb_iter.txt",extension,iter);
	     fprintf(fd,"commande = %s\n",buf);
		 fflush(fd);
	     // LANCE la commande copy
	     system(buf);
	     sprintf(buf,"Nb_iteration%s_%d.dat",extension,iter);
		 touch(buf);


		 // efface le fichier Fluent tf.dat
	     sprintf(buf,"del tf.dat >xresu_del.txt");
	     fprintf(fd,"commande = %s\n",buf);
		 fflush(fd);
	     // LANCE la commande del
	     system(buf);

		 // efface le fichier Fluent flatent.dat
	     sprintf(buf,"del flatent.dat >xresu_del.txt");
	     fprintf(fd,"commande = %s\n",buf);
		 fflush(fd);
	     // LANCE la commande del
	     system(buf);

		 // efface le fichier Fluent hc.dat
	     sprintf(buf,"del hc.dat >xresu_del.txt");
	    fprintf(fd,"commande = %s\n",buf);
		 fflush(fd);
	     // LANCE la commande del
	     system(buf);

		 // efface le fichier Fluent fconv.dat
	     sprintf(buf,"del fconv.dat >xresu_del.txt");
	     fprintf(fd,"commande = %s\n",buf);
		 fflush(fd);
	     // LANCE la commande del
	     system(buf);

		 // efface le fichier Fluent Nb_iteration.dat
	     sprintf(buf,"del Nb_iteration.dat >xresu_del.txt");
	     fprintf(fd,"commande = %s\n",buf);
		 fflush(fd);
	     // LANCE la commande del
	     system(buf);

		 // efface le fichier Fluent fin_fluent.dat
	     sprintf(buf,"del fin_fluent.dat >xresu_del.txt");
	     fprintf(fd,"commande = %s\n",buf);
		 fflush(fd);
	     // LANCE la commande del
	     system(buf);

		 // efface le fichier tf1.val
	     sprintf(buf,"del tf1.val >xresu_del.txt");
	     fprintf(fd,"commande = %s\n",buf);
		 fflush(fd);
	     // LANCE la commande del
	     system(buf);
//court:;

	   } // fin de while

	 }
	 else
	 { fprintf(fd,"pas de commande Solene pour cette heure\n");
	   fflush(fd);
	   exit(0);
	 }
	

    temps+=pas;
	}
	
  }  // fin for i (nb de pas)

creer_OK_Solene();
fprintf(fd,"\nFin couplage_solene_fluent\n\n");
fflush(fd);
fclose(fd);

exit(0);

}

//_________________________________________________________________
int lit_ligne_commande(fi,ligne_commande)
FILE *fi;
char *ligne_commande;
{
  int i;   /* lit ligne de commande ds ligne_commande sur console */
  //char c;
  
  i=-1;
  do
    { i++; 
      if((fscanf(fi,"%c",ligne_commande+i))==EOF)
		{   ligne_commande[i]=0;
			return(0);
		}
		
	/*printf("i= %d c=%c\n",i,ligne_commande[i]);*/
    }while(ligne_commande[i]!='\n');

  ligne_commande[i]=0;
  //printf("ligne = %s\n",ligne_commande);
  return(1); 

}

//_________________________________________________________________
void test_min_max(x,vmin_gen,vmax_gen)
double x;
double *vmin_gen,*vmax_gen;
{
		 if(x < *vmin_gen) *vmin_gen =  x;
         if(x > *vmax_gen) *vmax_gen =  x;
}


//_____________________________________________________
void met_extension (temps,extension)
int temps;
char *extension;
{  // modele energie diffuse meteo
	float xh_heure;
	int h_heure, m_minute;

		xh_heure= (float)temps/60;
		h_heure= (int) xh_heure;
		m_minute= temps-h_heure*60;
		//printf(" heure_minute %d H %d\n",h_heure,m_minute);
		//construit extension pour fichier val heure
		if(h_heure>=10 && m_minute >=10)
		{
		 sprintf(extension,"_%dH%d",h_heure,m_minute);
		}
		else if(h_heure>=10 && m_minute <10)
		{
		 sprintf(extension,"_%dH0%d",h_heure,m_minute);
		} 
		else if(h_heure<10 && m_minute >=10)
		{
		 sprintf(extension,"_0%dH%d",h_heure,m_minute);
		} 
		else if(h_heure <10 && m_minute <10)
		{
		 sprintf(extension,"_0%dH0%d",h_heure,m_minute);
		} 
		//printf("extension %s\n",extension);
}

//_________________________________________________________________
void touch(fichier)
char *fichier;
{
	 FILE *fp;
	 fp= fopen(fichier,"r");
	 	if ((fp=fopen(fichier,"r"))==NULL)
            { printf("\n  impossible ouvrir %s\n\n", fichier); 
			  
            }
	 fclose(fp);
}

//_________________________________________________________________
// Test d'arr�t sur analyse des �carts de temp�rature
// RETURN (1) arr�t
int lecture_analyse_ecart(nom,fd)
char *nom;
FILE *fd;
{
	FILE *pfic;
  double val_min;
  double val_max;
  int num_cont_liste;
  int nbfac,nomax;
  int nofac, nbcont_face;
  char c;
  int i,j;
  double somme,ecart_permis,total_permis ;
  double valeur;

  // ARRET SI (fabs(ecart)) < ecart_permis 
  //    OU SI (Somme des fabs( �cart) des mailles ayant un �cart > � fabs(ecart_permis)) < total_permis
  ecart_permis = 1.5;
  total_permis = 20;

  if ((pfic=fopen(nom,"r"))==NULL)
       {printf("\n  impossible ouvrir %s\n\n", nom); 
		exit(0);}


  fscanf(pfic,"%d %d %lf %lf",&nbfac,&nomax,&val_min,&val_max);
  fprintf(fd,"    ecart max compris entre %f et %f\n",val_min,val_max);
  fflush(fd);

  if(fabs(val_min) <= ecart_permis && fabs(val_max) <= ecart_permis)
  {   fclose(pfic);
	  return(1);
  }

  num_cont_liste = 0;
  somme=0;
  for(i=0;i<nbfac;i++)
	{
	 fscanf(pfic,"\n%c%d%d\n",&c,&nofac,&nbcont_face);
	 for(j=0;j<nbcont_face;j++)	
	 {	
		 fscanf(pfic,"%lf\n",&valeur);
		 if(fabs(valeur) > ecart_permis)
		 {
			 somme+= fabs(valeur);
			 num_cont_liste++;
		 }
	 }
	}
  fclose(pfic);

  fprintf(fd,"    total ecart au-dessus du seuil permis %f et %f\n",somme);
  fflush(fd);

  if(somme <= total_permis) return(1);
  else return(0);	  

}
//_________________________________________________________________
void format_entree()
{
 printf("\n la fonction couplage_solene_fluent\n a comme parametre ENTREE :\n\n");
 printf("\t hh1:mm1\n");
 printf("\t hh2:mm2\n");
 printf("\t pas(hh:mn)\n");
 printf("\t fichier_de_commande_solene: transitoire...(.bat)\n");
 printf("\n");
 exit(0);
  
}

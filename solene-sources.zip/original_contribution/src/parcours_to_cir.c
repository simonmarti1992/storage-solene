/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/*
link avec 
  solutile.o geomutile.o lib_solene_94.o 

*/
/*
 transforme un fichier solene dont le contour indique un parcours par un 
fichier solene dont chaque contour contient un point du parcours et son point suivant
*/


#include<solene.h>

int convertit_parcours();
void format_entree();



/*_________________________________________________________________*/
main(argc,argv)
 int argc;char **argv;
{char 	buf[512],*s_dir;
 double englob[10];
 int nbfac;
 
 struct modelisation_face *ff;
 int nbff;
 FILE *fp;


 
 if(argc<3)format_entree();

	s_dir=(char *)getenv("PWD");

  compose_nom_complet(buf,s_dir,argv[1],"cir");
  if((fp=fopen(buf,"r"))==NULL)
        { printf("\n impossible ouvrir %s\n",buf);
          exit(0);
		}
   lit_en_tete(fp,&nbff,&nomax,englob);
   ff=alloue_face(nbff,35);
   lit_fic_cir3d(fp,nbff,ff);
   fclose(fp);

   compose_nom_complet(buf,s_dir,argv[2],"cir");
   if((fp=fopen(buf,"w"))==NULL)
        { printf("\n impossible ouvrir %s\n",buf);
          exit(0);
		}
   ecrit_en_tete(fp,nbff,nomax,englob);
/// conversion
   printf("Transforme contour parcours en contours oeil-visee\n");
   nbfac = convertit_parcours(ff,nbff,fp);

   rewind(fp);
   ecrit_en_tete(fp,nbfac,nbfac,englob);
   fclose(fp);
   desalloue_fface(ff,nbff);

   printf("Fin parcours_to_cir\n");
   creer_OK_Solene();

}


/*____________________________________________________________________*/
int convertit_parcours(ff, nbff, fp)
struct modelisation_face *ff;
int nbff;
FILE *fp;
{
 int i,k,nbfac;
 struct contour *pcont;
 struct circuit *pcir;

 nbfac=0;
 for (k=0;k<nbff;k++)
 { //printf("traite le parcours %d\n",(ff+k)->nofac_fichier);
   pcont=(ff+k)->debut_projete;

      while(pcont)	   
       { pcir=pcont->debut_support; 

         // la face a creer contient pcir_nbp-2 contour
	     nbfac = nbfac+1;
         fprintf(fp,"f%d %d\n",nbfac,pcir->nbp-2);
         fprintf(fp,"%f %f %f\n",(ff+k)->vnorm[0],(ff+k)->vnorm[1],(ff+k)->vnorm[2]);
         for(i=0;i<pcir->nbp-2;i++)
         {  
			fprintf(fp,"c0\n");
			fprintf(fp," 4\n");
            fprintf(fp,"%f %f %f\n",pcir->x[i],pcir->y[i],pcir->z[i]);
            fprintf(fp,"%f %f %f\n",pcir->x[i+1],pcir->y[i+1],pcir->z[i+1]);
            fprintf(fp,"%f %f %f\n",pcir->x[i+1]+0.2,pcir->y[i+1]+0.2,pcir->z[i+1]+0.2);
            fprintf(fp,"%f %f %f\n",pcir->x[i],pcir->y[i],pcir->z[i]);
		 }
	
         pcont=pcont->suc; 
       } 
 }
 return(nbfac);
}

/*_________________________________________________________________*/
void format_entree()
{
  printf("\n    parcours_to_cir  fichier_in(.cir) fichier_out(.cir)\n\n");
   exit(0);
}

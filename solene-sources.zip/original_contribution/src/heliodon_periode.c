/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/*
cc heliodon_periode.c  solaire.o solutile.o geomutile.o lib_solene_94.o -o heliodon_periode -lm
*/
//D. GROLEAU Modif avril 2006 nb de p�riodes 64

/*****************************************************************/
/* calcule une serie d'heliodons pour une journee               */
/* le premier heliodon est calculee au premier pas de temps      */
/* suivant le lever du soleil, le dernier est le dernier pas de  */
/* avant le coucher du soleil                                    */
/* le fichier de sortie est du nom du fichier -jour/mois-hh:mn   */
/*****************************************************************/

#include<solene.h>
#include<ctype.h>
int info_date();

FILE *pmas,*ficetat;

int nb_etat;
struct modelisation_face *ff;
int nbff,nbfmax;

/*_________________________________________________________________*/
main(argc,argv)			
 int argc;char **argv;
{int i;
char c[2],*s_dir;
char buf[256];
  int nojour,nomois,hh,minute,hdeb,hfin,heur,pas,hh1,hh2,fin;
  double latitude;
  double declin,heure_lever,hm;
  char fres[2048],buf1[2048],buf2[2048];

         s_dir=(char *)getenv("PWD");

         if(argc<10)format_entree_heliodon_periode();

         sscanf(argv[3],"%lf",&(latitude));
         printf("\n lati = %lf ",latitude);

  	 sscanf(argv[4],"%d%c%d",&nojour,c,&nomois);
         if(c[0]!='/')format_entree_heliodon_periode();
         printf("\n nojour = %d nomois = %d ",nojour,nomois);

         sscanf(argv[5],"%d%c%d",&hh1,c,&minute); hh1=hh1*60+minute;
         sscanf(argv[6],"%d%c%d",&hh2,c,&minute); hh2=hh2*60+minute;


         sscanf(argv[7],"%d%c%d",&hh,c,&minute);
	 if(c[0]!=':')format_entree_heliodon_periode();
         if(nojour<1|| nojour>31||nomois<1||nomois>12)
				format_entree_heliodon_periode();
         if(hh<0||hh>24||minute<0||minute>60)format_entree_heliodon_periode();
         printf("\n pas hh = %d minute = %d ",hh,minute);


         normale_orientee=1;
         for(i=10;i<argc;i++)
            { sscanf(argv[i],"%c%c",c,c+1);
              if(*c!='-')format_entree_heliodon_periode();
              if(*(c+1)=='n') normale_orientee=0;
	      else if(*(c+1)=='t') traitement_faces_cachees=0;
              else format_entree_heliodon_periode();
            }

  /* calcule le pas en minute */
    pas=60*hh+minute;
  /* info date */
    latitude=angrad(latitude);
    i=numjour(nojour,nomois);
    i=(i-1)%365+1;     
    declin=declinaison(i);   
    heure_lever=anglev(declin,latitude);
    anglehoraire_EN_heure_minute(heure_lever,&hm);

    
    printf("declinaison = %lf  heure de lever = %lf\n\n",angdeg(declin),hm);
    hdeb=(int)hm*60;

    if(hh1<hdeb)
	{printf("\n heure de debut %d inferieure a l'heure de lever du soleil\n",hh1);exit(0);}
    if(hh2>(1440-hdeb))
	{printf("\n heure de fin %d superieure a l'heure de coucher du soleil\n",hh2);exit(0);}

    sprintf(buf1,"decompose_face %s",argv[1]);
    hdeb=hdeb+(hm-(int)hm)*100; hfin=1440-hdeb;
    heur=hh1; 
    nb_etat=0; fin=1;
    while(heur<=hh2)
	{hh=heur/60; minute=heur-hh*60;
         sprintf(fres,"%s_%d_%d_%d_%d",argv[1],nojour,nomois,hh,minute);
         if(normale_orientee==1)
         	{sprintf(buf,"heliodon %s %s %s %d:%d %s %s",argv[1],argv[2],argv[4],hh,minute,argv[3],fres);
		}
	else
		{sprintf(buf,"heliodon %s %s %s %d:%d %s %s -n",argv[1],argv[2],argv[4],hh,minute,argv[3],fres);
		}
printf("\n commande = %s\n",buf);
         system(buf);
         sprintf(buf2,"%s %s",buf1,fres);
	 strcpy(buf1,buf2);
         heur+=pas; 
	 nb_etat++;
	 if(fin==0)break;
         if(heur>=hh2){heur=hh2; fin=0;}
	}
        sprintf(buf2,"%s %s",buf1,argv[8]);
	printf("\n commande = %s\n",buf2);
	system(buf2);

    /* test si la commande decompose_face s'est bien passe */
	
	// Modif SII DFA 24-4-2006
	if (!existOkSolene()) {
		printf("\n PB execution de decompose_face\n");
	    exit(0);
	}
	cleanOkSolene();

    /* constitue le fichier (.mas) a partir du fichier (.eta) */
    compose_nom_complet(buf,s_dir,argv[8],"eta");
    if((ficetat=fopen(buf,"r"))==NULL)
           {printf("\n impossible ouvrir %s\n",buf); exit(0);}
     fscanf(ficetat,"%d %d %d",&nbff,&nbfmax,&nbcontour);
     ff=alloue_face(nbff,35);
 printf(" lit le fichier (.eta)nb_etat= %d nbff = %d \n",nb_etat,nbff);

   /*   
        alloue_contour(ff,nbff,nb_etat); 
        inutile les contours sont alloues dans 
        lit_fic_etat_contour
   */
      lit_fic_etat_contour(ficetat,ff,nbff,nb_etat);
      fclose(ficetat);
	sprintf(buf1,"del %s",buf);
	system(buf1); 
    /* ouvre le fichier (.mas) */
      compose_nom_complet(buf,s_dir,argv[9],"mas");
      pmas=fopen(buf,"w");
      fprintf(pmas," 1 %d %d \n",nojour,nomois);
      fprintf(pmas,"%4d %4d",nbff,nbfmax);
      traite_etat(ff,nbff,nb_etat,hh1,hh2,pas);
      fclose(pmas);
      desalloue_fface(ff,nbff);

     /* efface les fichiers heliodons */

	 fres[0]=0;

         efface_heliodons(s_dir,nojour,nomois,pas,argv[1],fres,hh1,hh2); 
       
creer_OK_Solene();

/* liste_des_pointeurs(); */

}
/*_________________________________________________________________*/
traite_etat(ff,nbff,nb_etat,hh1,hh2,pas)
int nbff,nb_etat,hh1,hh2;
struct modelisation_face *ff;
{int i,j,k,hdeb,deb,debut[64],fin[64],dh,fh,nb_per,kk;
 struct contour *pcont;


         for(i=0;i<nbff;i++)
           { pcont=(ff+i)->debut_projete;  
             fprintf(pmas,"\nf%d %d",(ff+i) ->nofac_fichier,nb_contour_face(ff+i,1)); 
             while(pcont)	   
               {fprintf(pmas,"\nc"); kk=0;
		   fprintf(pmas,"\n");
		   nb_per=0; deb=0; 
                   hdeb=hh1; 
		   for(k=0;k<nb_etat;k++)
			{if(pcont->etat[kk]==1)
				{if(deb==0){nb_per++; debut[nb_per-1]=k;deb=1;}}
			 else {if(deb){fin[nb_per-1]=k-1; deb=0;}}
			  kk++;
			}
		   if(deb)fin[nb_per-1]=nb_etat-1;

		   /* ecrit les intervalles sur le fichier .mas */
		   fprintf(pmas," %d ",nb_per);
		   for(k=0;k<nb_per;k++)
			{if(debut[k]==0) dh=hh1;
		      	 else dh=hdeb+debut[k]*pas-pas/2;
			 if(fin[k]==nb_etat-1) fh=hh2;
			 else fh=hdeb+fin[k]*pas+pas/2;
			/* pb a la fin : simplement ensoleille a hh2 */
			 if(dh==fh)dh=dh-pas/4;
			 fprintf(pmas," %d %d %d %d 100 ",dh/60,dh%60,fh/60,fh%60);
					
			
		  }
  		pcont=pcont->suc;
	       }
	   }
}
/*_________________________________________________________________*/
int lit_fic_etat_contour(pfic,f1,nbf1,no_etat)
FILE *pfic;
struct modelisation_face *f1;
int nbf1,no_etat;
{ char c;
 int k,kk,nbcont,i,j;
 struct contour *pc;

 for(k=0;k<nbf1;k++)
	{fscanf(pfic,"\n%c%d %d",&c,&kk,&nbcont);
	(f1+k)->nofac_fichier=kk;
        /*printf("\n face no %d   \n",(f1+k)->nofac_fichier); */
 	 (f1+k)->debut_projete=alloue_contour(1);
	 pc=(f1+k)->debut_projete;
         for(i=0;i<nbcont;i++)
            {if(i){pc->suc=alloue_contour(2); pc=pc->suc;}
	     fscanf(pfic,"\n%c",&c);
	     for(j=0;j<no_etat;j++)
	         {fscanf(pfic,"%d",&kk);
		  pc->etat[j]=kk; 
                 }
            }
        }
}
/*_________________________________________________________________*/
efface_heliodons(s_dir,nojour,nomois,pas,fichier,buf,hh1,hh2)
int nojour,nomois,pas,hh1,hh2;
char *fichier,*buf,*s_dir;
{ int heur,hh,minute,fin;
  char fres[256];
	/* calcule le pas en minute */
    	heur=hh1; fin=1;
   	 while(heur<=hh2)
		{hh=heur/60; minute=heur-hh*60;
         sprintf(fres,"%s_%d_%d_%d_%d",fichier,nojour,nomois,hh,minute);
		 compose_nom_complet(buf,s_dir,fres,"cir");
		// printf("%s\n", buf);
		  
         sprintf(fres,"del %s",buf);
		 system(fres); 
        	 heur+=pas; 
		 if(fin==0)break;
		 if(heur>=hh2){heur=hh2;fin=0;}
		}
}

/*_________________________________________________________________*/
format_entree_heliodon_periode()
{
  printf("\n   format d'entree des parametres \n\n");
  printf(" *heliodon_periode* fichier_select_in(.cir) fichier_masque_in(.cir) latitude jour/mois hh1:mn1 hh2:mn2 pas(hh:mn) geom_out(.cir) masc_geom_out(.mas) [-n]\n\n");
  exit(0);
}

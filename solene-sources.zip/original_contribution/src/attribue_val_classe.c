/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */
 
/* 
cc -o attribue_val_classe  attribue_val_classe.c solutile.o geomutile.o lib_solene_94.o -lm
*/

// D.GROLEAU avril 2004

/*transmet les valeurs d'un fichier classe produit par STATISTICA aux faces d'une g�ometrie */
/*  le fichier classe.txt est constitu� d'une suite de lignes comprenant
1 valeur_classe ecart_classe
2 valeur_classe ecart_classe
...

les lignes sont fournies dans l'ordre des contours des faces du fichier .val fourni en mod�le
 */

#include <solene.h>



// DECLARE FUNCTIONS

void format_entree();
void lit_et_transmet();
int lit_val_classe();

/*_______________________________________*/
/*declaration application */

FILE *fpval1,*fpval2,*fpval3;

int nbligne;
double 	valeur1_min,valeur2_min;
double 	valeur1_max,valeur2_max;
double  val_ecart[40000];
double  val_classe[40000];

/************************************************/
main(argc,argv)
int argc;char **argv;
{
 char buf[512],*s_dir;


  if(argc!=5){ format_entree(); exit(0);}


	s_dir=(char *)getenv("PWD");

 printf("\n\nCommande:  attribue_val_classe\n\n");

 compose_nom_complet(buf,s_dir,argv[1],"txt");
  if((fpval1=fopen(buf,"r"))==NULL)
	{ printf("impossible ouvrir %s\n",buf);
	  exit(0);
	}
	 printf(" fichier des valeurs classe � attribuer : %s\n",buf);

   // lit fichier transmis par classe
    nbligne= lit_val_classe();  // fpval1
	fclose(fpval1);

	//for(i=0; i<nbligne; i++) printf("ligne %d %d %f\n",i,nosolene[i],val_classe[i]);


 compose_nom_complet(buf,s_dir,argv[2],"val");
  if((fpval1=fopen(buf,"r"))==NULL)
	{ printf("impossible ouvrir %s\n",buf);
	  exit(0);
	}
	 printf(" suivant modele de valeurs: %s\n",buf);

 compose_nom_complet(buf,s_dir,argv[3],"val");
  if((fpval2=fopen(buf,"w"))==NULL)
	{ printf("impossible ouvrir %s\n",buf);
	  exit(0);
	}
	
	 printf(" valeurs de classe transmises dans : %s\n",buf);

  compose_nom_complet(buf,s_dir,argv[4],"val");
  if((fpval3=fopen(buf,"w"))==NULL)
	{ printf("impossible ouvrir %s\n",buf);
	  exit(0);
	}
	
	 printf(" valeurs d'ecart transmises dans : %s\n",buf);

 // attribue les valeurs
	lit_et_transmet();
 

 creer_OK_Solene();

 printf("\n\nFin du Traitement attribue_val_classe\n");

}

/*------------------------------------------------------------*/
int lit_val_classe()
{
int i,id;
int nof;

valeur1_min= 1000000.;
valeur2_min= valeur1_min;
valeur1_max= - valeur1_min;
valeur2_max= - valeur1_min;

	i=0;
	while(1)
	{ if (i > 40000)
		{ printf("trop de lignes dans le fichier classe (40000 max)\n\n");
		  exit(0);
		}
	  id= fscanf(fpval1,"%d %lf %lf", &nof, val_classe+i,val_ecart+i );
	  if(id==EOF) break;
	  //printf(" %d %10.2f %10.2f\n",nof,val_classe[i], val_ecart[i]);
	  if(val_classe[i] < valeur1_min) valeur1_min = val_classe[i];
	  if(val_classe[i] > valeur1_max) valeur1_max = val_classe[i];
	  if(val_ecart[i] < valeur2_min) valeur2_min = val_ecart[i];
	  if(val_ecart[i] > valeur2_max) valeur2_max = val_ecart[i];
	  i++;
	}
    printf("      nombre de lignes lues dans ce fichier : %d\n",i);
	return(i);

}


/*------------------------------------------------------------*/
void lit_et_transmet()
{
 int 	i,j, nbcontour,nbfac,nomax,nofac;
 double  valor, bidon;
 char c;
 int noc;

   fscanf(fpval1,"%d %d %f %f",&nbfac,&nomax,&valor,&valor);
   fprintf(fpval2,"%7d %7d %15.3f %15.3f\n",nbfac,nomax,valeur1_min,valeur1_max);
   fprintf(fpval3,"%7d %7d %15.3f %15.3f\n",nbfac,nomax,valeur2_min,valeur2_max);

   noc=0;

	for(i=0;i<nbfac;i++)
	 { 
	   fscanf(fpval1,"\n%c %d %d ",&c,&nofac,&nbcontour); 
	   //printf("lit noface %d\n",nofac);
	   fprintf(fpval2,"f%d %d\n",nofac,nbcontour);
	   fprintf(fpval3,"f%d %d\n",nofac,nbcontour);


		// attribue la valeur aux contours
	   for(j=0;j<nbcontour;j++) 
             { fscanf(fpval1,"%lf",&bidon);
		       fprintf(fpval2,"%15.6f\n",val_classe[noc]);
		       fprintf(fpval3,"%15.6f\n",val_ecart[noc]);
			   noc++; 
             }
     }
}

/*------------------------------------------------------------*/
void format_entree()
{
  printf("\n   attribue_val_classe  fichier_classe(.txt)  fichier_in2(.val) fichier_out_classe(.val)  fichier_out_classe_ecart(.val)\n\n");
  printf("\n Transmet les valeurs du fichier_classe.txt dans fichier out.val\n");
  printf(" suivant  la structure de fichier_in2.val \n\n");
  printf(" le fichier classe est constitu� d'une suite de lignes comprenant\n");
  printf("     1 valeur_classe ecart_classe\n");
  printf("     2 valeur_classe ecart_classe\n");
  printf("     .....  \n\n");
  printf("NOTA: l'ordre des lignes correspond � l'ordre des contours du fichier_in2.val \n");
  printf("la ligne 1 renseigne le contour 1 du fichier .val\n");
  printf("la ligne 2 renseigne le contour 2 du fichier .val\n");
  printf("et ainsi de suite\n");

}

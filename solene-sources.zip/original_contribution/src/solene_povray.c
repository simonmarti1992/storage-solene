/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/*

cc solene_povray.c solutile.o geomutile.o lib_solene_94.o -o info_fichier -lm

*/

// D. GROLEAU  juillet 2002
//Convertit un fichier triangul� solene en fichier povray

#include<solene.h>

struct modelisation_face *alloue_face();

void format_entree();

/*_________________________________________________________________*/
main(argc,argv)
 int argc;char **argv;
{struct modelisation_face *fs;
 struct contour *pcont;
 struct circuit *pcir;

 FILE *pf1,*pf2;

 int i,j,nbff,noma,nb_contour,nbtrou,noc;
 double englob[10];
 char buf[512],*s_dir;

 if(argc<2){format_entree(); exit(0);}

	s_dir=(char *)getenv("PWD");
printf(" Solene_povray\n\n");
printf(" Convertit fichier solene triangul� en fichier Povray\n");
 compose_nom_complet(buf,s_dir,argv[1],"cir");
 if((pf1=fopen(buf,"r"))==NULL)
       { printf("\n   le fichier %s n'existe pas\n",buf );
	 exit(0);
       }
 printf(" Convertit fichier solene triangul� : %s\n",buf);
compose_nom_complet(buf,s_dir,argv[1],"pov");
 if((pf2=fopen(buf,"w"))==NULL)
       { printf("\n   le fichier %s n'existe pas\n",buf );
	 exit(0);
       }
 printf("                 en fichier POV_Ray : %s\n",buf);

   lit_en_tete(pf1,&nbff,&noma,englob);
   printf("\nNombre de faces du fichier   = %d \n",nbff);
   fs=alloue_face(nbff,1000);

   // met une cam�ra pa d�faut (vue d'en haut)
   // une light source et une texture
   fprintf(pf2,"camera {\n");
 fprintf(pf2,"location <0, 190, 0>\n");
 fprintf(pf2,"look_at <0, 0, 0>\n");
 fprintf(pf2,"}\n");
fprintf(pf2,"light_source { <-20, 30,50> color rgb<1, 1, 1> }\n");
fprintf(pf2,"#declare Red = texture {\n");
 fprintf(pf2,"pigment { color rgb<0.8, 0.2, 0.2>}\n");
 fprintf(pf2,"   finish { ambient 0.9 diffuse 0.5 } \n");
 fprintf(pf2,"}\n");
 
 // fait un mesh de triangles 
 fprintf(pf2,"mesh {\n");
   //lit face par face
   for(i=0;i<nbff;i++)
   {  
	
	  lit_fic_cir3d(pf1,1,fs+i);
      nb_contour=nb_contour_face(fs+i,1);

	  //printf(" lecture de la face %d de %d contours \n",(fs+i)->nofac_fichier,nb_contour);

	  pcont=fs[i].debut_projete; 
	  noc=0;        
	  while(pcont)
         { 
		   nbtrou=nb_trou_contour(pcont);
		   // normalement pas de trou
		   noc++;
		   //printf("      lecture du contour %d avec ses %d trous \n",noc,nbtrou);
           pcir=pcont->debut_support;
  
				fprintf(pf2,"triangle {\n");
				for(j=0;j<3;j++)
				{ // repere am�ricain: dans le plan Z vers le haut, X vers la droite
				  // axe vertical  Y haut
					fprintf(pf2,"<%f, %f, %f>",pcir->x[j],pcir->z[j],pcir->y[j]);
				  if (j!=2) fprintf(pf2,",");
				}
				fprintf(pf2,"}\n");
           pcont=pcont->suc;
        }
	  //printf("             fin de lecture de la face\n");
   }
   // applique la texture � tous les triangles
   fprintf(pf2,"texture { \n");
   fprintf(pf2,"Red\n");
   fprintf(pf2,"}\n");
   fprintf(pf2,"}\n");

   fclose(pf1);
   fclose(pf2);

 
   printf("Fin de solene_povray\n");

  desalloue_fface(fs,nbff);

}
/*_________________________________________________________________*/
void format_entree()
{
  printf("\n    solene_povray   fichier_in (.cir .pov)  \n\n");
}

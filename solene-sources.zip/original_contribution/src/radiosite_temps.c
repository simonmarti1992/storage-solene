/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/* radiosite_temps.c : APPEL RADIOSITE ENSEQUENCE POUR TRAITER LE TEMPS	*/
/*______________________________________________________________________*/

/*
cc radiosite_temps.c  geomutile.o solutile.o lib_solene_94.o -o radiosite_temps -lm
*/

#include<solene.h>

/*_________________________________________________________________*/
main(argc,argv)           
int argc;
char **argv;
{
 int 	i,nb_pas;
 char   buf[2048];

   	if(argc<11) usage_rad_temps();

         sscanf(argv[1],"%d%",&nb_pas);


 /* APPEL RADIOSITE */

for(i=0;i<nb_pas;i++)
  {          
       /* compose ligne de commande */
       sprintf(buf,"radiosite %s%d %s %s %s %s%d  %s%d %s%d %s %s",argv[2],i,argv[3],argv[4],argv[5],argv[6],i,argv[7],i,argv[8],i,argv[9],argv[10]);

       printf("%s\n",buf);

      /* appel de radiosite */
       system(buf);

      /* test si OK  (rm OK_SOLENE) */
	  //Modif SII DFA 24-4-2006 
	if (!existOkSolene()) {
		printf("\n PB execution de radiosite au Pas %d\n\n",i);
	    exit(0);
	}
	cleanOkSolene();
  }

  creer_OK_Solene();
  printf("\nFin radiosite_temps\n\n");

}

/*_________________________________________________________________*/
/* Format de la fonction radiosite_temps */
int usage_rad_temps()
	{
  	printf("\n   format d'entree des parametres (option p : impression)\n\n");
  	printf("   *radiosite*  nb_luminance_a_traiter NOM_GEN_exitances_initiales(0 1 2....val)  coef_reflexion(.val)  facteurs_forme(.fac)  surfaces(.val)  out_incident_W/m2(.val)  out_reflechi_W/m2(.val)  out_absorbe_W/m2(.val)  i entier/e decimal/p decimal/s decimal  [p(impression)]\n");

 printf("\n      la fonction a comme parametres en ENTREE :\n\n");
 printf("\t nb_luminance_a_traiter\n"); 
 printf("\t NOM_GEN_exitances_initiales(0 1 2 ...val) sur la geometrie\n"); 
 printf("\t coef_reflexion(.val) des contours de la geometrie\n"); 
 printf("\t le fichier des facteurs de forme (.ff) de la geometrie\n"); 
 printf("\t les surfaces (.val) des contours de la geometrie\n"); 

  printf("\n           comme parametres en SORTIE, les descripteurs .val :\n\n");
   
 printf("\t eclairement (ou rayonnement) incident apres reflexion (.val)\n"); 
 printf("\t eclairement (ou rayonnement) reflechi apres reflexion (.val)\n"); 
 printf("\t eclairement (ou rayonnement) absorbe apres reflexion (.val)\n"); 

  printf("\n           comme parametres d'arret, soit :\n\n");
	printf("\ti suivi du nombre d'iterations maxi\n");
	printf("\te suivi de valeur d'energie restant a distribuer\n");
	printf("\tp suivi de valeur en %% d'energie restant a distribuer/premiere iteration\n");
	printf("\ts suivi de valeur de la difference maxi entre 2 iterations\n\n");


 	exit(0);
	}

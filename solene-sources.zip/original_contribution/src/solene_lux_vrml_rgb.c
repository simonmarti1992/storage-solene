/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/*

solene_lux_vrml_rgb

  solutile.o geomutile.o lib_solene_94.o


D. GROLEAU  septembre 2005

Traduit un fichier Solene avec ses valeurs d'�clairement et ses couleurs de face en fichier vrml et couleurs rgb
IN	g�om�trie(.cir)
IN	descripteur_lux.(val)
IN	descripteur_no_couleur.(val)
IN	fichier_des_couleurs(.txt)
IN	type_d_operation	// loi de luminosit� (couleur et �clairement)
OUT	fichier_vrml(.wrl)


*/

#include<solene.h>

// DECLARATIONS FUNCTIONS

int ecrit_en_tete();
void format_entree();
int lit_fic_rgb();
void modifie_rgb_luminosite();
void trans_solene_vrml();


// GLOBAL
#define HMAX 4096	// donnees rgb
float rr[HMAX],vv[HMAX],bb[HMAX];
int nb_rgb;
float minv,maxv,ecart_lux;

/*_________________________________________________________________*/
main(argc,argv)
 int argc;char **argv;
{
 char 	buf[512],*s_dir;
 double englob[10];
 int  nb, nbff, nomax;
 FILE *fp,*fp1;
 struct modelisation_face *ff;
 double *lux,*no_couleur;
 int i,op;


 printf("Fonction Solene : solene_lux_vrml_rgb\n\n");
 printf("argc %d \n",argc);

 if(argc!=7)format_entree();

	s_dir=(char *)getenv("PWD");

    // Lit Fichier Geometrie : nbff Faces dans  ff
  compose_nom_complet(buf,s_dir,argv[1],"cir");
  if((fp=fopen(buf,"r"))==NULL)
        { printf("\n impossible ouvrir %s\n",buf); exit(0);}
   lit_en_tete(fp,&nbff,&nomax,englob);
   ff=alloue_face(nbff,35);
   lit_fic_cir3d(fp,nbff,ff);
   fclose(fp);
        

	// calcule le nombre de contour de la geometrie
	nbc = nbcontours_total(ff, nbff);

    printf("\n geometrie_solene_IN %s (%d faces et %d contours)\n",buf,nbff,nbc);

    // Ouvre le fichier des valeurs d'�clairement (lux) : File fp
    compose_nom_complet(buf,s_dir,argv[2],"val");
	if((fp=fopen(buf,"r"))==NULL)
	{ printf("impossible ouvrir %s\n",buf);
	  exit(0);
	}
    printf(" descripteur_lux : %s\n",buf);
			//lit seulement  pour val min et max  */	
    fscanf(fp,"%d %d %f %f\n",&i,&i,&minv,&maxv);
	rewind(fp);
			// calcul de l'�cart en lux pour construire �chelle de luminosit�
	//ecart_lux=maxv_minv;
			// on pourrait aussi prendre ecart / � 0
	ecart_lux=maxv;
		    // Allocation du tableau des valeurs lux associ�es aux contours*/
	lux = alloue_double(nbc,456);
	lect_fic_val(fp, lux);
	fclose(fp);

	
    // Ouvre le fichier des valeurs de No de Couleur : File fp
    compose_nom_complet(buf,s_dir,argv[3],"val");
	if((fp=fopen(buf,"r"))==NULL)
	{ printf("impossible ouvrir %s\n",buf);
	  exit(0);
	}
    printf(" descripteur_no_de_couleur : %s\n",buf);
			    // Allocation du tableau des valeurs no_couleur associ�es aux contours*/
	no_couleur = alloue_double(nbc,456);
	lect_fic_val(fp, no_couleur);
	fclose(fp);

	// Ouvre le fichier couleurs :  File fp
    compose_nom_complet(buf,s_dir,argv[4],"txt");
	if((fp=fopen(buf,"r"))==NULL)
	{ printf("impossible ouvrir %s\n",buf);
	  exit(0);
	}
    printf(" fichier des couleurs rgb : %s\n",buf);
	nb_rgb = lit_fic_rgb(fp,rr,vv,bb);
	fclose(fp);

	// Lit type d'operation (luminosit�) argv[5]
	sscanf(argv[5], "%d", &op);
	printf("operation %d\n",op);
	if(op==0)printf("		rgb sans correction de luminosite f(lux)\n");   
	else if(op==1)printf("       rgb avec correction de luminosite f(lux) suivant �chelle max-min\n");   


	// Ouvre le fichier vrml en OUT : File fp1 
	compose_nom_complet(buf,s_dir,argv[6],"wrl");
	fp1=fopen(buf,"w");
    if(fp1==NULL) 
	{ printf("impossible creer %s\n",buf);
	  exit(0);
	}
	printf(" fichier_vrml_OUT %s\n",buf);
	fprintf(fp1,"#VRML V2.0 utf8\n");


/*
	for(nb=0;nb<nbc;nb++)
	{ printf("%f\n",lux[nb]);
	}
*/

  // Transforme Solene en Vrml  
  
	trans_solene_vrml(nbff,ff,lux,no_couleur,fp1,op);
    

  // fin
   fclose(fp1);

   	desalloue_fface(ff,nbff);
	desalloue_double(lux);
	desalloue_double(no_couleur);

   printf("\nFin du traitement solene_lux_vrml_rgb\n");
  		creer_OK_Solene();

}

/*____________________________________________________________________*/
void trans_solene_vrml(nbff,face,lux,no_couleur,fp,op)
struct modelisation_face *face;
int nbff,op;
double *lux,*no_couleur;
FILE *fp;
{
 int i,j,k;
 struct contour *pcont;
 struct circuit *pcir;

 int noc,nop;
 float rouge,vert,bleu;

 noc=0;					// 1 SHAPE PAR FACE
  for(j=0;j<nbff;j++) 
  {
	fprintf(fp,"Shape {\n");
	fprintf(fp,"geometry IndexedFaceSet {\n");
	fprintf(fp,"coord Coordinate { point [\n");
	pcont=(face+j)->debut_projete; 
    while(pcont)	   
      { pcir=pcont->debut_support;
         for(i=0;i<pcir->nbp-1;i++)
		 {  fprintf(fp," %f %f %f,\n",pcir->x[i],pcir->y[i],pcir->z[i]);
		 }
        pcont=pcont->suc; 
	  }
	fprintf(fp,"] }\n");

	fprintf(fp,"  color Color { color [\n");
	pcont=(face+j)->debut_projete;
    while(pcont)	   
	{       //  lux[noc], no_couleur[noc] : calcul  r g b
			k= (int) (no_couleur[noc])-1;
			modifie_rgb_luminosite(k,lux[noc],&rouge,&vert,&bleu,op);
			//printf("M3 %f %f %f,\n",rouge,vert,bleu);
			fprintf(fp," %f %f %f,\n",rouge,vert,bleu);
        pcont=pcont->suc; 
		noc++;
	  }
	fprintf(fp,"] }\n");

	fprintf(fp,"coordIndex [\n");
	pcont=(face+j)->debut_projete;
	nop=0;
    while(pcont)	   
      { pcir=pcont->debut_support;
        for(i=0;i<pcir->nbp-1;i++)
		 {  fprintf(fp," %d,",nop+i);
		 }
			fprintf(fp," -1,\n");
		nop=nop+pcir->nbp-1;
        pcont=pcont->suc; 
       } 
	fprintf(fp,"  ]\n");
	fprintf(fp," colorPerVertex FALSE\n");
	fprintf(fp," }\n");
	fprintf(fp,"}\n");
  }
}

/*------------------------------------------------------------*/
void modifie_rgb_luminosite(k,lux,rouge_m,vert_m,bleu_m,op)
int k,op;
double lux;
float *rouge_m,*vert_m,*bleu_m;
{ 
float reduc;

	//printf("M1 %f %f %f\n",rr[k],vv[k],bb[k]);
	if(op==0)
	{ 
		*rouge_m=rr[k];
		*vert_m=vv[k];
		*bleu_m=bb[k];
	}
	else if(op==1)
	{	reduc= 1-(maxv-lux)/ecart_lux;
		if (reduc== 0.0)reduc=.98; // pour �viter le noir 
		//printf("reduc=%f\n",reduc);
		*rouge_m=rr[k]*reduc;
		*vert_m=vv[k]*reduc;
		*bleu_m=bb[k]*reduc;
	}
	//printf("M2 %f %f %f,\n",*rouge_m,*vert_m,*bleu_m);

		
}

/*------------------------------------------------------------*/
int lit_fic_rgb(fp,rouge,vert,bleu)

FILE	*fp;
float	*rouge,*vert,*bleu;
{
int i,id;
	i=0;
	while(1)
	{ if (i > HMAX)
		{ printf("trop de lignes dans le fichier rgb (max %d)\n\n",HMAX);
		  exit(0);
		}
	  id= fscanf(fp,"%f %f %f", rouge+i,vert+i,bleu+i);
	  if(id==EOF) break;
	  printf("%d =%f %f %f \n",i, rouge[i],vert[i],bleu[i]);
	  i++;
	}
	printf("	nombre de lignes lues dans le fichier rgb : %d\n",i);
	return(i);
}
/*_________________________________________________________________*/
void format_entree()
{
printf("\n Traduit un fichier Solene avec ses valeurs d'�clairement et ses couleurs de face en fichier vrml et couleurs rgb\n\n");
printf("\n solene_lux_vrml_rgb \n\n");
printf("	IN	g�om�trie(.cir)\n");
printf("	IN	descripteur_lux.(val)\n");
printf("	IN	descripteur_no_couleur.(val) //renvoie au no de couleur dans le fichier_des_couleurs(.txt)\n");
printf("	IN	fichier_des_couleurs(.txt)\n");
printf("	IN	type_d_operation	// loi de luminosit� (couleur et �clairement)\n");
printf("	OUT	fichier_vrml(.wrl)\n");   
printf("\nNOTA:operation =0		rgb sans correction de luminosite f(lux)\n");   
printf("               =1		rgb avec correction de luminosite f(lux) suivant �chelle max-min\n"); 
printf("\nNOTA: le fichier des couleurs est constitu� de lignes de valeurs comprises entre 0 et 1:\n");
printf("			rouge vert bleu  // (couleur n�1) \n");
printf("			rouge vert bleu  // (couleur n�2) \n");
printf("			...............  //  \n");
printf("\nNOTA: le fichier_vrml(.wrl) peut �tre visualis� avec vrmlview\n");
  
  exit(0);
}

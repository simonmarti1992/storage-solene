/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/*

cc masques_cir.c  pers_util.o solutile.o geomutile.o lib_solene_94.o face_op_face.o poly_op_poly.o -o masques_cir -lm -lmalloc

*/

//si recompile, v�rifier nb de param�tres de coplanaire (sens de la normale)


// D.GROLEAU 
// D.GROLEAU    modifi� 23 juillet 2003 (rajoute fichier r�sultats nbre de visibilit�)
// D. GROLEAU  modification mars 2004   appel a coplanaire

/* POUR UN FICHIER .cir */
/* determine pour chaque point, centre de gravite de chaque contour de chaque face */
/* la visibilit� d'un objet d�fini par des points dans un fichierVISISBILITE.cir */
// les points de visibilit� test�s sont en fait
//   seulement le 1er point du premier contour de chaque face
//   il y a donc autant de fichiers r�sultats que de faces dans le fichier des points de visibilit�

// compte le nombre de visibilite de l'objet fichierVISISBILITE.cir

// sur le mod�le de masque_sol
// ATTENTION  modif de mars 2004:
// Ne tient pas compte des faces situ�es dans le m�me plan que celui du contour de la face en traitement


#include<solene.h>

// declare FUNCTIONS

void	close_fic_val();
double	distance();
void	ecrit_autre_val();
void	ecrit_en_tete_val();
void	ecrit_face_val();
void	ecrit_vis_dis_val();
void	format_entree_masques_cir();
void	masque_objet();
void	open_fic_val();
int		vois_je();


extern int z_axono_pers;

// declare en GLOBAL

struct modelisation_face *fac1,*fac2;

FILE *pv[100];
FILE *pnb;     // fichier nbre de visibilit�

extern int option_calcul_z;   /* option CALCUL du Z ds FACE-OP-FACE 1=oui */
                              /* utilise ds singul.c epure_polygone */
			                  /* et dans face_op_face.c             */
extern double coef_discol;

double tgvis,covis,sinvis;
double vnf[3];   /* normale de la  face en traitement */
double *xn_fac1, *yn_fac1, *zn_fac1; // les normales du masque fac1

int		im,tige;
int		i_vis,i_dis,i_nb_pts_vis,i_zmin_vis,i_hauteur_vis,i_pourcen_vis,i_ang_solid_vis;
int		nb_pt_visible,i_min,i_max;
double	dis_min[100],dis_max[100],ang_solid_min,ang_solid_max;
double	hauteur_min,hauteur_max;
double	zmin_vis,zmax_vis;

 double epsilone; // pour ajuster le point � voir

 double	 epsiloneN;  // parametre de coplanaire
 int	 facteurD;   // parametre de coplanaire


/*__________________________________________________________________________*/
main(argc,argv)           /* MASQUE  et visibilit� pour un FICHIER DE FACES */
int argc;char **argv;
{int	i, noc,nbfac,nbfac1,nbfac2,numax;
 double ang;
 char nom_in[256],nom_masc[256],nom_vis[256],nom_nbvis[256],nom_val[256],c,*s_dir;
 FILE *pfic_in,*pfic_masc,*pfic_vis;
 struct modelisation_face *fac ;
 struct contour *pcont;
 struct circuit *pcir;
 int *vis;
 double englob[10];

	
      /* initialisation */
   singularite=0; non_singularite=0; nb_etat=0;
   pb_masque=0; colle_max=coef_discol*DISCOL;
   pi=4*atan(1.);

   // initialisation pour coplan�rit�
   epsiloneN = 0.0001;
   facteurD= 1000;

   // ajustement du point � voir
   epsilone=0.00101;

   if(argc<7) format_entree_masques_cir();
 
      /* lecture parametres commande */

         //s_dir=(char *)getenv("PWD");
		s_dir="";

         compose_nom_complet(nom_in,s_dir,argv[1],"cir");
		 printf("fichier a traiter : %s \n",nom_in);

         compose_nom_complet(nom_masc,s_dir,argv[2],"cir");  
         printf("fichier masque : %s \n",nom_masc);

		 compose_nom_complet(nom_vis,s_dir,argv[3],"cir");  
         printf("fichier � voir : %s \n",nom_vis);

         sscanf(argv[4],"%lf",&ang);
		 if(ang<0 || ang>89.99 || ang<15) 
			{ printf("   *** 15 < angle_vision < 89.99 ***\n");
			  exit(0);
			}
         ang=pi*ang/180.;
         tgvis=tan(ang); covis=cos(ang); sinvis=sin(ang);

		 sprintf(nom_val,"%s%s",s_dir,argv[5]);
		 printf("fichier valeur de visibilit� (.val): %s \n",nom_val);

		 compose_nom_complet(nom_nbvis,s_dir,argv[6],"val");
		 printf("fichier resultat (nbre de visibilit�) : %s \n",nom_nbvis);


	  //impression */
      im=0;
	  // tige = non
	  tige=0;
	  // lit valeurs optionnelles
	  if(argc==8)
	  { sscanf(argv[7],"%c",&c);
	    if(c=='p')  im=1;
		if(c=='t')	tige=1;
	  }
 	  if(argc==9)
	  { sscanf(argv[8],"%c",&c);
	    if(c=='p')  im=1;
		if(c=='t')	tige=1;
	  }
 
      /* lecture des fichiers a traiter */

       if((pfic_in=fopen(nom_in,"r"))==NULL)
            { printf("\n impossible ouvrir %s\n",nom_in); exit(0);
            }
       if((pfic_masc=fopen(nom_masc,"r"))==NULL)
            { printf("\n impossible ouvrir %s\n",nom_masc); exit(0);
            }
       if((pfic_vis=fopen(nom_vis,"r"))==NULL)
            { printf("\n impossible ouvrir %s\n",nom_vis); exit(0);
            }
 
  /* lecture pfic_in */
       lit_en_tete(pfic_in,&nbfac,&numax,englob);
       printf("Traite %d faces\n",nbfac);
       fac=alloue_face(nbfac,34);
       lit_fic_cir3d(pfic_in,nbfac,fac);
       fclose(pfic_in);

  /* lecture pfic_masc :lit le fichier masque */
       lit_en_tete(pfic_masc,&nbfac1,&i,englob);
       printf("avec Masque de %d faces\n\n",nbfac1);
       fac1=alloue_face(nbfac1,34);
       lit_fic_cir3d(pfic_masc,nbfac1,fac1);
       fclose(pfic_masc);

	   // sauve les normales des faces du masque
	   xn_fac1 = alloue_double(nbfac1,567);
	   yn_fac1 = alloue_double(nbfac1,567);
	   zn_fac1 = alloue_double(nbfac1,567);
	   for(i=0;i<nbfac1;i++)
	   { xn_fac1[i] = (fac1+i)->vnorm[0];
	     yn_fac1[i] = (fac1+i)->vnorm[1];
	     zn_fac1[i] = (fac1+i)->vnorm[2];
	   }


  /* lecture pfic_vis :lit le fichier de l'objet � voir */
       lit_en_tete(pfic_vis,&nbfac2,&i,englob);
       printf("par rapport � visibilit� de %d faces\n\n",nbfac2);
       fac2=alloue_face(nbfac2,34);
       lit_fic_cir3d(pfic_vis,nbfac2,fac2);
       fclose(pfic_masc);

   /* Open fichiers val */
	   open_fic_val(nom_val,nbfac2,nbfac,numax);

	/* Open fichier val : du nbre de visibilit� */
	   if((pnb=fopen(nom_nbvis,"w"))==NULL)
            { printf("\n impossible ouvrir %s\n",nom_nbvis); exit(0);
            }
 
	   fprintf(pnb,"%7d %7d %15.2lf %15.2lf\n",nbfac,numax,0.,0.);

   /* initialise min et max des fichiers .val */
	   hauteur_min =0; hauteur_max =0;
	   ang_solid_min =0; ang_solid_max =0;
       vis=(int *)malloc(nbfac1*sizeof(int));


  /// TRAITEMENT

      /* observateur regarde vers le haut a verticale de oeil */
        obs.x=0; obs.y=0; obs.z=-1; 


      /* traitement pour chaque contour de chaque face de nom_in */
		 printf("Traitement en cours ...\n");

         for(i=0;i<nbfac;i++)
           { noc=0;
		      // traite une face
             pcont=(fac+i)->debut_projete; 
			 vnf[0]=(fac+i)->vnorm[0]; 
			 vnf[1]=(fac+i)->vnorm[1]; 
			 vnf[2]=(fac+i)->vnorm[2]; 
			 ecrit_face_val((fac+i)->nofac_fichier,nb_contour_face(fac+i,1),nbfac2);
			 fprintf(pnb,"f%d  %d\n",(fac+i)->nofac_fichier,nb_contour_face(fac+i,1));

				// traite un contour
             while(pcont)	   
               { pcir=pcont->debut_support;
		         centre_de_gravite(pcir, &obs.xo, &obs.yo, &obs.zo);
                 noc++;

                 //printf(" FACE %d  Contour %d\n",(fac+i)->nofac_fichier,noc);
                 //printf(" %lf %lf %lf\n",obs.xo,obs.yo,obs.zo);
			     masque_objet(nbfac1,vis,(fac+i),nbfac2);
				  
                 pcont=pcont->suc;
               } 
           }
  // FIN
       desalloue_fface(fac,nbfac);
       desalloue_fface(fac1,nbfac1);
       desalloue_fface(fac2,nbfac2);

	   desalloue_double(xn_fac1,nbfac1);
	   desalloue_double(yn_fac1,nbfac1);
	   desalloue_double(zn_fac1,nbfac1);

       close_fic_val(nbfac2,nbfac,numax);
	   fclose(pnb);

       creer_OK_Solene();
	   printf("\n\nFin du Traitement masques_cir\n");
}

/*_________________________________________________________________*/
void masque_objet(nbfac1,vis,fac,nbfac2)
int nbfac1,*vis;
struct modelisation_face *fac;
{  int i, vu, k, nbvu;
   struct contour *pcont;
   struct circuit *pcir;

  /* TRANSFORMATION fichier "masque" et COUPE PYRAMIDE , si vu */
       tranfo();
       for(i=0;i<nbfac1;i++)
	    { 	
	      if(!(coplanaire(fac,1,fac1+i,1,epsiloneN,0,facteurD)))
              { //printf(" qui n'est pas coplanaire avec face %d\n",(fac1+i)->nofac_fichier);
				 if(visible_pers(fac1+i,1))
                   { 
					 //printf(" qui voit la face %d\n",(fac1+i)->nofac_fichier);
					 vis[i]=1;
					 //liste_face(fac1+i,1);

                     tran_face(fac1+i,1,fac1+i,0);
                     tran_normale((fac1+i)->vnorm);
                     if((fac1+i)->debut_dessin) 
                        { calcul_d_du_plan(fac1+i,0);
					      //printf("Apres transfo\n");
					 	  //liste_face(fac1+i,0);
                          face_dans_vision(fac1+i,0);
					      //printf("Apres dans vision\n");
						  //liste_face(fac1+i,0);

                        }
                   }
                 else vis[i]=0;
               }
            else vis[i]=0;
          }
  /* PERSPECTIVE */
       init_fenetre_affichage();
       for(i=0;i<nbfac1;i++)
	   { if((fac1+i)->debut_dessin)
               { pers_conic_face(fac1+i,0);
				 //printf(" APRES PERS avec face %d\n",(fac1+i)->nofac_fichier);
				 //liste_face(fac1+i,0);
               }
	   }
  /* reajuste la fenetre a angle de vision */
       fen_aff[0]=-tgvis; fen_aff[1]=-tgvis; 
       fen_aff[3]=tgvis; fen_aff[4]=tgvis; 
       cal_fen_aff();
              /* attention si angvis proche de 90 */
              /* on evite fen_aff[6]=0 */
       if(fen_aff[6]<0.008) fen_aff[6]=0.008;

  // pour pers
            z_axono_pers=1;
            option_calcul_z=0;

  /* NORMALISATION */
       for(i=0;i<nbfac1;i++)
	   { if((fac1+i)->debut_dessin)
               { normalise_face(fac1+i,0);
	   			 //printf(" APRES NORMALISE avec face %d\n",(fac1+i)->nofac_fichier);
                 //liste_face(fac1+i,0);
               }
          }


  /* Test de VISIBILITE de l'objet nom_vis : 1 face, 1 contour */
	   // examen pour chaque pt du contour
	   // et ecrit les r�sultats 

	nb_pt_visible=0; zmin_vis=0; zmax_vis=0; i_min=0; i_max=0;
	pcont = (fac2)->debut_projete;
	pcir = pcont->debut_support;
	 // ne considere que le 1er pt du 1er contour de chaque face fa2
    for(k=0;k<nbfac2;k++) 
	{ 
	  pcont = (fac2+k)->debut_projete;
	  pcir = pcont->debut_support;
      //printf("pt de face %d\n",k+1);
	  // on lance le calcul :4 fois mais pas au centre et � epsilone pr�s en x et en y
	  nbvu=0;
	  //vu = vois_je(nbfac1,pcir->x[0],pcir->y[0],pcir->z[0]);
	  //nbvu+=vu;
	  vu = vois_je(nbfac1,pcir->x[0]+epsilone,pcir->y[0],pcir->z[0]);
	  nbvu+=vu;
	  vu = vois_je(nbfac1,pcir->x[0]-epsilone,pcir->y[0],pcir->z[0]);
	  nbvu+=vu;
	  vu = vois_je(nbfac1,pcir->x[0],pcir->y[0]+epsilone,pcir->z[0]);
	  nbvu+=vu;
	  vu = vois_je(nbfac1,pcir->x[0],pcir->y[0]-epsilone,pcir->z[0]);
	  nbvu+=vu;
	  // vu si vu au moins 3 fois
	  if(nbvu >= 2)
	  { vu=1;
	    nb_pt_visible++;
	  }
	  else vu = 0;
	  //printf("vu =  %d\n",vu);
	  // ecrit dans fic_val
	  ecrit_vis_dis_val(k,vu,pcir->x[0],pcir->y[0],pcir->z[0]);
	}
	// ecrit le nb de visibilit�s
	ecrit_autre_val(nb_pt_visible);

    z_axono_pers=0;
    option_calcul_z=1;

  /*  reinverse la normale et desallocation face->dessin */
	for(i=0;i<nbfac1;i++)
	   { (fac1+i)->vnorm[0] = xn_fac1[i];
	     (fac1+i)->vnorm[1] = yn_fac1[i];
	     (fac1+i)->vnorm[2] = zn_fac1[i];
		 if((fac1+i)->debut_dessin)
              { desalloue_chaine_contour((fac1+i)->debut_dessin);
                (fac1+i)->debut_dessin=NULL;
              }
	   }
}

/*-----------------------------------------------------------------------------*/
int vois_je(nbfac1,x,y,z)
int		nbfac1;
double	x,y,z;
{
 int	in,ij;
 double xyz[3],xp,yp,zp,ang_inc,bidon;
 struct contour *pcont;
 struct circuit *pcir;
double zm;
	//printf("vois-je le point xyz %f %f %f\n",x,y,z);
	 // direction point de vue - point � voir
	xyz[0] = x - obs.xo;
	xyz[1] = y - obs.yo;
	xyz[2] = z - obs.zo;
	//printf("vecteur de vue  %f %f %f\n",xyz[0],xyz[1],xyz[2]);

      // test si point � voir visible du plan de la face ang_inc >0 
      ang_inc=vincid(vnf,xyz,&bidon);
	  if(ang_inc <=0)
	  { //printf("pas vu (du a plan face)\n");
	    return(0);
	  }

	  // visible possiblement
       tranp(xyz[0],xyz[1],xyz[2],xyz,xyz+1,xyz+2);
      // coupe par pyramide : retient ou non le point */
       if(xyz[2]<0 && fabs(xyz[0]/xyz[2])<tgvis && fabs(xyz[1]/xyz[2])<tgvis) 
          { 
           // met en pers *
           xp=-xyz[0]/xyz[2];
           yp=-xyz[1]/xyz[2];
           zp=0;
           normalise_point(xp,yp,zp,&xp,&yp,&zp);
           /* test si dans masque */
           in=0;
           for(ij=0;ij<nbfac1;ij++)
		   { if((fac1+ij)->debut_dessin)
              { 
			    in=point_dans_face(xp,yp,fac1+ij,0);
			    //printf(" test in pour face %d in= %d\n",(fac1+ij)->nofac_fichier,in);
                if(in)
				{ // le point vis� est dans un masque
				  // test si devant ou derriere
					pcont = (fac1+ij)->debut_dessin;
					pcir = pcont->debut_support;
					//printf("normale face %f %f %f %f\n",pcir->vnorm[0],pcir->vnorm[1],pcir->vnorm[2],pcir->vnorm[3]);
					//liste_face((fac1+ij),0);
					zm= calcul_zplan(pcir,xp,yp);
					//printf("face %d\n",(fac1+ij)->nofac_fichier);
					//printf("zm %f  xyz %f\n",zm , xyz[2]);
					if( zm > xyz[2] )
					{ // le point vise est derriere le masque
				      //printf("pas vu (du a plan face)\n");
					  return(0);
					}
				}
              }
            }
              return(1);
          }
	   else 
	   { //printf("//pas vu (du champ de vision)\n");
		 return(0);
	   }
}


//_____________________________________________________________________________
// ouverture des fichiers val
void open_fic_val(nom,nbfac2,nbfac,numax)
char *nom;
int nbfac2,nbfac,numax;
{
 char	buf[256];
 struct contour *pcont;
 struct circuit *pcir;
 int	i;
 double	vm;

	 // pour une face de visibilit� : 1 point par face
	 // ouvre autant de fichiers que de faces
	 // pour un fichier 
			// de visibilit� avec la valeur Z du point vu
			// de distance de visibilit�

 i_vis =0 ; i_dis= i_vis+nbfac2;
 vm = 10000000.;

 for (i=0;i<nbfac2;i++)
 { sprintf(buf,"%s_zvis_%d.val",nom,i+1);
   printf("open %s\n",buf);
   if((pv[i_vis+i]=fopen(buf,"w"))==NULL)
            { printf("\n impossible ouvrir %s\n",buf); exit(0);
            }
   pcont=(fac2+i)->debut_projete;
   pcir= pcont->debut_support;
   ecrit_en_tete_val(i_vis+i,(double)0.,pcir->z[0],nbfac,numax);
 }

 for (i=0;i<nbfac2;i++)
 { sprintf(buf,"%s_dvis_%d.val",nom,i+1);
   printf("open %s\n",buf);
   if((pv[i_dis+i]=fopen(buf,"w"))==NULL)
            { printf("\n impossible ouvrir %s\n",buf); exit(0);
            }
   pcont=(fac2+i)->debut_projete;
   pcir= pcont->debut_support;
   ecrit_en_tete_val(i_dis+i,vm,-vm,nbfac,numax);
   dis_min[i]= vm; dis_max[i] =-vm;
 }

}

//_____________________________________________________________________________
// 
void ecrit_en_tete_val(i,vmin,vmax,nbfac,numax)
int		i;
double	vmin,vmax;
{
	fprintf(pv[i],"%7d %7d %15.2lf %15.2lf\n",nbfac,numax,vmin,vmax);
}

//_____________________________________________________________________________
// 
void ecrit_face_val(nof,nbc,nbfac2)
int	nof,nbc;
{
 	int i;
	for(i=0;i<nbfac2;i++)
	{
		fprintf(pv[i_vis+i],"f%d  %d\n",nof,nbc);
		fprintf(pv[i_dis+i],"f%d  %d\n",nof,nbc);
	}
}

//_____________________________________________________________________________
//
double distance(x1,y1,z1,x2,y2,z2)
double x1,y1,z1,x2,y2,z2;
{
double dis;

// calcul en 3D 
//dis= sqrt((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1)+(z2-z1)*(z2-z1));
// mieux en 2D, dist horizontale?);
dis= sqrt((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1));
return(dis);
}


//_____________________________________________________________________________
//
void ecrit_vis_dis_val(k,vu,x,y,z)
int	k,vu;
double x,y,z;
{
double dis;
 
	if(vu)
	{ fprintf(pv[i_vis+k],"%f\n",z);
	 dis= distance(obs.xo,obs.yo,obs.zo,x,y,z);
	 if(dis < dis_min[k]) dis_min[k] = dis;
	 if(dis > dis_max[k]) dis_max[k] = dis;
	 fprintf(pv[i_dis+k],"%f\n",dis);
	}
	else
	{ fprintf(pv[i_vis+k],"%f\n",(float)0.);
	  fprintf(pv[i_dis+k],"%f\n",(float)0.);
	}
}

//_____________________________________________________________________________
//
void ecrit_autre_val(nbvis)
int nbvis;
{
		 fprintf(pnb,"%d\n",nbvis);

}

//_____________________________________________________________________________
//
void close_fic_val(nbfac2,nbfac,numax)
int nbfac2,nbfac,numax;
{
	int i;
	// close fichier visibilit� (zvis)
	for (i=0;i<nbfac2;i++)
	{ fclose(pv[i_vis+i]);
	}

	// close fichier distance� (dist)
	for (i=0;i<nbfac2;i++)
	{ rewind(pv[i_dis+i]);
	  ecrit_en_tete_val(i_dis+i,dis_min[i],dis_max[i],nbfac,numax);
	  fclose(pv[i_dis+i]);
	}

}
/*_________________________________________________________________*/
void format_entree_masques_cir()
{
  printf("\n   format d'entree des parametres \n\n");
  printf("masques_cir fichier_in(.cir) fichier_masque_in(.cir) fichier_visibilite(.cir) angle_vision fichiers_val(.val) nb_de_visibilite[t] [p]\n\n");
  printf("	t - fichier visibilite= tige (defaut NON)\n");
  printf("	p - impression (defaut NON)\n");
  exit(0);
}

/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/*

cc info_fichier.c solutile.o geomutile.o lib_solene_94.o -o info_fichier -lm

*/

#include<solene.h>

struct modelisation_face *alloue_face();

FILE *pf1;

/*_________________________________________________________________*/
main(argc,argv)
 int argc;char **argv;
{struct modelisation_face *fs;
 struct contour *pcont;
 struct circuit *pcir;

 int i,nbff,noma,nb_contour,nbtrou,noc;
 double englob[10];
 char buf[512],*s_dir;

 if(argc<2){format_entree_info_fichier(); exit(0);}

	s_dir=(char *)getenv("PWD");


 compose_nom_complet(buf,s_dir,argv[1],"cir");
 if((pf1=fopen(buf,"r"))==NULL)
       { printf("\n   le fichier %s n'existe pas\n",buf );
	 exit(0);
       }

   lit_en_tete(pf1,&nbff,&noma,englob);
   printf("\nNombre de faces du fichier   = %d \n",nbff);
   fs=alloue_face(nbff,1000);
   //lit_fic_cir3d(pf1,nbff,fs);

   //lit face par face
   for(i=0;i<nbff;i++)
   {  
	
	  lit_fic_cir3d(pf1,1,fs+i);
      nb_contour=nb_contour_face(fs+i,1);

	  printf(" lecture de la face %d de %d contours \n",(fs+i)->nofac_fichier,nb_contour);

	  pcont=fs[i].debut_projete; 
      if(pcont)
       {noc=0;
        while(pcont)
         { 
		   nbtrou=nb_trou_contour(pcont);
		   noc++;
		   printf("      lecture du contour %d avec ses %d trous \n",noc,nbtrou);
           pcir=pcont->debut_support;
                       /* support ; en principe 1 seul */
           pcir=pcont->debut_interieur;
                      /* les trous */
           while(pcir)
              { 
                pcir=pcir->suc;
              }
           pcont=pcont->suc;
        }
     }
	  printf("             fin de lecture de la face\n");
   }
   fclose(pf1);

 
   printf("Fin de lecture\n");

  desalloue_fface(fs,nbff);

}
/*_________________________________________________________________*/
format_entree_info_fichier()
{
  printf("\n    *info_fichier_cir*   fichier_in (.cir)  \n\n");
}

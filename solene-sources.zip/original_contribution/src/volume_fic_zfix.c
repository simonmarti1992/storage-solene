/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/* 
cc volume_fic_zfix .c geomutile.o solutile.o lib_solene_94.o -o volume_fic  -lm 
*/
// D. GROLEAU
// cr�� juillet 2002
// modifi� nov 2002 (impose cote Z du toit ou de la base; le programme voit ce qu'il ya � faire
//				en fonction du Z du contour fourni)
// modifi�  nov 2003  (correction d'une erreur qui conduisait al�atoirement � construire le volume vers le haut ou le bas)

/*********************************************************/
/* genere un fichier de volumes 3D a partir d'un fichier */
/* de contours contenus dans un fichier (.cir) 
 et un Z fixe 
comme pour  rabaisser un plan de toiture � Z=val pour chaque contour  */

/* le mod�le est volume_fic  */
/*********************************************************/

#include<solene.h>

// FUNCTIONS

int desalloue_chaine_circuit();

void ecrit_en_tete();
void enr_face();
void format_entree();
void genere_bord_moins();
void genere_bord_plus();
void genere_dessus_moins();
void genere_dessus_plus();
void genere_dessous_moins();
void genere_dessous_plus();
void genere_faces();

// GLOBAL
FILE *pf1,*fval,*fp,*fval1;
struct modelisation_face *fc,*fv;
int nbfc,nbfs,no_app;
double englob[10],mini,maxi;
int dessous;

// fixe COTE Z
double coteZ;

/*----------------------------------------------------------------------*/
main(argc,argv)
int argc;char **argv;
{int nomax,numax;
 char	nom_fic[256],*s_dir; 
 float v1;
 int noenr;


 if(argc<4){format_entree(); exit(0);}
 s_dir=(char *)getenv("PWD");

 printf(" Fonction : volume_fic_zfix\n");
  /* lit le fichier des contours */
 compose_nom_complet(nom_fic,s_dir,argv[1],"cir");
 if((pf1=fopen(nom_fic,"r"))==NULL)
       { printf("\n   le fichier %s n'existe pas\n",nom_fic);
	 exit(0);
       }
printf("\n%s\n",nom_fic);

   lit_en_tete(pf1,&nbfc,&nomax,englob);
   fc=alloue_face(nbfc,1000);
   lit_fic_cir3d(pf1,nbfc,fc); 
   fclose(pf1);

/*printf("nbf %d\n",nbfc);*/

/* lit le fichier de hauteur */
     compose_nom_complet(nom_fic,s_dir,argv[2],"val");
     if((fval=fopen(nom_fic,"r"))==NULL)
            { printf("\nimpossible ouvrir %s\n",nom_fic);
	      exit(0);
	    }
printf("%s\n",nom_fic);

/* ajoute la hauteur en plus ou en moins */
/* c'est selon la valeur du .val de hauteur */
/*  iplus=1 si hauteur >0. ; =0 si hauteur <0 */
  
   fscanf(fval,"%d %d %f %f",&nbfs,&numax,&v1,&v1);

/*printf("nbf %d\n",nbfs);*/

   if(nbfs!=nbfc)
    {printf("\n les 2 fichiers ne comportent pas le meme nombre de faces\n");
     fclose(fval);exit(0);
    }
   if(nomax!=numax)
    {printf("\n les 2 fichiers ne comportent pas le meme nomax de faces\n");
     fclose(fval);exit(0);
    }

   compose_nom_complet(nom_fic,s_dir,argv[3],"cir");
   if((fp = fopen(nom_fic, "w"))==NULL)
	{ printf("\n impossible creer %s\n",nom_fic);
	  exit(0);
        }
printf("%s\n",nom_fic);

 /* le fichier .val d'appartenance  NE LE FAIT PAS pour SOLENE+ */

   if(argc==5) { printf(" ajoute les faces du dessous\n"); dessous=1; }
   else { printf(" ne genere pas les faces du dessous\n"); dessous=0; }

   printf(" execution en cours ....\n");

   ecrit_en_tete(fp,nbfc,nomax,englob);

   noenr=0; 
   genere_faces(nbfc,fc,&noenr);

  rewind(fp);
  ecrit_en_tete(fp,noenr,noenr,englob);

 desalloue_fface(fc,nbfc);
 fclose(fp); fclose(fval);

printf("Fin volume_fic_zfic\n\n");

creer_OK_Solene();

}
/*-----------------------------------------------------*/
void genere_faces(nbf,ff,noenr)
int nbf,*noenr;
struct modelisation_face *ff;
{int i,k,nbcont,nofac;
 struct contour *pcont;
 struct circuit *pcir,*pcirt;
 double h;
 char c;
 int haut_vers_bas;

  for(i=0;i<nbf;i++)
	{ printf("traite la face %d (no %d)\n",i,(ff+i)->nofac_fichier );
      nbcont=nb_contour_face(ff+i,1);

         fscanf(fval,"\n%c %d %d ",&c,&nofac,&nbcont);

   /* genere les pleins */
	pcont=(ff+i)->debut_projete;
    while(pcont)
    {
  	 pcir=pcont->debut_support;

	 fscanf(fval,"%lf",&h);

	 //test si rabat TOIT vers SOL
	 // ou  si remonte SOL vers TOIT
	 if(pcir->z[0] > h) 
	 { haut_vers_bas=1;
	   printf("construit vers le bas\n");
	 }
	 else
	 { haut_vers_bas=0;
	   printf("construit vers le haut\n");

	 }

	 // fixe cote Z
	 coteZ = h;

         if(haut_vers_bas == 0)
                      {    /* LE CONTOUR PLEIN */
                           /* genere la face du dessus */
			genere_dessus_plus(noenr,pcir,&englob[1],h,pcont);
                           /* genere la  face du dessous */
	                if(dessous)genere_dessous_plus(noenr,pcir,pcont);
                 	   /* genere les faces de bord */
                        genere_bord_plus(noenr,pcir,h,0);

                           /* LES CONTOURS VIDES trous*/
                 	   /* genere les faces de bord */
                        pcirt=pcont->debut_interieur;
                        while(pcirt)
                         {   /* inverser LES NORMALES */
                           genere_bord_plus(noenr,pcirt,h,1);
			   pcirt=pcirt->suc;
                         }
   
		      }

		   else 
		      {    /* LE CONTOUR PLEIN */
                           /* genere la face du dessus */
			genere_dessus_moins(noenr,pcir,pcont);
                           /* genere la  face du dessous */
			if(dessous)genere_dessous_moins(noenr,pcir,h,pcont);

  			else
			  { for(k=0;k<pcir->nbp;k++)
         			{ if(pcir->z[k]-h < englob[0]) englob[0]=pcir->z[k]-h;
  				}
			  }

                 	   /* genere les faces de bord */
                        genere_bord_moins(noenr,pcir,h,0);

                           /* LES CONTOURS VIDES */
                 	   /* genere les faces de bord */
                        pcirt=pcont->debut_interieur;
                        while(pcirt)
                         {   /* inverser LES NORMALES */
                           genere_bord_moins(noenr,pcirt,h,1);
			   pcirt=pcirt->suc;
                         }

		      }
           pcont=pcont->suc;
          }
	}
}
/*-----------------------------------------------------*/
void genere_dessus_plus(noenr,pcir,zmax,h,pcont)
int *noenr;
double *zmax;
struct circuit *pcir;
double h;
struct contour *pcont;
{
 int i,nbtrou;
 struct circuit *pcirt;

       *noenr=*noenr+1;
       nbtrou=nb_trou_contour(pcont);

          fprintf(fp,"f%d  1\n",*noenr);
	  fprintf(fp,"   %f %f %f\n",pcir->vnorm[0],pcir->vnorm[1],pcir->vnorm[2]);
          fprintf(fp,"c%d \n",nbtrou);

          fprintf(fp,"  %d \n",pcir->nbp);
        for(i=0;i<pcir->nbp;i++)
          { fprintf(fp,"    %f %f %f\n",pcir->x[i],pcir->y[i],coteZ);
	   if(*zmax<pcir->z[i]+h)*zmax=pcir->z[i]+h;
	  }

       /* rajoute les trous */

           pcirt=pcont->debut_interieur;
                      /* les trous */
           while(pcirt)
              { fprintf(fp,"t%\n");
                fprintf(fp,"  %d \n",pcirt->nbp);
                for(i=0;i<pcirt->nbp;i++)
                  { fprintf(fp,"    %f %f %f\n",pcirt->x[i],pcirt->y[i],coteZ);
	            if(*zmax<pcirt->z[i]+h)*zmax=pcirt->z[i]+h;
	          }
                pcirt=pcirt->suc;
              }


}
/*-----------------------------------------------------*/
void genere_dessous_plus(noenr,pcir,pcont)
int *noenr;
struct circuit *pcir;
struct contour *pcont;
{
  int i,nbtrou;
 struct circuit *pcirt;

      *noenr=*noenr+1;

       nbtrou=nb_trou_contour(pcont);

      fprintf(fp,"f%d  1\n",*noenr);
          fprintf(fp,"   %f %f %f\n",-(pcir->vnorm[0]),-(pcir->vnorm[1]),-(pcir->vnorm[2]));
          fprintf(fp,"c%d \n",nbtrou);

          fprintf(fp,"  %d \n",pcir->nbp);
          for(i=0;i<pcir->nbp;i++)
               fprintf(fp,"    %f %f %f\n",pcir->x[i],pcir->y[i],pcir->z[i]);


       /* rajoute les trous */

           pcirt=pcont->debut_interieur;
                      /* les trous */
           while(pcirt)
              { fprintf(fp,"t%\n");
                fprintf(fp,"  %d \n",pcirt->nbp);
                for(i=0;i<pcirt->nbp;i++)
                  { fprintf(fp,"    %f %f %f\n",pcirt->x[i],pcirt->y[i],(pcirt->z[i]));
	          }
                pcirt=pcirt->suc;
              }
}

/*-----------------------------------------------------*/
void genere_bord_plus(noenr,pcir,h,sens)
int *noenr;
double h;
struct circuit *pcir;
int sens;
{int i;
 struct circuit *pcirc;

   pcirc=alloue_circuit(10);
    pcirc->nbp=5;

    for(i=0;i<pcir->nbp-1;i++)
	{	 alloue_point_circuit(pcirc,10);
	 pcirc->x[0]=pcir->x[i]; pcirc->y[0]=pcir->y[i]; pcirc->z[0]=pcir->z[i];
	 pcirc->x[1]=pcir->x[i+1]; pcirc->y[1]=pcir->y[i+1]; pcirc->z[1]=pcir->z[i+1];
	 pcirc->x[2]=pcir->x[i+1]; pcirc->y[2]=pcir->y[i+1]; pcirc->z[2]=coteZ;
	 pcirc->x[3]=pcir->x[i]; pcirc->y[3]=pcir->y[i]; pcirc->z[3]=coteZ;
	 pcirc->x[4]=pcir->x[i]; pcirc->y[4]=pcir->y[i]; pcirc->z[4]=pcir->z[i];

         if(sens) invsens(pcirc); /* Pour inverser normale */

	 normale(pcirc,pcirc->vnorm);
	 enr_face(pcirc,noenr);


	}

    desalloue_chaine_circuit(pcirc,20);
}

/*-----------------------------------------------------*/
void genere_dessus_moins(noenr,pcir,pcont)
int *noenr;
struct circuit *pcir;
struct contour *pcont;
{
 int i,nbtrou;
 struct circuit *pcirt;

      *noenr=*noenr+1;

       nbtrou=nb_trou_contour(pcont);

      fprintf(fp,"f%d  1\n",*noenr);
          fprintf(fp,"   %f %f %f\n",(pcir->vnorm[0]),(pcir->vnorm[1]),
(pcir->vnorm[2]));
          fprintf(fp,"c%d \n",nbtrou);
         fprintf(fp,"  %d \n",pcir->nbp);
  for(i=0;i<pcir->nbp;i++)
         fprintf(fp,"    %f %f %f\n",pcir->x[i],pcir->y[i],pcir->z[i]);

     /* rajoute les trous */

           pcirt=pcont->debut_interieur;
                      /* les trous */
           while(pcirt)
              { fprintf(fp,"t%\n");
                fprintf(fp,"  %d \n",pcirt->nbp);
                for(i=0;i<pcirt->nbp;i++)
                  { fprintf(fp,"    %f %f %f\n",pcirt->x[i],pcirt->y[i],(pcirt->z[i]));
	          }
                pcirt=pcirt->suc;
              }

}
/*-----------------------------------------------------*/
void genere_dessous_moins(noenr,pcir,h,pcont)
int *noenr;
struct circuit *pcir;
double h;
struct contour *pcont;
{ 
 int i,nbtrou;
 struct circuit *pcirt;

         *noenr=*noenr+1;
       nbtrou=nb_trou_contour(pcont);

          fprintf(fp,"f%d  1\n",*noenr);
	  fprintf(fp,"   %f %f %f\n",-pcir->vnorm[0],-pcir->vnorm[1],-pcir->vnorm[2]);
          fprintf(fp,"c0 \n");
          fprintf(fp,"  %d \n",pcir->nbp);
   for(i=0;i<pcir->nbp;i++)
         {fprintf(fp,"    %f %f %f\n",pcir->x[i],pcir->y[i],coteZ);
	  if(pcir->z[i]+h < englob[0]) englob[0]=pcir->z[i]+h;
	 }

     /* rajoute les trous */

           pcirt=pcont->debut_interieur;
                      /* les trous */
           while(pcirt)
              { fprintf(fp,"t%\n");
                fprintf(fp,"  %d \n",pcirt->nbp);
                for(i=0;i<pcirt->nbp;i++)
                  { fprintf(fp,"    %f %f %f\n",pcirt->x[i],pcirt->y[i],coteZ);
	          }
                pcirt=pcirt->suc;
              }

}
/*-----------------------------------------------------*/
void genere_bord_moins(noenr,pcir,h,sens)
int *noenr;
double h;
struct circuit *pcir;
int sens;
{int i;
 struct circuit *pcirc;

   pcirc=alloue_circuit(10);
    pcirc->nbp=5;

    for(i=0;i<pcir->nbp-1;i++)
	{	 alloue_point_circuit(pcirc,10);
	 pcirc->x[0]=pcir->x[i]; pcirc->y[0]=pcir->y[i]; pcirc->z[0]=pcir->z[i];
	 pcirc->x[1]=pcir->x[i]; pcirc->y[1]=pcir->y[i]; pcirc->z[1]=coteZ;
	 pcirc->x[2]=pcir->x[i+1]; pcirc->y[2]=pcir->y[i+1]; pcirc->z[2]=coteZ;
	 pcirc->x[3]=pcir->x[i+1]; pcirc->y[3]=pcir->y[i+1]; pcirc->z[3]=pcir->z[i+1];
	 pcirc->x[4]=pcirc->x[0]; pcirc->y[4]=pcirc->y[0]; pcirc->z[4]=pcirc->z[0];

         if(sens) invsens(pcirc);  /* Pour inverser normale */
	 normale(pcirc,pcirc->vnorm);
	 enr_face(pcirc,noenr);
	}

    desalloue_chaine_circuit(pcirc,20);
}
/*-----------------------------------------------------*/
void enr_face(pcir,noenr)
struct circuit *pcir;
int *noenr;
{
 int i;
  (*noenr)++;
/*
                         fprintf(fval1,"f%d 1\n",*noenr); 
                         fprintf(fval1,"%d.0\n",no_app);
*/
  fprintf(fp,"f%d  1\n",*noenr);
  fprintf(fp,"    %f %f %f\n",pcir->vnorm[0],pcir->vnorm[1],pcir->vnorm[2]);
  fprintf(fp," c0\n");
  fprintf(fp,"   %d\n",pcir->nbp);
  for(i=0;i<pcir->nbp;i++)
	 fprintf(fp,"    %f %f %f\n",pcir->x[i],pcir->y[i],pcir->z[i]);
}


/*_________________________________________________________________*/
/* Format de la fonction VOLUME_FIC*/
void format_entree()
{
  printf("\n *volume_fic_zfix* fichier_in(.cir) fichier_in(.val) fichier_out(.cir)    [D]\n\n");

  printf(" Le fichier (.cir) contient les contours des volumes (toit ou base) � une certaine cote z\n");
  printf(" on construit le volume 3D en imposant la cote Z (de la base ou du toit)\n");
  printf(" le fichier (.val) contient les cotes Z � appliquer pour chaque contour \n\n");
  printf(" D : genere les faces de dessous (facultatif)\n\n");

  printf(" NOTA : � faire ensuite pour epurer la g�om�trie: \n");
  printf(" \t importer dans solene (supprime les faces doubles)\n");
  printf(" \t lancer la fonction sup_faces_non_visible pour enlever les faces jamais visibles\n\n");


}

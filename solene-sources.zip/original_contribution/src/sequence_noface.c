/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/*

cc sequence_noface.c -o sequence_noface ~marenne/newsolene/solutile.o ~marenne/newsolene/geomutile.o ~marenne/newsolene/face_op_face.o ~marenne/newsolene/poly_op_poly.o ~marenne/newsolene/lib_solene_94.o -lm

*/

#include<solene.h>


/*_________________________________________*/
/* DESCRIPTION
  res�quence les no de faces   d'un fichier .cir � partir d'une valeur de no
*/

int ecrit_en_tete();
void format_entree();

/*________________________________________________________________________*/
main(argc,argv)
char **argv;
int  argc ;
{
char 	buf[512],*s_dir;
double	englob[10];
int nbfac1,nomax1;

FILE *fsource,*fdest;
struct modelisation_face *fac1;

int i,nod;
int nb, nomax;


 if(argc!=4)
   { format_entree();
     exit(0);
   }
   

printf("Fonction Solene : sequence_noface\n");

 s_dir=(char *)getenv("PWD");

 compose_nom_complet(buf,s_dir,argv[1],"cir");
 if((fsource = fopen(buf, "r"))==NULL)
// if((fsource = fopen("c:\\temp\\Wessai_15_2.cir", "r"))==NULL)
	{ printf("\n impossible ouvrir %s\n",buf);
	  exit(0);
    }
printf("geometrie IN  = %s\n",buf);

 sscanf(argv[2],"%d",&nod);
 printf("face � renum�roter � partir de %d\n",nod);

 compose_nom_complet(buf,s_dir,argv[3],"cir");
 if((fdest = fopen(buf, "w"))==NULL)
// if((fdest = fopen("c:\\temp\\Wessai_UNI.cir", "w"))==NULL)
	{ printf("\n impossible creer %s\n",buf);
	  exit(0);
        }
printf("geometrie OUT = %s\n",buf);

   lit_en_tete(fsource,&nbfac1,&nomax1,englob);
   // alloue une face
   fac1=alloue_face(1,1000);

   ecrit_en_tete(fdest,nbfac1,nod+nbfac1-1,englob);

   
  /* traite le res�quen�age des no de faces */

  for(i=0;i<nbfac1;i++)
  {
   lit_fic_cir3d(fsource,1,fac1); 
   fac1->nofac_fichier=nod+i;
   //printf("face %d \n",fac1->nofac_fichier);
   output_face_sur_fichier(fac1,1,1,0,fdest,&nb,&nomax);
   desalloue_contour_face(fac1);
  }

  desalloue_fface(fac1,1);
  fclose(fsource);
  fclose(fdest);

  printf("fichier res�quenc� entre %d et %d\n",nod,nod+nbfac1-1);
  printf("Fin : sequence_noface\n");
  creer_OK_Solene();

 }


/*________________________________________________________________________*/
void format_entree()
{
  printf("\n sequence_noface  \n\n");
  printf("\t   param�tres de la fonction \n\n");
  printf("\t IN		fichier_in(.cir) \n");
  printf("\t IN		no_de_depart \n");
  printf("\t OUT	fichier_out(.cir) \n\n");
  exit(0);
}






/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/*

cc trou_face.c  solutile.o geomutile.o lib_solene_94.o

*/
// D. GROLEAU janvier 2005

// construit, a partir d'un fichier.cir  , 
// 
// un  fichiers .cir contenant la g�om�trie des contours des trous

#include<solene.h>


// DECLARATIONS FUNCTIONS

int ecrit_en_tete();
void format_entree();



/*_________________________________________________________________*/
main(argc,argv)
 int argc;char **argv;
{
 char 	buf[512],nom[512],*s_dir, c;
 double englob[10];
 int	i,j,jj,k, nbff,nomax;
 int	nofac, nbcir, nbtrou, nbpoint;
 FILE	*fp, *fpP;
 int	nbfP; // nb de faces  (de trous)
 double x,y,z,xn,yn,zn;

 if(argc!=2)format_entree();

	s_dir=(char *)getenv("PWD");

 printf(" Fonction Solene : trou_face\n\n");
  
// INPUT
  compose_nom_complet(buf,s_dir,argv[1],"cir");
  if((fp=fopen(buf,"r"))==NULL)
        { printf("\n impossible ouvrir %s\n",buf); exit(0);}
   lit_en_tete(fp,&nbff,&nomax,englob);
  printf("fichier IN � traiter : %s (%d faces)\n",buf,nbff);
        
// OUTPUT : 1 fichiers
  // PAROI
  sprintf(nom,"%s_TROU",argv[1]);
  printf("fichier OUT  TROU : %s\n",nom);
  compose_nom_complet(buf,s_dir,nom,"cir");
  fpP=fopen(buf,"w");
    if(fpP==NULL) 
	{ printf("impossible creer %s\n",buf);
	  exit(0);
	}
  ecrit_en_tete(fpP,nbff,nomax,englob);


// TRAITEMENT  
    nbfP  =0;
	
   // Lit FACE par face 
   for (i=0;i<nbff;i++)
   { 
		// lit info face
		fscanf(fp,"\n%c%d %d",&c,&nofac,&nbcir);     
							 //printf(" lit face no %d nb contour = %d\n",nofac,nbcir); 
        // lit normale
        fscanf(fp,"%lf %lf %lf",&xn,&yn,&zn);

		// lit chaque contour
        for(j=0;j<nbcir;j++)
		{  
            fscanf(fp,"\n%c%d",&c,&nbtrou);
							//printf(" lit contour  nbtrou = %d\n",nbtrou); 
			
	        // lit le nb de points  du contour */
            fscanf(fp,"%d",&nbpoint);
							//printf("  nb de pts %d\n",nbpoint);

			  
			// lit  les points du contour Plein
			for(k=0;k<nbpoint;k++)
                 { fscanf(fp,"%lf%lf%lf",&x,&y,&z);
				 }
				 // lit et ecrit les points du contour TROU
            // lit les trous du contour support et ecrit une face pour chaque Trou */
			for(jj=0;jj<nbtrou;jj++)
				{ 
							//printf("lit un trou\n");
                  fscanf(fp,"\n%c",&c);
                  fscanf(fp,"%d",&nbpoint);
				  // Ecrit une face avec le contour trou
				  nbfP++;
				  fprintf(fpP,"f%d 1\n",nbfP);
				  fprintf(fpP," %lf  %lf  %lf\n",xn,yn,zn);
				  fprintf(fpP,"c0\n");
				  fprintf(fpP,"%d\n",nbpoint); //nb de points

                  for(k=0;k<nbpoint;k++)
                  { fscanf(fp,"%lf%lf%lf",&x,&y,&z);
				    fprintf(fpP,"%15.5f %15.5f %15.5f\n",x,y,z);
				  }
				}  
		}
   }

 
/* re�crit en-tete avec bonnes valeurs */
   rewind(fpP);
   printf( "Fichier de TROUs : %d faces\n", nbfP);
   ecrit_en_tete(fpP,nbfP,nbfP,englob);

   fclose(fp);
   fclose(fpP);
   printf("\n");


   printf(" Fin du traitement: trou_face\n\n");

  		creer_OK_Solene();

}


/*_________________________________________________________________*/
void format_entree()
{
  printf("\ntrou_face  \n\n");
  printf("\n  Param�tres de la fonction:   \n\n");
  printf("\t IN    fichier_geometrie_in(.cir) \n\n");
  printf("NOTA:   un fichier est cr�� en sortie: \n");
  printf("\t\t  fichier_geometrie_in_TROU\n");
   exit(0);
}
/*_________________________________________________________________*/




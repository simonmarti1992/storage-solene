/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */
 
/***** mcdg_ensol_vu.c *************/
/**** pour these D. Follut ****/
/*** M.J. Antoine, CERMA, 1999 ***/

/* permet de determiner la distance au centre de gravite des faces ensoleillees vues */
/* par chaque patch d'un fichier observateur */

/*   Rappel ligne de compilation */

/* cc cdg_ensol_vu.c  ./UTILS/solutile.o ./UTILS/geomutile.o ./UTILS/lib_solene_94.o -o cdg_ensol_vu -lm */
   
 
/* Fichiers inclus */
#include<solene.h>
#include<ctype.h>
//#include<unistd.h>

struct vertex {double x,y,z;};


void usage();
int info_faces_contours();
int sauve_tableau();
void lect_fichier();
void lect_ff_param();
void centre_de_gravite();
void cdg_faces();
void nb_points_faces();

FILE *pfacvis;

main(argc,argv)           
int argc;
char **argv;
{ 
char *dir_courant;

char nom_descr_obs_in[256];
/* fichier de descripteurs lu pour observateurs */
double *descr_obs_in;
int nb_contour_obs;
int nbfac_obs, nomax_obs;
int no_contour_obs;
int *nb_cont_face_obs, *numero_face_obs;
double min_obs, max_obs;
char nom_geom_obs[256];
/* fichier (lu) pour geometrie du fichier-observateur */
struct modelisation_face *fac_obs;
/* faces */
struct vertex *CDG_obs;
/* centres de gravite des contours observateurs */


char nom_fvis[256];
/* fichier (lu) pour facteurs de visibilite */
float *ligne_fvis;
/* valeurs */


char nom_fluxsol_test[256];
/* fichier (lu) pour descripteur du fichier test */
double *fluxsol_test;
/* valeurs */
double seuil_sol = 0.0;
int nb_contour_test;
int nbfac_test, nomax_test;
int no_contour_test;
int *nb_cont_face_test, *numero_face_test;
double min_test, max_test;
char nom_geom_test[256];
/* fichier (lu) pour geometrie du fichier-test */
struct modelisation_face *fac_test;
/* faces */
struct vertex *CDG_test;
/* centres de gravite des contours observes */
int *nb_points_test;
/* nombre de points des contours observes */


/* Pour E/S fichiers */

FILE *pfic_descr;
FILE *pfic_geom;

/* Resultats */

double xGs, yGs, zGs;
/* Coordonnees du centre de gravite des faces ensoleillees vues */
int nbpGs;
/* Nombre total de points a prendre en compte */

char nom_pos_cdg[256];
/* fichier (cree) pour descripteur fichier observateur */
double *pos_cdg;
/* valeurs */


/* Autres */
double englob[10];
double mini, maxi; char c;
int OK_sauv=0;
double *auxiliaire;

/*** Lecture des parametres de la commande ***/

dir_courant=(char *)getenv("PWD");

if (argc<7)usage();

compose_nom_complet(nom_geom_obs,dir_courant,argv[1],"cir");
printf("Geometrie du fichier observateur: %s \n", nom_geom_obs);

compose_nom_complet(nom_geom_test,dir_courant,argv[2],"cir");
printf("Geometrie du fichier test: %s \n", nom_geom_test);

compose_nom_complet(nom_descr_obs_in,dir_courant,argv[3],"val");
printf("Fichier de descripteur observateur: %s \n", nom_descr_obs_in);

compose_nom_complet(nom_fluxsol_test,dir_courant,argv[4],"val");
printf("Flux solaires incidents du fichier test: %s \n", nom_fluxsol_test);

compose_nom_complet(nom_fvis,dir_courant,argv[5],"vis");
printf("Facteurs de visibilite : %s \n", nom_fvis);

compose_nom_complet(nom_pos_cdg,dir_courant,argv[6],"val");
printf("Positions des centres de gravite: %s \n", nom_pos_cdg);


/*** Ouverture des fichiers ***/

	/* Lecture d'un fichier .val pour infos fichier observateur*/
	

if ((pfic_descr=fopen(nom_descr_obs_in,"r"))==NULL)
            	{ 
		printf("\n  *** impossible ouvrir %s ***\n\n", nom_descr_obs_in); 
		goto fin;
            	}
fscanf(pfic_descr,"%d %d %lf %lf",&nbfac_obs,&nomax_obs,&min_obs,&max_obs);

numero_face_obs=(int *)malloc(nbfac_obs*sizeof(int));
if (numero_face_obs==NULL)
	{printf("Probleme d'allocation numero face (descripteur observateur), arret.\n\n");
	 exit(0);}
nb_cont_face_obs=(int *)malloc(nbfac_obs*sizeof(int));
if (nb_cont_face_obs==NULL)
	{printf("Probleme d'allocation nombre contours par face (descripteur observateur), arret.\n\n");
	 exit(0);}
fclose(pfic_descr);

nb_contour_obs = info_faces_contours(pfic_descr, nom_descr_obs_in, nbfac_obs, numero_face_obs, nb_cont_face_obs);
printf("Nombre de contours du fichier observateur: %d\n", nb_contour_obs);

CDG_obs = (struct vertex*)malloc(nb_contour_obs*sizeof(struct vertex));
if (CDG_obs==NULL)
	{printf("Probleme allocation centres de gravite du fichier observateur, abandon.\n");
	 exit(0);}


pos_cdg = (double*)malloc(nb_contour_obs*sizeof(double));
if (pos_cdg==NULL)
	{printf("Probleme allocation positions centres de gravite, abandon.\n");
	 exit(0);}



	/* Ouverture fichier de facteurs de visibilite */

if((pfacvis=fopen(nom_fvis,"rb"))==NULL)
		{
           	printf("\n impossible ouvrir %s\n",nom_fvis); 
		exit(0);
		}



	/* Ouverture descripteur du fichier test */

nb_contour_test=0;
if ((pfic_descr=fopen(nom_fluxsol_test,"r"))==NULL)
            	{ 
		printf("\n  *** impossible ouvrir %s ***\n\n", nom_fluxsol_test); 
		goto fin;
            	}
fscanf(pfic_descr,"%d %d %lf %lf",&nbfac_test,&nomax_test,&min_test,&max_test);	


numero_face_test=(int *)malloc(nbfac_test*sizeof(int));
if (numero_face_test==NULL)
	{printf("Probleme d'allocation numero face (descripteur test), arret.\n\n");
	 exit(0);}
nb_cont_face_test=(int *)malloc(nbfac_test*sizeof(int));
if (nb_cont_face_test==NULL)
	{printf("Probleme d'allocation nombre contours par face (descripteur test), arret.\n\n");
	 exit(0);}

nb_contour_test = info_faces_contours(pfic_descr, nom_fluxsol_test, nbfac_test, numero_face_test, nb_cont_face_test);
printf("Nombre de contours du fichier test: %d\n", nb_contour_test);

CDG_test = (struct vertex*)malloc(nb_contour_test*sizeof(struct vertex));
if (CDG_test==NULL)
	{printf("Probleme allocation centres de gravite du fichier observateur, abandon.\n");
	 exit(0);}

nb_points_test = (int*) malloc(nb_contour_test*sizeof(int));
if (nb_points_test==NULL)
	{printf("Probleme allocation nombre de points des contours observes, abandon.\n");
	 exit(0);
	}

fluxsol_test = (double*)malloc(nb_contour_test*sizeof(double));
if (fluxsol_test==NULL)
	{printf("Probleme allocation descripteurs fichier-test, abandon.\n");
	 exit(0);}

pfic_descr=fopen(nom_fluxsol_test, "r");	
lect_fichier(pfic_descr, nbfac_test, nomax_test, fluxsol_test);
fclose(pfic_descr);

/* Ouverture geometrie du fichier-observateur */

if ((pfic_geom=fopen(nom_geom_obs,"r"))==NULL)
            	{ 
		printf("\n  *** impossible ouvrir %s ***\n\n", nom_geom_obs); 
		goto fin;
            	}

lit_en_tete(pfic_geom,&nbfac_obs,&nomax_obs,englob);
      
fac_obs=alloue_face(nbfac_obs,34);
lit_fic_cir3d(pfic_geom,nbfac_obs,fac_obs);

fclose(pfic_geom);

/* Ouverture geometrie du fichier-test */

if ((pfic_geom=fopen(nom_geom_test,"r"))==NULL)
            	{ 
		printf("\n  *** impossible ouvrir %s ***\n\n", nom_geom_test); 
		goto fin;
            	}

lit_en_tete(pfic_geom,&nbfac_test,&nomax_test,englob);
      
fac_test=alloue_face(nbfac_test,34);
lit_fic_cir3d(pfic_geom,nbfac_test,fac_test);

fclose(pfic_geom);


/* Allocation 1 ligne de facteurs de visibilite */
ligne_fvis =(float *) malloc(nb_contour_test*sizeof(float));
if (ligne_fvis == NULL)
	{printf("\n*** Probleme d'allocation facteurs de visibilite.\n");
	exit(0);}



/******************************************************************/
/* Traitement en combinant descripteurs et facteurs de visibilite */
/******************************************************************/




/* Determination prealable des centres de gravite */
/* et rangement dans tableaux appropries */

cdg_faces(nbfac_obs, fac_obs, CDG_obs);

cdg_faces(nbfac_test, fac_test, CDG_test);

/* Determination des nombres de points des contours-test */

nb_points_faces(nbfac_test, fac_test, nb_points_test);

for (no_contour_obs=0;no_contour_obs<nb_contour_obs;no_contour_obs++)
	{nbpGs=0;
	 xGs = 0.0;yGs=0.0;zGs=0.0;

	/* Lecture facteurs de visibilite */

	lect_ff_param(pfacvis, ligne_fvis, nb_contour_test, no_contour_obs, -1); 

	for (no_contour_test=0;no_contour_test<nb_contour_test;no_contour_test++)

		{/* Si contour-test vu et ensoleille, prendre en compte son centre de gravite */
		 /* dans le calcul du centre de graviet global */

		if ((ligne_fvis[no_contour_test]>0) && (fluxsol_test[no_contour_test]>seuil_sol))
			{
			 xGs+=nb_points_test[no_contour_test]*(CDG_test+no_contour_test)->x;
			 yGs+=nb_points_test[no_contour_test]*(CDG_test+no_contour_test)->y;
			 zGs+=nb_points_test[no_contour_test]*(CDG_test+no_contour_test)->z;

			 nbpGs+=nb_points_test[no_contour_test];
			}
		}

	/* Quand exploration achevee, calculer centre de gravite des faces ensoleillees vues */
	/* et distance au CDG du contour observateur courant */

	if (nbpGs>0)
		{xGs/=nbpGs;
		 yGs/=nbpGs;
		 zGs/=nbpGs;

		 pos_cdg[no_contour_obs] =  (xGs-(CDG_obs+no_contour_obs)->x)*(xGs-(CDG_obs+no_contour_obs)->x);
		 pos_cdg[no_contour_obs] += (yGs-(CDG_obs+no_contour_obs)->y)*(yGs-(CDG_obs+no_contour_obs)->y);
		 pos_cdg[no_contour_obs] += (zGs-(CDG_obs+no_contour_obs)->z)*(zGs-(CDG_obs+no_contour_obs)->z);
		 pos_cdg[no_contour_obs] = sqrt(pos_cdg[no_contour_obs]);
		 
		}
	else
		pos_cdg[no_contour_obs] = -1.0;	
	}


/*** Sauvegarde fichier descripteurs resultat ***/

OK_sauv = sauve_tableau(pfic_descr, nom_pos_cdg, nbfac_obs, nomax_obs, nb_contour_obs, numero_face_obs, nb_cont_face_obs, 0.0, pos_cdg);



fclose(pfacvis);
free(numero_face_obs);
free(nb_cont_face_obs);
free(numero_face_test);
free(nb_cont_face_test);
free(fac_test);
free(fac_obs);
free(ligne_fvis);
free(pos_cdg);
free(fluxsol_test);
free(CDG_obs);
free(CDG_test);
free(nb_points_test);


fin:;
}

/*_____________________________________________________________________*/
void usage()
{printf("*cdg_ensol_vu* observateur(.cir) test-observe(.cir)  descripteur_observateur(.val) flux_solaire_test(.val) \n");
printf("facteurs de visibilite (.vis) position_cdg(.val)\n");
printf("-> Resultat: position_cdg.val, fichier d'indicateurs de la position \n");
printf("   du centre de gravite des faces ensoleillees vues\n");
 
exit(0);
}

/*_____________________________________________________________________*/
int info_faces_contours(pfic, nom, nbfac, numero_face, nb_cont_face)
FILE *pfic;
char nom[256];
int nbfac;
int *numero_face;
int *nb_cont_face;
{
/* LECTURE D'UN FICHIER nom.val POUR DETERMINER NBRE DE CONTOURS TOTAL */
/* - remplit les tableaux de numeros de faces et nombre de contours par face */
/* Remarque: le nombre de faces doit deja avoir ete lu dans le fichier, */
/* on doit proceder en deux temps */
	
int nb_contour_total=0;
int nbf, nomx;
int numero, nb_contours;
int f, ct;
double val_min, val_max;
char c;
double *auxiliaire;

nbf=0;
nomx=0;
val_min=0.0;
val_max=0.0;

if ((pfic=fopen(nom,"r"))==NULL)
            	{ 
		printf("\n  compte contours: impossible ouvrir %s\n\n", nom); 
		exit(0);
            	}
fscanf(pfic,"%d %d %lf %lf",&nbf,&nomx,&val_min,&val_max);

for(f=0;f<nbfac;f++)
		{
		fscanf(pfic,"\n%c%d%d\n",&c,&numero,&nb_contours);
		numero_face[f] = numero;
		nb_cont_face[f] = nb_contours;
		nb_contour_total+=nb_cont_face[f];
		auxiliaire=(double *)malloc(nb_cont_face[f]*sizeof(double));
		for(ct=0;ct<nb_cont_face[f];ct++)
			fscanf(pfic,"%lf\n",auxiliaire+ct);
		free(auxiliaire);
		}
fclose(pfic);

return nb_contour_total;

}


/*______________________________________________________________________________________*/
int sauve_tableau(pf, nom_fichier, nbfac, nomax, nb_contour_total, numero_face, nb_cont_face, decalage, tab)
/* Sauvegarde d'un tableau de valeurs (descripteurs) associees a un fichier de faces et contours */
/* avec eventuellement un decalage (utile pour conversion Kelvin->Celsius) */
FILE *pf;
char *nom_fichier;
int nbfac;
int nomax;
int *numero_face;
int *nb_cont_face;
double decalage;
double *tab;
{ 
double mini, maxi;
int i, k, num;
int sauvOK = 1;

if ((pf= fopen(nom_fichier,"w"))==NULL)
	sauvOK = 0;
else
	{mini=maxi=tab[0]-decalage;
	for(i=0;i<nb_contour_total;i++)
		{
		if(tab[i]-decalage<mini) mini=tab[i]-decalage;
		if(tab[i]-decalage>maxi) maxi=tab[i]-decalage;
		} 

	fprintf (pf,"%5d %5d %8.3lf %8.3lf\n", nbfac, nomax, mini, maxi);   

	num=0;
	for(i=0;i<nbfac;i++)
		{
		fprintf (pf,"f%d %d\n",numero_face[i],nb_cont_face[i]);
		for(k=0;k<nb_cont_face[i];k++)
			{
			fprintf (pf,"    %8.3f\n",tab[num]-decalage);
			num++;
			}
		}
	fclose(pf);
	}
return sauvOK;

}	


/*_________________________________________________________________*/
/* Lecture fichier au "bon" format (.val) et remplissage tableau 'valeur' */
void lect_fichier(pfic, nbfac, nomax, valeur)
FILE *pfic;
int nbfac;
int nomax;
double *valeur;
{ double val_min;
  double val_max;
  int num_cont, num_face, num_cont_liste;
  int nofac, nbcont_face;
  char c;

  fscanf(pfic,"%d %d %lf %lf",&nbfac,&nomax,&val_min,&val_max);
  num_cont_liste = 0;
  for(num_face=0;num_face<nbfac;num_face++)
	{
	fscanf(pfic,"\n%c%d%d\n",&c,&nofac,&nbcont_face);
	for(num_cont=0;num_cont<nbcont_face;num_cont++)	
		{	
		fscanf(pfic,"%lf\n",valeur+num_cont_liste);
		num_cont_liste++;
		}
	}
}



/*_____________________________________________________________________*/
/* Lecture des facteurs de visibilite dans fichier */

void lect_ff_param(pff, ligne_ff, nb_contour, i, j)
FILE *pff;
float *ligne_ff;
int nb_contour;
int i; /* Ligne */
int j; /* colonne */
/* Lit une ligne specifiee dans un fichier de facteurs */
/* arranges en Fij , i et j variant de 0 a nb_contour-1 */
/* si j positif, donne la seule valeur Fij */
/* sinon donne toute la ligne i */
{int f;
fseek(pff,(i*nb_contour)*sizeof(float),SEEK_SET);
fread(ligne_ff, sizeof(float), nb_contour, pff);

/* if (j<0)
	{printf("Ligne %d ", i+1);
	for (f=0;f<nb_contour;f++)
		printf(" %f ", ligne_ff[f]);
	printf("\n"); 
	}
else
	{printf("Valeur F de %d vers %d: %f\n", i+1,j+1,ligne_ff[j]); 
	}
*/

}

/*_________________________________________________________________

void centre_de_gravite(pcir, xg, yg, zg)
struct circuit *pcir;
double *xg, *yg, *zg;
{int k;
if (pcir->nbp <2)
	{printf("Erreur calcul centre de gravite\n");
	 exit(0);
	}
*xg=0.0; *yg=0.0; *zg=0.0;
for(k=0;k<pcir->nbp-1;k++) 
        { 
	*xg+=pcir->x[k];
        *yg+=pcir->y[k];
        *zg+=pcir->z[k];
        }
      
           
*xg=*xg/(pcir->nbp-1);
*yg=*yg/(pcir->nbp-1);
*zg=*zg/(pcir->nbp-1);

}
*/

/*__________________________________________________*/
void cdg_faces(nbfac, fac, CDG)
int nbfac;
struct modelisation_face *fac;
struct vertex *CDG;
{
struct contour *pcont;
struct circuit *pcir;
int ind_fac;
int noc, comptc;

comptc=0;

for(ind_fac=0;ind_fac<nbfac;ind_fac++) 
	{ noc=0;
             	
	pcont=(fac+ind_fac)->debut_projete;

        while(pcont) 	/* Balayage des contours de la face courante */   
               { pcir=pcont->debut_support;   

                centre_de_gravite(pcir, &((CDG+comptc)->x), &((CDG+comptc)->y), &((CDG+comptc)->z) );
		noc++; 
		comptc++;
           	
		pcont=pcont->suc; /* Passage au contour suivant de la face courante */
               }	
        }
}

/*____________________________________________*/
void nb_points_faces(nbfac, fac, nb_points)
int nbfac;
struct modelisation_face *fac;
int *nb_points;
{
struct contour *pcont;
struct circuit *pcir;
int ind_fac;
int noc, comptc;

comptc=0;

for(ind_fac=0;ind_fac<nbfac;ind_fac++) 
	{ noc=0;
             	
	pcont=(fac+ind_fac)->debut_projete;

        while(pcont) 	/* Balayage des contours de la face courante */   
               { pcir=pcont->debut_support;   

                *(nb_points+comptc) = (pcir->nbp)-1;
 		noc++; 
		comptc++;
           	
		pcont=pcont->suc; /* Passage au contour suivant de la face courante */
               }	
        }
}














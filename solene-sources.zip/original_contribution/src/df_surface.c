/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */
 
/*

cc surface.c  ~marenne/newsolene/solutile.o ~marenne/newsolene/geomutile.o ~marenne/newsolene/lib_solene_94.o  -o surface  -lm

*/


#include<solene.h>
struct modelisation_face *alloue_face();

 struct modelisation_face *ff;
 int nbff,trou;
 FILE *fp;
 float val_min,val_max;

/*_________________________________________________________________*/
main(argc,argv)
 int argc;char **argv;
{char buf[50],*s_dir;
 int i,j,nomax;
 double englob[10];
 
	s_dir=(char *)getenv("PWD");


 if(argc!=3 && argc!=4)format_entree();
         compose_nom_complet(buf,s_dir,argv[1],"cir");
  if((fp=fopen(buf,"r"))==NULL)
        { printf("\n impossible ouvrir %s\n",buf); exit(0);}
  lit_en_tete(fp,&nbff,&nomax,englob);
        ff=alloue_face(nbff,35);
        lit_fic_cir3d(fp,nbff,ff);
        fclose(fp);

  /* open fichier out .val */
         compose_nom_complet(buf,s_dir,argv[2],"val");
         if((fp=fopen(buf,"w"))==NULL)
	  { printf("impossible creer %s\n",buf);
	    exit(0);
	  }	
  /* calcul avec ou sans les trous */

	if(argc==4) trou=0;
	else trou=1;

  /* ecrit en tete .val */
   	val_min=10000000.; val_max=-val_min;
        fprintf(fp,"%6d %6d %15.5f %15.5f\n",nbff,nomax,val_min,val_max);

	obs.xo=0; obs.yo=0; obs.zo=0;

         for(j=0;j<nbff;j++) 
		{nbcontour=nb_contour_face(ff+j,1);
		 fprintf(fp,"f%d %d\n",(ff+j)->nofac_fichier,nbcontour);
		 surface_contour(ff+j);
		}
   rewind(fp);
   fprintf(fp,"%6d %6d %15.5f %15.5f\n",nbff,nomax,val_min,val_max);
   fclose(fp);

   printf("\n");

desalloue_fface(ff,nbff);

}

/*_________________________________________________________________*/
format_entree()
{
  printf("\n *surface* fichier_in(.cir) fichier_out(.val) [-t]\n\n");
  printf("  -t : ne tient pas compte des trous\n");
  printf("  Par defaut, le surface tient compte des trous\n\n");
   exit(0);
}

/*____________________________________________________________________*/
int surface_contour(ff)
struct modelisation_face *ff;
{double surf;
 struct contour *pc;
 struct circuit *pcir;


	     	obs.x=ff->vnorm[0];
	     	obs.y=ff->vnorm[1];
	     	obs.z=ff->vnorm[2];
            	tranfo();  
            	tran_face(ff,1,ff,0); 

  pc=ff->debut_dessin;

  while(pc)
	{pcir=pc->debut_support;
	 surf=fabs(surface(pcir->nbp,pcir->x,pcir->y));
         if(trou)
	   {
	 	pcir=pc->debut_interieur;
		 while(pcir)
	  	  {surf-=fabs(surface(pcir->nbp,pcir->x,pcir->y));
	   	   pcir=pcir->suc;
	   	  }
	  }
         fprintf(fp,"%15.5f\n",surf);
	   if(surf<val_min) val_min=surf;
	   if(surf>val_max) val_max=surf;
         pc=pc->suc;
	}
}

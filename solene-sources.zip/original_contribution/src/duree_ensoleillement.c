/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */
 
/*
cc duree_ensoleillement.c  ~marenne/newsolene/solutile.o  ~marenne/newsolene/geomutile.o ~marenne/newsolene/lib_solene_94.o  ~marenne/newsolene/solaire.o -o duree_ensoleillement -lm

*/


/* sur le modele de execute_gen_val de SOL_N_SOLARIS */
/* les parametres en entree:

  fichier_in(.cir) 
  fichier_in(.mas)
  jour/mois
  hh1:mn1
  hh2:mn2
  calcul_sans_masque(1 oui; 0 non)
        fichier_in(.mas) sans masque
   
    les parametres en sortie , les descripteurs:
   
  duree_ensoleillement_
  si calcul_sans_masque
      duree_ensoleillement_sans_masque
      %_reduction_duree_ensoleillement_du_aux_masque 
  
*/

#include<solene.h>


/*_________________________________________________________________*/
main(argc,argv) 
int argc;char **argv;

{
FILE *fpcir,*fpmas1,*fpmas2,*fpval,*fpval1;
int sans_masque;
char buf[256],*s_dir,c;
int nojour,nomois,jo,mo,indice_date;
int hh1,hh2,pas,minute;
int nbfac,nomax,nofac,nb_contour,nb_pas,nb_date;
double englob[10];
int *nbc_face,*no_face;
int i,j,k,kk,ind_valeur,h_deb,m_deb,temps,nbcontour,indice;
float x,vmin_gen,vmax_gen,v1,v2;
float *valeur;
struct modelisation_face *fac;

 if(argc<8) { format_entree(); exit(0); }
 sscanf(argv[6],"%d",&(sans_masque));
 if(sans_masque && argc<11) { format_entree(); exit(0); }

//	s_dir=(char *)getenv("PWD");
 s_dir="";

printf("\nDUREE d'ENSOLEILLEMENT\n\n");


/*lecture des parametres*/
		sprintf(buf,"%s.cir",argv[1]);
      
         //compose_nom_complet(buf,s_dir,argv[1],"cir");
         if((fpcir=fopen(buf,"r"))==NULL)
            { printf("\n impossible ouvrir %s\n",buf); exit(0);
            }

		sprintf(buf,"%s.mas",argv[2]);

         //compose_nom_complet(buf,s_dir,argv[2],"mas");
         if((fpmas1=fopen(buf,"r"))==NULL)
            { printf("\n impossible ouvrir %s\n",buf); exit(0);
            }
    if(sans_masque)
      {  
		sprintf(buf,"%s.mas",argv[7]);
		
		//compose_nom_complet(buf,s_dir,argv[7],"mas");
         if((fpmas2=fopen(buf,"r"))==NULL)
            { printf("\n impossible ouvrir %s\n",buf); exit(0);
            }
      }

  	 sscanf(argv[3],"%d%c%d",&nojour,&c,&nomois);
/*printf("jour mois %d %d\n",nojour,nomois);*/
         sscanf(argv[4],"%d%c%d",&hh1,&c,&minute);
         hh1=hh1*60+minute;
         sscanf(argv[5],"%d%c%d",&hh2,&c,&minute); 
         hh2=hh2*60+minute;
/*printf("hh1 hh2 pas %d %d\n",hh1,hh2);*/

   /* lecture de geom.cir FACE/FACE */


       lit_en_tete(fpcir,&nbfac,&nomax,englob);

       printf(" Traite %d faces\n",nbfac);
   nbc_face =alloue_int(nbfac,1023);
   no_face =alloue_int(nbfac,1023);
   nb_contour=0;
	/* alloue une seule face */
   fac=alloue_face(1,34);

   for(i=0;i<nbfac;i++)
     { lit_fic_cir3d(fpcir,1,fac);
       no_face[i]=fac->nofac_fichier;
       nbc_face[i]=nb_contour_face(fac,1);
       nb_contour+=nbc_face[i];
       desalloue_contour_face(fac);
     }
   desalloue_fface(fac,1);
    

printf("     soit  %d contours\n\n",nb_contour);


 /* allouer nb_contour*2 valeurs*/
   valeur=alloue_float(nb_contour*2,1023);

   for(j = 0; j<nb_contour*2; j++)
	   valeur[j] = 0;

 /* lit en tete des .mas  et determine indice de la bonne date */
     
        fscanf(fpmas1,"%d",&nb_date);
	for(j=0;j<nb_date;j++)
         { fscanf(fpmas1,"%d %d",&jo,&mo);
           if(mo == nomois && jo == nojour) indice_date=j;

         }
        fscanf(fpmas1,"%d %d",&i,&i);
/*printf("indice de la bonne date %d\n", indice_date);*/

    if(sans_masque)
      { 
        fscanf(fpmas2,"%d",&i);
	for(j=0;j<nb_date;j++) fscanf(fpmas2,"%d %d",&i,&i);
        fscanf(fpmas2,"%d %d",&i,&i);
      }



/* examine les contours et determine les valeurs */
/* stocke les valeurs dans valeur contour  apres contour */
/* soit nb_contour*nb_pas valeurs */
/* AVEC_MASQUE */

 /*printf("AVEC_MASQUE\n");*/


    ind_valeur=0;

    for(j=0;j<nbfac;j++)
       { fscanf(fpmas1,"\n%c%d %d",&c,&nofac,&nbcontour);
         /*printf("FACE %d\n",nofac);*/

         for(k=0;k<nbcontour;k++)  
           { /*printf("test contour %d\n",k+1);*/
             fscanf(fpmas1,"\n%c",&c);
             /* evalue valeur AVEC MASQUE pour chaque contour */
	     valeur[ind_valeur]=duree_soleil(nb_date,indice_date,hh1,hh2,fpmas1);
	     ind_valeur++;
           }

       }
   fclose(fpmas1);

/* constitue le fichier .val correspondant */
/* avec les valeurs  AVEC MASQUE*/

 printf(" Cree le Descripteur Duree_Ensoleillement Avec Masque : \n"); 

	/* calcule min_max pour le pas i AVEC MASQUE */
        vmin_gen=100000000.; vmax_gen=-vmin_gen;
        indice=0;
        for(j=0;j<nbfac;j++)
           { for(k=0;k<nbc_face[j];k++)
               { if(valeur[indice] < vmin_gen) vmin_gen=valeur[indice];
                 if(valeur[indice] > vmax_gen) vmax_gen=valeur[indice];
                 indice++;
               }
           }    

       /* open fichier .val */
       /* VOIR A COMPOSER LE NOM */
        if(sans_masque)sprintf(buf,"%s.val",argv[8]);
        else 
         {
           sprintf(buf,"%s.val",argv[7]);
         }
        printf("   %s\n",buf);

        fpval=fopen(buf,"w");

        fprintf(fpval,"%5d %5d %15.3f %15.3f\n",nbfac,nomax,vmin_gen,vmax_gen);

       /* stocke les valeurs  */
         indice=0;
         for(j=0;j<nbfac;j++)
           {
             /* printf("Face %d\n",no_face[j]);*/
             fprintf(fpval,"f%d %d\n",no_face[j],nbc_face[j]);

             for(k=0;k<nbc_face[j];k++)
               { 
                 /* printf("Contour %d indice %d\n",k+1,indice);*/
                 fprintf(fpval,"%10.3f\n",valeur[indice]);
                 indice++;
               }
           }    
        fclose(fpval);

/* evalue valeurs duree SANS MASQUE*/
/* SANS_MASQUE */

if(sans_masque)
 {
    /*printf("SANS_MASQUE\n");*/

    ind_valeur=nb_contour;

    for(j=0;j<nbfac;j++)
       { fscanf(fpmas2,"\n%c%d %d",&c,&nofac,&nbcontour);
         /*printf("FACE %d\n",nofac);*/

         for(k=0;k<nbcontour;k++)  
           { /*printf("test contour %d\n",k+1);*/
             fscanf(fpmas2,"\n%c",&c);

             /* evalue valeur  SANS MASQUE pour chaque contour */
	     valeur[ind_valeur]=duree_soleil(nb_date,indice_date,hh1,hh2,fpmas2);
	     ind_valeur++;
           }

       }

   fclose(fpmas2);


/* constitue le fichier .val correspondant */
/* avec les valeurs SANS MASQUE*/

 printf(" Cree le Descripteur Duree Sans Masque : \n");
 
	/* calcule min_max   SANS MASQUE */
        vmin_gen=100000000.; vmax_gen=-vmin_gen;
        indice=nb_contour;
        for(j=0;j<nbfac;j++)
           { for(k=0;k<nbc_face[j];k++)
               { if(valeur[indice] < vmin_gen) vmin_gen=valeur[indice];
                 if(valeur[indice] > vmax_gen) vmax_gen=valeur[indice];
                 indice++;
               }
           }    


       /* open 2 fichiers .val  : duree sans masque et % reduc */
       /* VOIR A COMPOSER LE NOM */

        sprintf(buf,"%s.val",argv[9]);
        printf("   %s\n",buf);
        fpval=fopen(buf,"w");

        fprintf(fpval,"%5d %5d %15.3f %15.3f\n",nbfac,nomax,vmin_gen,vmax_gen);

        sprintf(buf,"%s.val",argv[10]);
        printf("   %s\n",buf);
        fpval1=fopen(buf,"w");

        fprintf(fpval1,"%5d %5d 0 100\n",nbfac,nomax);

         indice=0;
         for(j=0;j<nbfac;j++)
           { fprintf(fpval,"f%d %d\n",no_face[j],nbc_face[j]);
             fprintf(fpval1,"f%d %d\n",no_face[j],nbc_face[j]);

             for(k=0;k<nbc_face[j];k++)
               { fprintf(fpval,"%10.3f\n",valeur[indice+nb_contour]);
				 if(valeur[indice+nb_contour])
				 { v1 = 100*(valeur[indice+nb_contour] - valeur[indice])/valeur[indice+nb_contour];
				   if(v1 < 0) v1=0;
				   if(v1 > 100) v1=100;
				 }
				 else v1 = 0;
                 fprintf(fpval1,"%10.3f\n", v1);

                 indice++;
               }
           }    
          fclose(fpval);
          fclose(fpval1);
     }

 

 free(valeur);
 free(nbc_face);
 free(no_face);

 	creer_OK_Solene();
	printf("\n\nFin du Traitement duree_ensoleillement.\n");
}

/*_________________________________________________________________*/
int duree_soleil(nb_date,ind_date,debper_mn,finper_mn,pf_mas)
int nb_date,ind_date,debper_mn,finper_mn;
FILE *pf_mas;
{ 
  int nb_per,dh[50],dm[50],fh[50],fm[50];
  float val[50];
  int duree_minute,i,k,heure,minute;
  int x,y;

  duree_minute=0;
  for(i=0;i<nb_date;i++)
     { fscanf(pf_mas,"%d",&nb_per);
	/*printf("\nnb_per %d",nb_per);*/
       for(k=0;k<nb_per;k++)
          { fscanf(pf_mas,"%d %d %d %d %f",dh+k,dm+k,fh+k,fm+k,val+k);
	    /*printf(" %d %d %d %d %f",dh[k],dm[k],fh[k],fm[k],val[k]);*/
          }

       /* duree ensoleillement sur ce jour pour la periode */
       if(i==ind_date)
          { for(k=0;k<nb_per;k++)
               { x=dh[k]*60+dm[k]; /* en minutes */
                 y=fh[k]*60+fm[k];
                 if(debper_mn!=finper_mn)duree_minute=duree_minute+partie_commune(debper_mn,finper_mn,x,y);
                 else duree_minute+=y-x;
               }
          }
     }
 return(duree_minute);
}


/*_________________________________________________________________*/
int partie_commune(deb1,fin1,deb2,fin2)
int deb1,fin1,deb2,fin2;
{
  int commun,c1,c2;
  if(deb1>deb2) c1=deb1; else c1=deb2;
  if(fin1<fin2) c2=fin1; else c2=fin2;
/*printf("deb1,fin1,deb2,fin2,c1,c2 %d %d %d %d %d %d\n",deb1,fin1,deb2,fin2,c1,c2);*/
  commun=c2-c1;
  if(commun>0) return(commun); else return(0);
}


/*_________________________________________________________________*/

int format_entree()
{
 printf(" la fonction a comme parametre ENTREE :\n");
 printf("\t fichier_in(.cir)\n"); 
 printf("\t fichier_in(.mas)\n");
 printf("\t jour/mois\n");
 printf("\t hh1:mn1\n");
 printf("\t hh2:mn2\n");
 printf("\t calcul_sans_masque(1 oui; 0 non)\n");
 printf("\t       fichier_in(.mas) sans masque\n");
   
 printf("           comme parametres en SORTIE, les descripteurs:\n");
   
 printf("\t duree_ensoleillement_\n");
 printf("\t si calcul_sans_masque\n");
 printf("\t    duree_ensoleillement_sans_masque\n\n"); 
 printf("\t    %%_reduction_duree_ensoleillement_du_au_masque\n\n"); 
}

/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */
 
/***** patchs_vus.c *************/

/* va lire dans un fichier de facteurs de visibilite angle solide (.ang)
ceux correspondant a une face et un contour de reference du fichier observateur 
et sauve le resultat comme un fichier .val, associe au fichier -test observe */
/* Dans le fichier .val, la valeur  correspond aux angles solides des patchs
 vus par le patch de reference */

/*   Rappel ligne de compilation */

/* cc patchs_vus.c  ./UTILS/solutile.o ./UTILS/geomutile.o  ./UTILS/lib_solene_94.o -o patchs_vus -lm */
   
 
/* Fichiers inclus */
#include<solene.h>
#include<ctype.h>
//#include<unistd.h>


void usage();
int info_faces_contours();
int numero_interne();
int sauve_tableau();
void lect_fichier();
void lect_ff_param();


FILE *pfacvis;

main(argc,argv)           
int argc;
char **argv;
{ 

/* Face et contour de reference */
/* du fichier observateur */

int noface_ref, nocont_ref;

/* Noms des fichiers et donnees */
char *dir_courant;

char nom_descr_obs_in[256];
/* fichier de descripteurs lu pour caracteristiques observateur */
double *descr_obs_in;
int nb_contour_obs;
int nbfac_obs, nomax_obs;
int no_contour_obs;
int *nb_cont_face_obs, *numero_face_obs;
double min_obs, max_obs;

char nom_fvis[256];
/* fichier (lu) pour facteurs de visibilite */
float *ligne_fvis;
/* valeurs */
int indligne;
/* Numero de ligne a lire dans le fichier .vis (contour de reference) */


char nom_descr_test[256];
/* fichier (lu) pour descripteur du fichier test */
double *descr_test;
/* valeurs */
int nb_contour_test;
int nbfac_test, nomax_test;
int no_contour_test;
int *nb_cont_face_test, *numero_face_test;
double min_test, max_test;

FILE *pfic_descr;
/* pointeur de fichier pour lecture-ecriture de fichiers .val */

char nom_descr_patch_vu[256];
/* fichier (cree) pour descripteur facteurs de visibilite du fichier test */
/* a partir du fichier .fac lu */
double *descr_patch_vu;
/* valeurs */

/* Autres */
int indcont;
int OK_sauv=0;

/*-------------------------------------------*/
/*** Lecture des parametres de la commande ***/
/*-------------------------------------------*/

dir_courant=(char *)getenv("PWD");

if (argc!=7) usage();

sscanf(argv[1],"%d", &noface_ref);
printf("No de la face de reference: %d\n", noface_ref);

sscanf(argv[2],"%d", &nocont_ref);
printf("No du contour de reference: %d\n", nocont_ref);

compose_nom_complet(nom_fvis,dir_courant,argv[3],"ang");
printf("Facteurs d'angle solide: %s \n", nom_fvis);

compose_nom_complet(nom_descr_obs_in, dir_courant,argv[4],"val");
printf("Fichier de descripteur observateur (entree): %s \n", nom_descr_obs_in);

compose_nom_complet(nom_descr_test, dir_courant,argv[5],"val");
printf("Descripteur du fichier test: %s \n", nom_descr_test);

compose_nom_complet(nom_descr_patch_vu, dir_courant,argv[6],"val");
printf("Descripteur de facteur de visibilite (resultat): %s \n", nom_descr_patch_vu);

/*** Ouverture des fichiers ***/

	/* Lecture d'un fichier .val pour infos fichier observateur*/
	

if ((pfic_descr=fopen(nom_descr_obs_in,"r"))==NULL)
            	{ 
		printf("\n  *** impossible ouvrir %s ***\n\n", nom_descr_obs_in); 
		goto fin;
            	}
fscanf(pfic_descr,"%d %d %lf %lf",&nbfac_obs,&nomax_obs,&min_obs,&max_obs);

numero_face_obs=(int *)malloc(nbfac_obs*sizeof(int));
if (numero_face_obs==NULL)
	{printf("Probleme d'allocation numero face (descripteur observateur), arret.\n\n");
	 exit(0);}
nb_cont_face_obs=(int *)malloc(nbfac_obs*sizeof(int));
if (nb_cont_face_obs==NULL)
	{printf("Probleme d'allocation nombre contours par face (descripteur observateur), arret.\n\n");
	 exit(0);}
fclose(pfic_descr);

nb_contour_obs = info_faces_contours(pfic_descr, nom_descr_obs_in, nbfac_obs, numero_face_obs, nb_cont_face_obs);
printf("Nombre de contours du fichier observateur: %d\n", nb_contour_obs);


	/* Ouverture fichier de facteurs d angle solide vus visibilite */

if((pfacvis=fopen(nom_fvis,"rb"))==NULL)
		{
           	printf("\n impossible ouvrir %s\n",nom_fvis); 
		exit(0);
		}

	/* Ouverture descripteur du fichier test */

nb_contour_test=0;
if ((pfic_descr=fopen(nom_descr_test,"r"))==NULL)
            	{ 
		printf("\n  *** impossible ouvrir %s ***\n\n", nom_descr_test); 
		goto fin;
            	}
fscanf(pfic_descr,"%d %d %lf %lf",&nbfac_test,&nomax_test,&min_test,&max_test);	
numero_face_test=(int *)malloc(nbfac_test*sizeof(int));
if (numero_face_test==NULL)
	{printf("Probleme d'allocation numero face (descripteur test), arret.\n\n");
	 exit(0);}
nb_cont_face_test=(int *)malloc(nbfac_test*sizeof(int));
if (nb_cont_face_test==NULL)
	{printf("Probleme d'allocation nombre contours par face (descripteur test), arret.\n\n");
	 exit(0);}

nb_contour_test = info_faces_contours(pfic_descr, nom_descr_test, nbfac_test, numero_face_test, nb_cont_face_test);
printf("Nombre de contours du fichier test: %d\n", nb_contour_test);

descr_test = (double*)malloc(nb_contour_test*sizeof(double));
if (descr_test==NULL)
	{printf("Probleme allocation descripteurs fichier-test, abandon.\n");
	 exit(0);}

pfic_descr=fopen(nom_descr_test, "r");	
lect_fichier(pfic_descr, nbfac_test, nomax_test, descr_test);
fclose(pfic_descr);

	/* Allocation 1 ligne de facteurs de visibilite */
	/* qui va etre sauvee comme un .val */

ligne_fvis =(float *) malloc(nb_contour_test*sizeof(float));
if (ligne_fvis == NULL)
	{printf("\n*** Probleme d'allocation facteurs de visibilite.\n");
	exit(0);}

	/* Allocation tableau de descripteurs */

descr_patch_vu = (double*)malloc(nb_contour_test*sizeof(double));
if (descr_patch_vu==NULL)
	{printf("Probleme allocation descripteurs visibilite fichier-test, abandon.\n");
	 exit(0);}



/*** Lecture d'une ligne du fichier */
/* de facteurs de visibilite ***/

	/* Recherche du numero de ligne a lire dans le fichier .fac */
	/* (numero interne du contour de reference) a partir des nos de face et contour externes */

indligne = numero_interne(pfic_descr, nom_descr_obs_in, noface_ref, nocont_ref);

if (indligne<0)
	{printf("Erreur numero de face reference ...\n");
	 exit(0);
	}

	/* lecture dans le fichier .vis */

lect_ff_param(pfacvis, ligne_fvis, nb_contour_test, indligne, -1);

	/* Conversion en type double */

for (indcont=0;indcont<nb_contour_test;indcont++)
	descr_patch_vu[indcont]=(double)ligne_fvis[indcont];


/*** Sauvegarde fichier descripteurs resultat ***/

OK_sauv = sauve_tableau(pfic_descr, nom_descr_patch_vu, nbfac_test, nomax_test, nb_contour_test, numero_face_test, nb_cont_face_test,
0.0,descr_patch_vu);


free(nb_cont_face_obs);
free(numero_face_test);
free(nb_cont_face_test);
free(ligne_fvis);
free(descr_patch_vu);
free(descr_test);
fclose(pfacvis);
free(numero_face_obs);

fin:;
}

/*_____________________________________________________________________*/
void usage()
{printf(" patchs_vus no_face_obs no_contour_obs fichier_visibilite_anglsolid(.ang) fichier_descripteur-observateur(.val) fichier_descripteur-test(.val) patchs_vus_anglsolid(.val)\n\n");
 
 exit(0);
}

/*_____________________________________________________________________*/
int info_faces_contours(pfic, nom, nbfac, numero_face, nb_cont_face)
FILE *pfic;
char nom[256];
int nbfac;
int *numero_face;
int *nb_cont_face;
{
/* LECTURE D'UN FICHIER nom.val POUR DETERMINER NBRE DE CONTOURS TOTAL */
/* - remplit les tableaux de numeros de faces et nombre de contours par face */
/* Remarque: le nombre de faces doit deja avoir ete lu dans le fichier, */
/* on doit proceder en deux temps */
	
int nb_contour_total=0;
int nbf, nomx;
int numero, nb_contours;
int f, ct;
double val_min, val_max;
char c;
double *auxiliaire;

nbf=0;
nomx=0;
val_min=0.0;
val_max=0.0;

if ((pfic=fopen(nom,"r"))==NULL)
            	{ 
		printf("\n  compte contours: impossible ouvrir %s\n\n", nom); 
		exit(0);
            	}
fscanf(pfic,"%d %d %lf %lf",&nbf,&nomx,&val_min,&val_max);

for(f=0;f<nbfac;f++)
		{
		fscanf(pfic,"\n%c%d%d\n",&c,&numero,&nb_contours);
		numero_face[f] = numero;
		nb_cont_face[f] = nb_contours;
		nb_contour_total+=nb_cont_face[f];
		auxiliaire=(double *)malloc(nb_cont_face[f]*sizeof(double));
		for(ct=0;ct<nb_cont_face[f];ct++)
			fscanf(pfic,"%lf\n",auxiliaire+ct);
		free(auxiliaire);
		}
fclose(pfic);

return nb_contour_total;

}

/*____________________________________________________________*/
int numero_interne(pfic_val, nom_in, noface_ref, nocont_ref)
/* Recherche du numero interne d'un contour */
/* a partir du numero de la face et du contour de reference */
/* grace a un fichier .val donnant l'organisation en faces et contours */


FILE *pfic_val;
char nom_in[256];
int noface_ref;
int nocont_ref;
{int nbfac, nomax;
double min, max;
int indface, indcont;
char c;
int nofac, nbcont;
int face_trouvee=0;
int contour_ok=0;
double auxil;

int num_interne;

if ((pfic_val=fopen(nom_in,"r"))==NULL)
            	{ 
		printf("\n  impossible ouvrir %s\n\n", nom_in); 
		exit(0);
            	}
fscanf(pfic_val,"%d %d %lf %lf",&nbfac,&nomax,&min,&max);

num_interne=0;
        
for(indface=0;indface<nbfac;indface++)
		{
		fscanf(pfic_val,"\n%c%d%d\n",&c,&nofac,&nbcont);
  	   	
		if((nofac!=noface_ref) && (!face_trouvee))  { num_interne+=nbcont; }
                else face_trouvee=1;
		
		for(indcont=0;indcont<nbcont;indcont++)
			fscanf(pfic_val,"%lf\n",&auxil);
		}
fclose(pfic_val);

if (!face_trouvee)
	num_interne=-1;
else
	num_interne+=nocont_ref-1;

return num_interne;
}

/*______________________________________________________________________________________*/
int sauve_tableau(pf, nom_fichier, nbfac, nomax, nb_contour_total, numero_face, nb_cont_face, decalage, tab)
/* Sauvegarde d'un tableau de valeurs (descripteurs) associees a un fichier de faces et contours */
/* avec eventuellement un decalage (utile pour conversion Kelvin->Celsius) */
FILE *pf;
char *nom_fichier;
int nbfac;
int nomax;
int *numero_face;
int *nb_cont_face;
double decalage;
double *tab;
{ 
double mini, maxi;
int i, k, num;
int sauvOK = 1;

if ((pf= fopen(nom_fichier,"w"))==NULL)
	sauvOK = 0;
else
	{mini=maxi=tab[0]-decalage;
	for(i=0;i<nb_contour_total;i++)
		{
		if(tab[i]-decalage<mini) mini=tab[i]-decalage;
		if(tab[i]-decalage>maxi) maxi=tab[i]-decalage;
		} 

	fprintf (pf,"%5d %5d %10.6lf %10.6lf\n", nbfac, nomax, mini, maxi);   

	num=0;
	for(i=0;i<nbfac;i++)
		{
		fprintf (pf,"f%d %d\n",numero_face[i],nb_cont_face[i]);
		for(k=0;k<nb_cont_face[i];k++)
			{
			fprintf (pf,"    %10.6f\n",tab[num]-decalage);
			num++;
			}
		}
	fclose(pf);
	}

return sauvOK;

}	




/*_________________________________________________________________*/
/* Lecture fichier au "bon" format (.val) et remplissage tableau 'valeur' */
void lect_fichier(pfic, nbfac, nomax, valeur)
FILE *pfic;
int nbfac;
int nomax;
double *valeur;
{ double val_min;
  double val_max;
  int num_cont, num_face, num_cont_liste;
  int nofac, nbcont_face;
  char c;

  fscanf(pfic,"%d %d %lf %lf",&nbfac,&nomax,&val_min,&val_max);
  num_cont_liste = 0;
  for(num_face=0;num_face<nbfac;num_face++)
	{
	fscanf(pfic,"\n%c%d%d\n",&c,&nofac,&nbcont_face);
	for(num_cont=0;num_cont<nbcont_face;num_cont++)	
		{	
		fscanf(pfic,"%lf\n",valeur+num_cont_liste);
		num_cont_liste++;
		}
	}
}



/*_____________________________________________________________________*/
/* Lecture des facteurs de visibilite dans fichier */

void lect_ff_param(pff, ligne_ff, nb_contour, i, j)
FILE *pff;
float *ligne_ff;
int nb_contour;
int i; /* Ligne */
int j; /* colonne */
/* Lit une ligne specifiee dans un fichier de facteurs */
/* arranges en Fij , i et j variant de 0 a nb_contour-1 */
/* si j positif, donne la seule valeur Fij */
/* sinon donne toute la ligne i */
{int f;
fseek(pff,(i*nb_contour)*sizeof(float),SEEK_SET);
fread(ligne_ff, sizeof(float), nb_contour, pff);

/* if (j<0)
	{printf("Ligne %d ", i+1);
	for (f=0;f<nb_contour;f++)
		printf(" %f ", ligne_ff[f]);
	printf("\n"); 
	}
else
	{printf("Valeur F de %d vers %d: %f\n", i+1,j+1,ligne_ff[j]); 
	}
*/

}


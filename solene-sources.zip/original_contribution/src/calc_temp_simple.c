/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */
 
/*______________________________________________________________________*/
/*                         calc_temp_simple.c : 			*/
/*          Calcul des temperatures de paroi en regime permanent	*/
/*              Une passe de calcul direct des temperatures		*/
/*                 Une passe de calcul des flux IR nets 		*/
/*                    Rapide et relativement grossier 			*/
/*    		Modifications apportees au programme "radiosite.c"      */
/* 		par Marie-Joelle Antoine, CERMA, EAN, 1997		*/
/*		- Prise en compte eventuelle de l'emission		*/
/*		- Separation de l'algorithme de radiosite 		*/
/*		dans une procedure a part, pour iteration		*/
/*______________________________________________________________________*/

/*   Rappel ligne de compilation

cc calc_temp_simple.c  solutile.o geomutile.o  lib_solene_94.o -o calc_temp_simple -lm

*/

/* Fichiers inclus */
#include<solene.h>
#include<ctype.h>
/*#include<unistd.h>*/

/* Pointeur global de fichier pour facteurs de forme */
FILE *fp;
/* Procedures auxiliaires */
void usage();
void lect_fichier();
void test_zeros();
void lecture_ff();
void met_a_zero();
double IR_ciel();
/* Procedure pour radiosite "generalisee" (incluant temperatures) */
int radiog(); 
/* calcul des temperatures */
int calc_temp_simple();


/** Convention: dans le corps du programme, les temperatures sont en Celsius **/
/** A l'interieur des procedures, elles sont en Kelvin **/

main(argc,argv)           
int argc;
char **argv;
{
/* DECLARATIONS DE VARIABLES */
	/* I/O programme */
	/** DONNEES **/
	/*** SOLAIRE ***/
char nom_dflux_inc_sol_init[256]; 
/* fichier (lu) pour densite initiale de flux incident solaire (direct+diffus)*/
double *dflux_inc_sol_init;
/* valeurs */
char nom_refl_sol[256];
/* fichier (lu) pour reflectivites dans le "solaire" (visible + PIR) */
double *refl_sol;
/* valeurs */

	/*** IR thermique et autres ***/
char nom_refl_IR[256];
/* fichier (lu) pour reflectivites dans l'IR */
double *refl_IR;
/* valeurs */
char nom_Tint[256];
/* fichier (lu) pour valeurs de temperature "interne" CL sol et parois */
double *Tint;
/* valeurs lues (en Celsius)*/
double Text;
/* temperature de l'air externe a entrer (en Celsius) */
double hext;
/* coefficient de transfert conducto-convectif avec l'air externe */
/* attention, convection uniquement, pas de transfert radiatif */
char nom_g[256];
/* fichier (lu) pour conductance des parois - murs ou sol */
double *g;
/* valeurs */
double *dflux_inc_ciel;
double dflux_inc_ciel0;
/* densite de flux incident recu dans l'IR de la part du ciel */
const double stefan = 5.67e-8;

	/*** GEOMETRIE ***/
char nom_faces_sol[256];
/* fichier (lu) pour faces appartenant au sol */
/* Fichier de valeurs, si valeur non nulle le contour considere fait partie du sol */
double *appart_sol;
char nom_surf[256];
/* fichier (lu) pour surfaces des facettes */
double *surf;
/* valeurs */
char nom_fform[256];
/* fichier (lu) pour facteurs de forme */
float *fform;
/* valeurs */
char nom_fac_ciel[256];
/* fichier (lu) pour facteurs de vue du ciel */
double *fac_ciel;
/* valeurs */


	/** RESULTATS **/
char nom_temp[256];
/* fichier (cree) des temperatures calculees, en Celsius */
double *temp;
/* valeurs */
char nom_dflux_abs_sol[256];
/* fichier (cree) des densites de flux nettes solaires absorbees */
double *dflux_abs_sol;
/* valeurs */
char nom_dflux_net_IR[256];
/* fichier (cree) des densites de flux nettes dans l'IR (parois) absorbees */
double *dflux_net_IR;
/* valeurs */

double *bilan_radiatif;

	/* variables auxiliaires */
int im = 1;		/* impression=oui */
int nbfac;		/* Nombre de faces dans modele geometrique */
int nb_contour_total; 	/* Nombre de contours total */
int *nb_cont_face;	/* Nombre de contours par face */
int *numero_face;	/* Numeros affectes aux faces */
double *exit_init;	/* Exitances (ou radiosites) initiales */
double *exit;		/* Exitances (ou radiosites) calculees */
int flag_arret = 2;	/* Arret quand moins de x% de l'energie initiale */
			/* reste a distribuer */
int epsilon;		/* Si flag_arret = 1 */
double pourc = 0.1;	/* Si flag_arret = 2 */
double seuil;		/* Si flag_arret = 3 */
int nb_iter_max;	/* Si flag_arret = 4 */

char *s_dir;
char c;
FILE *pfic;
FILE *pfic0, *pfic1, *pfic2, *pfic3, *pfic4, *pfic5, *pfic6, *pfic7;
FILE *pfic_temp;
FILE *pfic_sol;
FILE *pfic_IR;	

int gi;
int gnum;
int gk;
int nofac;
int nbcont;
double val_min, val_max;
double mini, maxi;
double englob[10];
double *rien;
int test_erreur = 0;
	
	/* DEBUT PROG */
s_dir=(char *)getenv("PWD");

if(argc != 15) usage();

printf("DETERMINATION DES TEMPERATURES DE SURFACES (methode Simple)\n");
 
	/* lecture parametres commande */

compose_nom_complet(nom_faces_sol, s_dir, argv[1], "val");
printf("\n  fichier de valeurs d'appartenance au sol : %s \n", nom_faces_sol);

compose_nom_complet(nom_dflux_inc_sol_init,s_dir,argv[2],"val");
printf("  densites de flux incident solaire initiales : %s \n", nom_dflux_inc_sol_init);

compose_nom_complet(nom_refl_sol,s_dir,argv[3],"val");
printf("  coefficients de reflexion solaires: %s \n", nom_refl_sol);

compose_nom_complet(nom_refl_IR,s_dir,argv[4],"val");
printf("  coefficients de reflexion IR: %s \n", nom_refl_IR);

compose_nom_complet(nom_Tint, s_dir, argv[5], "val");
printf("   temperatures internes (C): %s\n", nom_Tint);
	
sscanf(argv[6],"%lf",&Text);
printf("   temperature de l'air externe (C): %f\n", Text);

sscanf(argv[7],"%lf", &hext);
printf("   coefficient de transfert convectif: %f\n", hext);

compose_nom_complet(nom_g, s_dir, argv[8], "val");
printf("   conductances facettes: %s\n", nom_g);

compose_nom_complet(nom_surf,s_dir,argv[9],"val");
printf("  surfaces facettes: %s \n", nom_surf);

compose_nom_complet(nom_fform,s_dir,argv[10],"fac");
printf("  facteurs de forme : %s \n", nom_fform);

compose_nom_complet(nom_fac_ciel,s_dir,argv[11],"val");
printf("  facteurs de vue du ciel : %s \n", nom_fac_ciel);

compose_nom_complet(nom_temp,s_dir,argv[12],"val");
printf("  temperatures calculees (C): %s \n", nom_temp);

compose_nom_complet(nom_dflux_abs_sol,s_dir,argv[13],"val");
printf("  densites de flux solaire absorbe: %s \n", nom_dflux_abs_sol);

compose_nom_complet(nom_dflux_net_IR,s_dir,argv[14],"val");
printf("  densites de flux IR absorbe: %s\n", nom_dflux_net_IR);


	/* LECTURE D'UN FICHIER .val POUR NBRE DE CONTOURS TOTAL */
	/* Lecture du fichier des densites de flux incident initiales */
nb_contour_total=0;
if ((pfic=fopen(nom_dflux_inc_sol_init,"r"))==NULL)
            	{ 
		printf("\n  impossible ouvrir %s\n\n", nom_dflux_inc_sol_init); 
		goto fin;
            	}
fscanf(pfic,"%d %d %lf %lf",&nbfac,&nomax,&val_min,&val_max);	
numero_face=(int *)malloc(nbfac*sizeof(int));
nb_cont_face=(int *)malloc(nbfac*sizeof(int));
for(gi=0;gi<nbfac;gi++)
		{
		fscanf(pfic,"\n%c%d%d\n",&c,&nofac,&nbcont);
		numero_face[gi]=nofac;
		nb_cont_face[gi]=nbcont;
		nb_contour_total+=nbcont;
		rien=(double *)malloc(nbcont*sizeof(double));
		for(gk=0;gk<nbcont;gk++)
			fscanf(pfic,"%lf\n",rien+gk);
		}
free(rien);
	
fclose(pfic);
printf("nombre total de contours: %d\n", nb_contour_total);	

	/* allocations memoire */

appart_sol = (double*)malloc(nb_contour_total*sizeof(double));
if (appart_sol==NULL)
	{printf("Probleme d'allocation 0\n");
	goto fin;}
init_double(appart_sol,nb_contour_total);

dflux_inc_sol_init = (double*)malloc(nb_contour_total*sizeof(double));
if (dflux_inc_sol_init==NULL)
	{printf("\nProbleme d'allocation 1\n"); 
	goto fin;}
init_double(dflux_inc_sol_init,nb_contour_total);

refl_sol = (double*)malloc(nb_contour_total*sizeof(double));
if (refl_sol==NULL)
	{printf("\nProbleme d'allocation 2\n"); 
	goto fin;}
init_double(refl_sol,nb_contour_total);

refl_IR = (double*)malloc(nb_contour_total*sizeof(double));
if (refl_IR==NULL)
	{printf("\nProbleme d'allocation 3\n"); 
	goto fin;}
init_double(refl_IR,nb_contour_total);

Tint = (double*)malloc(nb_contour_total*sizeof(double));
if (Tint==NULL)
	{printf("\nProbleme d'allocation 4\n"); 
	goto fin;}
init_double(Tint,nb_contour_total);

g = (double*)malloc(nb_contour_total*sizeof(double));
if (g==NULL)
	{printf("\nProbleme d'allocation 5\n"); 
	goto fin;}
init_double(g,nb_contour_total);


surf =(double *)malloc(nb_contour_total*sizeof(double));
if (surf == NULL)
	{printf("\nProbleme d'allocation 6\n");
	 goto fin;}
init_double(surf,nb_contour_total);

fform =(float *) malloc(nb_contour_total*sizeof(float));
if (fform == NULL)
	{printf("\nProbleme d'allocation 7\n");
	goto fin;}

fac_ciel =(double *) malloc(nb_contour_total*sizeof(double));
if (fac_ciel == NULL)
	{printf("\nProbleme d'allocation 8\n");
	goto fin;}
init_double(fac_ciel,nb_contour_total);

temp = (double*) malloc(nb_contour_total*sizeof(double));
if (temp == NULL)
	{printf("\nProbleme d'allocation 9\n");
	goto fin;}
init_double(temp,nb_contour_total);

dflux_abs_sol = (double*) malloc(nb_contour_total*sizeof(double));
if (dflux_abs_sol == NULL)
	{printf("\nProbleme d'allocation 10\n");
	goto fin;}
init_double(dflux_abs_sol,nb_contour_total);

dflux_inc_ciel = (double*) malloc(nb_contour_total*sizeof(double));
if (dflux_inc_ciel == NULL)
	{printf("\nProbleme d'allocation 11\n");
	goto fin;}
init_double(dflux_inc_ciel,nb_contour_total);


dflux_net_IR = (double*)malloc(nb_contour_total*sizeof(double));
if (dflux_net_IR == NULL)
	{printf("\nProbleme d'allocation 12\n");
	 goto fin;}
init_double(dflux_net_IR,nb_contour_total);


exit_init =(double *)malloc(nb_contour_total*sizeof(double));
if (exit_init == NULL)
	{printf("\nProbleme d'allocation 13\n");
	 goto fin;}
init_double(exit_init,nb_contour_total);

exit =(double *)malloc(nb_contour_total*sizeof(double));
if (exit == NULL)
	{printf("\nProbleme d'allocation 14\n");
	goto fin;}
init_double(exit,nb_contour_total);

printf("\n\nOK toutes allocations\n\n");


	/*** LECTURE DES FICHIERS POUR DONNEES ***/

	/* Lecture des coefficients de reflexion "solaires" */
if ((pfic1=fopen(nom_refl_sol,"r"))==NULL)
        { 
	printf("\n  impossible ouvrir %s\n\n", nom_refl_sol); 
	goto fin;
        }
lect_fichier(pfic1, nbfac, nomax, refl_sol);
fclose(pfic1);
test_zeros(nb_contour_total, refl_sol);
/*** A ENLEVER ***/
/* printf("AFFICHAGE ALBEDO SOLAIRE \n");
for (gnum=0;gnum<nb_contour_total;gnum++)
	printf("Contour %d, albedo solaire:%8.3f\n", gnum, refl_sol[gnum]); 
*/
	/* Lecture du fichier de valeurs appartenance au sol */
if ((pfic2=fopen(nom_faces_sol,"r"))==NULL)
	{ 
	printf("\n  impossible ouvrir %s\n\n", nom_faces_sol); 
	goto fin;
       	}
lect_fichier(pfic2, nbfac, nomax, appart_sol);
fclose(pfic2);
/*** A ENLEVER ***/
/* printf("AFFICHAGE APPART SOL \n");
for (gnum=0;gnum<nb_contour_total;gnum++)
	printf("Contour %d, appart_sol:%8.3f\n", gnum, appart_sol[gnum]); 
*/
	/* Lecture des coefficients de reflexion IR */
if ((pfic3=fopen(nom_refl_IR,"r"))==NULL)
   	{ 
	printf("\n  impossible ouvrir %s\n\n", nom_refl_IR); 
	goto fin;
        }
lect_fichier(pfic3, nbfac, nomax, refl_IR);
fclose(pfic3);
test_zeros(nb_contour_total, refl_IR);
/*** A ENLEVER ***/
/* printf("AFFICHAGE ALBEDO IR \n");
for (gnum=0;gnum<nb_contour_total;gnum++)
	printf("Contour %d, albedo IR:%8.3f\n", gnum, refl_IR[gnum]);
*/


	/* Lecture des temperatures internes */
if ((pfic4=fopen(nom_Tint,"r"))==NULL)
        { 
	printf("\n  impossible ouvrir %s\n\n", nom_Tint); 
	goto fin;
        }
lect_fichier(pfic4, nbfac, nomax, Tint);
fclose(pfic4);
/*** A ENLEVER ***/
/* printf("AFFICHAGE TEMP INTERNES \n");
for (gnum=0;gnum<nb_contour_total;gnum++)
	printf("Contour %d, temp interne:%8.3f\n", gnum, Tint[gnum]);
*/

	/* Lecture des conductances */

if ((pfic5=fopen(nom_g,"r"))==NULL)
      	{ 
	printf("\n  impossible ouvrir %s\n\n", nom_g); 
	goto fin;
        }
lect_fichier(pfic5, nbfac, nomax, g);
fclose(pfic5);
/*** A ENLEVER ***/
/* printf("AFFICHAGE CONDUCTANCES \n");
for (gnum=0;gnum<nb_contour_total;gnum++)
	printf("Contour %d, conductance:%8.3f\n", gnum, g[gnum]);
*/

	/* Lecture de la surface de chaque face */
if ((pfic6=fopen(nom_surf,"r"))==NULL)
        { 
	printf("\n  impossible ouvrir %s\n\n", nom_surf); 
	goto fin;
        }
lect_fichier(pfic6, nbfac, nomax, surf);
fclose(pfic6);
/*** A ENLEVER ***/
/* printf("AFFICHAGE SURFACES\n");
for (gnum=0;gnum<nb_contour_total;gnum++)
	printf("Contour %d, surface:%8.3f\n", gnum, surf[gnum]);
*/
	/* Lecture des facteurs de forme */
if ((fp=fopen(nom_fform,"rb"))==NULL)
        { 
		printf("\n  impossible ouvrir %s\n\n", nom_fform); 
		goto fin;
        }

	/* Lecture des facteurs de vue du ciel */
if ((pfic7=fopen(nom_fac_ciel,"r"))==NULL)
        { 
		printf("\n  impossible ouvrir %s\n\n", nom_fac_ciel); 
		goto fin;
        }
lect_fichier(pfic7, nbfac, nomax, fac_ciel);
fclose(pfic7);
	// les % de ciel visible sont transformees en fraction de ciel (0 a 1)
for (gnum=0;gnum<nb_contour_total;gnum++)
 { fac_ciel[gnum]=fac_ciel[gnum]/100.;
 }

/*** A ENLEVER ***/
/* printf("AFFICHAGE FAC VUE CIEL \n");
for (gnum=0;gnum<nb_contour_total;gnum++)
	printf("Contour %d, fac vue ciel:%8.3f\n", gnum, fac_ciel[gnum]); 
*/
	/* Lecture du fichier des densites de flux solaire incident initiales */
if ((pfic0=fopen(nom_dflux_inc_sol_init,"r"))==NULL)
       { 
	printf("\n  impossible ouvrir %s\n\n", nom_dflux_inc_sol_init); 
	goto fin;
       	}

lect_fichier(pfic0, nbfac, nomax, dflux_inc_sol_init);
fclose(pfic0);
/*** A ENLEVER ***/
/* printf("AFFICHAGE FAC VUE CIEL \n");
for (gnum=0;gnum<nb_contour_total;gnum++)
	printf("Contour %d, fac vue ciel:%8.3f\n", gnum, dflux_inc_sol_init[gnum]); 
*/

	/*** ECRITURE DES EN-TETES ***/

	/* ECRITURE DE l'EN-TETE DU FICHIER RESULTAT TEMPERATURES */
mini=maxi=0.0;

if ((pfic_temp = fopen(nom_temp,"w"))==NULL)
        { 	
	printf("\n impossible ouvrir %s\n", nom_temp); 
	goto fin;
        }
 	fprintf (pfic_temp,"%5d %5d %8.3lf %8.3lf\n", nbfac, nomax, mini, maxi);

 
	/* ECRITURE DE l'EN-TETE DU FICHIER RESULTAT FLUX SOLAIRE ABSORBE */
if ((pfic_sol = fopen(nom_dflux_abs_sol,"w"))==NULL)
        { 	
	printf("\n impossible ouvrir %s\n", nom_dflux_abs_sol); 
	goto fin;
        }
fprintf (pfic_sol,"%5d %5d %8.3lf %8.3lf\n", nbfac, nomax, mini, maxi);
   
   	      	
	/* ECRITURE DE l'EN-TETE DU FICHIER RESULTAT FLUX IR ABSORBE*/
if ((pfic_IR = fopen(nom_dflux_net_IR,"w"))==NULL)
        { 	
	printf("\n impossible ouvrir %s\n", nom_dflux_net_IR); 
	goto fin;
        }
fprintf (pfic_IR,"%5d %5d %8.3lf %8.3lf\n", nbfac, nomax, mini, maxi);


	/*** CALCUL ET STOCKAGE DES FLUX NETS DANS LA BANDE SOLAIRE ***/
	/*** SOLAIRE = VISIBLE + PIR ***/

	/* RADIOSITE : METHODE A RAFFINEMENT PROGRESSIF */
printf("\nTraitement en cours ...");
printf("\n");

printf("Calcul du flux solaire absorbe net\n");
printf("(bande visible+proche IR)\n");

	/* Initialisation densite de flux partant */
for (gnum = 0; gnum < nb_contour_total; gnum++)
	exit_init[gnum] = dflux_inc_sol_init[gnum]*refl_sol[gnum];


	/* Lancement iterations */
	im = 0;
	test_erreur = radiog(im, nb_cont_face, numero_face, nbfac, nb_contour_total, exit_init, surf, refl_sol, fform, flag_arret, epsilon, nb_iter_max, seuil, pourc, exit);
exit;
	/* A ce stade: exitance = radiosite = densite de flux partant */
	/* de chaque facette, dans la bande visible + PIR */

	for (gnum = 0;gnum<nb_contour_total;gnum++)
		{dflux_abs_sol[gnum] = ((1/refl_sol[gnum]) - 1.0)*exit[gnum];}

	/* ecriture directe du fichier resultat: densite de flux solaire absorbe */

	/* mini et maxi */
mini=maxi=dflux_abs_sol[0];
for(gnum=0;gnum<nb_contour_total;gnum++)
	{
	if(dflux_abs_sol[gnum]<mini) mini=dflux_abs_sol[gnum];
	if(dflux_abs_sol[gnum]>maxi) maxi=dflux_abs_sol[gnum];
	}

rewind(pfic_sol);
fprintf (pfic_sol,"%5d %5d %8.3lf %8.3lf\n", nbfac, nomax, mini, maxi);   

gnum=0;
for(gi=0;gi<nbfac;gi++)
	{
	fprintf (pfic_sol,"f%d %d\n",numero_face[gi],nb_cont_face[gi]);
	for(gk=0;gk<nb_cont_face[gi];gk++)
		{
		fprintf (pfic_sol,"    %8.3f\n",dflux_abs_sol[gnum]);
		gnum++;
		}
	}

met_a_zero(nb_contour_total, exit_init);
met_a_zero(nb_contour_total, exit);

	/*** CALCUL DES FLUX IR ET TEMPERATURES DE PAROI ***/

	/* calcul du flux IR recu de la part du ciel */
dflux_inc_ciel0 = IR_ciel(Text, 0);
printf("Densite de flux maximale recue du ciel dans l'IR: %lf\n\n", dflux_inc_ciel0);

for (gnum = 0;gnum<nb_contour_total;gnum++)
	dflux_inc_ciel[gnum] = fac_ciel[gnum]*dflux_inc_ciel0;


im = 0;
	/* Lancement iterations sur temperatures */

printf("*** Calcul temperatures avec algorithme simple ***\n");

bilan_radiatif = (double*)malloc(sizeof(double));

*bilan_radiatif = 0.0;

test_erreur = calc_temp_simple(im, nb_cont_face, numero_face, nbfac, nb_contour_total,  appart_sol, surf, fform, dflux_inc_sol_init, dflux_abs_sol, refl_IR, Tint, Text+273, hext, g, fac_ciel, dflux_inc_ciel, exit_init, exit, temp, dflux_net_IR, bilan_radiatif);

	if (test_erreur)
		{printf("\n*** PROBLEME, le calcul des temperatures a echoue ...\n");
		 printf("Verifiez vos donnees numeriques ? ***\n");
		 goto fin;
		}


	/*** SAUVEGARDE DES RESULTATS, FLUX IR ET TEMPERATURES ***/
	/* ecriture resultats temperatures */
printf("** Attention, temperatures sauvees en Celsius ... **\n");
	/* mini et maxi */

for(gi=0;gi<nb_contour_total;gi++)
	{temp[gi] = temp[gi] - 273;}
mini=maxi=temp[0];
for(gi=0;gi<nb_contour_total;gi++)
	{
	if(temp[gi]<mini) mini=temp[gi];
	if(temp[gi]>maxi) maxi=temp[gi];
	}

rewind(pfic_temp);
fprintf (pfic_temp,"%5d %5d %8.3lf %8.3lf\n", nbfac, nomax, mini, maxi);   

gnum=0;
for(gi=0;gi<nbfac;gi++)
	{
	fprintf (pfic_temp,"f%d %d\n",numero_face[gi],nb_cont_face[gi]);
	for(gk=0;gk<nb_cont_face[gi];gk++)
		{
		fprintf (pfic_temp,"    %8.3f\n",temp[gnum]);
		gnum++;
		}
	}


	/* valeur nette pour chaque facette, dans l'IR */
	
	/* mini et maxi */
mini=maxi=dflux_net_IR[0];
for(gi=0;gi<nb_contour_total;gi++)
	{
	if(dflux_net_IR[gi]<mini) mini=dflux_net_IR[gi];
	if(dflux_net_IR[gi]>maxi) maxi=dflux_net_IR[gi];
	} 

rewind(pfic_IR);
fprintf (pfic_IR,"%5d %5d %8.3lf %8.3lf\n", nbfac, nomax, mini, maxi);   

gnum=0;
for(gi=0;gi<nbfac;gi++)
	{
	fprintf (pfic_IR,"f%d %d\n",numero_face[gi],nb_cont_face[gi]);
	for(gk=0;gk<nb_cont_face[gi];gk++)
		{
		fprintf (pfic_IR,"    %8.3f\n",dflux_net_IR[gnum]);
		gnum++;
		}
	}


printf("Fin\n\n");
fclose(pfic_temp);	
fclose(pfic_sol);	
fclose(pfic_IR);	
fclose(fp);	
	
free(exit_init);
free(exit);
free(appart_sol);
free(dflux_inc_sol_init);
free(refl_sol);
free(refl_IR);
free(Tint);
free(g);
free(surf);
free(fform);
free(fac_ciel);
free(dflux_inc_ciel);
free(temp);
free(dflux_abs_sol);
free(dflux_net_IR);

creer_OK_Solene();
fin:;		
}


/********************** PROCEDURES *********************************/

/*_________________________________________________________________*/
/* Format de la fonction rad */
void usage()
	{
  	printf("\n   format d'entree des parametres:\n\n");
  	printf("   *calc_temp_simple*  appartenance_sol(.val) flux_solaire_incident(.val)  coef_reflexion_solaire(.val)  coef_reflexion_IR(.val) temp_internes(.val) temp_externe coef_convection_externe conductances_facettes(.val) surfaces(.val) facteurs_forme(.fac) fac_vue_ciel(.val) temperatures_calculees(.val)  flux_solaire_net(.val)  flux_IR_net(.val)\n");
	printf("\ttemperatures exprimees en Celsius\n");
	
  	exit(0);
	}

/*_________________________________________________________________*/
/* Lecture fichier au "bon" format et remplissage tableau 'valeur' */
void lect_fichier(pfic, nbfac, nomax, valeur)
FILE *pfic;
int nbfac;
int nomax;
double *valeur;
{ double val_min;
  double val_max;
  int num_cont, num_face, num_cont_liste;
  int nofac, nbcont_face;
  char c;

  fscanf(pfic,"%d %d %lf %lf",&nbfac,&nomax,&val_min,&val_max);
  num_cont_liste = 0;
  for(num_face=0;num_face<nbfac;num_face++)
	{
	fscanf(pfic,"\n%c%d%d\n",&c,&nofac,&nbcont_face);
	for(num_cont=0;num_cont<nbcont_face;num_cont++)	
		{	
		fscanf(pfic,"%lf\n",valeur+num_cont_liste);
		num_cont_liste++;
		}
	}
}
/*_____________________________*/
/* Teste si zeros dans tableau */
void test_zeros(nb_valeurs, tab)
int nb_valeurs;
double *tab;
{
int compt;

for (compt=0;compt<nb_valeurs;compt++)
	{if (tab[compt] < 1e-3) 
		{ printf("Erreur, reflectivite nulle rencontree ...\n");
		  printf("Contour no %d\n", compt);
		   exit(0); }		
	}
}

/*____________________________________________*/
/* Met toutes les valeurs d'un tableau a zero */
void met_a_zero(nb_valeurs, tab)
int nb_valeurs;
double *tab;
{int compt;

for (compt=0;compt<nb_valeurs;compt++)
	tab[compt] = 0.0;
}


/*____________________________________________*/
/* Lecture des facteurs de forme dans fichier */
void lecture_ff(factf, ii, nb_contour_total)
float *factf;
int ii, nb_contour_total;
   {
   fseek(fp,(ii*nb_contour_total)*sizeof(float),SEEK_SET);
   fread(factf, sizeof(float), nb_contour_total, fp);
   }




/*______________________________________________________________________*/
/*    Radiosite "generalisee"    					*/
/* Tableau d'entree: `exit_init', tableau de sortie: 'exit' 		*/
/* Dans la bande solaire: mettre en entree la 1ere reflexion 		*/
/* du flux solaire incident 						*/
/* Dans l'IR: mettre en entree l'emission propre de chaque surface 	*/
/* On recupere en sortie l'exitance (ou la radiosite) de chaque surface */

int radiog(im, nb_cont_face, numero_face, nbfac, nb_contour_total, exit_init, surf, reflex, fform, flag_arret, epsilon, nb_iter_max, seuil, pourc, M)

int im;
int *nb_cont_face;
int *numero_face;
int nbfac;
int nb_contour_total;
double *exit_init;
double *surf;
double *reflex;
float *fform;
int flag_arret; 
int epsilon;
int nb_iter_max;
double seuil;
double pourc;
double *M;


{ 	int face;    
	int num_cont, contour; 
	int iteration; 
	int icont_liste_max;
	int iface_max;
	int icont_max;	
	double energie_totale; 
	double a_distribuer;
	double a_distribuer_preced;
	double a_distribuer_max;
	double *deltaM;
	double fform_recip;
	double dM;
	static int nb_iter_max_abs = 50000;
	int erreur = 0;

//printf("im= %d nbface = %d nb_contour_total = %d\n",im,nbfac,nb_contour_total);

	/* Allocations dynamiques */
       	deltaM =(double *)malloc(nb_contour_total*sizeof(double));

	/* initialisations */
	for(contour=0;contour<nb_contour_total;contour++)
	{	M[contour]=deltaM[contour]=exit_init[contour];
	   	//printf("\nInitialisation (W): %lf\n",M[contour]);

	}


	energie_totale=0.0;
   	for(contour=0;contour<nb_contour_total;contour++) 
	{ 		energie_totale+=deltaM[contour]*surf[contour];
   			//printf("\nEnergie totale a distribuer (W): %lf\n",energie_totale);
	}
   	printf("\nEnergie totale a distribuer (W): %lf\n",energie_totale);
	a_distribuer_preced=energie_totale;
	a_distribuer = energie_totale;


	/* iterations */
	
	iteration=1;
	while(iteration < nb_iter_max_abs) 
   		{
   		/*printf("...iteration %d...\r",iteration); */

   		a_distribuer_max=0.0;
   		num_cont=0;
		for(face=0;face<nbfac;face++)
		  {
		  for(contour=0;contour<nb_cont_face[face];contour++)
			{						 	 if(deltaM[num_cont]*surf[num_cont]>a_distribuer_max)
         				{
         				a_distribuer_max=deltaM[num_cont]*surf[num_cont];
					iface_max=face;     
					icont_max=contour+1;   
         				icont_liste_max=num_cont;	  
         				}		 		    
			num_cont++;
			}
		  }

   		if(im) printf("\nFlux maxi (W) en provenance de la face %d, contour %d (no %d) : %5.2f\n",numero_face[iface_max],icont_max,icont_liste_max+1,a_distribuer_max); 
 
		/* lecture des ff[ii] */
	
   		lecture_ff(fform,icont_liste_max,nb_contour_total);
  
   		num_cont=0;
        if(im==2)	
			{
			for(face=0;face<nbfac;face++)
				{
				for(contour=0;contour<nb_cont_face[face];contour++)
					{
	   printf("  FF f%dc%d -> f%dc%d = ",numero_face[iface_max],icont_max,numero_face[face],contour+1);
					if(fform[num_cont]==0) printf("0\n");
					else printf("%f\n",fform[num_cont]);
					num_cont++;
					}
				}
			}

		/* contribution de l'element de flux maximal, a tous les autres */
   		for(num_cont=0;num_cont<nb_contour_total;num_cont++) 
      			{
		
			fform_recip=fform[num_cont]*surf[icont_liste_max]/surf[num_cont];
			if(fform_recip>1.) fform_recip=1.;
			dM=reflex[num_cont]*deltaM[icont_liste_max]*fform_recip;    
      			deltaM[num_cont]+=dM;
      			M[num_cont]+=dM;
      			if(im==2) printf("dM = %8.2f\tdeltaM[%2d] = %8.2f\tM[%2d] = %8.2f\n",
							dM,num_cont+1,deltaM[num_cont],num_cont+1,M[num_cont]);   
      			}
   		deltaM[icont_liste_max]=0.0;

		a_distribuer=0.0;
   		for(num_cont=0;num_cont<nb_contour_total;num_cont++) 
      			a_distribuer+=deltaM[num_cont]*surf[num_cont]; 
  
   		if(im) printf("energie non distribuee (W): %.2lf\n\n",a_distribuer);


		/* Sortie de boucle ? */
		/* Pas genial mais dependant des conventions adoptees dans versions precedentes */

		if ((flag_arret == 1) && (a_distribuer < epsilon))
			break;
		if ((flag_arret == 2) && (a_distribuer < (pourc*energie_totale/100)))
			break;
		if ((flag_arret == 3) && (a_distribuer_preced-a_distribuer<seuil))
			break;
		if ((flag_arret == 4) && (iteration > nb_iter_max))
			break;
		
		a_distribuer_preced=a_distribuer;
	   	iteration++;
   		}

	free(deltaM);
	/* Les resultats a exploiter dans le corps du prog sont dans M */
	return erreur;
}

/* Calcul du flux IR envoye par le ciel		*/
/*______________________________________________*/
double IR_ciel(Ta, ind_Kelvin)
double Ta; 	/* temperature de l'air ambiant */
int ind_Kelvin; /* flag indiquant si la temperature d'entree est en Kelvin */

{ /* Calcul du flux IR maximum recu en provenance du ciel */
 /* d'apres modele these J. Noilhan */
/* On peut choisir un autre modele: Angstrom, Brunt, etc ... */
/* et prendre en compte la nebulosite */

if (ind_Kelvin)
	return (double)(5.5*(Ta-273) + 213);
else
	return (double)(5.5*Ta + 213);
}
 
	
/* Calcul des temperatures, algo. direct				 */
/*_______________________________________________________________________*/
int calc_temp_simple (im, nb_cont_face, numero_face, nbfac, nb_contour_total,  appart_sol, surf, fform,  dflux_inc_sol_init, dflux_abs_sol, refl_IR, Tint, Text, hext, g, fac_ciel, dflux_inc_ciel, exit_init, exit, temp, dflux_net_IR, bilan_radiatif)

int im;
int *nb_cont_face;
int *numero_face;
int nbfac;
int nb_contour_total;
float *appart_sol;
double *surf;
float *fform;
double *dflux_inc_sol_init;
double *dflux_abs_sol;
double *refl_IR;
double *Tint;			
double Text;			
double hext;
double *g;
double *fac_ciel;
double *dflux_inc_ciel;
double *exit_init;
double *exit;
double *temp;
double *dflux_net_IR;
double *bilan_radiatif;
{
int erreur = 0;
double stefan = 5.67e-8; /* Constante de Stefan */
double em_moy, hrad;
int flag_arret = 2;
double pourc = 0.1;
int epsilon = 1;
double seuil = 0.001;
int nb_iter_max = 1000;
int num_cont, j;
double somme_flux_inc;
double somme_flux_nets;

	/*** Conversion en Kelvin ***/

for (num_cont=0;num_cont<nb_contour_total;num_cont++)
	Tint[num_cont]+=273;

	/*** Bilan de rayonnement solaire ***/
	/* On en dispose, c'est le tableau dflux_abs_sol */

	/* Calcul des temperatures de paroi par une formule simple */
	/* avec linearisation du transfert radiatif dans l'infrarouge */

		/** Calcul de l'emissivite IR moyenne des surfaces **/
em_moy = 0.0;
for (num_cont=0;num_cont<nb_contour_total;num_cont++)
	em_moy = em_moy + (1 - refl_IR[num_cont]);
em_moy = em_moy/nb_contour_total;
hrad = 4.0*em_moy*stefan*Text*Text*Text;
printf("Coefficient de transfert radiatif IR linearise: %8.3f\n", hrad);

		/** Calcul des temperatures de paroi **/
for (num_cont=0;num_cont<nb_contour_total;num_cont++)
	{temp[num_cont] = Text + dflux_abs_sol[num_cont]/(hext + hrad);
	 temp[num_cont] = temp[num_cont] - g[num_cont]*(temp[num_cont] - Tint[num_cont])/(hext + hrad);
	//printf("Temp contour %d en C: %8.3lf\n", num_cont, temp[num_cont] - 273);
	}


	/*** Calcul des bilans IR ***/


	/* Initialisation des radiosites dans la bande IR */

printf("Initialisation radiosites IR\n");
for (num_cont=0;num_cont<nb_contour_total;num_cont++)
		exit_init[num_cont] = (1.0 - refl_IR[num_cont])*stefan*temp[num_cont]*temp[num_cont]*temp[num_cont]*temp[num_cont];
		
	/* Calcul des radiosites dans l'IR apres reflexions entre parois */

printf("Lancement calcul radiosites IR\n");
im = 0;
erreur = radiog(im, nb_cont_face, numero_face, nbfac, nb_contour_total, exit_init, surf, refl_IR, fform, flag_arret, epsilon, nb_iter_max, seuil, pourc, exit);


	/* Calcul des flux IR nets */

	/** NB: les flux nets ne sont pas calcules directement a partir  */
	/* des radiosites comme on le faisait dans la bande solaire,     */
	/* car l'expression fait intervenir l'inverse de l'albedo IR     */
	/* or, pour des albedos courants de l'ordre de 0.05, les erreurs */
	/* sont multipliees par 20 ... ce n'est pas satisfaisant 	 */
	/* du point de vue numerique.					**/

for (num_cont=0;num_cont<nb_contour_total;num_cont++)
	{ dflux_net_IR[num_cont] = 0.0;

	lecture_ff(fform, num_cont, nb_contour_total); 
 
	for (j=0;j<nb_contour_total;j++)
		{if (j != num_cont)
			dflux_net_IR[num_cont] = dflux_net_IR[num_cont] + fform[j]*exit[j];
						
		}

	dflux_net_IR[num_cont] = dflux_net_IR[num_cont]*(1 - refl_IR[num_cont]) - exit_init[num_cont] + (1 - refl_IR[num_cont])*dflux_inc_ciel[num_cont];
	
	}

	/* Calcul bilan radiatif global par rapport au ciel */
	somme_flux_inc = 0.0;
	somme_flux_nets = 0.0;
	for (num_cont=0;num_cont<nb_contour_total;num_cont++)
		{ somme_flux_inc = somme_flux_inc + dflux_inc_sol_init[num_cont]+dflux_inc_ciel[num_cont];

		  somme_flux_nets = somme_flux_nets + dflux_abs_sol[num_cont] + dflux_inc_ciel[num_cont] - fac_ciel[num_cont]*exit[num_cont];
		}

	*bilan_radiatif = somme_flux_nets/somme_flux_inc;

	printf("\nSomme des flux incidents (ciel): %8.3lf\n",somme_flux_inc);
	printf("Somme des flux nets (ciel)     : %8.3lf\n", somme_flux_nets);
	printf("Bilan radiatif global (relatif): %8.3lf\n\n", *bilan_radiatif);
	

	
return erreur;
}

/*_______________________________________________________*/
int init_double(dd,nb)
double *dd;
int nb;
{
 int i;
 
  for(i=0;i<nb;i++) dd[i]=0.;
}



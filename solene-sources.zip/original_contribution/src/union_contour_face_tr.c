/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

// union_contour_face_tr

/*
D. GROLEAU Fevrier 2006
  unit les contours de chacune des faces triangul�es d'une g�om�trie Solene
  les contours sont mitoyens et sans recouvrement (la face n'a �videmment pas de contour avec trou)
  l'union d'une face peut cr�er un ou plusieurs contours avec trous



  fonction solene_simail solene_geo
*/


#include <solene.h>

// DECLARATIONS FUNCTIONS

int ajoute_point();
int cherche_no_point();
int cherche_arete_suivant();
void constitue_circuit();
void ecrit_face();
int ecrit_en_tete();
void format_entree();
int nombre_de_points_du_contour();
void organise_circuit();
int point_dans_fenetre();
int retient_arete_si_non_mitoyenne();


#define MAXTAB 5000
#define EPSILONE 0.005
#define MAXTRVO 15


/*_________________________________________________________________*/
main(argc,argv)
 int argc;char **argv;
{
 char 	buf[512],*s_dir;
 double englob[10];
 
 int i,j, nbff,nomax;
 FILE *fp;
 struct modelisation_face *ff;
 struct contour *pcont, *pcont1;
 struct circuit *pcir,*pcir1;

 double tabx[MAXTAB], taby[MAXTAB], tabz[MAXTAB]; // contient les points coordonn�es 3D
 double tabx_t[MAXTAB], taby_t[MAXTAB]; // contient les points coordonn�es x et y 2D projet�s
 int  nbtab, ntab_no_point ;
 int tabA[MAXTAB], tabB[MAXTAB];
 int ntab_arete;
 int tabA_NM[MAXTAB], tabB_NM[MAXTAB], tabR_NM[MAXTAB];
 int ntab_arete_NM;
 int ref_point, deb_point;
 int oui;

 int id,ind, idebut,ideb,ifin;


if(argc!=3)format_entree();
 
// initialise
s_dir = "";
nbtab = 0 ;
ref_point = 1 ;
deb_point = 1 ; 

printf("\nFonction Solene : union_contour_face_tr\n\n");

printf("Unit les contours des faces triangul�es\n\n");


//  parametres a lire

// fichier solene .cir en Input
  compose_nom_complet(buf, s_dir,argv[1],"cir");
  if((fp=fopen(buf,"r"))==NULL)
        { printf("\n impossible ouvrir %s\n",buf); exit(0);}

   lit_en_tete(fp,&nbff,&nomax,englob);
   ff=alloue_face(nbff,35);
   lit_fic_cir3d(fp,nbff,ff);
   fclose(fp);
   printf("G�om�trie_in:    %s (%d faces)\n",buf,nbff);

   // fichier solene .cir en Output
  compose_nom_complet(buf, s_dir,argv[2],"cir");
  if((fp=fopen(buf,"w"))==NULL)
        { printf("\n impossible ouvrir %s\n",buf); exit(0);}
   printf("G�om�trie_out:   %s\n",buf);
   ecrit_en_tete(fp,nbff,nomax,englob);

// il est n�cessaire de raisonner dans le plan de chaque face
//    pour trouver si un point dans un contour en 2D
     obs.xo=0; obs.yo=0; obs.zo=0;


// Lit les faces avec ses coutours (sans trou)  et unit les contours pour chaque face
  for(j=0;j<nbff;j++) 
    {  
	  //printf("FACE %d\n",j+1);
	 // TRAITE LES POINTS ET LES LIGNES FACE / FACE

	   obs.x=(ff+j)->vnorm[0];
	   obs.y=(ff+j)->vnorm[1];
	   obs.z=(ff+j)->vnorm[2];
	   tranfo();  
       tran_face(ff+j,1,ff+j,0); // Projette la face suivant sa normale

	   // Etablit la liste des points
	   nbtab = 0;

       pcont=(ff+j)->debut_projete;
	   pcont1=(ff+j)->debut_dessin;
       while(pcont)	   
        { pcir=pcont->debut_support; 
	      pcir1=pcont1->debut_support;
           for (i=0;i<pcir->nbp-1;i++)
             {
               // test si ajoute le point (oui contient l'indice du point dans la table)
               oui = ajoute_point(pcir->x[i], pcir->y[i], pcir->z[i], tabx, taby, tabz, &nbtab, ref_point, deb_point) ;
if(oui!=-1)
{ // ajoute aussi les coordonnees X et Y projet�s dans le plan de la face dans tabx_t et taby_t
 tabx_t[nbtab-1]=pcir1->x[i];
 taby_t[nbtab-1]=pcir1->y[i];
}
             }
			if(pcont->debut_interieur)
			{ printf(" un PB: un contour avec trou\n");
			  exit(0);
			}            
          pcont=pcont->suc; 
          pcont1=pcont1->suc; 
		} //FIN while Pcont

	   //for(i=0;i<nbtab;i++) printf(" Points retenus %2d : %f %f %f __ %f %f\n",i+1,tabx[i],taby[i],tabz[i],tabx_t[i],taby_t[i]);
	   //printf("\n");

	   // Etablit les aretes des contours
	   ntab_arete=0;
       pcont=(ff+j)->debut_projete;
       while(pcont)	   
        { pcir=pcont->debut_support; 
	       for(i=0;i<pcir->nbp-1;i++)
		   {
		    // Met dans tabA et tabB les no des points, extr�mit�s des ar�tes du contour 
            id= cherche_no_point(pcir->x[i],pcir->y[i],pcir->z[i], tabx, taby, tabz, nbtab);
		    if(id==-1)
			{ printf("PB: ne trouve pas un point\n");
		      exit(0);
			}
			tabA[ntab_arete]=id;

			id= cherche_no_point(pcir->x[i+1],pcir->y[i+1],pcir->z[i+1], tabx, taby, tabz, nbtab);
		    if(id==-1)
			{ printf("PB: ne trouve pas un point\n");
		      exit(0);
			}
			tabB[ntab_arete]=id;
			ntab_arete++;
			if((ntab_arete+1) > MAXTAB)
			  { printf("trop d'aretes %d ... stop\n\n" , MAXTAB) ;
			    exit(0);
			  }

		   }            
          pcont=pcont->suc; 
	   } //FIN while Pcont

	   //for(i=0;i<ntab_arete;i++) printf(" arete %2d :  %2d %2d\n",i+1,tabA[i],tabB[i]);
	   //printf("\n");


	   // Etablit la liste des aretes NON mitoyennes
	   ntab_arete_NM=0;
	   for(i=0;i<ntab_arete;i++)
	   { 
		 if(retient_arete_si_non_mitoyenne(i,tabA[i],tabB[i],tabA,tabB,ntab_arete)) // retient l'ar�te
			{ tabA_NM[ntab_arete_NM]= tabA[i];
			  tabB_NM[ntab_arete_NM]= tabB[i];
			  tabR_NM[ntab_arete_NM]= 0; // statut non utilis� pour la suite
			  ntab_arete_NM++;
			}
	   }

	   //for(i=0;i<ntab_arete_NM;i++) printf(" Aretes retenues %d :  %3d %3d statut %3d\n",i+1, tabA_NM[i],tabB_NM[i],tabR_NM[i]);

	   // Etablit la liste des circuits possibles en parcourant les ar�tes
	   // Stocke les N� de points des circuits dans TabA 
	   // et les statuts (debut, fin de circuit, trou) des points dans TabB (voir organise_circuit())
	   ntab_no_point=0;
	   idebut=1;
	   for(i=0;i<ntab_arete_NM;i++)
	   {
		   if(tabR_NM[i]==0)
		   { if(idebut)
				{ ideb= tabA_NM[i];
				  ifin= tabB_NM[i];
				  tabR_NM[i]=1; // arete retenue
				  tabA[ntab_no_point]=ideb;
				  tabB[ntab_no_point]=-2; // debut de circuit				  
				  ntab_no_point++;
				  tabA[ntab_no_point]=ifin;
				  tabB[ntab_no_point]=0; // point interm�diaire de circuit				  
				  ntab_no_point++;

				  idebut=0;
				}
             while(1)
			 {
		      ind= cherche_arete_suivant(ifin,tabA_NM,tabB_NM,tabR_NM,ntab_arete_NM);
			  if(ind==0)
				{ // fin d'un circuit
				  // normalement on aurait pu le trouver ideb =ifin
				  tabB[ntab_no_point-1]=-1; // fin de circuit				  
				  idebut=1; // on continue avec un  nouveau circuit constitu� des aretes non encore utilis�es
				  break;
				}
			  else if(ind>0)
				{ // l'arete suivante a comme n�ind
				  ifin=tabB_NM[ind-1];
				  tabA[ntab_no_point]=ifin;
				  tabB[ntab_no_point]=0; // point interm�diaire de circuit				  
				  ntab_no_point++;

				}
			  else // ind<0)
				{ // l'arete suivante a comme n�ind mais il faut inverser les extr�mit�s
				  ind=-ind;
				  ifin=tabA_NM[ind-1];
				  tabA[ntab_no_point]=ifin;
				  tabB[ntab_no_point]=0; // point interm�diaire de circuit				  
				  ntab_no_point++;
				}
			 }//fin While cherche suivant
		   }
	   }

	   // Imprime circuits constitu�s
	   /*
	   printf("\nLES CIRCUITS\n");
	   for(i=0;i<ntab_no_point;i++) printf(" point %2d :  %2d   statut: %2d\n",i+1,tabA[i],tabB[i]);
	   printf("____________\n");
	   */

       // Organise les circuits de la face (contours support et contour trous)
	   organise_circuit(tabA,tabB,ntab_no_point,tabx_t,taby_t);
	   /*
	   printf("\nLES CIRCUITS ORGANISES\n");
	   for(i=0;i<ntab_no_point;i++) printf(" point %2d :  %2d   statut: %2d\n",i+1,tabA[i],tabB[i]);
	   */

	   // Ecrit la face dans le fichier out
	   ecrit_face(fp,(ff+j),tabA,tabB,ntab_no_point,tabx,taby,tabz);


    } //FIN FOR des faces

 fclose(fp) ;
 desalloue_fface(ff,nbff);

 printf("\nFin union_contour_face_tr\n");
 printf("\n__________________________________________________________\n");

}

/*_________________________________________________________________________*/
int ajoute_point(x,y,z, tabx, taby, tabz, nbtab,  ref_point, deb_point)
double x, y, z ;
double *tabx, *taby, *tabz ;
int *nbtab;
int ref_point, deb_point;
{  
  int nb,i ;
  double dx, dy, dz;
	// ajoute un point dans la table si le point est different
    // si le point existe , renvoie  -1 
    // sinon, ajoute le point dans la table et renvoie son numero (en fait son indice, nb-1,  le dernier du tableau)
  //printf("place Point %f %f %f \n",x,y,z);
  nb = *nbtab ;
  for (i=0 ;i<nb ;i++)
  {  dx = *(tabx+i) - x ;
     dy = *(taby+i) - y ;
     dz = *(tabz+i) - z ;
     if (fabs(dx) < EPSILONE && fabs(dy) < EPSILONE && fabs(dz) < EPSILONE) return(-1) ; 
							// on pourrait retourner l'indice du point : i
  }

 // ajoute le point dans la table ...
  *(tabx+nb) = x ;
  *(taby+nb) = y ;
  *(tabz+nb) = z ;
  //printf("ajoute le POINT ds table � indice %d = %f %f %f\n",nb,tabx[nb],taby[nb],tabz[nb]);

  if((nb+1) > MAXTAB)
  { printf("trop de points %d ... stop\n\n" , MAXTAB) ;
    exit(0);
  }
   nb++ ;
   *nbtab = *nbtab+1 ;
   return(nb-1) ; 
}

/*_________________________________________________________________*/
int cherche_no_point(x,y,z, tabx, taby, tabz, nbtab)
double x, y, z ;
double *tabx, *taby, *tabz ;
int nbtab;

{  
  int i ;
  double dx, dy, dz;
	// cherche un point dans la table et rencvoie son indice +1
  for (i=0 ;i<nbtab ;i++)
  {  dx = *(tabx+i) - x ;
     dy = *(taby+i) - y ;
     dz = *(tabz+i) - z ;
     if (fabs(dx) < EPSILONE && fabs(dy) < EPSILONE && fabs(dz) < EPSILONE) 
	 { // le point existe 
		 return(i+1);
	 }
  }
 return(-1) ; 
}

/*_________________________________________________________________*/
int retient_arete_si_non_mitoyenne(j,nod,nof,tabA,tabB, ntab)
int j,nod, nof;
int *tabA,*tabB;
int ntab;
{
	int i;

	for(i=0;i<ntab;i++)
	{ if(i!=j)
		{	if(tabA[i]==nod && tabB[i]==nof) return(0); // arete mitoyenne
			if(tabA[i]==nof && tabB[i]==nod) return(0); // arete mitoyenne
		}
	}

	//arete non mitoyenne
	return(1);

}

/*_________________________________________________________________*/
int cherche_arete_suivant(ifin,tabA_NM,tabB_NM,tabR_NM,ntab_arete_NM)
int ifin;
int *tabA_NM,*tabB_NM,*tabR_NM;
int ntab_arete_NM;
{
	int i;

	// renvoie le n� de l'arete qui suit le point n� ifin
	//     en n�gatif si  inverse arete
	// return(0) pas de suivant
	// marque =1 l'arete retenue

	for(i=0;i<ntab_arete_NM;i++)
	{ 
	  if(tabR_NM[i]==0)
		{	if(tabA_NM[i]==ifin)
				{   tabR_NM[i]= 1;
					return(i+1);    // le point debut de l'arete suit ifin
				}
			if(tabB_NM[i]==ifin)
				{   tabR_NM[i]= 1;				
				    return(-(i+1)); // le point fin de l'arete suit ifin
				}
		}
	}

	// pas de suivant
	return(0);


}

/*_________________________________________________________________*/
void organise_circuit(tabA,tabB,ntab_no_point,tabx_t,taby_t)
int *tabA,*tabB, ntab_no_point;
double *tabx_t,*taby_t;
{
	int i,j;
	double xp,yp;
	struct circuit *pcir;
	int idedan,isur,nopoly;

   // Mise en �vidence des trous et de leur contour support associ�
   // -2 point d�but de contour
   // -1 point fin de contour
   //  0 point courant 
   //  >0 on marque les circuits TROU (statut = no du circuit support)
   // les contours (support ou trous sont num�rot�s de 1 � n dans l'ordre d'apparition dans tab))
 
	// on travaille avec les coordonn�es des points projet�s suivant la normale

	for(i=0;i<ntab_no_point;i++)
	{ 	
		// cherche le d�but du prochain circuit i � analyser (statut -2)
		if(tabB[i]==-2)
		{
		   nopoly=0;
		   for(j=0;j<ntab_no_point;j++)
			{ // cherche le d�but du prochain circuit j � comparer (statut -2) 	# de j
			  if(tabB[j]==-2 ||  tabB[j]>0) nopoly++; // indique le no du poly j (possiblement englobant)
			  if(tabB[j]==-2 && i!=j)
				{ 
				  // cherche si i est un TROU pour j
				  //printf("cherche si %d est un trou pour %d\n",i,j);
				  // prend 1er point de i et test si dans contour qui commence en j
				  xp = tabx_t[tabA[i]-1];
				  yp = taby_t[tabA[i]-1];
				  //printf(" %f %f dans \n",xp,yp);
				  // constitue le circuit j
				  pcir=alloue_circuit(3456);
				  constitue_circuit(j,pcir,tabA,tabB,tabx_t,taby_t);

				   // test pt / dans fenetre circuit j
                   if(point_dans_fenetre(xp,yp,pcir->fen))
                          { inpoly(&idedan,&isur,xp,yp,pcir);
                            if(idedan)
								{ // met � j statut no du poly support return(0);
								  //printf("oui un trou\n");
								  tabB[i]=nopoly;
								}
                          }
				   // desalloue circuit
				   desalloue_circuit(pcir,0);
				}// Fin if(tab pour j
			}
		}// Fin if(tab pour i
	}
}

/*_________________________________________________________________*/
void constitue_circuit(j,pcir,tabA,tabB,tabx_t,taby_t)
int j;
struct circuit *pcir;
int *tabA,*tabB;
double *tabx_t,*taby_t;
{
	int k,ind;
	int nbpoin;

	// j : indice du 1er pt du circuit dans tabA
            pcir->suc=NULL;
			// nb de points � allouer
			nbpoin=nombre_de_points_du_contour(j,tabB);
			//printf("	nb de points du circuit %d\n",nbpoin);
			pcir->nbp=nbpoin;
            alloue_point_circuit(pcir,1004);
            for(k=0;k<pcir->nbp;k++)
				{ ind=tabA[j+k]-1;
			      //printf("ind %d\n",ind);
				  pcir->x[k]= tabx_t[ind];
				  pcir->y[k]= taby_t[ind];
				  pcir->z[k]= 0;
				}
            fenetre_circuit(pcir); 

			/*
			printf("le circuit constitu� \n");
			for(k=0;k<pcir->nbp;k++)
				{ printf("%10.3f %10.3f %10.3f\n",pcir->x[k],pcir->y[k],pcir->z[k]);
				}
		    */
}


/*_________________________________________________________________*/
void ecrit_face(fp,ff,tabA,tabB,ntab_no_point,tabx,taby,tabz)
FILE *fp;
struct modelisation_face *ff;
int *tabA,*tabB, ntab_no_point;
double *tabx,*taby,*tabz;
{
	int nb_contour, nb_trou, no_poly, nbpoin;
	int i,j,k,ind;

	// cherche nombre de contours de la face
	nb_contour=0;
    for(j=0;j<ntab_no_point;j++)
			{ // compte les d�buts de circuit 
			  if(tabB[j]==-2 )nb_contour++;
			}
	//printf("nb de contour %d\n",nb_contour);
	// �crit en-t�te face
	fprintf(fp,"f%d %d\n",ff->nofac_fichier,nb_contour);
	fprintf(fp,"%f %f %f\n",ff->vnorm[0],ff->vnorm[1],ff->vnorm[2]);

	// �crit chaque contour avec ses trous
	no_poly=0;
    for(j=0;j<ntab_no_point;j++)
		{ if(tabB[j] > 0) no_poly++; // on compte les contours dans l'ordre ; ici un TROU
		  if(tabB[j]==-2 )  // ici 
			{ // un d�but de contour support
			  no_poly++;
			  // cherche combien de trous (d�but de circuit =no_poly)
			  nb_trou=0;
			  for(k=0;k<ntab_no_point;k++)
				{ // compte les d�buts de circuit avec statut=no du contour support
				  if(tabB[k]==no_poly )nb_trou++;
				}
			  // cherche combien de points dans le contour support (d�but de circuit =no_poly)
			  nbpoin=nombre_de_points_du_contour(j,tabB);
			  //printf(" ecrit CONTOUR SUPPORT : indice debut %d, nbpoin %d, nb_trou %d\n",j,nbpoin,nb_trou);

			  // �crit en-t�te contour support
		 	  fprintf(fp,"c%d \n%d\n",nb_trou,nbpoin);
			  // �crit les points du contour support
              for(k=0;k<nbpoin;k++)
				{ ind= tabA[j+k]-1; 
				  fprintf(fp,"%10.3f %10.3f %10.3f\n",tabx[ind],taby[ind],tabz[ind]);
				}

			  // �crit chaque trou du contour support
			  for(i=0;i<ntab_no_point;i++)
				{ // un trou: d�but avec statut=no du contour support
				  if(tabB[i]==no_poly )
				  { nbpoin=nombre_de_points_du_contour(i,tabB);
				    // �crit en-t�te contour trou
		 			fprintf(fp,"t \n%d\n",nbpoin);
			        // �crit les points du contour support
                   for(k=0;k<nbpoin;k++)
				   {  ind= tabA[i+k]-1;
					  fprintf(fp,"%10.3f %10.3f %10.3f\n",tabx[ind],taby[ind],tabz[ind]);
					}
				  }
				} 
			}// Fin d'�criture d'un contour avec ses trous
		  }// FIN d'�criture de la face

}

/*_________________________________________________________________*/
int nombre_de_points_du_contour(i,tabB)
int i;
int *tabB;
{ 	
	int k,nbpoin;   

	nbpoin=0;
	k=i;				// i indice du 1er point du circuit (d�but du circuit)
	while(tabB[k]!=-1)  // test jusqu'� fin de circuit (-1)
		{ nbpoin++;
		  k++;
		}
	return(nbpoin+1);
}
/*_________________________________________________________________*/
void format_entree()
{
  printf("\n    Unit les contours des faces d'une g�om�trie \n\n") ;
  printf("\n    union_contour_face_tr  \n");
  printf("\n         a comme param�tres\n");

  printf("IN    fichier_in(.cir) fichier_out(.cir)  \n");
  printf("OUT   fichier_in(.cir) fichier_out(.cir)  \n\n");
  printf("NOTA   s'applique particuli�rement aux faces triangul�es, avec contours mitoyens et sans superposition de contours  \n");
  printf("NOTA   et contenant des trous  \n");
 exit(0);
}
/*_________________________________________________________________*/


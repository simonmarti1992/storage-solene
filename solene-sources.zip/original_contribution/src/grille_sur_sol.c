/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

// grille_sur_sol.c



// D. GROLEAU (janvier 2004)


// construit un sol grille � partir d'un sol constitu�
// avec son socle � cote zinf donn�e


#include<solene.h>


// DECLARATIONS FUNCTIONS

void	calcul_normale();
double	chercheZ();
int	    ecrit_en_tete();
int     point_dans_face_modif();
int		point_dans_fenetre();
void	pointXY();
double	pointZ();
void	format_entree();

// DECLARATION GLOBAL
	// info Grille
int nl,nc ;
double xor,yor,dx,dy ;
int nb_pb;

/*_________________________________________________________________*/
main(argc,argv)
int argc;char **argv;
{

 char 	buf[512],*s_dir;
 double englob[10];
 int	i,j,nbff,nomax,n,nof;

 FILE *fp;

 struct modelisation_face *ff;
 double xp ,yp,*zp ;
 double x1,y1,z1,x2,y2,z2,x3,y3,z3,x4,y4,z4;
 double x[3],y[3],z[3];
 double nx,ny,nz;
 double zinf;

 printf("\nFonction Solene : grille_sur_sol\n\n");

 if(argc !=10)format_entree();

	s_dir=(char *)getenv("PWD");

 nb_pb=0;

sscanf(argv[1],"%d",&nl);
sscanf(argv[2],"%d",&nc);


sscanf(argv[3],"%lf",&xor);
sscanf(argv[4],"%lf",&yor);
sscanf(argv[5],"%lf",&dx);
sscanf(argv[6],"%lf",&dy);


 
printf("\n Grille : %d lignes,  %d colonnes\n",nl,nc);
printf(" Origine : %f,  %f\n",xor,yor);
printf(" Maille : dx =  %f,  dy= %f\n",dx,dy);


// ouvre le fichier de sol existant
  compose_nom_complet(buf,s_dir,argv[7],"cir");
  if((fp=fopen(buf,"r"))==NULL)
        { printf("\n impossible ouvrir %s\n",buf);
          exit(0);
		}
   lit_en_tete(fp,&nbff,&nomax,englob);
   ff=alloue_face(nbff,35);
   lit_fic_cir3d(fp,nbff,ff);
   fclose(fp);
   printf("\nFichier de sol :  %s (%d faces)\n",buf,nbff);

// reconstitue le sol grille avec le socle, � cote zinf
	sscanf(argv[8],"%lf",&zinf);

// stocke le fichier Grille.txt : x y z ligne par ligne */

   compose_nom_complet(buf,s_dir,argv[9],"txt");
   printf("Fichier Grille x,y,z  � cr�er : %s \n",buf);

   fp=fopen(buf,"w");
    if(fp==NULL) 
	{ printf("impossible creer %s\n",buf);
	  exit(0);
	}

  // evalue le Z sur les points de la grille, ligne par ligne du bas vers le haut

    zp= alloue_double((nl+1)*(nc+1),12);
    n=0 ; 
    for(i=0;i<=nl;i++) 
    { for (j=0 ;j<=nc ;j++)
		{ pointXY(i,j,&xp,&yp) ;
		  zp [n] = chercheZ(ff,nbff,xp,yp);
		  if(zp [n] == -9999999.99) zp [n] = zinf+1;
		  fprintf(fp," %f %f %f\n",xp,yp,zp[n]);
		  n++ ;
		}
	}
	fclose(fp);
	desalloue_fface(ff,nbff);


// stocke le fichier SOLENE.CIR 

   compose_nom_complet(buf,s_dir,argv[9],"cir");
   printf("Fichier Grille sol � cr�er : %s \n",buf);
   printf(" avec son socle � la cote  %f \n",zinf);

   fp=fopen(buf,"w");
    if(fp==NULL) 
	{ printf("impossible creer %s\n",buf);
	  exit(0);
	}

    // nb de faces � cr�er
	nbff= (nl)*(nc)*2 +1 +4;  // avec face dessous et 4 face verticales

    ecrit_en_tete(fp,nbff,nbff,englob);
	n=0 ; 
	nof=0 ;
    for(i=0;i<nl;i++) 
    { for (j=0 ;j<nc ;j++)
		{ // traite une maille de 4 points
		  pointXY(i,j,&x1,&y1) ;
		  pointXY(i,j+1,&x2,&y2) ;
		  pointXY(i+1,j,&x3,&y3) ;
		  pointXY(i+1,j+1,&x4,&y4) ;
		  z1= pointZ(i,j,zp) ;
		  z2= pointZ(i,j+1,zp) ;
		  z3= pointZ(i+1,j,zp) ;
		  z4= pointZ(i+1,j+1,zp) ;

		  // constitue face triangle 1,2,3
		  x[0]= x1; y[0]= y1; z[0]= z1;
		  x[1]= x2; y[1]= y2; z[1]= z2;
		  x[2]= x3; y[2]= y3; z[2]= z3;
		 calcul_normale(x,y,z,&nx,&ny,&nz);
		 nof++;
		 fprintf(fp,"f%d 1\n",nof) ;
		 fprintf(fp,"%f %f %f\n",nx,ny,nz) ;
		 fprintf(fp,"c0\n") ;
		 fprintf(fp,"4\n") ;

		 fprintf(fp,"%f %f %f\n",x1,y1,z1) ;
		 fprintf(fp,"%f %f %f\n",x2,y2,z2) ;
		 fprintf(fp,"%f %f %f\n",x3,y3,z3) ;
		 fprintf(fp,"%f %f %f\n",x1,y1,z1) ;

		 n++ ;

		  // constitue face triangle 2,4,3
		  x[0]= x2; y[0]= y2; z[0]= z2;
		  x[1]= x4; y[1]= y4; z[1]= z4;
		  x[2]= x3; y[2]= y3; z[2]= z3;
		 calcul_normale(x,y,z,&nx,&ny,&nz);
		 nof++;
		 fprintf(fp,"f%d 1\n",nof) ;
		 fprintf(fp,"%f %f %f\n",nx,ny,nz) ;
		 fprintf(fp,"c0\n") ;
		 fprintf(fp,"4\n") ;

		 fprintf(fp,"%f %f %f\n",x2,y2,z2) ;
		 fprintf(fp,"%f %f %f\n",x4,y4,z4) ;
		 fprintf(fp,"%f %f %f\n",x3,y3,z3) ;
		 fprintf(fp,"%f %f %f\n",x2,y2,z2) ;
		 n++ ;

	 }
	}

	// ajoute la face de dessous couvrant l'ensemble de la grille, � cote zinf

		  pointXY(0,0,&x1,&y1) ;
		  pointXY(0,nc,&x2,&y2) ;
		  pointXY(nl,nc,&x3,&y3) ;
		  pointXY(nl,0,&x4,&y4) ;

		 nof++;
		 fprintf(fp,"f%d 1\n",nof) ;
		 fprintf(fp,"0 0 -1\n") ;
		 fprintf(fp,"c0\n") ;
		 fprintf(fp,"5\n") ;

		 fprintf(fp,"%f %f %f\n",x1,y1,zinf) ;
		 fprintf(fp,"%f %f %f\n",x2,y2,zinf) ;
		 fprintf(fp,"%f %f %f\n",x3,y3,zinf) ;
		 fprintf(fp,"%f %f %f\n",x4,y4,zinf) ;
		 fprintf(fp,"%f %f %f\n",x1,y1,zinf) ;

	// ajoute la face verticale sur ligne 0
		 nof++;
		 fprintf(fp,"f%d 1\n",nof);
		 fprintf(fp,"0 -1 0\n");
		 fprintf(fp,"c0\n");
		 fprintf(fp,"%d\n",nc+1+3);
		 for(i=0;i<=nc;i++)
		 { pointXY(0,i,&x1,&y1);
		   z1= pointZ(0,i,zp) ;
		   fprintf(fp,"%f %f %f\n",x1,y1,z1) ;
		 }
		 fprintf(fp,"%f %f %f\n",x1,y1,zinf) ;
		 pointXY(0,0,&x1,&y1);
		 z1= pointZ(0,0,zp) ;
		 fprintf(fp,"%f %f %f\n",x1,y1,zinf) ;
		 fprintf(fp,"%f %f %f\n",x1,y1,z1) ;

	// ajoute la face verticale sur ligne nl
		 nof++;
		 fprintf(fp,"f%d 1\n",nof);
		 fprintf(fp,"0 1 0\n");
		 fprintf(fp,"c0\n");
		 fprintf(fp,"%d\n",nc+1+3);
		 for(i=0;i<=nc;i++)
		 { pointXY(nl,i,&x1,&y1);
		   z1= pointZ(nl,i,zp) ;
		   fprintf(fp,"%f %f %f\n",x1,y1,z1) ;
		 }
		 fprintf(fp,"%f %f %f\n",x1,y1,zinf) ;
		 pointXY(nl,0,&x1,&y1);
		 z1= pointZ(nl,0,zp) ;
		 fprintf(fp,"%f %f %f\n",x1,y1,zinf) ;
		 fprintf(fp,"%f %f %f\n",x1,y1,z1) ;

	// ajoute la face verticale sur colonne 0
		 nof++;
		 fprintf(fp,"f%d 1\n",nof);
		 fprintf(fp,"-1 0 0\n");
		 fprintf(fp,"c0\n");
		 fprintf(fp,"%d\n",nl+1+3);
		 for(i=0;i<=nl;i++)
		 { pointXY(i,0,&x1,&y1);
		   z1= pointZ(i,0,zp) ;
		   fprintf(fp,"%f %f %f\n",x1,y1,z1) ;
		 }
		 fprintf(fp,"%f %f %f\n",x1,y1,zinf) ;
		 pointXY(0,0,&x1,&y1);
		 z1= pointZ(0,0,zp) ;
		 fprintf(fp,"%f %f %f\n",x1,y1,zinf) ;
		 fprintf(fp,"%f %f %f\n",x1,y1,z1) ;

	// ajoute la face verticale sur colonne nc
		 nof++;
		 fprintf(fp,"f%d 1\n",nof);
		 fprintf(fp,"1 0 0\n");
		 fprintf(fp,"c0\n");
		 fprintf(fp,"%d\n",nl+1+3);
		 for(i=0;i<=nl;i++)
		 { pointXY(i,nc,&x1,&y1);
		   z1= pointZ(i,nc,zp) ;
		   fprintf(fp,"%f %f %f\n",x1,y1,z1) ;
		 }
		 fprintf(fp,"%f %f %f\n",x1,y1,zinf) ;
		 pointXY(0,nc,&x1,&y1);
		 z1= pointZ(0,nc,zp) ;
		 fprintf(fp,"%f %f %f\n",x1,y1,zinf) ;
		 fprintf(fp,"%f %f %f\n",x1,y1,z1) ;

   fclose(fp);
   desalloue_double(zp) ;

   printf("nb de faces cr��es : %d\n",nof);
   printf("nb de NON_correspondances : %d\n",nb_pb);


   printf("\nFin du traitement grille_sur_sol\n");
   creer_OK_Solene();
}

/*____________________________________________________________________*/
void pointXY(i,j,xp,yp)
int i,j;
double *xp,*yp ;
{
 *yp=(i)*dy+yor;  
 *xp=(j)*dx+xor;
 //printf("xp,yp %f %f \n",*xp,*yp);

}
 
/*____________________________________________________________________*/
double pointZ(i,j,z)
double *z;
int i,j;
{
 int n ;
 n= i*(nc+1)+j;
 return (z[n]);
}

/*_________________________________________________________________*/
double chercheZ(fac1,nbff,xp,yp)
struct modelisation_face *fac1;
int nbff;
double xp,yp;
{
 int i,in;
 struct contour *pcont;
 struct circuit *pcir;

	for(i=0;i<nbff;i++)
	{
	  in= point_dans_face_modif(xp,yp,fac1+i,1);
      if(in)
		{ // le point vis� est dans la face
		  // calcul d du plan
		  calcul_d_du_plan(fac1+i,1);
		  pcont = (fac1+i)->debut_projete;
		  pcir = pcont->debut_support;
		  pcir->vnorm[3]= (fac1+i)->vnorm[3];
		  //printf("normale face %f %f %f %f\n",pcir->vnorm[0],pcir->vnorm[1],pcir->vnorm[2],pcir->vnorm[3]);
		  //liste_face((fac1+ij),0);
		  return(calcul_zplan(pcir,xp,yp));
		}
    }

	printf("pb : n'a pas trouv� de z : met cote socle + 1\n");
	nb_pb++;
	return(-9999999.99);

}

/*________________________________________________________________________*/
int point_dans_face_modif(xp,yp,face,projete)
double xp,yp;
struct modelisation_face *face;
int projete;
{             /* si pt interieur a face : return(1) */
              /* cherche pour chaque contour de la face */
              /* avec verification si trou */
 int idedan,isur;
 struct contour *pcont;
 struct circuit *pcir;

   if(projete)pcont=face->debut_projete; else pcont=face->debut_dessin;
   if((point_dans_fenetre(xp,yp,face->fen))==0) return(0);
   while(pcont)	   
       { pcir=pcont->debut_support; 
                 /* test pt / fenetre circuit */
         if(point_dans_fenetre(xp,yp,pcir->fen))
            { inpoly(&idedan,&isur,xp,yp,pcir);
              if(isur==1) return(1); // MODIFICATION aulieu de 0
              if(idedan)
                 {         /* test si point ds trou ; si oui idedan=0 */
	           pcir=pcont->debut_interieur;
                   while(pcir)    
	              {    /* test pt / fenetre circuit */
                        if(point_dans_fenetre(xp,yp,pcir->fen))
                          { inpoly(&idedan,&isur,xp,yp,pcir);
                            if(idedan || isur) return(0);
                          }
	                pcir=pcir->suc;
	              }
                   return(1);
                 }
            }
         pcont=pcont->suc; 
       } 
  return(0);
}
/*________________________________________________________________________*/
void calcul_normale(x,y,z,xnn,ynn,znn)
double *x,*y,*z;
double *xnn,*ynn,*znn;
{
 double x1,y1,z1,x2,y2,z2,norm;
 int i,j,k;

// calcul la normale sur les 3 points 
	i=0; j=1; k=2;
    x1=x[j]-x[i]; y1=y[j]-y[i]; z1=z[j]-z[i];
    x2=x[k]-x[j]; y2=y[k]-y[j]; z2=z[k]-z[j];
    *xnn=y1*z2-y2*z1;
    *ynn=-x1*z2+x2*z1;
    *znn=x1*y2-x2*y1;

    norm=sqrt(*xnn*(*xnn)+*ynn*(*ynn)+*znn*(*znn));
    if(norm)
     {
      *xnn=*xnn/norm; *ynn=*ynn/norm; *znn=*znn/norm;
	  if(*znn<0)
	  { *xnn=-*xnn;
		*ynn=-*ynn;
		*znn=-*znn;
	  }
     }
}

/*_________________________________________________________________*/
void format_entree()
{

  printf("\n    grille_sur_sol nl nc xor yor dx dy fichier_sol_in(.cir)  zinf_socle fichier_grille_out(.cir et .txt) \n\n");
  printf("Construit un sol grille (triangul�) � partir d'un sol d�j� constitu�, avec son socle\n");
  printf("Peut s'appliquer � une g�om�trie 3D (attention aux faces superpos�es, le z est calcul� sur la premi�re face rencontr�e)\n");

printf("\nIN	nl			// nb de lignes de la grille\n");
printf("IN	nc 			// nb de colonnes de la grille\n");
printf("IN	xor 			// x origine de la grille\n");
printf("IN	yor 			// y origine de la grille\n");
printf("IN	dx 			// dimension x de la maille de la grille\n");
printf("IN	dy 			// dimension y de la maille de la grille\n");
printf("IN	fichier_sol_in(.cir) 	//  fichier de sol d�j� constitu� (ou une g�om�trie 3D)\n");
printf("IN	zinf_socle\n");
printf("OUT	fichier_grille_out(.cir et .txt)	//  fichier de sol Solene � constituer sur la grille\n");
printf("                                                //  fichier grille x,y,z ligne par ligne\n");

printf("NOTA: si pas de correspondance x,y avec le sol, alors met la cote Zinf_socle+1\n");

  exit(0);
}



/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/* toit_sur_sol_a_0.c	*/
/*______________________________________________________________________*/

// D. GROLEAU (fevrier 2004)

/*
Prend chaque face de toit � sa vraie cote z
	La projette sur le sol
	Calcule le z moyen de la zone de sol recouverte
	Translate de cette valeur le Z du toit
	et stoke
Les volumes peuvent ensuite par volume_fic_zfix etre reconstruit sur un sol horizontal 

Seul les toits qui recouvrent le sol sont pris en compte, sinon ils sont seulement comptabilis�s comme pb
*/


#include <solene.h>

// declare Fonctions
void construit_facade();
int  ecrit_en_tete();
void format_entree();
void normale_vert();
void probleme();
int test_meme_point();
double zmoyen_de_geom();

// declare Global

struct modelisation_face *facsol ;	/* geometrie du sol */
struct modelisation_face *factoit;	/* geometrie des toits */

#define EPSI 0.0001

int pb;


/*_________________________________________________________________*/
main(argc,argv)           /* BATI_SUR_SOL */
int argc;char **argv;
{
	int i,j,nbfac_toit,noc,nofac, nb;

 	char nom_sol[256],nom_toit[256],nom_facade[256];
	char *s_dir, buf[256];

 	FILE *pfic,*pficr, *pficx;
	double englob[10];

	struct contour *pcont;
	struct circuit *pcir;
	double zmoyen;

	s_dir=(char *)getenv("PWD");

   	if(argc!=4) format_entree();

	printf("Fonction: toit_sur_sol_a_0\n");

	pb=0;

// test si fichier du sol existe
	compose_nom_complet(nom_sol,s_dir,argv[1],"cir");
    printf("\n  fichier du sol : %s \n", nom_sol);
	if ((pfic=fopen(nom_sol,"r"))==NULL)
      { 
		printf("\n  impossible ouvrir %s\n\n", nom_sol); 
		exit(0);
      }
	fclose(pfic);

// lecture fichier des toits 
	compose_nom_complet(nom_toit,s_dir,argv[2],"cir");
    printf("\n  fichier des toits : %s \n", nom_toit);

	if ((pfic=fopen(nom_toit,"r"))==NULL)
      { 
		printf("\n  impossible ouvrir %s\n\n", nom_toit); 
		exit(0);
      }
    lit_en_tete(pfic,&nbfac_toit, &nomax, englob);
	printf("  nb de faces toit %d\n",nbfac_toit);
    factoit=alloue_face(nbfac_toit, 1000);
    lit_fic_cir3d(pfic, nbfac_toit, factoit);
	fclose(pfic);

// open fichier r�sultat des toits
	compose_nom_complet(nom_facade,s_dir,argv[3],"cir");
    printf("\n  fichier des toits � cr�er : %s \n", nom_facade);
	if ((pficr=fopen(nom_facade,"w"))==NULL)
      { 
		printf("\n  impossible ouvrir %s\n\n", nom_facade); 
		exit(0);
      }
    // ecrit en tete
	ecrit_en_tete(pficr,nbfac_toit, nomax, englob);

// Applique le traitement � chaque contour de toit
	nb=0; nomax=0;

	nofac=0;
	for(i=0;i<nbfac_toit;i++)
	{
	 printf("traite face %d\n", (factoit+i)->nofac_fichier);
	 pcont=(factoit+i)->debut_projete;
	 noc=1;
	 while(pcont)	   
       { pcir=pcont->debut_support;
	 
		 // Ecrit le contour dans fichier de face temporaire XTOIT
	 	 printf("     contour %d\n", noc);
		 pficx=fopen("XTOIT.cir","w");
		 ecrit_en_tete(pficx,1, 1, englob);
		 fprintf(pficx,"f%d 1\n",(factoit+i)->nofac_fichier);
		 fprintf(pficx,"%f %f %f\n",(factoit+i)->vnorm[0],(factoit+i)->vnorm[1],(factoit+i)->vnorm[2]);
		 fprintf(pficx,"c0\n%d\n",pcir->nbp);
         for(j=0;j<pcir->nbp;j++)
		 { fprintf(pficx,"%f %f %f\n",pcir->x[j],pcir->y[j],pcir->z[j]);
		 }
		 fclose(pficx);

		 // ignore les trous

		 // Retient le sol recouvert par le contour toit: fenetre_fic
		 sprintf(buf,"fenetre_fic %s XTOIT XSOL",argv[1]);
		 //printf("      commande : %s\n",buf);
		 system(buf);

		 // Calcule le z moyen du sol XSOL
		 zmoyen=zmoyen_de_geom("XSOL");

		 if(zmoyen!=-999.999)
		 {
			// Translate le toit de z moyen
			 for(j=0;j<pcir->nbp;j++)
			 { pcir->z[j]= pcir->z[j] - zmoyen;
			 }
		 }

		sprintf(buf,"del XTOIT.cir");
		system(buf);

		sprintf(buf,"del XSOL.cir");
		system(buf);

		 // Contour suivant
         pcont=pcont->suc;
		 noc++;
       } 
		 if(zmoyen!=-999.999)
		 {	    output_face_sur_fichier(factoit+i,1,1,0,pficr,&nb,&nomax);
		 }

	}

// FIN du TRAITEMENT  
//   output_face_sur_fichier(factoit,nbfac_toit,1,0,pficr,&nb,&nomax);
   rewind(pficr);
    // re_ecrit en tete
	ecrit_en_tete(pficr,nb, nomax, englob);

   fclose(pficr);

    desalloue_fface(factoit,nbfac_toit);

	creer_OK_Solene();


	printf("\n\nNB de Pb : %d\n",pb);
	printf("\n\nFin de toit_sur_sol_a_0\n");
	exit(0);
}

//_______________________________________________
double zmoyen_de_geom(nom)
char *nom;
{

struct modelisation_face *ff ;	
struct contour *pcont;
struct circuit *pcir;
int i,nbf,nbcont;
double englob[10];
FILE *pfic;
double zmoyen,zmoyenP,surf,surface_cont;
double xg,yg,zg;
char nom_geom[256];


	compose_nom_complet(nom_geom,"",nom,"cir");

	if ((pfic=fopen(nom_geom,"r"))==NULL)
      { 
		printf("\n  impossible ouvrir %s\n\n", nom); 
		exit(0);
      }
    lit_en_tete(pfic,&nbf, &i, englob);
	printf("  nb de faces toit %d\n",nbf);
    ff=alloue_face(nbf, 1000);
    lit_fic_cir3d(pfic, nbf, ff);
	fclose(pfic);

	zmoyen=0;
	zmoyenP=0;
	nbcont=0;
	surf=0;
	for(i=0;i<nbf;i++)
	{
	 pcont=(ff+i)->debut_projete;
	 while(pcont)	   
     { pcir=pcont->debut_support;
       centre_de_gravite(pcir,&xg,&yg,&zg);
	   surface_cont=fabs(surface(pcir->nbp,pcir->x,pcir->y));
	   zmoyen+=zg;
	   zmoyenP+=zg*surface_cont;
	   nbcont++;
	   surf+=surface_cont;
	   //printf("z %10.2f surf %10.2f\n",zg,surface_cont);

	   pcont=pcont->suc;
	 }
	}
//printf("zmoyen %10.2f zmoyenP %10.2f\n",zmoyen/nbcont,zmoyenP/surf);
//printf("\n");
	desalloue_fface(ff,nbf);
	// on retourne la valeur pond�r�e par la surface (en 2d)
	if(nbf==0)
	{ printf("pb Xsol\n");
	  pb++;
	  return(-999.999);
	}

	return(zmoyenP/surf);
}



/*_________________________________________________________________*/
/* Format de la fonction  */
void format_entree()
{
 printf(" toit_sur_sol_a_0   geom_sol_in(.cir)  geom_toit_in(.cir)  geom_toit_out(.cir) \n\n");
 printf("\n la fonction a comme parametres en ENTREE :\n");
 printf("\t geometrie_sol_in(.cir)\n"); 
 printf("\t geometrie_toit_in(.cir)\n");  
 printf("\n              comme parametres en SORTIE :\n");
 printf("\t geom_toit_out(.cir) \n\n"); 
 exit(0);
}



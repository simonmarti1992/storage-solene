/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/* 
cc -o sel_cir_fen  sel_cir_fen.c solutile.o geomutile.o lib_solene_94.o -lm
*/


/*retient la face avec les contours contenu ds fen rectangulaire  */
#include<solene.h>



/*_______________________________________*/
/*declaration application */

struct fenet {    double xmin;
				  double ymin;
				  double zmin;
				  double xmax;
				  double ymax;
				  double zmax;
               };

FILE *fpcir1,*fpval1,*fpcir2,*fpval2;

int nbfac1,nomax1;
int nbfac2,nomax2;
double englob[10],xmin,ymin,zmin,xmax,ymax,zmax;

int	op;
float 	valeur,val_min,val_max;

struct modelisation_face *fac1;
struct fenet fen1,fen2;

/************************************************/
main(argc,argv)
int argc;char **argv;
{
 char buf[512],*s_dir;


  if(argc!=9){ format_entree(); exit(0);}


	s_dir=(char *)getenv("PWD");


 compose_nom_complet(buf,s_dir,argv[1],"cir");
  if((fpcir1=fopen(buf,"r"))==NULL)
	{ printf("impossible ouvrir %s\n",buf);
	  exit(0);
	}
	
 compose_nom_complet(buf,s_dir,argv[2],"cir");
  if((fpcir2=fopen(buf,"w"))==NULL)
	{ printf("impossible ouvrir %s\n",buf);
	  exit(0);
	}
	
  sscanf(argv[3],"%lf",&xmin);
  sscanf(argv[4],"%lf",&ymin);
  sscanf(argv[5],"%lf",&zmin);
  sscanf(argv[6],"%lf",&xmax);
  sscanf(argv[7],"%lf",&ymax);
  sscanf(argv[8],"%lf",&zmax);

 fen1.xmin=xmin;
 fen1.ymin=ymin;
 fen1.zmin=zmin;
 fen1.xmax=xmax;
 fen1.ymax=ymax;
 fen1.zmax=zmax;

   lit_en_tete(fpcir1,&nbfac1,&nomax1,englob);

   printf("\n lecture des %d faces\n",nbfac1);
   fac1=alloue_face(nbfac1,1000);
   lit_fic_cir3d(fpcir1,nbfac1,fac1); 
   fclose(fpcir1);

   ecrit_en_tete(fpcir2,nbfac1,nomax1,englob);

   nb_etat=0;      /* nb de valeurs entieres allouees par contour */

   nbfac2=0; nomax2=0;

	printf(" execution en cours ...\n");

  traite_sel_cir_fen();


  rewind(fpcir2);
/*
  englob[2]=xmin; englob[3]=ymin;
  englob[4]=xmax; englob[5]=ymin;
  englob[6]=xmax; englob[7]=ymax;
  englob[8]=xmin; englob[9]=ymax;
*/
  ecrit_en_tete(fpcir2,nbfac2,nomax2,englob);

  printf(" %d faces retenues\n",nbfac2);

 creer_OK_Solene();

}
/*------------------------------------------------------------*/
int format_entree()
{
  printf("\n   *sel_cir_fen*  fichier_in(.cir)  fichier_out(.cir) xmin ymin zmin xmax ymax zmax\n\n");

}

/*------------------------------------------------------------*/
int traite_sel_cir_fen()
{
 int 	i;

	for(i=0;i<nbfac1;i++)
	 {
 
printf("face %d\n",i);

/*printf("%f %f %f\n",(fac1+i)->fen[0],(fac1+i)->fen[1],(fac1+i)->fen[2]);
  printf("%f %f %f\n",(fac1+i)->fen[3],(fac1+i)->fen[4],(fac1+i)->fen[5]);
*/

           fen2.xmin=(fac1+i)->fen[0];
           fen2.ymin=(fac1+i)->fen[1];
           fen2.zmin=(fac1+i)->fen[2];
           fen2.xmax=(fac1+i)->fen[3];
           fen2.ymax=(fac1+i)->fen[4];
           fen2.zmax=(fac1+i)->fen[5];

	    if(fen1_contient_fen2(&fen1,&fen2)==1) /* si les fenetres se coupent */
             {
              output_face_sur_fichier(fac1+i,1,1,0,fpcir2,&nbfac2,&nomax2);
             }
	}
}

/*____________________________________________________________________*/
/*  retour = 0  fen1 ne contient pas totalement fn2		      */
/*  retour = 1  fen1	contient pas totalement fn2		      */
/*____________________________________________________________________*/
int fen1_contient_fen2(fen1,fen2)
struct fenet *fen1,*fen2;
{

   /*printf("\n recoup %lf %lf %lf %lf %lf %lf",fen1->xmin,fen1->ymin,fen1->zmin,fen2->xmin,fen2->ymin,fen2->zmin);
   printf("\n        %lf %lf %lf %lf %lf %lf",fen1->xmax,fen1->ymax,fen1->zmax,fen2->xmax,fen2->ymax,fen2->zmax);
   */

if(fen2->xmin < fen1->xmin) return(0);
if(fen2->xmax > fen1->xmax) return(0);
if(fen2->ymin < fen1->ymin) return(0);
if(fen2->ymax > fen1->ymax) return(0);
if(fen2->zmin < fen1->zmin) return(0);
if(fen2->zmax > fen1->zmax) return(0);
return(1);

}

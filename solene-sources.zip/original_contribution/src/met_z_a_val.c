/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/*

met_z_a_valeur

D. GROLEAU  d�cembre 2003
D. GROLEAU  janvier 2004  (� partir d'un fichier de valeurs)

Impose le Z d'un fichier .cir � partir d'un fichier de valeurs



solutile.o geomutile.o lib_solene_94.o

*/

#include<solene.h>

// DECLARATIONS FUNCTIONS

int ecrit_en_tete();
void format_entree();
void trans_face();


/*_________________________________________________________________*/
main(argc,argv)
 int argc;char **argv;
{
 char 	buf[512],*s_dir;
 double englob[10];
 int  nb, nbff, nomax;
 FILE *fp;
 struct modelisation_face *ff;
 double *cotez;
 int i;
 float minv,maxv;

 printf("Fonction Solene : met_z_a_val\n\n");

 if(argc<4)format_entree();

	s_dir=(char *)getenv("PWD");

    // lit Fichier Geometrie
  compose_nom_complet(buf,s_dir,argv[1],"cir");
  if((fp=fopen(buf,"r"))==NULL)
        { printf("\n impossible ouvrir %s\n",buf); exit(0);}
   lit_en_tete(fp,&nbff,&nomax,englob);
   ff=alloue_face(nbff,35);
   lit_fic_cir3d(fp,nbff,ff);
   fclose(fp);
        

	// calcule le nombre de contour de la geometrie
	nbc = nbcontours_total(ff, nbff);

    printf("\n geometrie_IN %s (%d faces et %d contours)\n",buf,nbff,nbc);

    // LIT les valeurs de Z � imposer
    compose_nom_complet(buf,s_dir,argv[2],"val");
	if((fp=fopen(buf,"r"))==NULL)
	{ printf("impossible ouvrir %s\n",buf);
	  exit(0);
	}
    printf(" ValeurZ � imposer : %s\n",buf);

	//lit seulement  pour val min et max  */	
    fscanf(fp,"%d %d %f %f\n",&i,&i,&minv,&maxv);
    rewind(fp);
	

    // Allocation du tableau des valeurs associ�es aux contours*/
	cotez = alloue_double(nbc,456);
	lect_fic_val(fp, cotez);
	fclose(fp);
/*
	for(nb=0;nb<nbc;nb++)
	{ printf("%f\n",cotez[nb]);
	}
*/

  /* applique la valeur Z */ 
  
	    trans_face(nbff,cotez,ff,1);
    

/* stocke le fichier */

   compose_nom_complet(buf,s_dir,argv[3],"cir");
   fp=fopen(buf,"w");
    if(fp==NULL) 
	{ printf("impossible creer %s\n",buf);
	  exit(0);
	}
	   printf(" geometrie_OUT %s\n",buf);

   ecrit_en_tete(fp,nbff,nomax,englob);
   output_face_sur_fichier(ff,nbff,1,0,fp,&nb,&nomax);
   fclose(fp);
   printf("\nFin du traitement met_z_a_val\n");
  		creer_OK_Solene();

	desalloue_fface(ff,nbff);
}

/*_________________________________________________________________*/
/*____________________________________________________________________*/
void trans_face(nbff,valeurz,face,projete)
struct modelisation_face *face;
int nbff;
int projete;
double *valeurz;
{int i,j;
 struct contour *pcont;
 struct circuit *pcir;

 int noc;

 noc=0;
  for(j=0;j<nbff;j++) 
  {
	  
   if(projete)pcont=(face+j)->debut_projete; else pcont=(face+j)->debut_dessin;
   
      while(pcont)	   
       { pcir=pcont->debut_support; 
         for(i=0;i<pcir->nbp;i++)
		 { pcir->z[i] = valeurz[noc];

		 }

	     pcir=pcont->debut_interieur;
         while(pcir)
			{for(i=0;i<pcir->nbp;i++)
				{ pcir->z[i] = valeurz[noc];
				}
			 pcir=pcir->suc;
			}
         pcont=pcont->suc; 
		 noc++;
       } 
  }
}


/*_________________________________________________________________*/
void format_entree()
{
  printf("\n    met_z_a_val  fichier_in(.cir) fichier_valeurZ(.val) fichier_out(.cir)\n\n");
  exit(0);
}

/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */
 
/* bati_sur_sol.c	*/
/*______________________________________________________________________*/

// D. GROLEAU (2003)
// D. GROLEAU  janvier 2004 (produit aussi le mapping des objets projet�s sur le sol)
/*
Construit les faces verticales de prismes 3D 
� partir du plan de toiture (ou de contours quelconques)
et du sol;
Les contours projet�s sur le sol sont stock�s en dur dans le fichier MAPPING.cir
*/


#include <solene.h>

// declare Fonctions
void construit_facade();
int  ecrit_en_tete();
void format_entree();
void normale_vert();
void probleme();
int test_meme_point();

// declare Global

struct modelisation_face *facsol ;	/* geometrie du sol */
struct modelisation_face *factoit;	/* geometrie des toits */

#define EPSI 0.0001


/*_________________________________________________________________*/
main(argc,argv)           /* BATI_SUR_SOL */
int argc;char **argv;
{
	int i,j,nbfac_toit,noc,nofac, premiere_fois,premiere_fois1;

 	char nom_sol[256],nom_toit[256],nom_facade[256];
	char *s_dir, buf[256];

 	FILE *pfic,*pficr, *pficx;
	double englob[10];

	struct contour *pcont;
	struct circuit *pcir;

	s_dir=(char *)getenv("PWD");

   	if(argc!=4) format_entree();

	printf("Fonction: bati_sur_sol\n");

	premiere_fois=0;
	premiere_fois1=0;

// test si fichier du sol existe
	compose_nom_complet(nom_sol,s_dir,argv[1],"cir");
    printf("\n  fichier du sol : %s \n", nom_sol);
	if ((pfic=fopen(nom_sol,"r"))==NULL)
      { 
		printf("\n  impossible ouvrir %s\n\n", nom_sol); 
		exit(0);
      }
	fclose(pfic);

// lecture fichier des toits 
	compose_nom_complet(nom_toit,s_dir,argv[2],"cir");
    printf("\n  fichier des toits : %s \n", nom_toit);

	if ((pfic=fopen(nom_toit,"r"))==NULL)
      { 
		printf("\n  impossible ouvrir %s\n\n", nom_toit); 
		exit(0);
      }
    lit_en_tete(pfic,&nbfac_toit, &i, englob);
	printf("  nb de faces toit %d\n",nbfac_toit);
    factoit=alloue_face(nbfac_toit, 1000);
    lit_fic_cir3d(pfic, nbfac_toit, factoit);
	fclose(pfic);

// open fichier r�sultat des facades
	compose_nom_complet(nom_facade,s_dir,argv[3],"cir");
    printf("\n  fichier des facades � cr�er : %s \n", nom_facade);
	if ((pficr=fopen(nom_facade,"w"))==NULL)
      { 
		printf("\n  impossible ouvrir %s\n\n", nom_facade); 
		exit(0);
      }
    // ecrit en tete
	ecrit_en_tete(pficr,nbfac_toit, nbfac_toit, englob);

// Applique le traitement � chaque contour de toit
	nofac=0;
	for(i=0;i<nbfac_toit;i++)
	{
	 printf("traite face %d\n", (factoit+i)->nofac_fichier);
	 pcont=(factoit+i)->debut_projete;
	 noc=1;
	 while(pcont)	   
       { pcir=pcont->debut_support;
	 
		 // Ecrit le contour dans fichier de face temporaire XTOIT
	 	 printf("     contour %d\n", noc);
		 pficx=fopen("XTOIT.cir","w");
		 ecrit_en_tete(pficx,1, 1, englob);
		 fprintf(pficx,"f%d 1\n",(factoit+i)->nofac_fichier);
		 fprintf(pficx,"%f %f %f\n",(factoit+i)->vnorm[0],(factoit+i)->vnorm[1],(factoit+i)->vnorm[2]);
		 fprintf(pficx,"c0\n%d\n",pcir->nbp);
         for(j=0;j<pcir->nbp;j++)
		 { fprintf(pficx,"%f %f %f\n",pcir->x[j],pcir->y[j],pcir->z[j]);
		 }
		 fclose(pficx);

		 // ignore les trous

		 // Retient le sol recouvert par le contour toit: fenetre_fic
		 sprintf(buf,"fenetre_fic %s XTOIT XSOL",argv[1]);
		 //printf("      commande : %s\n",buf);
		 system(buf);
		 sprintf(buf,"del XTOIT.cir");
		 system(buf);

		 // Uni le sol recouvert par le contour toit: union
		 sprintf(buf,"union  XSOL XSOLUNI",noc,noc);
		 //printf("      commande : %s\n",buf);
		 system(buf);

		 // POUR MAPPING
		 if(premiere_fois) // non
		 { sprintf(buf,"concatfic -m  MAPPING XSOL MAPPING1");
		   system(buf);

		   sprintf(buf,"del MAPPING.cir");
		   system(buf);
		   sprintf(buf,"del XSOL.cir");
		   system(buf);
		   sprintf(buf,"ren MAPPING1.cir MAPPING.cir");
		   system(buf);
		 }
		 else // c'est la premi�re fois
		 { 
		   sprintf(buf,"ren  XSOL.cir MAPPING.cir");
		   system(buf);
		   premiere_fois++;
		 }


		 // Construit les faces verticales en rabattant le contour du toit
		 // sur l'emprise au Sol Uni
		 construit_facade(pcir,pficr,nofac);
		 nofac = nofac + pcir->nbp-1;


		 // POUR MAPPING_UNI (faces polygonales non plane, union des facettes projett�es sur le sol  )
		 if(premiere_fois1) // non
		 { sprintf(buf,"concatfic -m  MAPPING_UNI XSOLUNI MAPPING_UNI1");
		   system(buf);

		   sprintf(buf,"del MAPPING_UNI.cir");
		   system(buf);
		   sprintf(buf,"del XSOLUNI.cir");
		   system(buf);
		   sprintf(buf,"ren MAPPING_UNI1.cir MAPPING_UNI.cir");
		   system(buf);
		 }
		 else // c'est la premi�re fois
		 { 
		   sprintf(buf,"ren  XSOLUNI.cir MAPPING_UNI.cir");
		   system(buf);
		   premiere_fois1++;
		 }


		 // Contour suivant
         pcont=pcont->suc;
		 noc++;
       } 
	}

// FIN du TRAITEMENT                                     
    // re-ecrit en tete
	rewind(pficr);
	ecrit_en_tete(pficr,nofac, nofac, englob);
	fclose(pficr);

    desalloue_fface(factoit,nbfac_toit);

	creer_OK_Solene();
	printf("\n\nFin de bati_sur_sol\n");
	exit(0);
}

//_______________________________________________________
void construit_facade(pcir,pficr,nofac)
struct circuit *pcir;
FILE *pficr;
int nofac; // no de face r�sultat o� rendu
{
 int i,j, ideb, ifin, oui, nbpoint, sens;
 double surf_toit, surf_sol;
 double xnn,ynn,znn;

 FILE *pfsol;
 int nbfac_s;
 double englob[10];
 struct modelisation_face *facs;
 struct contour *pconts;
 struct circuit *pcirs;

 // cherche sens de pcir du toit
	surf_toit = surface(pcir->nbp,pcir->x,pcir->y);
    //printf("surftoit = %f\n", surf_toit);

 // lit l'emprise au sol du toit: XSOL_UNI
	if ((pfsol=fopen("XSOLUNI.cir","r"))==NULL)
      { printf("\n  impossible ouvrir XSOLUNI.cir\n\n"); 
		exit(0);
      }
	lit_en_tete(pfsol,&nbfac_s, &i, englob);
    facs=alloue_face(nbfac_s, 1000);
    lit_fic_cir3d(pfsol, nbfac_s, facs);
	fclose(pfsol);
	// normalement une seulement face d'un seul contour
	if(nbfac_s != 1) { probleme(1,nbfac_s); exit(0); }
	if(nb_contour_face(facs,1) != 1) { probleme(2,nb_contour_face(facs,1)); exit(0); }

 // cherche sens de l'emprise  au sol
	pconts=facs->debut_projete;
	pcirs=pconts->debut_support;
	surf_sol = surface(pcirs->nbp,pcirs->x,pcirs->y);

 // accorde les sens toit et sol
	if(surf_sol*surf_toit <0)
	{ invsens(pcir);
	  surf_toit = -surf_toit;
	}
	if(surf_toit <0) sens =1;
	else sens =-1;

 // construit pour chaque arete de pcir toit, sa facade verticale
	for(i=0;i<pcir->nbp-1; i++)
	{ 
	  // cherche indice des points debut et fin d'arete de toit (de pcir)
	  //     dans pcirs
	  ideb = -1; ifin = -1;
	  for(j=0;j<pcirs->nbp-1; j++)
	  { if(ideb == -1)
		{ oui = test_meme_point(pcir->x[i],pcir->y[i],pcirs->x[j],pcirs->y[j]);
		  if(oui) ideb = j;
		}
		if(ifin == -1)
		{ oui = test_meme_point(pcir->x[i+1],pcir->y[i+1],pcirs->x[j],pcirs->y[j]);
		  if(oui) ifin = j;
		}
		if(ideb >=0 && ifin >=0) break;
	  } // fin de j

	  // compose circuit de la face verticale
	  nofac++;
	  fprintf(pficr,"f%d 1\n",nofac);
	  	// normale
	  normale_vert(pcir->x[i],pcir->y[i],pcir->z[i],pcir->x[i+1],pcir->y[i+1],pcir->z[i+1],&xnn,&ynn,&znn,sens);
	  fprintf(pficr,"%f %f %f\n",xnn,ynn,znn);

	  if(ideb < ifin)
	  { nbpoint= ifin-ideb +1 +2 +1;

		// les points
		fprintf(pficr,"c0\n %d\n",nbpoint);
		fprintf(pficr,"%f %f %f\n",pcir->x[i],pcir->y[i],pcir->z[i]);
		for (j=ideb;j<=ifin;j++)
		{ fprintf(pficr,"%f %f %f\n",pcirs->x[j],pcirs->y[j],pcirs->z[j]);
		}
	  }
	  else // ifin < ideb
	  { nbpoint= pcirs->nbp-1 -ideb +ifin +1 +2 +1;

		// les points
		fprintf(pficr,"c0 \n %d\n",nbpoint);
		fprintf(pficr,"%f %f %f\n",pcir->x[i],pcir->y[i],pcir->z[i]);
		for (j=ideb;j<pcirs->nbp-1;j++)
		{ fprintf(pficr,"%f %f %f\n",pcirs->x[j],pcirs->y[j],pcirs->z[j]);
		}
		for (j=0;j<=ifin;j++)
		{ fprintf(pficr,"%f %f %f\n",pcirs->x[j],pcirs->y[j],pcirs->z[j]);
		}
	  }
	  fprintf(pficr,"%f %f %f\n",pcir->x[i+1],pcir->y[i+1],pcir->z[i+1]);
	  fprintf(pficr,"%f %f %f\n",pcir->x[i],pcir->y[i],pcir->z[i]);

	} // fin de i , pour chaque arete de toit

 desalloue_fface(facs,nbfac_s);
}

//_______________________________________________________
int test_meme_point(x1,y1,x2,y2)
double x1,y1,x2,y2;
{
	if( fabs(x1-x2) > EPSI) return(0);
	if( fabs(y1-y2) > EPSI) return(0);
	return(1);
}

//_______________________________________________________
void normale_vert(xi,yi,zi,xj,yj,zj,xnn,ynn,znn,sens)
double xi,yi,zi,xj,yj,zj;
double *xnn, *ynn, *znn;
{
 double xk,yk,zk;
 double x1,y1,z1,x2,y2,z2;
 double norm;

	xk=xj; yk=yj; zk=zj+10;
    x1=xj-xi; y1=yj-yi; z1=zj-zi;
    x2=xk-xj; y2=yk-yj; z2=zk-zj;
    *xnn=y1*z2-y2*z1;
    *ynn=-x1*z2+x2*z1;
    *znn=x1*y2-x2*y1;

    norm=sqrt(*xnn*(*xnn)+*ynn*(*ynn)+*znn*(*znn));
    if(norm)
     {
      *xnn=(*xnn/norm)*sens;
	  *ynn=(*ynn/norm)*sens;
	  *znn=(*znn/norm)*sens;
    }
	else
	{ probleme(3,0);
	}
}

//_______________________________________________________
void probleme(no,nb)
int no,nb;
{
	if(no == 1)
	{ printf("XSOL_UNI a plus d'une face : %d\n",nb);
	}
	else if(no ==2)
	{ printf("XSOL_UNI a plus d'un contour : %d\n",nb);
	}
	else if(no ==3)
	{ printf("PB calcul de normale\n");
	}

}

/*_________________________________________________________________*/
/* Format de la fonction fraction_ciel */
void format_entree()
{
 printf(" bati_sur_sol   geom_sol_in(.cir)  geom_toit_in(.cir)  geom_facades_out(.cir) \n\n");
 printf("\n la fonction a comme parametres en ENTREE :\n");
 printf("\t geometrie_sol_in(.cir)\n"); 
 printf("\t geometrie_toit_in(.cir)\n");  
 printf("\n              comme parametres en SORTIE :\n");
 printf("\t geom_facades_out(.cir) \n\n"); 
 printf("NOTA produit un fichier MAPPING.cir des objets d�pos�s sur le sol \n\n"); 
 exit(0);
}



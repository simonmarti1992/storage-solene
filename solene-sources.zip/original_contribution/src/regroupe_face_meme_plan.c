/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/*

 regroupe_face_meme_plan   

*/
// D.GROLEAU		Avril 2004

// Regroupe en contours les faces de meme plan
// pour pouvoir, ensuite, unir les contours au sein de chaque face par union_contour_face

// on suppose, dans le fichier d'origine, un contour par face
// on prend appui sur decoupe_face_vert et fluent_to_solene


#include<solene.h>

// declaration de fonctions
int ecrit_en_tete();
void format_entree();


//GLOBAL
struct modelisation_face *alloue_face();

/*___________________________________________________________________*/
main(argc,argv)        
int argc;char **argv;
{
 int i,j,k;
 double englob[10];
 char 	nom_in[512],nom_out[512];
 int nbff,noma,nbf1;
 struct modelisation_face *fs;
 FILE *pf1,*pficr;
 char *s_dir;
 double epsiloneN;   // pour comparer vecteur normal d'abord
 int facteurD;    // et ecart z des 2 plans pour verifier coplanerit�
 int *id;

 long pointe;
 struct contour *pcont;
 struct circuit *pcir;
 int noc;


   nb_etat=0;
   epsiloneN = 0.0001;
   facteurD  = 1000;  

   s_dir="";

   printf("Fonction Solene : regroupe_face_meme_plan\n\n");
   if(argc<3) format_entree();
 
   if(argc >=4)   sscanf(argv[3],"%lf",&epsiloneN);
   if(argc ==5)   sscanf(argv[4],"%d",&facteurD);


      printf("epsiloneN = %f\n",epsiloneN);
	  printf("facteurD = %d\n\n",facteurD);


 /* OPen la geometrie ENTREE */

 	/* fichier .cir en entree */
            compose_nom_complet(nom_in,s_dir,argv[1],"cir");
            if((pf1=fopen(nom_in,"r"))==NULL) 
               { printf(" impossible ouvrir %s\n",nom_in);
   	             format_entree();
               }
 /* OPen  geometrie SORTIE */
            compose_nom_complet(nom_out,s_dir,argv[2],"cir");
            if((pficr=fopen(nom_out,"w"))==NULL) 
               { printf(" impossible ouvrir %s\n",nom_out);
   	             format_entree();
               }

  /* lit fichier IN */
			printf("geometrie IN  : %s\n",nom_in);

   lit_en_tete(pf1,&nbff,&noma,englob);
   printf("       nombre de faces du fichier = %d\n",nbff);
   fs=alloue_face(nbff,1000);
   lit_fic_cir3d(pf1,nbff,fs); 
   fclose(pf1);

   // alloue un drapeau : face a traiter =1 sino 0 
   id=alloue_int(nbff,89);
   for(i=0;i<nbff;i++)
   { id[i]=1;
   }

			printf("geometrie OUT : %s\n",nom_in);

   // ecrit entete fichier OUT
   nbf1=0;
   ecrit_en_tete(pficr,nbf1,nbf1,englob);


     printf("\nTraitement en cours ...\n");

	 // en principe fichier de faces d'un seul contour
     for(i=0;i<nbff;i++)
     { 
		if(id[i])  // face non encore enregistr�e
		{
		  //printf("traite face %d\n",(fs+i)->nofac_fichier);
		  id[i]=0;
		  nbf1++;
		  		// ecrit la face i et son contour
		  pointe=ftell(pficr);
		  fprintf(pficr,"f%d %5d\n",nbf1,1);
		  fprintf(pficr,"%f %f %f\n",(fs+i)->vnorm[0],(fs+i)->vnorm[1],(fs+i)->vnorm[2]);
		  noc=1;
		  // �crit le contour
		  pcont=(fs+i)->debut_projete; 
          pcir=pcont->debut_support; 
		  fprintf(pficr,"c0\n%d\n",pcir->nbp);
		  for(k=0;k<pcir->nbp;k++)
			{ fprintf(pficr,"%f %f %f\n",pcir->x[k] ,pcir->y[k] ,pcir->z[k] );
			}

	      for(j=i+1;j<nbff;j++)
			{ if(id[j])  // face non encore trait�e
				{ //printf("    par rapport a face %d\n",(fs+j)->nofac_fichier);
			      // test si face j coplanaire avec face i
					if(coplanaire(fs+i,1,fs+j,1,epsiloneN,0,facteurD)) 
					{ 	
						//printf("       coplanaire avec %d\n",(fs+j)->nofac_fichier);
						id[j]=0;

						// ecrit la face j comme contour suivant de la face i 
			   		    noc++;
						// �crit le contour
						pcont=(fs+j)->debut_projete; 
						pcir=pcont->debut_support; 
						fprintf(pficr,"c0\n%d\n",pcir->nbp);
						for(k=0;k<pcir->nbp;k++)
							{ fprintf(pficr,"%f %f %f\n",pcir->x[k] ,pcir->y[k] ,pcir->z[k] );
							}
					}
				}
			} //fin for j

		  // r��crit le nombre de contours de la face i en traitement
		  fseek(pficr,pointe,SEEK_SET);
		  fprintf(pficr,"f%d %5d\n",nbf1,noc);
		  // remet � la fin pour la nouvelle face
		  fseek(pficr,0,SEEK_END);

		} // fin de if(id[i]	
	 } //fin for i


  printf("nb de faces cr�es: %d faces\n",nbf1);
  // reecrit entete
  rewind(pficr);
  ecrit_en_tete(pficr,nbf1,nbf1,englob);
  fclose(pficr);

 

   desalloue_fface(fs,nbff);
   
   printf("\nFin regroupe_face_meme_plan\n\n");

   creer_OK_Solene();
}



/*_________________________________________________________________*/
/* Format de la fonction */
void format_entree()
{
  printf("\n   regroupe_face_meme_normale  fichier_in(.cir) fichier_out(.cir) [epsiloneN] [facteurD]\n\n");
  printf("\n   s'applique � un fichier de faces d'inclinaison quelconque\n\n");
  printf("\n   le regroupement en contours au sein d'une m�me face a lieu quand 2 faces sont dans la meme plan � epsilone pr�s (d�faut 0.0001)\n\n");
  printf("\n   et l'�cart sur d inf�rieur � facteurD*epsilone (facteurD, d�faut 1000)\n\n");
  exit(0);
}

/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/*

cc cylindre.c  solutile.o geomutile.o lib_solene_94.o -o cylindre -lm

// SII, Freddy 17 mars 2006 voir : // Modif SII FR060317
*/
/* cylindre.c  fait un cylindre .cir  */




#include<solene.h>
//#include <stdlib.h>
//#include <sys/stat.h>


/*_________________________________________________________________*/
int main(int argc,char **argv)
 /*int argc;char **argv;*/
{char 	buf[512],	buf1[512],	buf2[512],*s_dir;
 double angle,xc,yc,zc,x,y,xo,yo,rayon,pi,englob[10],pas,ang;
 float hauteur;
 int i,nbpas;
 FILE *fp;
// Modif SII FR060317
   char *pcTemp = "";
// Fin modif SII FR060317

 if(argc!=8)format_entree();

	s_dir=(char *)getenv("PWD");

        pi=4*atan(1.); 

  sscanf(argv[1],"%lf",&xc);
  sscanf(argv[2],"%lf",&yc);
  sscanf(argv[3],"%lf",&zc);
  sscanf(argv[4],"%lf",&rayon);
  sscanf(argv[5],"%f",&hauteur);
  sscanf(argv[6],"%d",&nbpas);

  printf("\n cylindre centre : (%f,%f,%f)\n",xc,yc,zc);
  printf(" rayon : %f\n",rayon);
  printf(" hauteur : %f\n",hauteur);
  printf(" nbpas : %d\n",nbpas);
 
   englob[0]=zc; 	 englob[1]=zc;
   englob[2]=xc-rayon;   englob[3]=yc-rayon;
   englob[4]=xc+rayon;   englob[5]=yc-rayon;
   englob[6]=xc+rayon;   englob[7]=yc+rayon;
   englob[8]=xc-rayon;   englob[9]=yc+rayon;


/* genere face cercle du dessous dans SOLENE_TEMP_1.cir */

//   compose_nom_complet(buf,s_dir,"SOLENE_TEMP_1","cir");
//   printf("fichier temporaire : %\n",buf);

// Dbt modif TL le 20070313
// Modif SII FR060317
//   sprintf( pcTemp, "%s\\SOLENE_TEMP_1.cir", getenv( "SOLENETEMP" ) );
//   fp=fopen("C:\\SOLENE\\PRIVATE\\TEMP\\SOLENE_TEMP_1.cir","w");
//   fp=fopen(pcTemp,"w");
// Fin modif SII FR060317

//   if(fp==NULL) 
//	{
// Modif SII FR060317
//	  printf("impossible creer C:\\SOLENE\\PRIVATE\\TEMP\\SOLENE_TEMP_1.cir\n");
//	  printf("impossible creer %s\n", pcTemp);
// Fin modif SII FR060317
//	  exit(0);
//	}
if( (fp=createFileTmpSolene("SOLENE_TEMP_1.cir","w")) == NULL ) {
	printf("impossible creer %s\n", pcTemp);
	exit(0);
}
// Fin modif TL le 20070313
	
   ecrit_en_tete(fp,1,1,englob);

    fprintf(fp,"f1 1\n");
    fprintf(fp,"  0  0  1 \n");
    fprintf(fp,"  c0 \n");
    fprintf(fp,"  %d \n",nbpas+1);
    
    pas=360./nbpas; pas=pas*pi/180.;

   for(i=0;i<nbpas;i++)
    { ang=pas*i;
      x=xc+rayon*cos(ang);      y=yc+rayon*sin(ang);
      if(i==0) { xo=x; yo=y; }
 //  fprintf(fp,"%12.3f %12.3f %12.3f\n",x,y,zc);
      fprintf(fp,"%f %f %f\n",x,y,zc);
    }
 //  fprintf(fp,"%12.3f %12.3f %12.3f\n",xo,yo,zc);
   fprintf(fp,"%f %f %f\n",xo,yo,zc);

   fclose(fp);


/* appelle volume_fic avec hauteur en .val dans SOLENE_TEMP_2.val */
//   compose_nom_complet(buf,s_dir,"SOLENE_TEMP_2","val");
//   printf("fichier temporaire : %\n",buf);

// Dbt modif TL le 20070313
// Modif SII FR060317
//   sprintf( pcTemp, "%s\\SOLENE_TEMP_2.val", getenv( "SOLENETEMP" ) );
//   fp=fopen("C:\\SOLENE\\PRIVATE\\TEMP\\SOLENE_TEMP_2.val","w");
//   fp=fopen(pcTemp,"w");
// Fin modif SII FR060317

//   if(fp==NULL) 
//	{
// Modif SII FR060317
//	  printf("impossible creer C:\\SOLENE\\PRIVATE\\TEMP\\SOLENE_TEMP_2.val\n");
//	  printf("impossible creer %s\n", pcTemp);
// Fin modif SII FR060317
//	  exit(0);
//	}
if( (fp=createFileTmpSolene("SOLENE_TEMP_2.val","w")) == NULL ) {
	printf("impossible creer %s\n", pcTemp);
	exit(0);
}
// Fin modif TL le 20070313
	
    fprintf(fp,"  1  1  %f %f \n",hauteur,hauteur);
    fprintf(fp,"f1 1\n");
    fprintf(fp,"%f\n",hauteur);
    fclose(fp);

   //compose_nom_complet_sans_ext(buf1,s_dir,"SOLENE_TEMP_1");
   //compose_nom_complet_sans_ext(buf2,s_dir,"SOLENE_TEMP_2");
// Modif SII FR060317
//   sprintf(buf,"volume_fic C:\\SOLENE\\PRIVATE\\TEMP\\SOLENE_TEMP_1 C:\\SOLENE\\PRIVATE\\TEMP\\SOLENE_TEMP_2  %s  D",argv[7]);
   sprintf(buf,"volume_fic \"%s\\SOLENE_TEMP_1\" \"%s\\SOLENE_TEMP_2\"  \"%s\"  D", getenv( "SOLENETEMP" ), getenv( "SOLENETEMP" ), argv[7]);
// Fin modif SII FR060317
   printf("commande= %s\n",buf);

   system(buf);
   
// Modif SII FR060317
	sprintf( buf, "del \"%s\\SOLENE_TEMP_1.cir\" \"%s\\SOLENE_TEMP_2.val\"", getenv( "SOLENETEMP" ), getenv( "SOLENETEMP" ) );
//   system("del C:\\SOLENE\\PRIVATE\\TEMP\\SOLENE_TEMP_1.cir C:\\SOLENE\\PRIVATE\\TEMP\\SOLENE_TEMP_2.val"); 
   system( buf ); 
// Fin modif SII FR060317

  creer_OK_Solene();
  printf("\n");
}

/*_________________________________________________________________*/
int format_entree()
{
  printf("\n    *cylindre* x_centre y_centre z_centre rayon  hauteur nbpas fichier_out(.cir)     \n\n");
   exit(0);
}

/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/* 
cc ouverture_directionnelle.c geomutile.o solutile.o lib_solene_94.o -o volume_fic  -lm 
*/


// D. GROLEAU juillet 2003
// D. GROLEAU avril   2004, ajoute une sortie .TXT pour analyse statistique

/*********************************************************/
/* calcul d'une rose d'ouverture autour d'un point 
 par rapport � une g�om�trie de contours horizontaux
 munis d'un descripteur de hauteur 
 
 ouverture = angle entre H/D (Hauteur du b�timent/ Distance au b�timent)
*/
/*********************************************************/

#include<solene.h>

// DECLARE FUNCTIONS
void applique_tr_rot();
void boite_arete();
int gere_coupe_arete();
int coupe_avec_arete();
float examine_rayon_geo();
void format_entree();
void lit_fic_rose();
int test_si_coupe_arete();
int test_si_coupe_cir();

/*----------------------------------------------------------------------*/
main(argc,argv)
int argc;char **argv;
{
 char	nom_fic[256],nom_fic_geom[256],buf[256], *s_dir; 
 int i,j;

 FILE *pf1,*pval,*prose,*prose1,*prose2;
 struct modelisation_face *fc,*fs;
 struct contour *pcont;
 struct circuit *pcir;
 int nbfc,nbfs, nomax, noc;
 double englob[10];
 double *hauteur , xg,yg,zg;
 int	nb_dir,pas_angle;
 double angle, angleR;
 float	valeur, valeurD;   // valeur = angle = tg (H/L);  valeurD = L

 pi=4*atan(1.);

 if(argc<6){format_entree(); exit(0);}
 s_dir=(char *)getenv("PWD");

 
 printf("Fonction Solene: Ouverture directionnelle\n\n");

  /* Lit le fichier des contours a evaluer */
 compose_nom_complet(nom_fic,s_dir,argv[1],"cir");
 if((pf1=fopen(nom_fic,"r"))==NULL)
    { printf("\n   le fichier %s n'existe pas\n",nom_fic);
	  exit(0);
    }
  printf("\ncentre de gravite des contours des faces � evaluer: %s\n",nom_fic);

  lit_en_tete(pf1,&nbfc,&nomax,englob);
  fc=alloue_face(nbfc,1000);
  lit_fic_cir3d(pf1,nbfc,fc); 
  fclose(pf1);
    printf("      nombre de faces  %d\n",nbfc);


  /* Lit le fichier des g�om�tries  masque */
 compose_nom_complet(nom_fic_geom,s_dir,argv[2],"cir");
 if((pf1=fopen(nom_fic_geom,"r"))==NULL)
   { printf("\n   le fichier %s n'existe pas\n",nom_fic_geom);
	 exit(0);
   }
  printf("\ngeometrie 2D emprise des zones: %s\n",nom_fic_geom);

  lit_en_tete(pf1,&nbfs,&nomax,englob);
  fs=alloue_face(nbfs,1000);
  lit_fic_cir3d(pf1,nbfs,fs); 
  fclose(pf1);

  // nb total de contours
  nbc = nbcontours_total(fs, nbfs);
  printf("      nombre total de zones  %d\n",nbc);
  // et fait une copie dans dessin , qui recevra le r�sultat des rotations
  for(i=0;i<nbfs;i++)
  { copie_face_projete(fs+i,1,fs+i,0);
  //liste_face(fs+i,1);
  //liste_face(fs+i,0);
  }


 /* Lit le fichier de hauteur associ� */
  compose_nom_complet(nom_fic,s_dir,argv[3],"val");
  if((pval=fopen(nom_fic,"r"))==NULL)
    { printf("\nimpossible ouvrir %s\n",nom_fic);
	  exit(0);
	}
  printf("fichier associ� des hauteurs : %s\n",nom_fic);

 // Allocation du tableau des valeurs associ�es aux contours*/
  hauteur = alloue_double(nbc,456);
  lect_fic_val(pval, hauteur);
  fclose(pval);

 /* lit nb de directions de la rose et clacul pas d'angle */
   sscanf(argv[4],"%d",&nb_dir);
   pas_angle=360/nb_dir;


 /* Open 2 fichiers rose : angle et distance */
  sprintf(buf,"%s_A",argv[5]);
  compose_nom_complet(nom_fic,s_dir,buf,"ros");
  if((prose=fopen(nom_fic,"w"))==NULL)
    { printf("\nimpossible ouvrir %s\n",nom_fic);
	  exit(0);
	}
  printf("\nfichier  rose resultat Angle: %s\n",nom_fic);
  
  sprintf(buf,"%s_D",argv[5]);
  compose_nom_complet(nom_fic,s_dir,buf,"ros");
  if((prose1=fopen(nom_fic,"w"))==NULL)
    { printf("\nimpossible ouvrir %s\n",nom_fic);
	  exit(0);
	}
  printf("\nfichier  rose resultat Distance: %s\n",nom_fic);

  //
  fprintf(prose,"%d %d %d\n",nbfc,nb_dir,1);
  fprintf(prose1,"%d %d %d\n",nbfc,nb_dir,1);

// Open 1 fichier pour STAT en .txt seulement pour angle
  sprintf(buf,"%s_A",argv[5]);
  compose_nom_complet(nom_fic,s_dir,buf,"txt");
  if((prose2=fopen(nom_fic,"w"))==NULL)
    { printf("\nimpossible ouvrir %s\n",nom_fic);
	  exit(0);
	}
  printf("\nfichier  rose resultat Angle (en.txt pour stat de classification): %s\n",nom_fic);

 // TRAITEMENT
  printf("\n      execution en cours ....\n");

// Pour chaque centre de gravit� de contour � �valuer
   for(i=0;i<nbfc;i++)
   {
	pcont=(fc+i)->debut_projete;
	//
	fprintf(prose,"f%d %d\n",(fc+i)->nofac_fichier,nb_contour_face(fc+i,1));
	fprintf(prose1,"f%d %d\n",(fc+i)->nofac_fichier,nb_contour_face(fc+i,1));

	noc=0;
    while(pcont)
        {
		  //
		  fprintf(prose,"%d\n",noc+1);
		  fprintf(prose1,"%d\n",noc+1);

  		  pcir=pcont->debut_support;
		  centre_de_gravite(pcir,&xg,&yg,&zg);
		  //printf("pour Point face %d, no  contour %d\n",(fc+i)->nofac_fichier,noc+1);

		  //	Pour chaque direction
		  angle = -90 - pas_angle;
		  for (j=0;j<360;j+=pas_angle)
		  { 
			angle= angle + pas_angle;
			//printf("\nangle (/nord): %d (rotation %f)\n",j,angle);
			angleR=angle * 4*atan(1.) /180.; 

			// applique la translation et la rotation au masque
			// pour �tudier l'intersection sur une 1/2 droite Y=0
			 applique_tr_rot(xg,yg,zg,angleR,fs,nbfs);

		    // examine le rayon dans cette direction
		    valeur= examine_rayon_geo(fs,nbfs,hauteur,&valeurD);
			// ecrit valeur pour cette direction
			//
			fprintf(prose,"%3d %10.2f\n",j,valeur*180/pi);
			fprintf(prose2," %3.0f",valeur*180/pi);

			// convention: distance infinie, on met 0
			if(valeurD == 100000) valeurD=0;
			fprintf(prose1,"%3d %10.2f\n",j,valeurD);

		  }
          pcont=pcont->suc;
		  noc++;
		  fprintf(prose2,"\n");

        }

   }// fin for face i

 desalloue_fface(fs,nbfs); 
 desalloue_fface(fc,nbfc);
 desalloue_double(hauteur);
 fclose(prose);
 fclose(prose1);
 fclose(prose2);

 // TEST : lecture du fichier .ros
 /*
 printf("\n test lecture rose\n");
  compose_nom_complet(nom_fic,s_dir,argv[5],"ros");
  if((prose=fopen(nom_fic,"r"))==NULL)
    { printf("\nimpossible ouvrir %s\n",nom_fic);
	  exit(0);
	}
 lit_fic_rose(prose);
 */
 //

printf("Fin ouverture_directionnelle\n\n");

creer_OK_Solene();

}

/*____________________________________________________________________*/
void lit_fic_rose(prose)
FILE *prose;
{
	int nbf, nb_dir,nb_val;
	int num_face,nofac,nbcont_face,num_cont;
	int i,angle,noc;
	float val1,val2,val3;
	char c;

	fscanf(prose,"%d %d %d",&nbf,&nb_dir,&nb_val);
	printf("nbf nb_dir, nb_val : %d %d %d\n",nbf,nb_dir,nb_val);

	for(num_face=0;num_face<nbf;num_face++)
	{
	 fscanf(prose,"\n%c%d%d\n",&c,&nofac,&nbcont_face);
	 printf("f%d %d\n",nofac,nbcont_face);

	 for(num_cont=0;num_cont<nbcont_face;num_cont++)	
		{
		 fscanf(prose,"%d\n",&noc);
		 printf(" contour %d \n ", noc);

		  for(i=0;i< nb_dir;i++)
			{ 
			  if(nb_val ==1)
				{	fscanf(prose,"%d %f\n",&angle,&val1);
					printf(" %d  %f \n ", angle,val1);
				}
			  else if (nb_val ==2)
				{	fscanf(prose,"%d %f %f",&angle,&val1,&val2);
					printf("%d  %f  %f\n", angle,val1,val2);
				}
			  else if (nb_val ==3)
				{	fscanf(prose,"%d %f %f %f",&angle,&val1,&val2,&val3);
					printf("%d  %f  %f  %f\n", angle,val1,val2,val3);
				}
		  }
		}
	}
}

/*____________________________________________________________________*/
void applique_tr_rot(xg,yg,zg,angle,face,nbface)
double xg,yg,zg,angle;
struct modelisation_face *face;
int nbface;
{
 int i,j;
 double co,si,tempo, yt;
 struct contour *pcont,*pcontr;
 struct circuit *pcir,*pcirr;

 //printf("xg,yg %f %f \n",xg,yg);
 co=cos(angle);   si=sin(angle);

 for(j=0;j<nbface;j++)
 {
   /* on ne fait pas ttourner la normale
   tempo=face->vnorm[0];
   (face+j)->vnorm[0]=tempo*co-(face+j)->vnorm[1]*si;
   (face+j)->vnorm[1]=tempo*si+(face+j)->vnorm[1]*co;
   */
    
   pcont= (face+j)->debut_projete;
   pcontr=(face+j)->debut_dessin;
   while(pcont)	   
   { pcir= pcont->debut_support; 
     pcirr=pcontr->debut_support;
     for(i=0;i<pcir->nbp;i++)
	 { tempo=pcir->x[i] - xg;
	   yt= pcir->y[i] - yg;
	   pcirr->x[i]=tempo*co-yt*si;
       pcirr->y[i]=tempo*si+yt*co;
	 }
	 fenetre_circuit(pcirr);

	 pcir=pcont->debut_interieur;
	 pcirr=pcontr->debut_interieur;
     while(pcir)
	 { for(i=0;i<pcir->nbp;i++)
		{ tempo=pcir->x[i] - xg;
	      yt= pcir->y[i] - yg;
	      pcirr->x[i]=tempo*co-yt*si;
          pcirr->y[i]=tempo*si+yt*co;
	    }
	   fenetre_circuit(pcirr);
	   pcir= pcir->suc;
	   pcirr=pcirr->suc;
	 }

    pcont=pcont->suc; 
    pcontr=pcontr->suc; 
   } 

  fen_face(face+j,0);
  //liste_face(face+j,0);
 }
}

/*-----------------------------------------------------*/
float examine_rayon_geo(ff,nbf,haut,valeurD)
struct modelisation_face *ff;
int nbf;
double *haut;
float *valeurD;
{
 int i,j,noc,nog;
 struct contour *pcont;
 struct circuit *pcir;
 double xint;
 float valeur;

 valeur = 0;
 *valeurD = 100000;
  nog=0; 
  // examine le rayon sur l'ensemble des faces du masque de la g�om�trie
  for(i=0;i<nbf;i++)
	{ 
	 pcont=(ff+i)->debut_dessin;
	 noc=0;
     while(pcont)
        {
		 pcir=pcont->debut_support;

		 // test si 1/2 droite horizontale coupe le contour
		 // si oui, renvoie point de coupe 
		 if(test_si_coupe_cir(pcir))
		 {
	      // test si coupe chaque arete du circuit
		  for(j=0;j<pcir->nbp-1;j++)
			{ if(gere_coupe_arete(pcir->x[j],pcir->y[j],pcir->x[j+1],pcir->y[j+1],&xint))
			  { // intersection trouv�e
			    //printf("inter avec face %d contour %d : %f (haut %5.2f)\n",(ff+i)->nofac_fichier,noc+1,xint,haut[nog]);
				if(xint < *valeurD) *valeurD = xint;
		        if(atan(haut[nog]/xint) > (double) valeur) valeur= (float) (atan (haut[nog]/xint));
				//printf("%f\n",valeur);
			  }
			}

		 }

          pcont=pcont->suc;
		  noc++;
		  nog++;
        }
	}
  return(valeur);
}

/*_________________________________________________________________*/
int test_si_coupe_cir(pcir)
struct circuit *pcir;
{
	
	// la demi-droite y=0 coupe possiblement le circuit
	//          si ymin*ymax <0 et xmax>0
	if(pcir->fen[1]*pcir->fen[4] <0 && pcir->fen[3] >0) return(1);
	else return(0);
}


/*_________________________________________________________________*/
int gere_coupe_arete(x1,y1,x2,y2,xint)
double x1,y1,x2,y2;
double *xint;
{
 double xmin,ymin,xmax,ymax;

	boite_arete(x1,y1,x2,y2,&xmin,&ymin,&xmax,&ymax);
	//printf("x1 y1 x2 y2 : %f %f %f %f\n", x1,y1,x2,y2);
	//printf("xmin y x y : %f %f %f %f\n", xmin,ymin,xmax,ymax);
	if(test_si_coupe_arete(xmin,ymin,xmax,ymax))
	{ 
	  if(coupe_avec_arete(x1,y1,x2,y2,xint))
	  { return(1);
	  }
	}
	return(0);
}
/*_________________________________________________________________*/
void boite_arete(x1,y1,x2,y2,xmin,ymin,xmax,ymax)
double x1,y1,x2,y2;
double *xmin,*ymin,*xmax,*ymax;
{
	*xmin=x1; *xmax=x2;
	if(x2 < *xmin) { *xmin=x2; *xmax=x1; }
	*ymin=y1; *ymax=y2;
	if(y2 < *ymin) { *ymin=y2; *ymax=y1; }
}
/*_________________________________________________________________*/
int test_si_coupe_arete(xmin,ymin,xmax,ymax)
double xmin,ymin,xmax,ymax;
{
	
	// la demi-droite y=0 coupe possiblement l'arete de boite englobante donn�e
	//          si ymin*ymax <0 et xmax>0
	if( ymin*ymax <=0 && xmax >0) return(1);
	else return(0);
}

/*_________________________________________________________________*/
int coupe_avec_arete(x1,y1,x2,y2,xint)
double x1,y1,x2,y2,*xint;
{	
 double dx,dy,a,b;
	// la demi-droite y=0 (positive) coupe possiblement l'arete donn�e
	// si l'intersection xint est >0
	dx = x2-x1;
	if( dx== 0)
	{  *xint = x1;
	   return(1);
	}
	else
	{ dy = y2-y1;
	  if(dy==0) return(0);
	  a = dy/dx;
	  b = y1-a*x1;
	  *xint = -b/a;
	  if(*xint > 0) return(1);
	  else return(0);
	}
}

/*_________________________________________________________________*/
/* Format de la fonction */
void format_entree()
{
  printf("\n ouverture_directionnelle \n");
	printf("\n       a comme param�tre d'entr�e\n");
  printf("\n IN  fichier_points_in (.cir)\n");
  printf("\n IN  fichier_zone_in(.cir)\n");
  printf("\n IN  fichier_zone_hauteur_in(.val)\n");
  printf("\n IN  nb_de_directions_de_la_rose\n");
    printf("\n       a comme param�tre de sortie\n");
  printf("\n OUT  fichier_rose (.ros et .txt) \n");

  printf(" Le fichier fichier_points_in(.cir) contient les contours (centre de gravit�) � evaluer \n");
  printf(" Le fichier fichier_zone_in(.cir) contient les contours horizontaux des volumes \n");
  printf(" Le fichier fichier_zone_hauteur_in(.val) la hauteur des plans horizontaux\n");
  printf(" Les r�sultats sont dans 2 fichier_rose (.ros), _A (angle) et _D (distance)\n");
  printf(" et 1 fichier (.txt) _A pour analyse stat de classification\n");

}

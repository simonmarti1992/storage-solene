/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */
 
/* arc_solene.c */
/* 

cc -o arc_solene arc_solene.c solutile.o geomutile.o lib_solene_94.o -lm
 
*/

/* Conversion fichier ARC+ (.gs1) en fichier SOLENE (.cir) */

/*---------------------------------------------------------------------------*/
#include<solene.h>
#include <stdlib.h>
#include <sys/stat.h>

//#include <sys/file.h>

#define SEEK_SET 0
#define NBPMAX 1024
FILE *fi,*fo;

int  f_in,f_out,num,nbc_coul,coul[50],inverse_sens,nodeb,nofin;
double precision,x[NBPMAX],y[NBPMAX],z[NBPMAX],xnn,ynn,znn;
double xmin,ymin,zmin,xmax,ymax,zmax;
int pcoul[NBPMAX],nop_poly[NBPMAX],nbp_poly[NBPMAX],nbp_bon_poly[NBPMAX];
int statut[NBPMAX],nbpoly;
char buf[512],buf1[512],nom_in[512],nom_out[512];

/*________________________________________________________*/
main(argc,argv)
int  argc;
char *argv[];    /* ou **argv */

{
 int i,nbc,nc1,nc2;
 double x1,x2;
 char cc,*s_dir;

	s_dir=(char *)getenv("PWD");


 /* initialise extremes x,y,z */
 xmin=ymin=zmin=9999999.;
 xmax=ymax=zmax=-xmin;

 /* lit et traite les parametres */

  num=1; precision=0.001; inverse_sens=0;
  nbc_coul=0;

            compose_nom_complet(nom_in,s_dir,argv[1],"gs1");
            if((fi=fopen(nom_in,"r"))==NULL) 
               { printf(" impossible ouvrir %s\n",nom_in);
   	         format_entree();
               }
            fclose(fi);

            compose_nom_complet(nom_out,s_dir,argv[2],"cir");
            if((fo=fopen(nom_out,"w"))==NULL) 
               { printf(" impossible ouvrir %s\n",nom_out);
   	         format_entree();
               }

for(i=3;i<argc;i++)
   { sprintf(buf,"%s",argv[i]);
     if(buf[0]!='-')format_entree();
     else if(buf[1]=='n')
        {      /* numerotation des faces : num */
          i++; sprintf(buf,"%s",argv[i]);
          sscanf(buf,"%d",&num);
        }
     else if(buf[1]=='c')
        {      /* couleur des faces a recuperer : coul */
          i++;
          nbc=lit_intervalle(argv[i],'-',&x1,&x2);
          nc1=x1; if(nbc==2) nc2=x2; else nc2=nc1;
          for(nbc=nc1;nbc<=nc2;nbc++)
             { coul[nbc_coul]=nbc; nbc_coul++;
             }
        }
     else if(buf[1]=='p')
        {      /* precision de recollement des points : precision */
          i++; sprintf(buf,"%s",argv[i]);
          sscanf(buf,"%lf",&precision);
        }
     else if(buf[1]=='N')
        {      /* inversion du sens des faces : inverse_sens=1 */
          inverse_sens=1;
        } 

    else format_entree();
  }

 fi=fopen(nom_in,"r");

printf(" num=%d nb_coul=%d inverse=%d precision=%lf\n",num,nbc_coul,inverse_sens,precision);

 if(nbc_coul==0) { nbc_coul=1; coul[0]=0; }
printf(" Couleurs a recuperer : ");for(i=0;i<nbc_coul;i++) printf("%d ",coul[i]);
printf("\n");
/* convertit */
 nodeb=num; nofin=nodeb-1;
 convertit();

 fclose(fi); fclose(fo);

 if(nofin<nodeb) 
    { sprintf(buf,"del %s",nom_out);
      system(buf);
      printf("\n ...conversion terminee : 0 faces generees\n\n");
    }
 else printf("\n ...conversion terminee : %d faces generees\n\n",nofin-nodeb+1);


 creer_OK_Solene();
 printf("\n");
}

/*______________________________________________________*/
int format_entree()
{
 printf("\n  *arc_solene* f_arc(.gs1) f_solene(.cir) [-n #] [-c #] [-c #] [...]  [-p #] [-N]  \n");
 printf("\n");   
 printf("     f_arc : Nom du fichier Arc+ a convertir \n");
 printf("     f_solene : Nom du fichier des faces transformees dans Solene \n");
 printf("[] indique que le parametre est optionnnel\n");
 printf("     -n # : Numerotation des faces incrementees de 1 ,a partir\n            du numero # (valeur entiere) .Defaut : 1\n");
 printf("     -c # ou c#-# : Transfert les faces de couleur # (valeur entiere) ou de couleur # a #\n               Defaut : toutes les faces sont transferees sans ordre\n");
 printf("     -p # : Supprime les points distants de moins de # (valeur reelle)\n            Defaut : 0.001\n");
 printf("     -N   : Inversion du sens des faces . Defaut : pas d'inversion\n");
 printf("     -u   : Le fichier .gs1 est un Fichier UNIX (defaut DOS)\n");
 exit(0);
}


/*______________________________________________________*/
int convertit()
{ 
  int nbf_fi,i,j,k,kk,couleur,p2,p3,nbp,nbpp,nd,nb_lu;
  double xx,yy,zz;

  fprintf(fo,"%5d  %5d\n",nofin-nodeb,nofin);
 /* initialise boite englobante */
  fprintf(fo,"%10.1lf %10.1lf\n",zmin,zmax);
  fprintf(fo,"%10.1lf %10.1lf\n",xmin,ymin);
  fprintf(fo,"%10.1lf %10.1lf\n",xmax,ymin);
  fprintf(fo,"%10.1lf %10.1lf\n",xmax,ymax);
  fprintf(fo,"%10.1lf %10.1lf\n",xmin,ymax);

nb_lu=0;

/* Recupere Couleur par Couleur; donc lit autant de fois le fichier */
 for(kk=0;kk<nbc_coul;kk++)
  { nd=nofin+1;
    fseek(fi,0L,SEEK_SET);
    fscanf(fi,"%d",&nbf_fi);
	    // p2=1 si contour =-1 si ligne
    while(((fscanf(fi,"%d%d%d%d",&couleur,&p2,&p3,&nbp)))!=EOF)
    { /* lit une face */
      if(nbp>NBPMAX)
        { printf(" trop de points dans une face (%d)\n",NBPMAX);
          exit(0);
        }

nb_lu++;
/*printf(" lit face no %d \n",nb_lu);*/

      for(j=0;j<nbp;j++)
        { fscanf(fi,"%d%lf%lf%lf",pcoul+j,x+j,y+j,z+j);
          statut[j]=0;
        }
     couleur=pcoul[1]; /* couleur prise sur le 2eme point */
      /* Retient le contour  si la couleur et si p2=1 (contour) */
     if(p2==1 && (coul[kk]==0 ||couleur==coul[kk]))
        {    /* nb de  polygones */
             /* si plusieurs ,le signale et met plusieurs contours support */
          nb_poly(nbp);
            /* enleve points proches par poly */
          nbpp=0;
          for(i=0;i<nbpoly;i++)
            { k=nop_poly[i];
              nbp_bon_poly[i]=sup_pt_proche(x+k,y+k,z+k,statut+k,nbp_poly[i]);
              if(nbp_bon_poly[i]>3) nbpp++;
                /* inverse si inverse_sens=1 */
              if(inverse_sens) inverse(x+k,y+k,z+k,statut+k,nbp_poly[i]);
            }
            /*  si > 3 pts,ajoute une face de une facette ds .cir */
          if(nbpp>0)
            {
              nofin++;
              if(nbpp>1) printf("   face %d de %d facettes\n",nofin,nbpp);
/*printf(" ecrit face no %d \n",nofin);*/
              fprintf(fo,"f%d 1\n",nofin);
                 /* calcule normale sur 1er contour bon */
              for(i=0;i<nbpoly;i++)
                 { if(nbp_bon_poly[i]>3)
                     { j=nop_poly[i];
                       calcul_normale(nbp_bon_poly[i],x+j,y+j,z+j,statut+j,&xnn,&ynn,&znn);
                       break;
                     }
                 }
              fprintf(fo,"  %lf %lf %lf\n",xnn,ynn,znn);
              for(i=0;i<nbpoly;i++)
                 { if(nbp_bon_poly[i]>3)
                      { if(i==0)fprintf(fo," c%d\n",nbpp-1);
			else fprintf(fo," t\n");
                        fprintf(fo,"    %d\n",nbp_bon_poly[i]);
                        j=nop_poly[i];
                        for(k=j;k<j+nbp_poly[i];k++)
                          { if(statut[k]==0)
				{ fprintf(fo,"  %lf %lf %lf\n",x[k],y[k],z[k]);
				  cherche_ext(x[k],y[k],z[k]);
				} 
                          }
                      }
                 }
            }
        }
    }
 if(nofin>=nd)
    printf(" Couleur %2d : faces generees de %d a %d\n",coul[kk],nd,nofin);
 }
  /* termine  reecrit en_tete */
  fseek(fo,0L,SEEK_SET);
  fprintf(fo,"%5d  %5d\n",nofin-nodeb+1,nofin);
 /* initialise boite englobante */
  fprintf(fo,"%10.1lf %10.1lf\n",zmin,zmax);
  fprintf(fo,"%10.1lf %10.1lf\n",xmin,ymin);
  fprintf(fo,"%10.1lf %10.1lf\n",xmax,ymin);
  fprintf(fo,"%10.1lf %10.1lf\n",xmax,ymax);
  fprintf(fo,"%10.1lf %10.1lf\n",xmin,ymax);
}

/*______________________________________________________*/
int nb_poly(nbp)
int nbp;
{   /* determine un poly quand 1er pt = dernier pt  */
    /* independamment du parametre de couleur */
 int i;
  nbpoly=0;
  nop_poly[0]=0; nbp_poly[0]=1;
  for(i=1;i<nbp;i++)
    { nbp_poly[nbpoly]++;
      if(fabs(x[i]-x[nop_poly[nbpoly]])<.001&&fabs(y[i]-y[nop_poly[nbpoly]])<.001&&fabs(z[i]-z[nop_poly[nbpoly]])<.001)
        { /* 1 poly */
	x[i]=x[nop_poly[nbpoly]];
	y[i]=y[nop_poly[nbpoly]];
	z[i]=z[nop_poly[nbpoly]];
          nbpoly++; i++;
          nop_poly[nbpoly]=i; nbp_poly[nbpoly]=1;         
        }
    }
}

/*______________________________________________________*/
int sup_pt_proche(x,y,z,statut,nbp)
double *x,*y,*z;
int *statut,nbp;
{
 int i,j,k,nbpp;
         /* suppression artificielle des pts proches avec statut <0 */
 nbpp=nbp;
 for(i=0;i<nbp-1;i++)
   { if(statut[i]==0)
       { for(k=i+1;k<nbp;k++)
          { if(statut[k]==0)
              { if(fabs(x[i]-x[k])<precision && fabs(y[i]-y[k])<precision && fabs(z[i]-z[k])<precision)
                  { nbpp--;
                    statut[k]=-1;
                    i--;
                  }
                break;
              }
          }
        }
   }
 return(nbpp);
}

/*________________________________________________________________________*/
int inverse(x,y,z,statut,nbp)
double *x,*y,*z;
int nbp,*statut;
{
 int i,j,k;
 double s;
 for(i=1;i<nbp/2;i++)
    {j=nbp-i-1;
     s=x[i]; x[i]=x[j]; x[j]=s;
     s=y[i]; y[i]=y[j]; y[j]=s;
     s=z[i]; z[i]=z[j]; z[j]=s;
     k= statut[i]; statut[i]=statut[j];statut[j]=k;
    }
  }

/*________________________________________________________________________*/
int calcul_normale(nbp,xx,yy,zz,statut,xnn,ynn,znn)
double *xx,*yy,*zz;
double *xnn,*ynn,*znn;
int *statut,nbp;
{
 double x1,y1,z1,x2,y2,z2,norm;
 double *x,*y,*z;
 int i,j,k,ii,nb,l,ibreak;

// constitue une liste de points consecutifs avec statut 0
x = alloue_double(nbp,1236);
y = alloue_double(nbp,1237);
z = alloue_double(nbp,1238);
nb=0;
for(i=0;i<nbp;i++)
{ if(statut[i]==0)
   {  x[nb]=xx[i]; y[nb]=yy[i]; z[nb]=zz[i];
      nb++; 
   }
}
if(nbp <4)
{ printf("Pb pour calculer la normale <3pts\n");
  // attribue arbitrairement une normale car n'a pas pu la calculer
  *xnn=0; *ynn=0; *znn=1;
  return(0);
}

// calcul la normale sur 3 points non alignes
ibreak=0;
for(l=0;l<nb-2;l++)
{ i=l; j=l+1; k=l+2;
    x1=x[j]-x[i]; y1=y[j]-y[i]; z1=z[j]-z[i];
    x2=x[k]-x[j]; y2=y[k]-y[j]; z2=z[k]-z[j];
    *xnn=y1*z2-y2*z1;
    *ynn=-x1*z2+x2*z1;
    *znn=x1*y2-x2*y1;

    norm=sqrt(*xnn*(*xnn)+*ynn*(*ynn)+*znn*(*znn));
    if(norm)
     {
      *xnn=*xnn/norm; *ynn=*ynn/norm; *znn=*znn/norm;
	  ibreak=1;
	  break;
     }
}

desalloue_double(x);
desalloue_double(y);
desalloue_double(z);


 if(ibreak==0)
 { // attribue arbitrairement une normale car n'a pas pu la calculer
  *xnn=0; *ynn=0; *znn=1;
 }
}

/*________________________________________________________________________*/
int cherche_ext(x,y,z)
double x,y,z;
{
	if(x<xmin)xmin=x;
	if(x>xmax)xmax=x;
	if(y<ymin)ymin=y;
	if(y>ymax)ymax=y;
	if(z<zmin)zmin=z;
	if(z>zmax)zmax=z;
}


/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */


/*

cc solene_khoros.c  solutile.o geomutile.o lib_solene_94.o -o solene_khoros -lm 

*/
/* POUR UN FICHIER .cir */
/* convertit en fichier khoros.kho
    nb de pts
	x y z des points
	....
	nb de pts
	x y z des points
	....
*/
#include<solene.h>



/*_________________________________________________________________*/
main(argc,argv)           /*  */
int argc;char **argv;
{
 char nom_in[256],nom_out[256],*s_dir;
 FILE *pfic,*pfout;
 struct modelisation_face *fac ;
 struct contour *pcont;
 struct circuit *pcir;
 double englob[10];
 int i,k;

   if(argc<3) format_entree_solene_khoros();
 
      /* lecture parametres commande */

         s_dir=""; //(char *)getenv("PWD");


         compose_nom_complet(nom_in,s_dir,argv[1],"cir");
		 printf("fichier solene a convertir : %s \n",nom_in);

		 compose_nom_complet(nom_out,s_dir,argv[2],"kho");  
         printf("en fichier  (.kho) : %s \n",nom_out);

      /* le fichier a traiter */

       if((pfic=fopen(nom_in,"r"))==NULL)
            { printf("\n impossible ouvrir %s\n",nom_in); exit(0);
            }

       if((pfout=fopen(nom_out,"w"))==NULL)
           { printf("\n impossible ouvrir %s\n",nom_out); exit(0);
           }

  /* lecture en_tete pfic */
       lit_en_tete(pfic,&nbfac,&nomax,englob);
       printf("Traite %d faces\n",nbfac);
       fac=alloue_face(nbfac,34);
       lit_fic_cir3d(pfic,nbfac,fac);
       fclose(pfic);
      
 printf("Convertit solene.cir en khoros.kho ...\n");

 for(i=0;i<nbfac;i++)
   {
	 pcont=(fac+i)->debut_projete; 

     while(pcont)	   
       { pcir=pcont->debut_support;
         
	     fprintf(pfout,"%d\n",pcir->nbp);
	     for(k=0;k<pcir->nbp;k++) 
           { 
	         fprintf(pfout,"%12.3f %12.3f %12.3f\n",pcir->x[k],pcir->y[k],pcir->z[k]);
           }
      
         pcont=pcont->suc;
       } 
   }

  desalloue_fface(fac,nbfac);
 
  fclose(pfout);

    creer_OK_Solene();
	printf("\n\nFin du Traitement solene_khoros\n");


}

/*_________________________________________________________________*/
int format_entree_solene_khoros()
{
  printf("\n   format d'entree des parametres \n\n");
  printf("solene_khoros fichier_in(.cir) fichier_out(.kho) \n\n");
  exit(0);
}



/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */
 
/* analyse_val_tps.c 
 
 Analyse les valeurs d'un descripteur fonction du temps	
 valeur min,  heure du min
 valeur max,  heure du max
 moyenne
 valeur cumul�e
 et d'autres si n�cessaire ...

 D.Groleau 22 janvier 2002
*/

#include<solene.h>

void usage_analyse();

/*_________________________________________________________________*/
main(argc,argv)           
int argc;
char **argv;
	{

	int		hdeb,hfin,i,k,j,nc;
	char	buf[512],nom[512],c;
	int		nbfac,nofac,nomax,nbcont,nb_contour_total;
	char	*s_dir;
 	FILE	*pfic,*pfic1,*pfic2,*pfic3,*pfic4,*pfic5,*pfic6;
	float	valeur;
	float	*val_min, *heure_val_min, *val_max, *heure_val_max, *val_cum;
	float	min,max;

	s_dir=(char *)getenv("PWD");

   	if(argc<4) usage_analyse();
 
	// Lit heure d�but et fin
	sscanf(argv[2],"%d",&hdeb);
	sscanf(argv[3],"%d",&hfin);

	printf("Analyse le descripteur : %s de %d  �  %d  heures\n",argv[1],hdeb,hfin);

	// Lecture du premier fichier val pour calculer le nb de contours

	if (hdeb < 10 ) sprintf(buf,"%s_0%dh00",argv[1],hdeb);
	else sprintf(buf,"%s_%dh_00",argv[1],hdeb);
	compose_nom_complet(nom,s_dir,buf,"val");

	if ((pfic=fopen(nom,"r"))==NULL)
      { 
		printf("\n  impossible ouvrir %s\n\n", nom); 
		exit(0);
      }
	fscanf(pfic,"%d %d %f %f",&nbfac,&nomax,&min,&max);	
	nb_contour_total=0;
	for(i=0;i<nbfac;i++)
		{
		fscanf(pfic,"\n%c%d%d\n",&c,&nofac,&nbcont);
		nb_contour_total+=nbcont;
		for(k=0;k<nbcont;k++)
			{
			 fscanf(pfic,"%f\n",&valeur);
			}
		}
	fclose(pfic);

	printf("\nnombre de faces %d\nnombre de contours total %d\n\n",nbfac,nb_contour_total);

	// Alloue et Initialise les valeurs

	val_min = alloue_float(nb_contour_total,123);
	heure_val_min = alloue_float(nb_contour_total,123);
	val_max = alloue_float(nb_contour_total,123);
	heure_val_max = alloue_float(nb_contour_total,123);
	val_cum = alloue_float(nb_contour_total,123);

	// Ouvre les fichiers r�sultats
	// A VOIR val_min val_max

	sprintf(buf,"%s_val_min",argv[1]);
    compose_nom_complet(nom,s_dir,buf,"val");
	if ((pfic1=fopen(nom,"w"))==NULL)
      { printf("\n  impossible ouvrir %s\n\n", nom); 
		exit(0);
      }
	fprintf(pfic1,"%d %d %f %f\n",nbfac,nomax,min,max);	

	sprintf(buf,"%s_heure_val_min",argv[1]);
	compose_nom_complet(nom,s_dir,buf,"val");
	if ((pfic2=fopen(nom,"w"))==NULL)
      { printf("\n  impossible ouvrir %s\n\n", nom); 
		exit(0);
      }
	fprintf(pfic2,"%d %d %d %d\n",nbfac,nomax,hdeb,hfin);	

	sprintf(buf,"%s_val_max",argv[1]);
    compose_nom_complet(nom,s_dir,buf,"val");
	if ((pfic3=fopen(nom,"w"))==NULL)
      { printf("\n  impossible ouvrir %s\n\n", nom); 
		exit(0);
      }
	fprintf(pfic3,"%d %d %f %f\n",nbfac,nomax,min,max);	

    sprintf(buf,"%s_heure_val_max",argv[1]);
	compose_nom_complet(nom,s_dir,buf,"val");
	if ((pfic4=fopen(nom,"w"))==NULL)
      { printf("\n  impossible ouvrir %s\n\n", nom); 
		exit(0);
      }
	fprintf(pfic4,"%d %d %d %d\n",nbfac,nomax,hdeb,hfin);	

	sprintf(buf,"%s_val_moy",argv[1]);
    compose_nom_complet(nom,s_dir,buf,"val");
	if ((pfic5=fopen(nom,"w"))==NULL)
      { printf("\n  impossible ouvrir %s\n\n", nom); 
		exit(0);
      }
	fprintf(pfic5,"%d %d %f %f\n",nbfac,nomax,min,max);	

	sprintf(buf,"%s_val_cumul",argv[1]);
    compose_nom_complet(nom,s_dir,buf,"val");
	if ((pfic6=fopen(nom,"w"))==NULL)
      { printf("\n  impossible ouvrir %s\n\n", nom); 
		exit(0);
      }
	fprintf(pfic6,"%d %d %f %f\n",nbfac,nomax,min,max);	

	// Lit les descripteurs de hdeb � hfin et g�re les valeurs

	for (i=hdeb;i<=hfin;i++)
	{

	  // lecture du  val � heure =i

		if (i < 10 ) sprintf(buf,"%s_0%dh00",argv[1],i);
		else sprintf(buf,"%s_%dh00",argv[1],i);
		compose_nom_complet(nom,s_dir,buf,"val");
		printf("\n  traite : %s \n", nom);

		if ((pfic=fopen(nom,"r"))==NULL)
		{ 
			printf("\n  impossible ouvrir %s\n\n", nom); 
			exit(0);
		}

		fscanf(pfic,"%d %d %f %f",&nbfac,&nomax,&min,&max);	
		nc=0;
		for(j=0;j<nbfac;j++)
		{
			fscanf(pfic,"\n%c%d%d\n",&c,&nofac,&nbcont);
			if(i==hfin)
			{	// ecrit la face
			 fprintf(pfic1,"f%d %d\n",nofac,nbcont);
			 fprintf(pfic2,"f%d %d\n",nofac,nbcont);
			 fprintf(pfic3,"f%d %d\n",nofac,nbcont);
			 fprintf(pfic4,"f%d %d\n",nofac,nbcont);
			 fprintf(pfic5,"f%d %d\n",nofac,nbcont);
			 fprintf(pfic6,"f%d %d\n",nofac,nbcont);
			}					
	
			for(k=0;k<nbcont;k++)
			{
				fscanf(pfic,"%f\n",&valeur);
				if(i==hdeb)
				{	// place les valeurs
					val_min[nc] = valeur;
					heure_val_min[nc] = hdeb;
					val_max[nc] = valeur;
					heure_val_max[nc] = hdeb;
					val_cum[nc] = valeur;
				}
				else
				{	// test les valeurs
					if(valeur < val_min[nc])
					{ val_min[nc] = valeur;
					  heure_val_min[nc] = i;
					}
					if(valeur > val_max[nc])
					{ val_max[nc] = valeur;
					  heure_val_max[nc] = i;
					}
					val_cum[nc] += valeur;
				}

				if(i==hfin)
				{	// ecrit les valeurs
				 fprintf(pfic1,"%f\n",val_min[nc]);
				 fprintf(pfic2,"%f\n",heure_val_min[nc]);
				 fprintf(pfic3,"%f\n",val_max[nc]);
				 fprintf(pfic4,"%f\n",heure_val_max[nc]);
				 fprintf(pfic5,"%f\n",val_cum[nc]/(hfin-hdeb+1));
				 fprintf(pfic6,"%f\n",val_cum[nc]);	
				}

				nc++;
			}
		}
	fclose(pfic);
	}

	printf(" \nFin du traitement analyse_val_tps\n");

    creer_OK_Solene();
	exit(0);
	}


/*_________________________________________________________________*/
/* Format de la fonction  */
void usage_analyse()
	{
  	printf("\n   format d'entree des parametres\n\n");
  	printf("   analyse_val_tps   nom_descripteur_a_traiter_fonction_du_temps  heure_debut heure_fin\n\n");
	printf("   les fichiers analyses sont des fichiers .val construits comme suit :\n");
	printf("            nom_descripteur_a_traiter_fonction_du_temps_**h00 \n");
	printf("            ** variant de heure_d�but � heure_fin par pas d'une heure\n");
	printf("   Cr�e en sortie les fichiers descripteurs suivants:\n");
	printf("	nom_descripteur_a_traiter_fonction_du_temps_val_min\n");
	printf("	nom_descripteur_a_traiter_fonction_du_temps_heure_val_min\n");
	printf("	nom_descripteur_a_traiter_fonction_du_temps_val_max\n");
	printf("	nom_descripteur_a_traiter_fonction_du_temps_heure_val_max\n");
	printf("	nom_descripteur_a_traiter_fonction_du_temps_val_moy\n");
	printf("	nom_descripteur_a_traiter_fonction_du_temps_val_cumul\n");
  	exit(0);
	}

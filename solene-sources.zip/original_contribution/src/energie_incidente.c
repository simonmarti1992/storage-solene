/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/*

cc energie_incidente.c solaire.o  -o energie_incidente -lm 

*/

#include<solene.h>

/*******************************************************/
/* genere energie solaire incidente pour plan recepteur */
/*******************************************************/
main(argc,argv)
 int argc;char **argv;

{
double latitude,heure_lever,declin,hm,azi,haut,incidence;
double incl,orien,dorien,dincl,ang_incid,rn,h,b1,g1,b,fi,g,d,albedo;
double dtemp;
double xyzsol[3],vnorm[3];
int ciel,direct,diffus,global;
int jour,mois,hh,minute,i;
int hdeb,mindeb,hfin,minfin,minpas;
long deb,fin;
char c,cc[2];
double vx,vy,vz,lgv;

         if(argc<6)format_entree_energie_incidente();
         sscanf(argv[1],"%lf",&(latitude));
  	 sscanf(argv[2],"%d%c%d",&jour,&c,&mois);
         if(c != '/')format_entree_energie_incidente();
         sscanf(argv[3],"%d%c%d",&hh,&c,&minute);
	 if(c != ':')format_entree_energie_incidente();
         if(jour<1|| jour>31||mois<1||mois>12)
		{ printf("   *** jour/mois incorrect ***\n");
		  exit(0);
		}
	if(hh<0 || hh>24 || minute <0 || minute>60)	
		{ printf("   *** pas_hh:pas_mn incorrect ***\n");
		  exit(0);
		}
	if(hh==0 && minute==0) minpas=60;
	else minpas=hh*60+minute;

         sscanf(argv[4],"%lf",&incl);
         if(incl<-90 || incl>90)
		{ printf("   *** inclinaison incorrecte ***\n");
		  exit(0);
		}

         sscanf(argv[5],"%lf",&orien);
         if(orien<-180 || orien>180)
		{ printf("   *** orientation incorrecte ***\n");
		  exit(0);
		}

	albedo=.2; fi=1; ciel=2;
         for(i=6;i<argc;i+=2)
            { sscanf(argv[i],"%c%c",cc,cc+1);
              if(cc[0]!='-')format_entree_energie_incidente();
              if(cc[1]=='a')
		{ /* albedo */
		  sscanf(argv[i+1],"%lf",&albedo);
		  if(albedo<0 || albedo >1)
		    { printf("   *** albedo incorrect ***\n");
		      exit(0);
		    }
		}
              else if(cc[1]=='f')
		{ /* fraction insolation */
		  sscanf(argv[i+1],"%lf",&fi);
		  if(fi<0 || fi >1)
		    { printf("   *** fraction insolation incorrecte ***\n");
		      exit(0);
		    }
		}
              else if(cc[1]=='c')
		{ /* ciel 1 2 ou 3 */
		  sscanf(argv[i+1],"%df",&ciel);
		  if(ciel<1 || ciel >2)
		    { printf("   *** ciel(1 2 ou 3) incorrect ***\n");
		      exit(0);
		    }
		}
              else format_entree_energie_incidente();
            }

  /* info date */
    i=numjour(jour,mois);
    i=(i-1)%365+1;          
    declin=declinaison(i);   
printf(" declinaison      = %.2lf\n",angdeg(declin));

    heure_lever=anglev(declin,angrad(latitude));
    anglehoraire_EN_heure_et_minute(heure_lever,&hdeb,&mindeb);
	if(mindeb<10) printf(" heure de lever   = %2dH0%d\n",hdeb,mindeb);
	else printf(" heure de lever   = %2dH%d\n",hdeb,mindeb);
    anglehoraire_EN_heure_et_minute(-heure_lever,&hfin,&minfin);
	if(minfin<10) printf(" heure de coucher = %2dH0%d\n",hfin,minfin);
	else printf(" heure de coucher = %2dH%d\n",hfin,minfin);
 
 
	printf("\nEnergie incidente sur plan de normale (%6.2lf,%6.2lf)\n\n",incl,orien);
	printf(" lat: %6.2lf date: %d/%d  albedo: %4.2lf  fi: %4.2lf ciel: %d\n\n",latitude,jour,mois,albedo,fi,ciel);

	printf(" heure     azimut  hauteur    DIR   DIF   GLO   incidence\n\n");

   dorien=angrad(orien); dincl=angrad(incl);

   deb=60*hdeb; fin=60*hfin+minfin;
   while(deb < (60*hdeb+mindeb)) deb+=minpas;
   while(deb<fin)
     {
	hh=deb/60; minute=deb%60;

	info_solaire(latitude,jour,mois,hh,minute,xyzsol,&azi,&haut);
	vx= -sin((double)azi);
	vy= -cos((double)azi);
	vz= tan((double)haut);
printf("COMPOSANTES SOLEIL %f %f %f \n",vx,vy,vz);
   lgv=sqrt(vx*vx+vy*vy+vz*vz);
   printf("COMPOSANTES SOLEIL %f %f %f \n",vx/lgv,vy/lgv,vz/lgv);

		/* angle incidence pour le plan recepteur */
	vcompxyz(dorien,dincl,vnorm);
	printf("composantes normale du plan : %f %f %f\n", vnorm[0],vnorm[1],vnorm[2]);
	ang_incid=vincid(vnorm,xyzsol,&dtemp);
	printf("ANGLE_INCIDENCE %f\n", ang_incid);

	printf("composantes du soleil : %f %f %f\n", xyzsol[0],xyzsol[1],xyzsol[2]);
	d=sqrt(vnorm[0]*vnorm[0]+vnorm[1]*vnorm[1]+vnorm[2]*vnorm[2]);
	printf("D %f\n", d);

	d=d*sqrt(xyzsol[0]*xyzsol[0]+xyzsol[1]*xyzsol[1]+xyzsol[2]*xyzsol[2]);
	printf("D %f\n", d);

	printf("sinus azimut : %f\n", sin(azi));
	printf("INCIDENCE %f\n", acos(sin(azi))*180./3.14159);
	if(ang_incid>0)
     		{ incidence=acos(ang_incid);
       		  incidence=angdeg(incidence);
     		}
	else incidence=-999;
		/* rn=rii(haut,ciel)         direct normal */
	rn=rii(haut,ciel);
		/* b1=rbsolclair(h,rn)    direct au sol */
	b1=rbsolclair(haut,rn);
		/* g1=rgsolclair(h,ciel)  global au sol */
	g1=rgsolclair(haut,ciel);
		/* b=rbsol(b1,fi)         direct moyen au sol */
	b=rbsol(b1,fi);
		/* g=rgsol(g1,fi)         global moyen au sol */
	g=rgsol(g1,fi);
		/* d=g-b                  diffus moyen au sol */
	d=rdsol(b,g);
		/* flux direct diffud et global sur face */
	direct=0;
	if(ang_incid>0) direct=rbplan(rn,ang_incid,fi);
	diffus=rdplan(d,g,albedo,dincl);
	global=direct+diffus;
        if(incidence<0)
	   { if(minute<10) printf(" %2dH0%d :  %7.2lf  %7.2lf  %5d %5d %5d\n",hh,minute,angdeg(azi),angdeg(haut),direct,diffus,global);
	     else printf(" %2dH%2d :  %7.2lf  %7.2lf  %5d %5d %5d\n",hh,minute,angdeg(azi),angdeg(haut),direct,diffus,global);

	   }
        else
	   { if(minute<10) printf(" %2dH0%d :  %7.2lf  %7.2lf  %5d %5d %5d    %5.2lf\n",hh,minute,angdeg(azi),angdeg(haut),direct,diffus,global,incidence);
	     else printf(" %2dH%2d :  %7.2lf  %7.2lf  %5d %5d %5d    %5.2lf\n",hh,minute,angdeg(azi),angdeg(haut),direct,diffus,global,incidence);

	   }

	deb+=minpas;
     }
 	system("cat /dev/null >OK_SOLENE");
}

/*_________________________________________________________________*/
format_entree_energie_incidente()
{
  printf("\n   format d'entree des parametres \n\n");
  printf("   *energie_incidente* latitude jour/mois pas_hh:pas_mn inc_norm orien_norm [-a albedo] [-c ciel(1,2,3)] [-f fraction_insolation]\n\n");

  printf("   Valeurs par Defaut :\n");
  printf("      - albedo =.2\n");
  printf("      - ciel   = 2\n");
  printf("      - f.ins  = 1\n");


  printf("   Convention pour definir la Normale :\n");
  printf("      - inclimaison >0 vers le haut (0 a 90) et <0 vers le bas\n");
  printf("      - orientation 0=sud  <0 vers Est et >0 vers Ouest\n\n");

  exit(0);
}

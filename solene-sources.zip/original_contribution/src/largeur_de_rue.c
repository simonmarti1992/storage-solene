/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

// largeur_de_rue

// D. GROLEAU juin 2003


#include <solene.h>
void format_entree();

// pour d�terminer largeur de rue dans une trame urbaine carr�e
// compos�e de 3 * 3 blocs carr�s construit
// connaissant la surface totale de l'emprise de la rue
// et la dimension du d'un bloc
/*----------------------------------------------------------------------*/
main(argc,argv)
int argc;char **argv;
{
 
double surfR, dimB, Wrue;

 if(argc<2) format_entree();

	printf("fonction : Largeur de rue\n");

	sscanf(argv[1],"%lf",&surfR);
	sscanf(argv[2],"%lf",&dimB);
	printf("surface rue  = %lf \n",surfR);
	printf("dim Bloc     = %lf \n",dimB);


	// formule :  largeur de la rue Wrue telle que : 9*Wrue*Wrue +18*WRue*dimB = surfR
	// donc          9*Wrue*Wrue +18*WRue*dimB - surfR =0
	// et Wrue = (-b +- SQRT(b2-4ac))/2a

	Wrue= (-18.0*dimB + sqrt(18.0*18.0* dimB* dimB + 4.0*9.0*surfR))/(2.0*9.0);
	printf("Largeur = %lf \n",Wrue);
}
 
/*_________________________________________________________________*/
void format_entree()
{
  printf("\n   largeur_de_rue  surface_de_rue  dim_bloc\n\n");
  exit(0); 
}

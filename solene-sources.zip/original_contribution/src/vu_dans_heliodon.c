/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

//D.Groleau mars 2001
/*
cc vu_dans_heliodon.c   solutile.o geomutile.o lib_solene_94.o -o vu_dans_heliodon -lm
*/

/*****************************************************************/
/* calcule geometrie vue dans heliodon, decompose et produit descripteur vu */
/*****************************************************************/

#include<solene.h>
#include<ctype.h>



/*_________________________________________________________________*/
main(argc,argv)			
 int argc;char **argv;
{int i;
char *s_dir;
char buf[256],buf1[512],buf2[500];

         s_dir=(char *)getenv("PWD");

         if(argc<8)format_entree();

//COMPOSE  et lance LA COMMANDE pour Heliodon 
sprintf(buf,"heliodon %s %s %s %s %s %s\\XXXXVU",argv[1],argv[2],argv[3],argv[4],argv[5],getenv(SOLENETEMP));

printf("\n commande = %s\n",buf);
system(buf);

//test si la commande Heliodon s'est bien passe */
//MODIF SII DFA 24-4-2006
if ( ! existOkSolene()) {
	printf("\n PB execution de heliodon  ou heliodon_select\n");
	exit(0);
}
cleanOkSolene();

// compose et lance la commande decompose_cir_val
sprintf(buf2,"decompose_cir_val %s %s\\XXXXVU %s",argv[1],getenv(SOLENETEMP), argv[6]); // SII DFA 24-4-2006
printf("\n commande = %s\n",buf2);
system(buf2);

  /* test si la commande decompose_face s'est bien passe */
if (!existOkSolene()) 	
	{ printf("\n PB execution de decompose_face\n");
	  exit(0);
	}
cleanOkSolene();

// del de XXXXVU
cleanFileTmpSolene("XXXXVU.cir"); //SII DFA 24-4-2006
// del fichier creer argv[6].eta
compose_nom_complet(buf,s_dir,argv[6],"eta");
sprintf(buf1,"del %s",buf);
printf("%s\n",buf1);
system(buf1);

// renomme le fichier descripteur nom_out_0.val en argv[7].val
sprintf(buf,"%s_0",argv[6]);
compose_nom_complet(buf1,s_dir,buf,"val");

compose_nom_complet(buf,s_dir,argv[7],"val");
sprintf(buf2,"copy %s %s",buf1,buf);
printf("%s\n",buf2);
system(buf2);

sprintf(buf2,"del %s",buf1);
printf("%s\n",buf2);
system(buf2);
       
creer_OK_Solene();

/* liste_des_pointeurs(); */

}


/*_________________________________________________________________*/
format_entree()
{
  printf("\n   format d'entree des parametres \n\n");
  printf(" *vu_dans_heliodon* fichier_select_in(.cir) fichier_masque_in(.cir) jour/mois heure:minute latitude  geom_out(.cir) descripteur_vu(.val)[-n]\n\n");
  exit(0);
}

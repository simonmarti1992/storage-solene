/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/*__________________________  fluent_val_to_solene.c   __________________________ */
//
// D.Groleau, janvier 2003
// modifi� D.Groleau oct 2003 (changement de format du fichier .dat de Fluent)
// modifi� D.Groleau dec 2003 (on affecte valeur V_DEFAUT=1000 si pas de correspondance entre noeuds Fluent et Solene)
// modifi� D.Groleau jan 2004 (on ajoute un param�tre par d�faut, pour �valuer correspondance en 3D (d�faut) ou en 2D)
/*______________________________________________________________________    */
/* Pour couplage Solene - Fluent   (r�cup�ration des valeurs de Fluent */
/* Pour fichier de geometrie.cir triangul�		  */
/* cr�e un fichier de descripteur .val,  		      */
/*  a partir de donn�es FLUENT(fichier profile)
	on r�cup�re le centre de gravit� des mailles et la valeurs associ�e
*/
/*______________________________________________________________________  */


#include<solene.h>


void format();
int lit_fic_fluent();
void test_min_max();

#define V_DEFAUT 1000

/*_________________________________________________________________*/
main(argc,argv)           
int argc;char **argv;
	{

/*--------------*/
/* Declarations */
/*--------------*/

	char *rep_courant;		/* repertoire courant */
	FILE *pficg, *pficv, *pficr ;	/* pointeurs pour manips fichiers */
	char nom_geometrie[256];				/* fichier de geometrie lu */
	char nom_valeur[256];					/* fichier de valeur � cr�er (descripteur) */ 
	char nom_fluent[256];					    /* fichier de valeurs n3s  */
	
	int nbfac,nomax;			    /* nombre de faces d'apres le fichier de geometrie */
	double englob[10];
	int nb_contour_total;		/* nombre total de contours */
	double *valeur_n3s,*x_n3s,*y_n3s,*z_n3s;	/* valeurs lues de N3S ou Fluent*/

	struct modelisation_face *fac;	/* faces */
 	struct contour *pcont;		/* id. */
	struct circuit *pcir;		/* id. */

	int		nf,i;					
	int		nb_val_n3s;
	int		oui,noc;
	double	epsi =0.001;
	double	xg,yg,zg, flux;
	double	vmin_gen,vmax_gen;

	int		en_2D;

/*-----------------------------*/
/* lecture parametres commande */
/*-----------------------------*/

	rep_courant = (char *)getenv("PWD");  

   	if(argc<4) format(); 
 
	printf("\nFonction SOLENE: fluent_val_to_solene\n");

		// correspondance maillages Fluent et Solene en 2D ou en 3D	
		en_2D=0;
		if(argc==5)
		{  sscanf(argv[4],"%d",&en_2D);
		   if(en_2D!=1) format();
		}

    compose_nom_complet(nom_geometrie,rep_courant,argv[1],"cir");  
        printf("\n\nFichier de geometrie : %s \n",nom_geometrie); 

	compose_nom_complet(nom_fluent,rep_courant,argv[2],"dat");  
        printf("Fichier  n3s         : %s \n",nom_fluent);

	compose_nom_complet(nom_valeur,rep_courant,argv[3],"val");  
        printf("Fichier de valeur    : %s \n",nom_valeur);


/* fichiers en input */

       if((pficg=fopen(nom_geometrie,"r"))==NULL)
		{
        	printf("\n impossible ouvrir %s\n",nom_geometrie); 
			exit(0);
		}

	   /* Lecture fichier geometrie a traiter */
       lit_en_tete(pficg,&nbfac,&nomax,englob);      
       fac=alloue_face(nbfac,34);
       lit_fic_cir3d(pficg,nbfac,fac);
       fclose(pficg);
	   //
	   // nb de contours du fichier
	   nb_contour_total = nbcontours_total(fac, nbfac);

	   // Lit fichier des valeurs de FLUENT
	   if((pficr=fopen(nom_fluent,"r"))==NULL)
		{
        	printf("\n impossible ouvrir %s\n",nom_fluent); 
			exit(0);
		}
	   // Allocation du tableau des valeurs_n3s FlLUENT*/
	   // alloue nb_contour_total valeurs
	   // ATTENTION si plus de valeurs fluent
	   printf("  nb de faces %d ; nb de contours Solene %d\n",nbfac,nb_contour_total);
	   valeur_n3s = alloue_double(nb_contour_total,457);
	   x_n3s = alloue_double(nb_contour_total,457);
	   y_n3s = alloue_double(nb_contour_total,457);
	   z_n3s = alloue_double(nb_contour_total,457);

	   nb_val_n3s=lit_fic_fluent(pficr,valeur_n3s,x_n3s,y_n3s,z_n3s,nb_contour_total);
	   fclose(pficr);
	   	
	   printf("  nb de contours Solene %d\n  nb de val fluent %d\n",nb_contour_total,nb_val_n3s);
/*
		for(i=0; i< nb_val_n3s ; i++)
			{
				printf("%d %f %f %f %f\n",i+1, x_n3s[i],y_n3s[i],z_n3s[i],valeur_n3s[i]);
			}
*/

 // ouvre le fichier de valeurs � �crire en OUTPUT     
       if((pficv=fopen(nom_valeur,"w"))==NULL)
		{
            printf("\n impossible ouvrir %s\n",nom_valeur); 
			exit(0);
  		}
          
/*------------------------------------------------------------*/
/* affectation des valeurs de  Fluent aux contours de Solene     */
/*------------------------------------------------------------*/
		/* calcule min_max   */
		vmin_gen=10000000.; vmax_gen=-vmin_gen;

  fprintf (pficv,"%6d %6d %15.4f %15.4f\n", nbfac, nomax,vmin_gen,vmax_gen);   

  for(nf=0;nf<nbfac;nf++) 
  {
	pcont=(fac+nf)->debut_projete;
	fprintf (pficv,"f%d %d\n", fac[nf].nofac_fichier, nb_contour_face(fac+nf,1));   
	noc=0;
    while(pcont) 	
    { pcir=pcont->debut_support; 
	  
	 // cherche valeur � affecter au contour
	 // normalement, on trouve le correspondant du centre de gravit� du contour
	 //              dans la liste des points fournis par FLUENT
	 centre_de_gravite(pcir,&xg,&yg,&zg);
	 oui=0;
	 //printf("test Solene %f %f %f\n", xg,yg,zg);
	 for (i =0 ; i< nb_val_n3s; i++)
	 {
		 if(en_2D==0)  // en 3D
		 {
			//printf("  avec n3s  %f %f %f\n", x_n3s[i],y_n3s[i],z_n3s[i]);
			if(fabs(xg - x_n3s[i]) < epsi && fabs(yg - y_n3s[i]) < epsi && fabs(zg - z_n3s[i]) < epsi)
				{ flux = valeur_n3s[i]; 
				  oui = 1;
				  break;
				}
		 }
		 else			// en 2D
		 { 	if(fabs(xg - x_n3s[i]) < epsi && fabs(yg - y_n3s[i]) < epsi)
				{ flux = valeur_n3s[i]; 
				  oui = 1;
				  break;
				}
		 }

	 }
	  // on a trouver un noeud qui correspond au point, sinon pb
	 if(oui==0)
	 { //printf("pb de correspondance face: %d contour %d\n",fac[nf].nofac_fichier,noc+1); 
		 // pas de correspondance on attribue la valeur 1000;
         fprintf (pficv," %d\n",V_DEFAUT);  
	 }
	 else
	 {   // on attribue la valeur flux au contour
	     test_min_max(flux,&vmin_gen,&vmax_gen);
	     fprintf (pficv," %.5f\n", flux);
	 }
	 noc++;
	 pcont=pcont->suc; 
	} 
  }

  // r�ecrit en-tete de val
  rewind(pficv);
  fprintf (pficv,"%6d %6d %15.4f %15.4f\n", nbfac, nomax,vmin_gen,vmax_gen);   
  fclose(pficv);

/* Desallocations */
    desalloue_fface(fac,nbfac);
	desalloue_double(valeur_n3s);
	desalloue_double(x_n3s);
	desalloue_double(y_n3s);
	desalloue_double(z_n3s);
       	
	printf(" fin du traitement\n\n");
}

/*_________________________________________________________________*/
int lit_fic_fluent(pf,val,x,y,z,nbcontour)
FILE *pf;
double *val,*x,*y,*z;
int nbcontour;
{
 char buf[128],c[2];
 int i, nbp, no;

	no=0;
	while(1)
	{ if(fscanf(pf,"%s",buf)==EOF) break;
	  // lit en tete de face et nb de points maillage
	  //printf("%s ",buf);
	  fscanf(pf,"%s",buf); 	  //printf("%s ",buf);
	  fscanf(pf,"%d",&nbp);   //printf("%d ",nbp);
	  fscanf(pf,"%c",c);   //printf("%c\n",c[0]);

	  //lit x
	  //printf("lit les x\n");
	  fscanf(pf,"%s",buf); 	  //printf("%s\n",buf);
	  for(i=0;i<nbp;i++)
	  { fscanf(pf,"%lf",x+no+i);   //printf("%f\n ",x[no+i]);
	    //printf("%d, %d \n", nbp,i+1);
		if(no +i> nbcontour)
		{ printf("un PB: plus de points FLUENT que de contours SOLENE\n");
		  exit(0);
		}
	  }
	  fscanf(pf,"%s",buf);   //printf("OK1 fin :%s\n",buf);

  	  //lit y
	  //printf("lit les y\n");
	  fscanf(pf,"%s",buf); 	  //printf("%s\n",buf);
	  for(i=0;i<nbp;i++)
	  { fscanf(pf,"%lf",y+no+i);   //printf("%f\n ",y[no+i]);
	    //printf("%d, %d \n", nbp,i+1);
		if(no > nbcontour)
		{ printf("un PB: plus de points FLUENT que de contours SOLENE\n");
		  exit(0);
		}
	  }
	  fscanf(pf,"%s",buf);   //printf("OK1 fin :%s\n",buf);

  	  //lit z
	  //printf("lit les z\n");
	  fscanf(pf,"%s",buf); 	  //printf("%s\n",buf);
	  for(i=0;i<nbp;i++)
	  { fscanf(pf,"%lf",z+no+i);   //printf("%f\n ",z[no+i]);
		if(no +i > nbcontour)
		{ printf("un PB: plus de points FLUENT que de contours SOLENE\n");
		  exit(0);
		}
	  }
	  fscanf(pf,"%s",buf);   //printf("OK1 fin :%s\n",buf);

  	  //lit valeur
	  //printf("lit les valeurs\n");
	  fscanf(pf,"%s",buf); 	 //printf("%s\n",buf);
	  for(i=0;i<nbp;i++)
	  { fscanf(pf,"%lf",val+no+i);   //printf("%f\n ",val[no+i]);
		if(no +i > nbcontour)
		{ printf("un PB: plus de points FLUENT que de contours SOLENE\n");
		  exit(0);
		}
	  }
	  fscanf(pf,"%s",buf);   //printf("OK1 fin :%s\n",buf);
	  
	  // lit fin de face
	  fscanf(pf,"%s",buf);   //printf("OK1 fin :%s\n",buf);
	  //printf("fin de face\n");

	  no=no+nbp;
	  //printf("no=%d\n",no);

	} // fin de While

	return(no);
}

/*_________________________________________________________________*/
void test_min_max(x,vmin_gen,vmax_gen)
double x;
double *vmin_gen,*vmax_gen;
{
		 if(x < *vmin_gen) *vmin_gen =  x;
         if(x > *vmax_gen) *vmax_gen =  x;
}


/*_________________________________________________________________*/
void format()
	{
  	printf("Transfert de valeurs fournies par Fluent � Solene sur un maillage 3D \n\n");	
	printf("\n   format d'entree des parametres \n\n");
  	printf("fluent_val_to_solene\n");
	printf("IN   maillage_a_traiter(.cir)\n");
	printf("IN   fichier_valeur_fluent(.dat)\n"); 
	printf("OUT  fichier_resultat(.val) \n");
	printf("[IN]   correspondance_en_2D  \n\n");

	printf("NOTA: les correspondances entre les maillage Fluent et Solene \n");	
	printf("      sont �tablis par d�faut en 3D, sauf si le param�tre optionnel correspondance_en-2D\n");	
	printf("      est pr�sent et mis � 1 dans la ligne de commande \n\n");	
	printf("NOTA: les valeurs Ffluent sont transmises au fichier solene maillage_a_traiter(.cir) \n");
	printf("      quand on trouve un contour Solene correspondant au contour transmis par Fluent,\n"); 
	printf("      sinon on donne une valeur arbitraire de 1000 au contour Solene\n\n");

  	exit(0);
	}

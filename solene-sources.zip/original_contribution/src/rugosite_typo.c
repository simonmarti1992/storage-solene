/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/*

cc rugosite_typo.c -o rugosite_typo ~marenne/newsolene/solutile.o ~marenne/newsolene/geomutile.o ~marenne/newsolene/face_op_face.o ~marenne/newsolene/poly_op_poly.o ~marenne/newsolene/lib_solene_94.o -lm


  D.GROLEAU 
	modifi� 20 f�vrier 2003 (statistique d'exposition des fa�ades)
*/
// s'applique � des contours 2D
/*_________________________________________*/
/* DESCRIPTION
  pour un fichier .cir , 

*/
#include <solene.h>

// d�claration Functions
void angles_poly();
int classe_dir();
int classe_dir_exp();
int convex_pol();
void direction_arete_poly();
void evalue_surf_frontale_par_classe();
void expo_arete_poly();
void initialise_classe_surf_front();
void imprime_classar();
void imprime_classe_dir();
void imprime_classar_exp();
void imprime_classe_exp();
void imprim_rugosite();
void imprim_surf_front();
void format_entree();
void l_exposition_des_aretes();
void la_convexite();
void la_direction_des_aretes();
void la_surface();
void le_nb_arete();
void le_nb_de_trou();
void le_perimetre();
void les_angles_du_poly();
void les_surf_lateral();
void normale_vert();
void surf_lat_arete_poly();
void traite();

//extern int option_calcul_z; 

int 	nbclasse_dir;
int d_ang;   /* angle d'analyse des surfaces frontales */
double surf_frontale[36],rugosite[36];

/*_________________________________________*/
/* declarations */

FILE *fsource,*fdest;
int nbfac1;
struct modelisation_face	*fac1;

double dir_arete_poly();
double longueur_arete_poly();
double norm_arete_poly();

double surf_plein,per_plein;
double surf_total_plein_englobant,surf_total_plein_vide,surf_total_vide;
double peri_total_plein_englobant;
double surf_terrain, hauteur_my_bati;

struct dir_arete { double angle;
	 	   double longar;
		 } classar[8],classar_exp[8];
double total_longar,total_longar_exp;
int nb_de_vide;

/*________________________________________________________________________*/
main(argc,argv)
char **argv;
int  argc ;
{
char 	buf[512],*s_dir;
double	englob[10],rayon,coef_compac;
int nomax1;
double surf_my_des_plein,peri_my_des_plein;

 if(argc!=4)
   { format_entree();
     exit(0);
   }
printf("Fonction : rugosite_typo\n\n");
 s_dir=(char *)getenv("PWD");

 compose_nom_complet(buf,s_dir,argv[1],"cir");
 if((fsource = fopen(buf, "r"))==NULL)
	{ printf("\n impossible ouvrir %s\n",buf);
	  exit(0);
        }

 sscanf(argv[2],"%lf",&surf_terrain);
 sscanf(argv[3],"%lf",&hauteur_my_bati);


   lit_en_tete(fsource,&nbfac1,&nomax1,englob);
   fac1=alloue_face(nbfac1,1000);
   lit_fic_cir3d(fsource,nbfac1,fac1); 
   fclose(fsource);

  /* initialise valeurs globales */

 surf_total_plein_englobant=0;
 surf_total_plein_vide=0;
 surf_total_vide=0;
 total_longar=0;
 total_longar_exp=0;

 nb_de_vide=0;
 peri_total_plein_englobant=0;

 d_ang=15;
 initialise_classe_surf_front();

 nbclasse_dir=8;
 imprime_classe_dir();

  /* TRAITE  chaque face */

  printf(" traitement en cours\n");
//  option_calcul_z=1;

  traite();

  desalloue_fface(fac1,nbfac1);

 /* imprime TOTAUX */

 printf("\nLES TOTAUX : \n");
 printf(" nb_de_plein  (englobant)   = %d\n",nbfac1);
 printf(" apprecier la distribution (homogene, repartie, lineaire...)\n");

 printf(" nb_de_vide (trous inter.)  = %d\n",nb_de_vide);

 printf(" surf_total_plein_englobant = %f\n",surf_total_plein_englobant);
 printf(" surf_total_vide            = %f\n",surf_total_vide);
 printf(" surf_total_plein-vide      = %f\n",surf_total_plein_vide);

 printf(" peri_total_plein_englobant = %f\n",peri_total_plein_englobant);

      /* S/P et coef COMPACITE du PLEIN ENGLOBANT */
      /* nota : pourrait aussi etre fait en tenant compte des vides */
/* EN COMMENTAIRE  car le calcul globalise n'est pas juste */
/*
  coef_compac=(surf_total_plein_englobant/peri_total_plein_englobant);
  printf(" SURF PLEIN englobant/PER englobant  = %lf\n",coef_compac);
  rayon=surf_total_plein_englobant/(4.*atan(1.));
  rayon=sqrt(rayon);
  rayon=rayon/2.;

printf(" S/P cercle de meme S = %lf\n",rayon);
  coef_compac=coef_compac/rayon;
printf(" compacite_plein_englobant 0< <1  = %f\n",coef_compac);
*/

 imprime_classar();

 imprime_classe_exp();

 /* imprime MOYENNES */

 printf("\nLES MOYENNES : \n");
 printf(" nb_my_de_vides_int (/nb face)  = %f\n",(float)nb_de_vide/nbfac1);

surf_my_des_plein=surf_total_plein_englobant/nbfac1;
peri_my_des_plein=peri_total_plein_englobant/nbfac1;
 printf(" surf_my_des_plein  (/nb face)  = %f\n",surf_my_des_plein);
 printf(" peri_my_des_plein  (/nb face)  = %f\n",peri_my_des_plein);

      /* S/P et coef COMPACITE du PLEIN ENGLOBANT */
      /* nota : pourrait aussi etre fait en tenant compte des vides */

  coef_compac=(surf_my_des_plein/peri_my_des_plein);
  printf(" SURF PLEIN englobant/PER englobant  = %lf\n",coef_compac);
  rayon=surf_my_des_plein/(4.*atan(1.));
  rayon=sqrt(rayon);
  rayon=rayon/2.;
printf(" S/P cercle de meme S (=R/2) = %lf\n",rayon);
  coef_compac=coef_compac/rayon;
printf(" compacite_moyenne_1_bloc_bati 0< <1  = %f\n",coef_compac);




 if(nb_de_vide)
   { printf(" surf_my_des_vides  (/nb vide)  = %f\n",surf_total_vide/nb_de_vide);
   }
 else 
   { printf(" surf_my_des_vides (/nb vide)   = 0\n");
   }

 printf(" surf_my_des_plein-vide (/nb face) = %f\n",surf_total_plein_vide/nbfac1);

 /* imprime VALEURS RAPPORTEES AU TERRAIN*/

 printf("\nLES VALEURS RAPPORTEES AU TERRAIN : \n");
 printf(" surf_terrain     = %f\n",surf_terrain);
 printf(" hauteur_my_bati  = %f\n",hauteur_my_bati);
 printf(" densite_surfacique (bati/terrain)  = %f\n",surf_total_plein_vide/surf_terrain);
 printf(" densite_surfacique (plein englobant/terrain)  = %f\n",surf_total_plein_englobant/surf_terrain);
 printf(" volumique construit  = %f\n",surf_total_plein_vide*hauteur_my_bati);
 printf(" volumique construit/surface terrain (cos volumique)  = %f\n",surf_total_plein_vide*hauteur_my_bati/surf_terrain);

 printf(" SURFACE FRONTALE (en m), en fait composante frontale des lineaires des facades\n");
 imprim_surf_front();

 printf(" DENSITE FRONTALE, valeur frontales*hmy/surf_terrain\n et la rugosite zd et z0\n");
 /*imprim_densite_front();*/
 imprim_rugosite();

    creer_OK_Solene();

 printf("fin du traitement\n");


 }

/*________________________________________________________________________*/
void traite()
{
 int 	i;
 double coef_compac,rayon;


 for(i=0;i<8;i++)
   { (classar+i)->longar=0; 
   }


 for(i=0;i<nbfac1;i++)
    { 
      printf("\nFACE no =%d\n",(fac1+i)->nofac_fichier);

      /* la face a un seul contour avec de trous possibles */

      la_surface(fac1+i);
      le_perimetre(fac1+i);

      /* S/P et coef COMPACITE */
  coef_compac=(surf_plein/per_plein);
printf(" SURF PLEIN englobant/PER englobant  = %lf\n",coef_compac);
  rayon=surf_plein/(4.*atan(1.));
  rayon=sqrt(rayon);
  rayon=rayon/2.;
printf(" S/P cercle de meme S = %lf\n",rayon);
  coef_compac=coef_compac/rayon;
printf(" coef compact 0< <1 = %lf\n",coef_compac);

      le_nb_de_trou(fac1+i);
      le_nb_arete(fac1+i);
      la_convexite(fac1+i);
printf(" Direction des aretes\n");
      la_direction_des_aretes(fac1+i);
printf(" Exposition des aretes\n");
      l_exposition_des_aretes(fac1+i);
printf(" Angles du polygone\n");
/*      les_angles_du_poly(fac1+i);*/
printf(" Les surfaces laterales\n");
	les_surf_lateral(fac1+i);


    }
}

/*________________________________________________________________________*/
void la_surface(fac)
struct modelisation_face *fac;

{
 struct contour *pcont;
 struct circuit *pcir;
 double surf_vide,surf;
 int i;

   surf_plein=0; surf_vide=0; i=0;
   pcont=fac->debut_projete;
   while(pcont)	   
       { pcir=pcont->debut_support; 
         surf_plein+=fabs(surface(pcir->nbp,pcir->x,pcir->y));
	 pcir=pcont->debut_interieur;
         while(pcir)
	      {
               surf=fabs(surface(pcir->nbp,pcir->x,pcir->y));
	       i++;
	       printf(" surf VIDE %2d = %lf\n",i,surf);
               surf_vide+=surf;
	       pcir=pcir->suc;
	      }
         pcont=pcont->suc; 
       }
   printf(" surf VIDE TOTAL = %lf\n",surf_vide);
   printf(" surf PLEIN englobant  = %lf\n",surf_plein);
   printf(" surf PLEIN-VIDE  = %lf\n",surf_plein-surf_vide);

/* fait TOTAL sur l'ensemle des faces */

 surf_total_plein_englobant+=surf_plein;
 surf_total_plein_vide+=surf_plein-surf_vide;
 surf_total_vide+=surf_vide;
   
} 

/*________________________________________________________________________*/
void le_perimetre(fac)  
struct modelisation_face *fac;

{
 struct contour *pcont;
 struct circuit *pcir;
 double per_vide,per;
 int i;


   per_plein=0; per_vide=0; i=0;
   pcont=fac->debut_projete;
   while(pcont)	   
       { pcir=pcont->debut_support; 
         per_plein+=perimetre_poly(pcir->nbp,pcir->x,pcir->y);
	 i=0;
	 pcir=pcont->debut_interieur;
         while(pcir)
	      {
               per=perimetre_poly(pcir->nbp,pcir->x,pcir->y);
	       i++;
	       printf(" perimetre VIDE %2d = %lf\n",i,per);
               per_vide+=per;
	       pcir=pcir->suc;
	      }
         pcont=pcont->suc; 
       }
   printf(" perimetre PLEIN  = %lf\n",per_plein);

   peri_total_plein_englobant+=per_plein;
   
} 

/*________________________________________________________________________*/
void le_nb_de_trou(fac)  
struct modelisation_face *fac;

{
 struct contour *pcont;
 struct circuit *pcir;
 int i;

   i=0;
   pcont=fac->debut_projete;
   while(pcont)	   
       { 
	 pcir=pcont->debut_interieur;
         while(pcir)
	      {
	       i++; 
	       pcir=pcir->suc;               
	      }
         pcont=pcont->suc; 
       }
   printf(" nb de trous  = %d\n",i);

   nb_de_vide+=i;
   
}
 
/*________________________________________________________________________*/
void le_nb_arete(fac)  
struct modelisation_face *fac;

{
 struct contour *pcont;
 struct circuit *pcir;
 int i,nb_plein,nb_vide;

   nb_plein=0; nb_vide=0; i=0;
   pcont=fac->debut_projete;
   while(pcont)	   
       { pcir=pcont->debut_support; 
         nb_plein+=pcir->nbp-1;
	 pcir=pcont->debut_interieur;
         while(pcir)
	      {
               nb_vide=pcir->nbp-1;
	       i++;
	       printf(" nb aretes VIDE %2d = %d\n",i,nb_vide);
	       pcir=pcir->suc;
	      }
         pcont=pcont->suc; 
       }
   printf(" nb d'aretes PLEIN  = %d\n",nb_plein);
   
} 

/*________________________________________________________________________*/
void la_convexite(fac)  
struct modelisation_face *fac;

{
 struct contour *pcont;
 struct circuit *pcir;
 int i,conv_plein,conv_vide;

   conv_plein=0; conv_vide=0; i=0;
   pcont=fac->debut_projete;
   while(pcont)	   
       { pcir=pcont->debut_support; 
         conv_plein=convex_pol(pcir->nbp,pcir->x,pcir->y);
	 pcir=pcont->debut_interieur;
         while(pcir)
	      {
               conv_vide=convex_pol(pcir->nbp,pcir->x,pcir->y);
	       i++;
	       if(conv_vide)printf(" trou %2d = CONVEXE\n",i);
               else printf(" trou %2d = CONCAVE\n",i);
	       pcir=pcir->suc;
	      }
         pcont=pcont->suc; 
       }
    if(conv_plein)printf(" plein   = CONVEXE\n");
    else printf("plein = CONCAVE\n");
   
} 

/*____________________________________________________________________*/

int convex_pol(nbp,x,y)
int nbp;
double *x,*y;
{
 double s,signe;
 int i;

  for(i=0;i<nbp-3;i++)
     {s=surface(3,&x[i],&y[i]);
      if(i==0) { if(s>0) signe= 1; else signe=-1; }
      else     { if(s*signe < 0) return(0); }
     }
  return(1);
}

/*________________________________________________________________________*/
void la_direction_des_aretes(fac)  
struct modelisation_face *fac;

{
 struct contour *pcont;
 struct circuit *pcir;
 int i;

   pcont=fac->debut_projete;
   while(pcont)	   
       { pcir=pcont->debut_support; 
         direction_arete_poly(pcir->nbp,pcir->x,pcir->y);
	 i=0;
	 pcir=pcont->debut_interieur;
         while(pcir)
	      {
               direction_arete_poly(pcir->nbp,pcir->x,pcir->y);
	       i++;
	       pcir=pcir->suc;
	      }
         pcont=pcont->suc; 
       }
   
} 
/*________________________________________________________________________*/
void direction_arete_poly(nbp,x,y)
int nbp;
double *x,*y;

{ int i,j;
  double ang_dir,long_arete;

  for(i=0;i<nbp-1;i++) 
   { ang_dir=dir_arete_poly(x[i],y[i],x[i+1],y[i+1]);
     long_arete=longueur_arete_poly(x[i],y[i],x[i+1],y[i+1]);
     j=classe_dir(ang_dir);  
/*     printf(" arete %d : angle %6.2lf  longueur %10.3lf, CLASSE  : %d\n",i+1,ang_dir,long_arete,j);*/
     (classar+j-1)->longar += long_arete;
     total_longar+=long_arete;
   }
}

/*________________________________________________________________________*/
double dir_arete_poly(x1,y1,x2,y2)
double x1,y1,x2,y2;
{
 double longueur,cosa,angle,x,y,xr,yr;

  longueur=longueur_arete_poly(x1,y1,x2,y2);
/*printf("\nlongueur = %lf\n",longueur);*/
  x=x2-x1; y=y2-y1;
  xr=1; yr=0;
/*printf(" x y %f %f\n",x,y);*/
  cosa=(x*xr+y*yr)/longueur;

/*printf("cos a %lf\n",cosa);*/
cosa=fabs(cosa);
/*printf("cos a %lf\n",cosa);*/

  angle=acos(cosa)*180/(4*atan(1.));
/*printf("angle = %lf\n",angle);*/
/*
  if(x>0 && y<0) angle=-angle;
  if(x<0 && y>0) angle=angle-180;
  if(x<0 && y<0) angle=-(angle-180);
  if(angle==180) angle=0;
*/
 if (x>=0 && y>0) angle=angle;
 if(x>=0 && y<0) angle=-angle;
 if(x<0 && y>0) angle =-angle;
 if(x<0 && y<0) angle=angle;

/*printf("angle = %lf\n",angle);*/
 return(angle);
  
}

/*________________________________________________________________________*/
int classe_dir(angle)
double angle;
{
 double delta,deb;
 int i;  
          /* return valeur de 1 a 8 */

  delta=180./nbclasse_dir;

  for(i=0;i<nbclasse_dir;i++)
   { /*printf("i=%d\n",i);*/
     if(i==0)
      { deb=90;
        if(angle <= deb && angle > deb-delta/2) return(1);
	deb=-90+delta/2;
/*        if(angle>=90 && angle < deb-delta/2) return(1);*/
        if(angle>=-90 && angle < deb) return(1);
      }
     else
      { deb=90-delta/2-delta*(i-1);
/*printf("deb %f\n",deb); */
        if(angle <= deb && angle > deb-delta) return(i+1);
      }
   }
 printf(" et alors .. . PB\n\n"); exit(0);
}


/*________________________________________________________________________*/
void imprime_classe_dir()
{
 double delta,deb;
 int i;

  delta=180./nbclasse_dir;
printf("delta des classes de direction : %f\n",delta);

  for(i=0;i<nbclasse_dir;i++)
   { if(i==0)
      { deb=90; 
        (classar+i)->angle=deb;
        printf(" CLASSE  1 (%6.2f) : %6.2f a %6.2f",deb,deb,deb-delta/2);
	deb=-90+delta/2;
        printf(" et  %6.2f a %6.2f\n",deb,deb-delta/2);
      }
     else
      { deb=90-delta/2-delta*(i-1); 
        (classar+i)->angle=(deb+deb-delta)/2;
       printf(" CLASSE %2d (%6.2f) : %6.2f a %6.2f\n",i+1,(deb+deb-delta)/2,deb,deb-delta);
      }
   }
}

/*________________________________________________________________________*/
void imprime_classar()
{
 double delta,deb,valp;
 int i;

  delta=180./nbclasse_dir;
 printf("\nLongueur totale des aretes = %f\n",total_longar);
 printf("\nClasse de direction des aretes\n");
  for(i=0;i<nbclasse_dir;i++)
   { valp= (classar+i)->longar/total_longar;        
     if(i==0)
      { deb=90; 
        printf(" CLASSE  1 (%6.2f) : l= %8.2f soit %6.2f\n",deb,(classar+i)->longar,valp);
      }
     else
      { deb=90-delta/2-delta*(i-1); 
        (classar+i)->angle=(deb+deb-delta)/2;
       printf(" CLASSE %2d (%6.2f) : l= %8.2f soit %6.2f\n",i+1,(deb+deb-delta)/2,(classar+i)->longar,valp);
      }
   }
}


/*________________________________________________________________________*/
double longueur_arete_poly(x1,y1,x2,y2)
double x1,y1,x2,y2;
{
 
 return(sqrt((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1)));
}

/*________________________________________________________________________*/
void les_angles_du_poly(fac)  
struct modelisation_face *fac;

{
 struct contour *pcont;
 struct circuit *pcir;
 int i;

   pcont=fac->debut_projete;
   while(pcont)	   
       { pcir=pcont->debut_support; 
         /* met circuit dans bon sens */
         if(surface(pcir->nbp,pcir->x,pcir->y)>0){ printf("inv\n");invsens(pcir);}
         angles_poly(pcir->nbp,pcir->x,pcir->y);
	 i=0;
	 pcir=pcont->debut_interieur;
         while(pcir)
	      {
                /* met circuit dans bon sens */
                if(surface(pcir->nbp,pcir->x,pcir->y)>0){ printf("inv\n");invsens(pcir);}
                angles_poly(pcir->nbp,pcir->x,pcir->y);
	        i++;
	        pcir=pcir->suc;
	      }
         pcont=pcont->suc; 
       }
   
} 
/*________________________________________________________________________*/
void angles_poly(nbp,x,y)
int nbp;
double *x,*y;

{ int i;
  double ang,x1,y1,x2,y2;

  for(i=0;i<nbp-1;i++) 
   { x1=x[i+1]-x[i]; y1=y[i+1]-y[i];
     if(i==nbp-2)
       { x2=x[1]-x[0]; y2=y[1]-y[0];
       }
     else
       { x2= x[i+2]-x[i+1]; y2=y[i+2]-y[i+1];
       }
     printf("vect  %lf scal %lf\n",x1*y2-x2*y1,x1*x2+y1*y2);
     ang=atan2(x1*y2-x2*y1,x1*x2+y1*y2);
     ang=180-ang*180/(4*atan(1.));
     if(ang>180) ang=360-ang;
     /*j=classe_angle(cos_ang);*/
     printf("angle aretes %d %d:  angle %6.2lf\n",i+1,i+2,ang);
   }
}

/*________________________________________________________________________*/
void l_exposition_des_aretes(fac)  
struct modelisation_face *fac;

{
 struct contour *pcont;
 struct circuit *pcir;
 int i, sens;

   pcont=fac->debut_projete;
   while(pcont)	   
       { pcir=pcont->debut_support; 
         if(surface(pcir->nbp,pcir->x,pcir->y)>0){ invsens(pcir); sens=1; }
	     expo_arete_poly(pcir->nbp,pcir->x,pcir->y,pcir->z,sens);
	     i=0;
	     pcir=pcont->debut_interieur;
         while(pcir)
	      {
               expo_arete_poly(pcir->nbp,pcir->x,pcir->y,pcir->z);
	       i++;
	       pcir=pcir->suc;
	      }
         pcont=pcont->suc; 
       }
   
} 

/*________________________________________________________________________*/
void expo_arete_poly(nbp,x,y,z,sens)
int nbp;
double *x,*y,*z;
int sens;

{ int i,j;
  double xnn,ynn,znn;
  double ang_exp,long_arete,cosang;

  for(i=0;i<nbp-1;i++) 
   { /*printf("Arete %d\n",i+1);*/
     //ang_dir=norm_arete_poly(x[i],y[i],x[i+1],y[i+1]);

	// evaluation de la normale
	 normale_vert(x[i],y[i],z[i],x[i+1],y[i+1],z[i+1],&xnn,&ynn,&znn,sens);

    // angle avec direction Nord (function de solaire.c);
	cosang = incid(0.,1.,0.,xnn,ynn,znn,&ang_exp);
	ang_exp = angdeg(ang_exp); // en degr�
	if(xnn<0) ang_exp= 180+ang_exp;

    long_arete=longueur_arete_poly(x[i],y[i],x[i+1],y[i+1]);
    j=classe_dir_exp(ang_exp);  
    //printf(" arete %d : angle %6.2lf  longueur %10.3lf, CLASSE  : %d\n",i+1,ang_exp,long_arete,j);
    (classar_exp+j-1)->longar += long_arete;
    total_longar_exp+=long_arete;

   }
}

/*________________________________________________________________________*/
int classe_dir_exp(angle)
double angle;
{
 double delta, deltam;
 int classe;  
  /* return valeur de 1 a 8 */

  delta=360./nbclasse_dir;
  deltam=delta/2;
  if(angle < deltam | angle >= 360-deltam) return(1);
  classe = (int) ((angle-deltam) / delta);
  return(classe+2);
}

/*________________________________________________________________________*/

// NON UTILISEE
double norm_arete_poly(x1,y1,x2,y2)
double x1,y1,x2,y2;
{
 double angle,x[3],y[3],z[3],norm[3],xr,yr,xa,ya;


 x[0]=x1; y[0]=y1; z[0]=0;
 x[1]=x2; y[1]=y2; z[1]=0;
 x[2]=x2; y[2]=y2; z[2]=1;

 normale_avec_3pts(x,y,z,norm);
/*printf("   normale : %f %f\n",norm[0],norm[1]);*/
 /* cos angle entre 2 vecteurs; l'arete et le vecteur (0,1) */
 xa=x2-x1; ya=y2-y1;
 xr=1; yr=0;
 angle=cos_angle_vec(xa,ya,xr,yr);
 angle=acos(angle)*180/(4*atan(1.));
printf("   xa,ya : %f %f\n",xa,ya);
 /* exposition de l'arete ou direction de la normale */
if(norm[0]>0) 
 {printf("   exposition (<0 Est)angle : %f\n",-angle);
 }
else printf("   exposition (<0 Est)angle : %f\n",angle);

 /* pour evaluation opposition d'orientation des normales d'aretes */
if(angle>90) angle=180-angle;
if(norm[0]>0) angle=-angle; 
printf("   exposition (0 Sud Nord -90 Est 90 Ouest : %f\n",angle);
return(angle);
  
}

/*________________________________________________________________________*/
void imprime_classe_exp()
{
 double delta,valp;

  delta=380./nbclasse_dir;
printf("\n Classes d'exposition en pourcentage (par secteur d'�tendue de %f)\n",delta);

    valp= ((classar_exp+0)->longar/total_longar_exp)*100;
	printf(" CLASSE  1 (Nord)       %f \n", valp);
    valp= ((classar_exp+1)->longar/total_longar_exp)*100;
	printf(" CLASSE  2 (Nord-Est)   %f \n", valp);
    valp= ((classar_exp+2)->longar/total_longar_exp)*100;
	printf(" CLASSE  3 (Est)        %f \n", valp);
    valp= ((classar_exp+3)->longar/total_longar_exp)*100;
	printf(" CLASSE  4 (Sud-Est     %f \n", valp);
    valp= ((classar_exp+4)->longar/total_longar_exp)*100;
	printf(" CLASSE  5 (Sud)        %f \n", valp);
    valp= ((classar_exp+5)->longar/total_longar_exp)*100;
	printf(" CLASSE  6 (Sud-Ouest)  %f \n", valp);
    valp= ((classar_exp+6)->longar/total_longar_exp)*100;
	printf(" CLASSE  7 (Ouest)      %f \n", valp);
    valp= ((classar_exp+7)->longar/total_longar_exp)*100;
	printf(" CLASSE  8 (Nord-Ouest) %f \n", valp);
	
}


/*________________________________________________________________________*/
void les_surf_lateral(fac)  
struct modelisation_face *fac;

{
 struct contour *pcont;
 struct circuit *pcir;

   pcont=fac->debut_projete;
   while(pcont)	   
       { pcir=pcont->debut_support;
         if(surface(pcir->nbp,pcir->x,pcir->y)>0){ invsens(pcir);}

          /* cherche surf laterale sur chaque arete */
	     surf_lat_arete_poly(pcir->nbp,pcir->x,pcir->y,0);


	     pcir=pcont->debut_interieur;
         while(pcir)
	      {
               if(surface(pcir->nbp,pcir->x,pcir->y)>0){ invsens(pcir);}

               /* cherche surf laterale sur chaque arete */
	       surf_lat_arete_poly(pcir->nbp,pcir->x,pcir->y,1);


	       pcir=pcir->suc;
	      }
         pcont=pcont->suc; 
       }
   
} 

/*________________________________________________________________________*/
void surf_lat_arete_poly(nbp,x,y,trou)
int nbp,trou;
double *x,*y;

{ int i;
  double vx,vy;

  for(i=0;i<nbp-1;i++) 
   { /*printf("Arete %d\n",i+1);*/

     vy=-(x[i+1]-x[i]); vx=y[i+1]-y[i];
     /* inverse normale si trou */
     if(trou) {vy=-vy; vx=-vx;}
     /*printf("   normale : %f %f  \n",vx,vy);*/

    /* lon=longueur_arete_poly(x[i],y[i],x[i+1],y[i+1]);*/

     evalue_surf_frontale_par_classe(vx,vy);
   }
}

/*________________________________________________________________________*/
void evalue_surf_frontale_par_classe(vx,vy)
double vx,vy;

{ int i,k;
  double dir[2],pi,ang,prod_scal;

   /* pour chaque direction calcul du front de d_ang en d-ang degres */

  k=0;
  for(i=0; i<360 ;i=i+d_ang)
   {  
     pi=4*atan(1.);
     ang=i*pi/180.; 
     dir[0]=cos(ang); dir[1]=sin(ang);
     /*printf (" direction %d cos sin %f %f ",i,dir[0],dir[1]);*/
     
   	 /* prod scal */
          prod_scal= (dir[0]*vx+dir[1]*vy);
          if(prod_scal>0)
           {
             /*printf("   longueur laterale = prod_scal: %f\n",fabs(prod_scal));*/
      	     surf_frontale[k]+=fabs(prod_scal);        	

           }
        /*  else printf("   pas vu\n");*/
     k++;
   }

}

/*________________________________________________________________________*/
void initialise_classe_surf_front()
{ 
 int k,i;

  k=0; 
  for(i=0; i<360 ;i=i+d_ang)
   {  surf_frontale[k]=0;
      k++;
   }
}


/*________________________________________________________________________*/
void imprim_surf_front()
{
 int k,i;

  k=0; 
  for(i=0; i<360 ;i=i+d_ang)
   {  printf (" direction %3d surf frontale %f\n",i,surf_frontale[k]);
      k++;      
   }

}
/*________________________________________________________________________*/
void imprim_densite_front()
{
 int k,i;

  k=0; 
  for(i=0; i<360 ;i=i+d_ang)
   {  printf (" direction %3d densite frontale %f\n",i,surf_frontale[k]*hauteur_my_bati/surf_terrain);
      k++;      
   }

}

/*________________________________________________________________________*/
void imprim_rugosite()
{
 int k,i;
 double V,STCB,SFT,SFT_my,CDSFT,zd,z0,z0_my;

/* imprime densite frontale et rugosite zd z0 */

 STCB=surf_total_plein_vide;
 V= surf_total_plein_vide*hauteur_my_bati;

/* zd serait independant du sens du vent */

      zd=hauteur_my_bati*pow(STCB/surf_terrain,0.6);
      printf (" zd :  %f\n",zd);

/* calcul rugosite z0 */

  k=0; 
  z0_my=0; SFT_my=0;
  for(i=0; i<360 ;i=i+d_ang)
   {  SFT=surf_frontale[k]*hauteur_my_bati;
      CDSFT=SFT*0.8;

      z0=(hauteur_my_bati-zd)*exp(-0.4/(sqrt(0.5*CDSFT/surf_terrain)));

      z0_my+=z0;
      SFT_my+=SFT/surf_terrain;

/*  printf (" direction %3d densite frontale %f z0 %f\n",i,surf_frontale[k]*hauteur_my_bati/surf_terrain,z0);*/
   printf (" direction %3d densite frontale %f z0 %f\n",i,SFT/surf_terrain,z0);
     k++;      
   }
   printf (" MOYENNE densite frontale %f z0 %f\n",SFT_my/k,z0_my/k);

}


//_______________________________________________________
void normale_vert(xi,yi,zi,xj,yj,zj,xnn,ynn,znn,sens)
double xi,yi,zi,xj,yj,zj;
double *xnn, *ynn, *znn;
{
 double xk,yk,zk;
 double x1,y1,z1,x2,y2,z2;
 double norm;

	xk=xj; yk=yj; zk=zj+10;
    x1=xj-xi; y1=yj-yi; z1=zj-zi;
    x2=xk-xj; y2=yk-yj; z2=zk-zj;
    *xnn=y1*z2-y2*z1;
    *ynn=-x1*z2+x2*z1;
    *znn=x1*y2-x2*y1;

    norm=sqrt(*xnn*(*xnn)+*ynn*(*ynn)+*znn*(*znn));
    if(norm)
     {
      *xnn=(*xnn/norm)*sens;
	  *ynn=(*ynn/norm)*sens;
	  *znn=(*znn/norm)*sens;
    }
	else
	{ printf("PB calcul de normale\n");
	}
}


/*________________________________________________________________________*/
void format_entree()
{
  printf("\n   *rugosite_typo*  fichier_in(.cir) surface_territoire hauteur_my_bati \n\n");
}


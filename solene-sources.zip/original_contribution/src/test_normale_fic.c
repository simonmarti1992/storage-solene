/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/*

cc test_normale_fic.c solutile.o geomutile.o solaire.o lib_solene_94.o -o test_normale_fic -lm

*/

#include<solene.h>
#include<ctype.h>
#include <stdlib.h>
#include <sys/stat.h>

main(argc,argv) 
int argc;char **argv;
{int k;
 char sobs[20],nom[512],pourcentage[20],c[2],cc[2],*s_dir,*ch;
 int i;
 double xyzsol[3],a,h;
 int nojour,nomois,hh,minute;
 double lati;
char ligne_commande[512],nom_out[512],buf[512];

 if(argc<7){ format_entree_test_normale_fic();return(0); }

	s_dir=(char *)getenv("PWD");


   printf("\n TEST DES NORMALES D'UN FICIHIER \n");

            /* lit le type de l'observateur */
 sscanf(argv[1],"%c%c",cc,cc+1);
 if(cc[0]!='-'){ format_entree_test_normale_fic();return(0); }
 else if(cc[1]=='a')
    {sprintf(sobs,"%s %s %s",argv[2],argv[3],argv[4]);
     sprintf(nom,"%s",argv[5]);
     compose_nom_complet(nom_out,s_dir,argv[6],"cir");
}
 else if(cc[1]=='p')
    {sprintf(sobs,"%s %s %s %s %s %s %s",argv[2],argv[3],argv[4],argv[5],argv[6],argv[7],argv[8]);
     sprintf(nom,"%s",argv[9]);
     compose_nom_complet(nom_out,s_dir,argv[10],"cir");
    }
 else if(cc[1]=='h')
    {sscanf(argv[2],"%d%c%d",&nojour,c,&nomois);
     if(*c!='/'){ format_entree_test_normale_fic();return(0); }
     sscanf(argv[3],"%d%c%d",&hh,c,&minute);
     if(*c!=':'){ format_entree_test_normale_fic();return(0); }
     sscanf(argv[4],"%lf",&(lati));
     printf("\n nojour = %d nomois = %d ",nojour,nomois);
     printf("\n hh = %d minute = %d ",hh,minute);
     printf("\n lati = %lf ",lati);
     info_solaire(lati,nojour,nomois,hh,minute,xyzsol,&a,&h);
     sprintf(sobs," %lf %lf %lf ",xyzsol[0],xyzsol[1],xyzsol[2]);
     sprintf(nom,"%s",argv[5]);
     compose_nom_complet(nom_out,s_dir,argv[6],"cir");
    }
 else { format_entree_test_normale_fic(); return(0); }



 if(argc>7 && cc[1]!='p')
   {sscanf(argv[7],"%c%c",c,c+1);
    if(c[0]!='-'|| c[1]!='p'){ format_entree_test_normale_fic();return(0); }
    else sscanf(argv[8],"%s",pourcentage);
   }
 else if(argc>11 && cc[1]=='p')
   {sscanf(argv[11],"%c%c",c,c+1);
    if(c[0]!='-'|| c[1]!='p'){ format_entree_test_normale_fic();return(0); }
    else sscanf(argv[12],"%s",pourcentage);
   }

 else{ pourcentage[0]='2';pourcentage[1]=0;}

printf("\n argc = %d type = %c pourcentage = %s nom = %s nom_out = %s \n",argc,cc[1],pourcentage,nom,nom_out);

if(cc[1]=='p')
  {  sprintf(ligne_commande,"pers %s %s %s\\ffff1 -n",nom,sobs, getenv(SOLENETEMP)); //SII DFA 24-4-2006
     system(ligne_commande);
     sprintf(ligne_commande,"pers %s %s %s\\ffff2",nom,sobs, getenv(SOLENETEMP));//SII DFA 24-4-2006
     system(ligne_commande);
  }
else
{  sprintf(ligne_commande,"axono %s %s %s\\ffff1 -n",nom,sobs, getenv(SOLENETEMP));//SII DFA 24-4-2006
     system(ligne_commande);
     sprintf(ligne_commande,"axono %s %s %s\\ffff2",nom,sobs, getenv(SOLENETEMP));//SII DFA 24-4-2006
     system(ligne_commande);
  }

   sprintf(ligne_commande,"nofic_op_nofic %s\\ffff1 moins %s\\ffff2 %s\\ffff3", getenv(SOLENETEMP), getenv(SOLENETEMP), getenv(SOLENETEMP)); //SII DFA 24-4-2006
 system(ligne_commande);
 sprintf(ligne_commande,"compare_surface %s\\ffff3 + %s %s %s\\ffff1", getenv(SOLENETEMP), pourcentage,nom, getenv(SOLENETEMP)); // SII 24-4-2006
 system(ligne_commande);

 sprintf(ligne_commande,"nofic_op_nofic %s et %s\\ffff1 %s\\ffff2",nom, getenv(SOLENETEMP), getenv(SOLENETEMP)); // SII 24-4-2006
 system(ligne_commande);

 sprintf(ligne_commande,"inverse_normale %s\\ffff2 %s\\ffff3 -n", getenv(SOLENETEMP), getenv(SOLENETEMP)); // SII 24-4-2006
  system(ligne_commande);
 sprintf(ligne_commande,"nofic_op_nofic %s\\ffff3 ou %s %s\\ffff1",getenv(SOLENETEMP),nom, getenv(SOLENETEMP)); // SII 24-4-2006
  system(ligne_commande);

 
 sprintf(ligne_commande,"copy %s\\ffff1.cir %s",getenv(SOLENETEMP),nom_out); // SII 24-4-2006
 system(ligne_commande);

 sprintf(ligne_commande,"del %s\\ffff1.cir", getenv(SOLENETEMP)); // SII 24-4-2006
 system(ligne_commande);

 sprintf(ligne_commande,"del %s\\ffff2.cir", getenv(SOLENETEMP)); // SII 24-4-2006
 system(ligne_commande);

 sprintf(ligne_commande,"del %s\\ffff3.cir", getenv(SOLENETEMP)); // SII 24-4-2006
 system(ligne_commande);

 creer_OK_Solene();

   printf("\n");

}
/*_________________________________________________________________*/
int format_entree_test_normale_fic()
{
  printf("\n   *test_normale_fic* (-a x y z)|(-h jj/mm hh:mm latitude) (-p xo yo zo xv yv zv ang_vis) fichier_in(.cir) fichier_out(.cir) [-p pourcentage] \n\n");
}

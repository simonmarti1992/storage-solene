/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

// Temperature_brillance_directionnelle.c

// D. GROLEAU mars 2007
//			 sur le mod�le et en remplacement de temperature_brillance_axono 

/*__________________________________________________________________________*/
/* 
D�termine pour un ensemble de directions donn�es (hauteur et azimut),
	les temp�ratures radiantes pour chaque direction.
Simule en fait un capteur a�roport� � une distance cons�quente d'une sc�ne,
	dont on conna�t le champ de temp�rature � la surface de son enveloppe. 
La vision s'apparente � une vision axonom�trique; le traitement utilise donc une projection axonom�trique

La temp�rature radiante est alors pour chaque direction:
   
	 Somme pour toute maille visible [Emissivit�_maille * T4_maille * Surf_maille * cos(angle incidence)] 
	 / Somme [Surf_maille * cos(angle incidence)]
   
Les r�sultats mis en tableau (au format excel .csv) peuvent ensuite �tre pr�sent�s sous forme de rosace par Matlab
� partir des ex�cutables fournis par JP Lagouarde: visu_cerma.m et polarjet_jpl.m

Recherche men�e cojointement avec JP Lagouarde INRA de Bordeaux (temp�rature directionnelle, rosaces)

NOTA: pour le moment le nb de directions de la rosace est donn� dans le code
et l'�criture de la rosace faite en cons�quence avec ces valeurs (voir � rendre g�n�ral)
/*__________________________________________________________________________*/


#include<solene.h>

// DECLARE FUNCTIONS

void calcule_directions_rosace();
int ecl_des_patch_ds_face();
void evalue_surf();
void fait_axono_fac1();
void format_parametre();
int nb_directions_rosace(); 


// AUTRES DECLARATIONS

struct modelisation_face *fac1,*fac2,*fac3;

int nbfac1,nbfac2,nbfac3;
int ndir;	// nb de directions de la rosace

extern int option_calcul_z;   /* option CALCUL du Z ds FACE-OP-FACE 1=oui */
                              /* utilise ds singul.c epure_polygone */
							  /* et dans face_op_face.c             */
extern 	double coef_discol;
extern 	int z_axono_pers;

double somme_surf_norm; // surface normale visible cumul�e
double valeur_ecl;		
double *temperature_masc, *emissivite_masc, *surf_masc;
double *t_resul;  // stocke les temp radiantes avant leur impression dans le fichier r�sultat rosace
double *normal_x, *normal_y, *normal_z;
double vnf[3];

double	 epsiloneN;  // parametre de coplanaire
int	 facteurD;   // parametre de coplanaire


/*_________________________________________________________________*/
main(argc,argv)           
int argc;char **argv;
	{
	int i, k, j, indice, nomax;
 	char nom_masc[256], nom_masc_tr[256];
	char nom_surf[256], nom_temperature[256], nom_emissivite[256], nom_rosace[256];
 	FILE *pfic, *pval, *poutt;

	char *s_dir;
	double englob[10];

/* initialisation */
   	singularite=0; non_singularite=0; nb_etat=0;
   	pb_masque=0; colle_max=coef_discol*DISCOL;
   	pi=4*atan(1.);

// initialisation pour coplan�rit�
   epsiloneN = 0.0001;
   facteurD= 1000;

	s_dir = (char *)getenv("PWD");  

   	if(argc!=7) format_parametre();

// LECTURE parametres commande 

    printf(" Fonction Solene : Temperature_brillance_directionnelle\n\n");

    compose_nom_complet(nom_masc,s_dir,argv[1],"cir");  
    printf("geometrie masque            : %s \n",nom_masc);

    compose_nom_complet(nom_masc_tr,s_dir,argv[2],"cir");  
    printf("geometrie masque triangul�e : %s \n",nom_masc_tr);

    compose_nom_complet(nom_temperature,s_dir,argv[3],"val");  
    printf("temp�rature du masque : %s \n",nom_temperature);

    compose_nom_complet(nom_emissivite,s_dir,argv[4],"val");  
    printf("�missivit� du masque : %s \n",nom_emissivite);

    compose_nom_complet(nom_surf,s_dir,argv[5],"val");  
    printf("surface du masque triangul�e : %s \n",nom_surf);

    compose_nom_complet(nom_rosace,s_dir,argv[6],"csv");  
    printf("temp�rature r�sultat (rosace) : %s \n",nom_rosace);

// OPEN les fichiers a traiter  

// lecture  pfic masque ;  alloue fac1 nbfac1 pour traitement axono
// et             met original ds fac3 nbfac3 

	if((pfic=fopen(nom_masc,"r"))==NULL)
	{ printf("\n impossible ouvrir %s\n",nom_masc); 
	  exit(0);
	}
   lit_en_tete(pfic,&nbfac1,&nomax,englob);
   printf("geometrie masque %d faces\n",nbfac1);
   fac1=alloue_face(nbfac1,34);
   fac3=alloue_face(nbfac1,34);
   nbfac3=nbfac1;
   lit_fic_cir3d(pfic,nbfac3,fac3);
   fclose(pfic);

// lecture  pfic masque triangule;  alloue fac2 nbfac2 

   if((pfic=fopen(nom_masc_tr,"r"))==NULL)
	{ printf("\n impossible ouvrir %s\n",nom_masc_tr); 
	  exit(0);
	}
   lit_en_tete(pfic,&nbfac2,&nomax,englob);
   printf("geometrie masque triangul�e %d faces\n",nbfac2);
   fac2=alloue_face(nbfac2,34);
   lit_fic_cir3d(pfic,nbfac2,fac2);
   fclose(pfic);
// nb total de contours
   nbc = nbcontours_total(fac2, nbfac2);
   printf("    nb de contours de masque_triangul� : %d\n",nbc);

// lecture  pval des temperatures du masque triangule 
// et stockage des valeurs 

	if ((pval = fopen(nom_temperature,"r")) == NULL)
		{ printf("\n  impossible d'ouvrir %s !!\n\n", nom_temperature);
		  exit(0);
		}
  // Allocation du tableau des valeurs associ�es aux contours*/
  temperature_masc = alloue_double(nbc,456);
  lect_fic_val(pval, temperature_masc);
  fclose(pval);
  //for(i=0;i<nbc;i++) printf("%f\n",*(temperature_masc+i));
  // on eleve les temperatures Kelvin � la puissance 4
  for(i=0;i<nbc;i++)
  { temperature_masc[i] = pow(temperature_masc[i] +273,4.);
  }

// lecture pval des emissivites du masque triangule 
// et stockage des valeurs 

	if ((pval = fopen(nom_emissivite,"r")) == NULL)
		{ printf("\n  impossible d'ouvrir %s !!\n\n", nom_emissivite);
		  exit(0);
		}
  // Allocation du tableau des valeurs associ�es aux contours*/
  emissivite_masc = alloue_double(nbc,456);
  lect_fic_val(pval, emissivite_masc);
  fclose(pval);
  //for(i=0;i<nbc;i++) printf("%f\n",*(emissivite_masc+i));

// lecture pval des surfaces du masque triangule 
// et stockage des valeurs 
	if ((pval = fopen(nom_surf,"r")) == NULL)
		{ printf("\n  impossible d'ouvrir %s !!\n\n", nom_surf);
		  exit(0);
		}
  // Allocation du tableau des valeurs associ�es aux contours*/
  surf_masc = alloue_double(nbc,456);
  lect_fic_val(pval, surf_masc);
  fclose(pval);

// ouverture du FICHIER resultat rosace.txt
	if ((poutt = fopen(nom_rosace,"w")) == NULL)
		{ printf("\n  impossible de creer %s !!\n\n", nom_rosace);
		  exit(0);
		}

// DETERMINE les Vecteurs Direction � Evaluer dans normal_x, normal_y, normal_z
  ndir= nb_directions_rosace(30,5,10);  // pourrait �tre param�tr�
  t_resul = alloue_double(ndir,456);
  normal_x = alloue_double(ndir,456);
  normal_y = alloue_double(ndir,456);
  normal_z = alloue_double(ndir,456);
  calcule_directions_rosace(30,5,10);


// TRAITEMENT :  EVALUE temperature de Brillance  directionnelle
  
  printf("\nTraitement en cours ...\n\n");

// traitement pour chaque direction

 for(i=0;i<ndir;i++) 
  { 
	//printf("\nTraite direction %d \n",i+1);
    vnf[0]=normal_x[i]; vnf[1]=normal_y[i]; vnf[2]=normal_z[i];

    /* observateur regarde dans le sens de la normale a la face */
	// on fait axono de vecteur: Point de vue, (0,0,0)
    obs.x = vnf[0];
    obs.y = vnf[1];
    obs.z = vnf[2];
	obs.xo=0; obs.yo=0; obs.zo=0; 
		//printf("      pt de calcul %lf %lf %lf\n",obs.xo,obs.yo,obs.zo);   
        //printf("      direction %lf %lf %lf\n",vnf[0],vnf[1],vnf[2]);  

    // transformation a appliquer a chaque contour du masque 
    tranfo();

	/* TRAITEMENT pour cette direction : 
				axono de fac1 (masque)
				avec patch visibles de fac3 (masque_triangule)
	*/
	
    fait_axono_fac1();

	// Evalue la temp�rature radiante � partir de la surface normale de chaque maille visible dans la direction vis�e
	somme_surf_norm=0;
	valeur_ecl=0;

	evalue_surf(); 

	// calcule de la temp�rature radiante
	if(somme_surf_norm) // represente la surface normale cumul�e visible
			{ valeur_ecl = valeur_ecl / somme_surf_norm;
		      // calcule la temperature en Celsius
		      valeur_ecl = pow (valeur_ecl,0.25) - 273;
			}
	else
	{ printf("division par 0; normalement ne devrait pas arriver\n");
	}
	// stocke la valeur Tr pour cette direction
	t_resul[i]= valeur_ecl; // stockage temporaire avant impression dans rosace

 } // Fin FOR des directions

//  Impression des tempertures sur la ROSACE
	printf("\n Imprime les temperatures radiantes en tableau suivant hauteur et azimut \n");
	printf("   colonne : angle/zenith de 5� � 60� par pas de 5�\n");
	printf("   ligne   : angle/nord de 0� � 350� par pas de 10� (en passant par l'EST\n");

        fprintf (poutt,"%5.2f,,,,,,,,,,,,\n",t_resul[0]);
		// ecrit la ligne des valeurs hauteur/ z�nith
		fprintf(poutt, ",");
			for(j=5;j<=60;j=j+5)
			{  	fprintf(poutt, "%d,",j);
			}
		fprintf(poutt,"\n");

		// ecrit les valeurs apr ligne d'azimut
		for (i=0;i<360; i=i+10)
		{ indice= i/10 +1;
		  //printf("ligne %d\n",indice);
		  fprintf(poutt, "%d,",i);
		  k=0;
		  for(j=5;j<=60;j=j+5)
			{  	fprintf(poutt, "%5.2f,",t_resul[indice+k]);
				k=k+36;
			}
		  fprintf(poutt,"\n");
		}

		fprintf(poutt,"\n");
		fclose(poutt);
  
// Desalloue

 desalloue_fface(fac1,nbfac1);
 desalloue_fface(fac2,nbfac2);
 desalloue_fface(fac3,nbfac3);
 desalloue_double(temperature_masc);
 desalloue_double(emissivite_masc);
 desalloue_double(surf_masc);
 desalloue_double(t_resul);
 desalloue_double(normal_x);
 desalloue_double(normal_y);
 desalloue_double(normal_z);

 creer_OK_Solene();
 printf("\n\nFin de temperature_brillance_directionnelle\n");

 exit(0);
}


/*_________________________________________________________________*/
void fait_axono_fac1()
{  
	int i;

/* met en axono le fichier Masque non triangul� fac1 */
/* COPIE ORIGINAL fac3 ds fac1 pour travail */
    for(i=0;i<nbfac1;i++) 
	{ //printf("copie face indice %d\n",i);
		copie_face(fac3+i,fac1+i);
	}

   init_fenetre_affichage();

/* TRANSFORMATION axono fichier "masque" , si vu */
    for(i=0;i<nbfac1;i++)
	{ if(visible_axono(fac1+i,1))
           { 
			//printf("\n   apres visible_axono face %d\n",(fac1+i)->nofac_fichier);
	        tran_face(fac1+i,1,fac1+i,0);
            tran_normale((fac1+i)->vnorm);
            }
      }

   cal_fen_aff();

/* NORMALISATION */

   for(i=0;i<nbfac1;i++)
     { if((fac1+i)->debut_dessin)
           {  
		     normalise_face(fac1+i,0);		 
           }
	   copie_face_projete(fac1+i,0,fac1+i,1);
     }

 /* TRAITE VU/CACHE ; resultat dans ->dessin */

    traite_moins(fac1,nbfac1);

/* IMPRTESSION vu
		   
       for(i=0;i<nbfac1;i++)
	   {if((fac1+i)->debut_dessin)
					  {
					  printf("\n   apres vu cach� face %d\n",(fac1+i)->nofac_fichier);
					  //printf("\n   liste face %d apres pers\n",(fac1+i)->nofac_fichier);
					  //liste_face(fac1+i,0);
					  }
	   }
*/
}


/*_________________________________________________________________*/
void evalue_surf()
{
  /* evalue la temperature de brillance sur le contour en traitement
  /* pour chaque face de fac2 (nbfac2)  masque triangul� porteur de temp�rature */
  /* cherche si vue ds la projection axono fac1 (nbfac1) */
  /* si vu, test pour chaque centre de gravite des contours de fac2 */
  /*        si est dans le polygone image fac1 de la face */
  /*           si oui, evalue surface normale et temperature de brillance avec contour en traitement */
 int i,j;
 int noc;

 noc=0;
 for(i=0;i<nbfac2;i++)
  { //printf(" Examine dans Masque_TR  Face  %d\n",(fac2+i)->nofac_fichier);
	 /* cherche si fac2+i vue ds pers : 
        elle est vue si on trouve une face coplanaire fac1+j vue */
    for(j=0;j<nbfac1;j++)
     { 
	  if((fac1+j)->debut_dessin)
        { //printf("  dans Masque  Face vue %d\n",(fac1+j)->nofac_fichier);
	      // on utilise fac3 pour avoir la vraie normale de fac1

	      if(coplanaire(fac2+i,1,fac3+j,1,epsiloneN,1,facteurD)) // anciennement 0.00001
			{ 
			  //printf("   Coplanaires Face Masque_TR %d et Face Masque %d\n",(fac2+i)->nofac_fichier,(fac1+j)->nofac_fichier);
			  /* elle est vue au moins en partie ;
			     calcule la surface normale de ses contours avec le contour en traitement 
			     et la temp�rature de brillance qui en r�sulte */
		   	  if(ecl_des_patch_ds_face(i,j,noc)) 
			    { //un facteur de forme non nul
				  //evalue temp�rature de brillance vers le contour en traitement
				  break;
				}
			 }
		}
	 }//fin de for j
	noc=noc+nb_contour_face(fac2+i,1);
  }// fin du for i

}


/*_________________________________________________________________*/
int ecl_des_patch_ds_face(i,j,ind_contour)
int i,j;
int ind_contour;
{ 

	/* cherche contours de fac2+i contenu dans face fac1+j */
	/* et calcule surface et temperature de brillance pour le contour en traitement de fac */

 struct contour *pcont;
 struct circuit *pcir;
 double xg,yg,zg;
 double xp, yp, zp;
 double xyz[3];
 double ang_inc;
 int noc, dans_face;

 double norm_visee[3];
 double norm_contour[3];
 double cos_angle_incid_axono;


 noc=0; dans_face=0;
 	   // ajout: calcul angle entre Normale � contour et axe de vis�e
	   // comme si c'�tait une axono
	   // vrai pour l'ensemble des contours de la face
			norm_visee[0]= vnf[0];
			norm_visee[1]= vnf[1];
			norm_visee[2]= vnf[2];
			norm_contour[0]= (fac2+i)->vnorm[0];
			norm_contour[1]= (fac2+i)->vnorm[1];
			norm_contour[2]= (fac2+i)->vnorm[2];

			//printf("visee %f %f %f\n", norm_visee[0],norm_visee[1],norm_visee[2]);
			//printf("normale contour%f %f %f\n", norm_contour[0],norm_contour[1],norm_contour[2]);
 
		   	cos_angle_incid_axono =vincid(norm_visee,norm_contour,&ang_inc);
			//printf("cos, %f \n", cos_angle_incid_axono);
			//il doit etre n�gatif sinon pas vu
			cos_angle_incid_axono = fabs (cos_angle_incid_axono);

   pcont=(fac2+i)->debut_projete;			
   while(pcont)
    { pcir=pcont->debut_support;
       /* cherche centre de gravite */
       centre_de_gravite(pcir, &xg, &yg, &zg);
	   //printf("point, %f %f %f\n", xg,yg,zg);

	   /* transforme et normalise */
       tranp(xg,yg,zg,xyz,xyz+1,xyz+2);
	   //printf("point transformer , %f %f %f\n", xyz[0],xyz[1],xyz[2]);
	   normalise_point(xyz[0],xyz[1],xyz[2],&xp,&yp,&zp);
	   //printf("point normaliser , %f %f %f\n", xp,yp,zp);

       /* test si ds face j vue en axono */
       if(point_dans_face(xp,yp,(fac1+j),0))
       {
		// donc parmi les faces coplanaires , c'est la bonne
		dans_face=1;
		//printf("face %d surf %f surf_norm %f\n",(fac2+i)->nofac_fichier, surf_masc[ind_contour], surf_masc[ind_contour]*cos_angle_incid_axono);

		// on cumule la surface normale dans somme_surf_norm
		somme_surf_norm += surf_masc[ind_contour]*cos_angle_incid_axono;
		// on ajoute � l'�clairement
		valeur_ecl += temperature_masc[ind_contour] * emissivite_masc[ind_contour] * surf_masc[ind_contour]* cos_angle_incid_axono;
	   }
       ind_contour++;
       noc++;
       pcont=pcont->suc;
   }
 return(dans_face);
}

/*_________________________________________________________________*/
int nb_directions_rosace(haut_min,haut_pas,azi_pas)
int haut_min,haut_pas,azi_pas;
{
 int ihaut, iaz;
 int ndir;

 ndir=0;

	for (ihaut= 90; ihaut>=haut_min; ihaut=ihaut-haut_pas) 
	{
		if(ihaut !=90)
		{
			for (iaz= -180; iaz <180; iaz=iaz+azi_pas)		
			{ // du nord au nord en passant par l'ESt,SUD et OUEST
			  ndir++;
			}
		}
		else
		{
			ndir++;
		}
	}

  return(ndir);
}

/*_________________________________________________________________*/
void calcule_directions_rosace(haut_min,haut_pas,azi_pas)
int haut_min,haut_pas,azi_pas;
{
 int ihaut, iaz;
 double xyz[3], pi;
 double azi, haut;
 int ndir;

 pi= 4*atan(1.);
 ndir=0;

	for (ihaut= 90; ihaut>=haut_min; ihaut=ihaut-haut_pas) 
	{
		//printf("ihaut= %d\n",ihaut);
		if(ihaut !=90)
		{
			for (iaz= -180; iaz <180; iaz=iaz+azi_pas)		
			{ // du nord au nord en passant par l'ESt,SUD et OUEST
			  
			  //printf("   iaz= %d",iaz);
			  azi= (double) iaz; 
			  azi= angrad(azi);
			  haut= (double) ihaut;
			  haut= angrad(haut);
			  //printf("  %f %f  ", azi,haut);
			  // calcul le vecteur
			  vcompxyz(azi,haut,xyz);
			  normal_x[ndir]= xyz[0];
			  normal_y[ndir]= xyz[1];
			  normal_z[ndir]= xyz[2];
			  //printf(" direction=%d  %f %f %f \n",ndir+1,xyz[0],xyz[1],xyz[2]);
			  ndir++;
			}
		}
		else
		{
		    vcompxyz(0.,pi/2,xyz);
			normal_x[ndir]= xyz[0];
			normal_y[ndir]= xyz[1];
			normal_z[ndir]= xyz[2];
			//printf(" direction=%d  %f %f %f \n",ndir+1,xyz[0],xyz[1],xyz[2]);
			ndir++;
		}
	}
}

/*_________________________________________________________________*/
void format_parametre()
{

 printf("\ntemperature_brillance_directionnelle\n\n");

 printf("       a comme parametres \n\n");
 printf("\tIN geometrie_masque(.cir)\n");
 printf("\tIN geometrie_masque_triangule (.cir)\n");
 printf("\tIN temperature de surface de geometrie_masque_triangule (.val)\n");
 printf("\tIN �missivite de geometrie_masque_triangule (.val)\n");
 printf("\tIN surface de geometrie_masque_triangule (.val)\n");
 printf("\tOUT temperature_directionnelle_rosace(.csv)\n\n");

  	exit(0);
}

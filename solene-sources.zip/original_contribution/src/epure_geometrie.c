/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

// D.Groleau 20 mars 2001
/*
cc epure_geometrie.c  solutile.o geomutile.o poly_op_poly.o face_op_face.o lib_solene_94.o 
*/

// suppression des faces toujours invisibles 
// d�coupage des faces partiellment visibles

//Proc�dure
// r�alise plusieurs vu_dans_axono du fichier original, suivant quelques points de vue
// cr�e un fichier unique des faces visibles (normalement il y a des superpositions de contours)
// union_contour_face


#include<solene.h>



struct table_etat{int *etat;};
int nb_etat;
FILE *ficetat,*fcop,*fp;
char buf[256],nom[256];
struct modelisation_face *ff[30];
struct modelisation_face *alloue_face();
int nbf,nbfmax;
struct table_etat *fetat;

/*_________________________________________________________________*/
main(argc,argv)
char *argv[];
int argc;
{double englob[10],englob1[10];
 int no,i,j,nofic,nbff[30],k,nbfic;
 float xv,yv,zv;
 char *s_dir;

  
           s_dir= "";//(char *)getenv("PWD");
		   nb_etat = 0;

  if(argc<4){format_entree();exit(0);}

// Lit le fichier � traiter et les vues � r�aliser dans un fichier vue.txt
  printf("Realise plusieurs vues axonometriques (axono)\n");

  compose_nom_complet(buf,s_dir,argv[1],"cir");
  if((fp=fopen(buf,"r"))==NULL)
  { printf("\n impossible ouvrir %s\n",buf); exit(0);
  }
  lit_en_tete(fp,&nbff[0],&no,englob);
  printf(" de %s (%d faces)\n",buf,nbff[0]);
  fclose(fp);

  compose_nom_complet(buf,s_dir,argv[2],"txt");
  if((fp=fopen(buf,"r"))==NULL)
  { printf("\n impossible ouvrir %s\n",buf); exit(0);
  }
  printf(" les vues sont definies dans %s \n",buf);

// Realise les vues correspondantes (axono)
  nbfic=0;
  while(fscanf(fp,"%f",&xv)!=-1)
  { nbfic++;
    fscanf(fp,"%f",&yv);
    fscanf(fp,"%f",&zv);
	sprintf(buf,"axono %s  %f %f %f %s\\XEPUR%d",
	argv[1],xv,yv,zv,getenv(SOLENETEMP),nbfic);
	printf("%s\n",buf);
	system(buf);
  }

// Relit les fichiers correspondants aux vues axono
// Et en fait un fichier unique avec pour chaque face,ses contours issus de chaque vue

 /* lit tous les fichiers d'etats */
  nbfmax=-1; nofic=0; i=1;
  for(i=1;i<=nbfic;i++)
    {
	 sprintf(nom,"%s\\XEPUR%d",getenv(SOLENETEMP), i);
	 compose_nom_complet(buf,"",nom,"cir");
     if((fp=fopen(buf,"r"))==NULL)
     { printf("\n impossible ouvrir %s\n",buf); exit(0);
	 }
     lit_en_tete(fp,&nbff[nofic],&no,englob1);
     nbfmax=imax(nbfmax,no);
     ff[nofic]=alloue_face(nbff[nofic],35);
     lit_fic_cir3d(fp,nbff[nofic],ff[nofic]);
     fclose(fp);
     nofic++;
    }

  /* allocation de la table de correspondance (indice et no de face) */
   fetat=(struct table_etat *)malloc((nbfmax+1)*sizeof(*fetat));
   if(fetat==NULL)
   {printf("\n pb allocation fetat \n"); exit(0);
   }
   for(i=0;i<(nbfmax+1);i++)
	{(fetat+i)->etat=(int *)malloc(nbfic*sizeof(int));
	 if((fetat+i)->etat==NULL)
	 {printf("\n pb allocation des etats de fetat \n"); exit(0);
	 }
     for(j=0;j<nbfic;j++)(fetat+i)->etat[j]=-1;
	}

  /* remplit la table */
   for(i=0;i<nbfic;i++)
	{for(k=0;k<(nbfmax+1);k++)
	  {if(k<nbff[i])
            {j=(ff[i]+k)->nofac_fichier;
             if(j!=0)(fetat+j)->etat[i]=k;
	    }
	  }
	}
 /*
   for(i=0;i<nbfic;i++)
	{for(k=1;k<(nbfmax+1);k++)
           printf("\n etat = %d face = %d corres = %d ",i,k,(fetat+k)->etat[i]);
        }
 */

  /* ouvre et initialise le fichier des faces resultats */
   //Modif SII DF 24-04-2006
   fcop=createFileTmpSolene("XEPUR.cir","w");

   nbf=0;
   ecrit_en_tete(fcop,nbf,nbfmax,englob);
   printf("nbfmax %d\n",nbfmax);
  /* constitue successivement chacune des faces avec ses contours */
   for(i=1;i<=nbfmax;i++)
   { //printf("traite face %d\n",i);
	 traite_recompose_face(nbfic,i);
   }

 /* ferme le fichier des faces resultats */
    rewind(fcop);
    ecrit_en_tete(fcop,nbf,nomax,englob);
    fclose(fcop); 

 /*  desallocation */
    for(j=0;j<nofic;j++)desalloue_fface(ff[j],nbff[j]);

// Fait l'UNION des contours de chaque face
    //Modif SII DFA 24-04-2006
	sprintf(buf,"union_contour_face  %s\\XEPUR %s",getenv(SOLENETEMP),argv[3]);

	printf("\n%s\n",buf);
	system(buf);

// Supprime les fichiers temporaires
  for(i=1;i<=nbfic;i++)
    {
	 //Modif SII DFA 24-04-2006
	 sprintf(buf,"del %s\\XEPUR%d.cir",getenv(SOLENETEMP),i);
	 system(buf);
	}
	sprintf(buf,"del %s\\XEPUR.cir",getenv(SOLENETEMP));
	system(buf);

 creer_OK_Solene();
 printf("\n\nFin du Traitement\n");

}

/*_________________________________________________________________*/
traite_recompose_face(nbfic,no)
int no;
{struct modelisation_face *face,*f1;
 struct contour *pc;
 double norm[3],nor[3];
 int i,j,k,kk;

    face=alloue_face(1,10);
	face->nofac_fichier=no;
 /* concatene les faces resultats des vues - dans une meme face  */
    kk=0;
    for(i=0;i<nbfic;i++)
	{ k=(fetat+no)->etat[i];
      if(k>=0)
		{//printf("prend etat %d indice %d\n",i,k); 
		 if(kk==0)
			{ copie_face_projete(ff[i]+k,1,face,1);
			}
		 else
			{ concatene_fface(ff[i]+k,1,face,1);
			}
		 kk=1;
		}
	}
   if(kk==0)return;

 /* est-ce necessaire de recoller les points proches sur la face avant d'en faire son union?
 /* ce travail est-il � faire aussi sur l'ensemble des points du fichier
 /* stocke la face face sur le fichier resultat */
    output_face_sur_fichier(face,1,1,0,fcop,&nbf,&nomax);
    desalloue_fface(face,1);

}

/*_________________________________________________________________*/

format_entree()
{
  printf("\nFormat d'entree des parametres \n");
  printf("\n  epure_geometrie geom_in(.cir) point_de_vue(.txt) geom_epure_out(.cir)\n");
  printf("\n  Enleve les parties de geometrie invisibles\n");
  printf("\n  Le fichier point_de_vue contient les composantes x,y,z des vues axonom�triques � r�aliser\n");
  printf("\n  Seules les parties de g�om�trie visibles dans ces vues sont conserv�es\n");
  exit(0);
}


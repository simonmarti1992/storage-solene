/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */
 
// arrondi � un certain nombre de decimales
#include<solene.h>


// DECLARATIONS FUNCTIONS

void format_entree();
void arrondi_face();
double arrondi_valeur();


/*_________________________________________________________________*/
main(argc,argv)
 int argc;char **argv;
{
 char 	buf[512],*s_dir;
 double arrondi,englob[10];
 int j,nb, nbff,nomax;
 FILE *fp;
 struct modelisation_face *ff;

 if(argc<4)format_entree();

	s_dir=(char *)getenv("PWD");

  printf("Arrondi... \n");

  sscanf(argv[3],"%lf",&arrondi); // lit nombre de decimale
  printf("\n �  %f  decimales ",arrondi);

  arrondi = pow(10.,arrondi);  // 1O a la puissance n (nb de decimales)
  

  compose_nom_complet(buf,s_dir,argv[1],"cir");
  printf("\n le fichier  %s\n",buf); 

  if((fp=fopen(buf,"r"))==NULL)
        { printf("\n impossible ouvrir %s\n",buf); exit(0);}
   lit_en_tete(fp,&nbff,&nomax,englob);
   ff=alloue_face(nbff,35);
   lit_fic_cir3d(fp,nbff,ff);
   fclose(fp);
        
  /* calcul de l'arrondi */ 
     
   for(j=0;j<nbff;j++) 
    {
	  
	    arrondi_face(arrondi,ff+j,1);
    
    }

/* stocke le fichier */

   compose_nom_complet(buf,s_dir,argv[2],"cir");
   fp=fopen(buf,"w");
    if(fp==NULL) 
	{ printf("impossible creer %s\n",buf);
	  exit(0);
	}
   ecrit_en_tete(fp,nbff,nomax,englob);
   output_face_sur_fichier(ff,nbff,1,0,fp,&nb,&nomax);
   fclose(fp);
   printf("\n");
  		creer_OK_Solene();

	desalloue_fface(ff,nbff);
}

/*_________________________________________________________________*/
void format_entree()
{
  printf("\n    *arrondi*  fichier_in(.cir)  fichier_out(.cir)  arrondi_nb_decimale\n\n");
   exit(0);
}

/*____________________________________________________________________*/
void arrondi_face(arrondi,face,projete)
double arrondi;
struct modelisation_face *face;
int projete;
{int i;
 struct contour *pcont;
 struct circuit *pcir;

   
   if(projete)pcont=face->debut_projete; else pcont=face->debut_dessin;

      while(pcont)	   
       { pcir=pcont->debut_support; 
         for(i=0;i<pcir->nbp;i++)
           {
			pcir->x[i]= arrondi_valeur(arrondi,pcir->x[i]);
			pcir->y[i]= arrondi_valeur(arrondi,pcir->y[i]);
			pcir->z[i]= arrondi_valeur(arrondi,pcir->z[i]);
			}
	     pcir=pcont->debut_interieur;
         while(pcir)
			{for(i=0;i<pcir->nbp;i++)
				{
					pcir->x[i]= arrondi_valeur(arrondi,pcir->x[i]);
					pcir->y[i]= arrondi_valeur(arrondi,pcir->y[i]);
					pcir->z[i]= arrondi_valeur(arrondi,pcir->z[i]);
				}
			pcir=pcir->suc;
			}
         pcont=pcont->suc; 
       } 
}

/*____________________________________________________________________*/
double arrondi_valeur(arrondi,valeur)
double arrondi;
double valeur;
{
double val_arrondi, x2,x3;
int val_int;

 x2 = valeur * arrondi;
 val_int = x2;
 x3 = val_int;
 if( fabs(x2-x3) >= 0.5) 
 {
	  if (valeur > 0) val_arrondi = x3 + 1;
	  else val_arrondi = x3 - 1;
 }
 else val_arrondi = x3;


return(val_arrondi / arrondi);
}

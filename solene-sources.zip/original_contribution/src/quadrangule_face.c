/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/*

cc quadrangule_face.c  solutile.o geomutile.o lib_solene_94.o  -o quadrangule_face  -lm

D.GROLEAU mars 2006 modification : le nb d'intervalles est diff�rent sur les aretes prises 2 � 2 
		voir MODIF mars 2006
D.GROLEAU d�c 2006 modification : cas o� l'ar�te est de dimension inf�rieure � la taille de la maille 
		voir MODIF dec 2006
D. GROLEAU janvier 2007 modification: calcul en double au lieu de float


*/
// quadrangule les circuits des faces de 4 cot�s sans trou

#include<solene.h>

// declarations fonctions

int ecrit_en_tete();
int evalue_nb_contour_quadrangule();
void format_entree();

//void imprime_pt();   // version avant MODIF mars 2000
void imprime_pt1();

double longueur_arete(); // janvier 2007

int nb_quadrangle1();

void output_cont();
void output_ff();

void place_pt();    // version avant MODIF mars 2000
void place_pt_int1();

//int quadrangule();  // version avant MODIF mars 2000
int quadrangule1();

// GLOBAL

double ca,cb,cc,cd;
FILE *fp;

/*_________________________________________________________________*/
main(argc,argv)
int argc;char **argv;
{
 char nom[256],buf[256],*s_dir;
 int j,nbfac,nomax,nb,noc,nb_contour,nb_contour_av,zero;
 int nc_total, nc_total_q;
 double englob[10];
 double dim_maille; // janvier 2007

 struct modelisation_face *ff;
 struct contour *pcont;
 struct circuit *pcir;
 
 s_dir=(char *)getenv("PWD");

 if(argc!=4 )format_entree();

 printf("Fonction Solene : quadrangule_face\n\n");

 /* open fichier in .cir */
 compose_nom_complet(nom,s_dir,argv[1],"cir");
 if((fp=fopen(nom,"r"))==NULL)
    { printf("\n impossible ouvrir %s\n",nom);
      exit(0);
    }
 lit_en_tete(fp,&nbfac,&nomax,englob);
 ff=alloue_face(nbfac,35);
 lit_fic_cir3d(fp,nbfac,ff);
 fclose(fp);

 //dim maille

 sscanf(argv[2],"%lf",&dim_maille);

 /* open fichier out .val */
 compose_nom_complet(buf,s_dir,argv[3],"cir");
 if((fp=fopen(buf,"w"))==NULL)
	{ printf("impossible creer %s\n",buf);
	  exit(0);
	}	

 ecrit_en_tete(fp,nbfac,nomax,englob);

// traite la quadrangulation
printf("Quadrangule les faces de 4 cotes sans trou\n");
printf("du fichier %s de %d faces\n",nom,nbfac);

printf("Dimension de maille  %f\n",dim_maille);
printf("R�sultat dans %s\n",buf);

nc_total = nbcontours_total(ff, nbfac);
nc_total_q =0;

for(j=0;j<nbfac;j++) 
  { 
    //printf("Traitement de la face no %d \n",(ff+j)->nofac_fichier);

    nb_contour_av = nb_contour_face(ff+j,1);
    nb_contour = evalue_nb_contour_quadrangule(ff+j,dim_maille);
	//printf("nb de contour apres quadrangulation = %d\n",nb_contour);

	if(nb_contour != nb_contour_av)
	 {
       fprintf(fp,"f%d %d\n",(ff+j)->nofac_fichier,nb_contour);
       fprintf(fp," %lf  %lf  %lf\n",(ff+j)->vnorm[0],(ff+j)->vnorm[1],(ff+j)->vnorm[2]);

       pcont=(ff+j)->debut_projete; 
	   noc=0;
       while(pcont)	   
        { 
	      //printf("Contour %d\n",noc);
	      pcir=pcont->debut_support;

		  if (pcont->debut_interieur == NULL && pcir->nbp ==5)
		   { // pas de trou et un quadrilatere

// MODIF mars 2006
/*             zero = quadrangule(pcir,dim_maille);
			 if(zero==0) 
			 { printf("stocke tel quel\n");
			   output_cont(pcont,fp,0);
			 }
			 else nc_total_q ++;
*/
			  zero =quadrangule1(pcir,dim_maille); 
			  //printf("zero= %d\n",zero);
			  if(zero==0) 
			  { printf("stocke tel quel\n");
			    output_cont(pcont,fp,0);
			  }
			  else nc_total_q ++;
// FIN MODIF 
		   }
		  else
		  {
			// stocke le contour tel quel
            //printf("stocke tel quel\n");
			output_cont(pcont,fp,0);
		  }

          noc++;
		  pcont=pcont->suc;
	    }
	  }
	 else  // stocke la face telle quelle
	  {
        //printf("stocke la face telle quelle\n");
		output_ff(ff+j,1,1,0,fp,&nb,&nomax);
	  }
  }

desalloue_fface(ff,nbfac);
fclose(fp);
printf("\n%d contours quadrangul�s sur un total de %d contours\n",nc_total_q,nc_total);
printf("\nFin traitement quadrangule_face\n");

creer_OK_Solene();



}

/*_________________________________________________________________*/

int evalue_nb_contour_quadrangule(fac,dim_maille)
struct modelisation_face *fac;
double dim_maille; // janvier 2007
{ 
  int nb,noc;
  struct contour *pcont;
  struct circuit *pcir;
  
  noc=0;
  pcont=(fac)->debut_projete; 
  while(pcont)	   
     { 
	   pcir=pcont->debut_support;
       if (pcont->debut_interieur == NULL && pcir->nbp == 5)
	   { // pas de trou et un quadrilatere : quadrangule

//            nb = nb_quadrangle(pcir,dim_maille);
            nb = nb_quadrangle1(pcir,dim_maille);
			//printf("nb de mailles carr� = %d\n",nb);
			noc+=nb;
	   }
	   else
	   {
        noc++;
	   }
	   pcont=pcont->suc;
	 }
  return(noc);

}

/*_________________________________________________________________*/
int nb_quadrangle1 (pcir,dim_maille)
struct circuit *pcir;
double dim_maille; // janvier 2007
{
 int k,nb[2];
 double ddd; // janvier 2007

 // cherche  le nb de point sur les 2 premi�res aretes apres quadrangulation
  for(k=0;k<2 ;k++)
   {
	ddd=longueur_arete(pcir->x[k],pcir->y[k],pcir->z[k],pcir->x[k+1],pcir->y[k+1],pcir->z[k+1]);
    nb[k]= ddd/dim_maille;
	nb[k]++;
   }
  //printf("nb0=%d nb1=%d\n",nb[0] , nb[1]);
  if(nb[0] < 3 && nb[1] < 3)
   { // arete trop courte pour la maille
	 // on ne quadrangule pas
     return(1);
   }
  else
  {	//MODIF dec 2006
   if((nb[0]-1)<=0) return((nb[1]-1));
   if((nb[1]-1)<=0) return((nb[0]-1));
   //Fin MODIF 
   return((nb[0]-1)*(nb[1]-1));
  }
}



/*_________________________________________________________________*/
int quadrangule1 (pcir,dim_maille)
struct circuit *pcir;
double dim_maille; // janvier 2007
{
 int i,j,k,nb[2];
 double ddd; // janvier 2007
 double *xp,*yp,*zp; // janvier 2007

 int nbp, nb1, nb2;


 // d�termine le d�coupage
  // cherche  le nb de point sur les 2 premi�res aretes apres quadrangulation
  for(k=0;k<2 ;k++)
   {
	ddd=longueur_arete(pcir->x[k],pcir->y[k],pcir->z[k],pcir->x[k+1],pcir->y[k+1],pcir->z[k+1]);
	//printf("ddd=%f\n",ddd);
    nb[k]= ddd/dim_maille;
	nb[k]++;
   }
  if(nb[0] < 3 && nb[1] < 3)
   { // arete trop courte pour la maille
	 // on ne quadrangule pas
     return(0);
   }

 nb1=nb[0]; nb2=nb[1];
 //MODIF dec 2006
 if(nb1==1)nb1=2;
 if(nb2==1)nb2=2;
 //Fin MODIF
 //printf("decoupage nb1= %d nb2= %d\n",nb1,nb2); 
 nbp = nb1*nb2;
 // alloue les coordonnees
  xp = alloue_double(nbp,349); // janvier 2007
  yp = alloue_double(nbp,350); // janvier 2007
  zp = alloue_double(nbp,351); // janvier 2007

 // place les 4 points du circuit
  place_pt(pcir->x[0],pcir->y[0],pcir->z[0],0, xp,yp,zp);
  place_pt(pcir->x[1],pcir->y[1],pcir->z[1],nb1-1, xp,yp,zp);
  place_pt(pcir->x[2],pcir->y[2],pcir->z[2],(nb1*nb2)-1,xp,yp,zp);
  place_pt(pcir->x[3],pcir->y[3],pcir->z[3],nb1*(nb2-1),xp,yp,zp);

    //imprime_pt1(nb1,nb2,xp,yp,zp);

 // engendre les pts intermediaires du contour entre i et j avec intervalle 
  place_pt_int1(0, nb1-1, 1, 1, xp,yp,zp,nb1);
  place_pt_int1(0, nb1*(nb2-1), nb1, nb1, xp,yp,zp,nb2);
  place_pt_int1(nb1*(nb2-1),(nb1*nb2)-1, nb1*(nb2-1)+1, 1, xp,yp,zp,nb1);
  place_pt_int1(nb1-1,(nb1*nb2)-1, 2*nb1-1, nb1, xp,yp,zp,nb2);

    //imprime_pt1(nb1,nb2,xp,yp,zp);

 // engendre les pts intermediaires interieurs sur les lignes 
  for(k=nb1; k< nb1*(nb2-1) ; k+=nb1)
  {
    place_pt_int1(k, k+nb1-1, k+1, 1, xp,yp,zp,nb1);
  }
   
    //imprime_pt1(nb1,nb2,xp,yp,zp);


 // engendre les circuits 
  for(k=1; k<nb2; k++)
  { j = (k-1)*nb1;

    for(i=0; i<nb1-1; i++)
	{    
	  fprintf(fp,"c0\n5\n");

	  fprintf(fp," %10.3f %10.3f %10.3f\n", xp[j+i],yp[j+i],zp[j+i]);
      fprintf(fp," %10.3f %10.3f %10.3f\n", xp[j+i+1],yp[j+i+1],zp[j+i+1]);
      fprintf(fp," %10.3f %10.3f %10.3f\n", xp[j+i+1+nb1],yp[j+i+1+nb1],zp[j+i+1+nb1]);
	  fprintf(fp," %10.3f %10.3f %10.3f\n", xp[j+i+nb1],yp[j+i+nb1],zp[j+i+nb1]);
	  fprintf(fp," %10.3f %10.3f %10.3f\n", xp[j+i],yp[j+i],zp[j+i]);
	}
  }

  desalloue_double(xp); // janvier 2007
  desalloue_double(yp); // janvier 2007
  desalloue_double(zp); // janvier 2007
 return(1);
}

/*_________________________________________________________________*/
/*
int quadrangule (pcir,dim_maille)
struct circuit *pcir;
float dim_maille;
{
 int i,j,k,nb;
 float ddd, long_min_arete;
 float *xp,*yp,*zp;

 // cherche la plus petite arete et le nb de point sur aretes apres quadrangulation
  long_min_arete = 10000000.; 
  for(k=0;k<pcir->nbp-1 ;k++)
   {
	ddd=longueur_arete(pcir->x[k],pcir->y[k],pcir->z[k],pcir->x[k+1],pcir->y[k+1],pcir->z[k+1]);
    if(ddd < long_min_arete)long_min_arete=ddd;
   }
  nb= long_min_arete/dim_maille; nb++;

  if(nb < 3)
   { // on ne quadrangule pas (longueur arete trop petite pour dim maille)
	 //printf(" <3\n");
     return(0);
   }
    
//printf("arete long  = %f\n",long_min_arete);
//printf("nbpt = %d\n",nb);

 // alloue les coordonnees
  xp = alloue_float(nb * nb,349);
  yp = alloue_float(nb * nb,350);
  zp = alloue_float(nb * nb,351);

 // place les 4 points du circuit
  place_pt(pcir->x[0],pcir->y[0],pcir->z[0],0, xp,yp,zp);
  place_pt(pcir->x[1],pcir->y[1],pcir->z[1],nb-1, xp,yp,zp);
  place_pt(pcir->x[2],pcir->y[2],pcir->z[2],(nb*nb)-1,xp,yp,zp);
  place_pt(pcir->x[3],pcir->y[3],pcir->z[3],nb*(nb-1),xp,yp,zp);

  
  //  imprime_pt(nb,xp,yp,zp);

 // engendre les pts intermediaires du contour entre i et j avec intervalle 
  place_pt_int1(0, nb-1, 1, 1, xp,yp,zp,nb);
  place_pt_int1(0, nb*(nb-1), nb, nb, xp,yp,zp,nb);
  place_pt_int1(nb*(nb-1),(nb*nb)-1, nb*(nb-1)+1, 1, xp,yp,zp,nb);
  place_pt_int1(nb-1,(nb*nb)-1, 2*nb-1, nb, xp,yp,zp,nb);

  //  imprime_pt(nb,xp,yp,zp);

 // engendre les pts intermediaires interieurs sur ls lignes 
  for(k=nb; k< nb*(nb-1) ; k+=nb)
  {
    place_pt_int1(k, k+nb-1, k+1, 1, xp,yp,zp,nb);
  }
   
 //   imprime_pt(nb,xp,yp,zp);

 // engendre les circuits 
  for(k=1; k<nb; k++)
  { j = (k-1)*nb;

    for(i=0; i<nb-1; i++)
	{    
	  fprintf(fp,"c0\n5\n");

	  fprintf(fp," %10.3f %10.3f %10.3f\n", xp[j+i],yp[j+i],zp[j+i]);
      fprintf(fp," %10.3f %10.3f %10.3f\n", xp[j+i+1],yp[j+i+1],zp[j+i+1]);
      fprintf(fp," %10.3f %10.3f %10.3f\n", xp[j+i+1+nb],yp[j+i+1+nb],zp[j+i+1+nb]);
	  fprintf(fp," %10.3f %10.3f %10.3f\n", xp[j+i+nb],yp[j+i+nb],zp[j+i+nb]);
	  fprintf(fp," %10.3f %10.3f %10.3f\n", xp[j+i],yp[j+i],zp[j+i]);
	}
  }
 return(1);
}
*/

/*________________________________________________________________________*/

void place_pt(x,y,z,iplace,xp,yp,zp)
double x,y,z;
int iplace;
double *xp,*yp,*zp; // janvier 2007
{
	//printf("   place en %d      pt %f %f %f\n",iplace,x,y,z);
	xp[iplace] = x;
	yp[iplace] = y;
	zp[iplace] = z;
}


/*________________________________________________________________________*/
void place_pt_int1(ipt1,ipt2,idemarre,inter,xp,yp,zp,nbp)
int ipt1,ipt2,idemarre,inter;
double *xp,*yp,*zp; // janvier 2007
int nbp;
{
  int k,indice;
  double dx,dy,dz; // janvier 2007

  dx= (xp[ipt2]-xp[ipt1])/(nbp-1);
  dy= (yp[ipt2]-yp[ipt1])/(nbp-1);
  dz= (zp[ipt2]-zp[ipt1])/(nbp-1);

  //printf("place pt inter\n");
  indice = idemarre;
  for(k=1; k<nbp-1; k++)
   {
	xp[indice] = xp[ipt1] + k*dx;
	yp[indice] = yp[ipt1] + k*dy;
	zp[indice] = zp[ipt1] + k*dz;

	//printf("   place  %d %d  en%d    pt %f %f %f\n",ipt1,ipt2,indice,xp[indice],yp[indice],zp[indice]);

	indice = indice + inter;
   }
}

/*________________________________________________________________________*/
double longueur_arete(x1,y1,z1,x2,y2,z2)
double x1,y1,z1,x2,y2,z2;
{
 double longueur; // janvier 2007
 longueur=(sqrt((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1)+(z2-z1)*(z2-z1)));
/*printf("longueur arete %f\n",longueur);*/
 return(longueur);
 
}

/*________________________________________________________________________*/
void imprime_pt1(nb1,nb2,xp,yp,zp)
int nb1,nb2;
double *xp,*yp,*zp; // janvier 2007
{
	int i,j,k;

	printf("\nListe Points\n");
	k=0;
	for(i=0;i<nb2;i++)
	{ printf("Ligne %d\n",i);
		for(j=0;j<nb1;j++)
	    {
		  printf("  %f %f %f\n",xp[k],yp[k],zp[k]);
		  k++;
		}
	}
}

/*________________________________________________________________________*/
/*
void imprime_pt(nb,xp,yp,zp)
int nb;
float *xp,*yp,*zp;
{
	int i,j,k;

	printf("\nListe Points\n");
	k=0;
	for(i=0;i<nb;i++)
	{ printf("Ligne %d\n",i);
		for(j=0;j<nb;j++)
	    {
		  printf("  %f %f %f\n",xp[k],yp[k],zp[k]);
		  k++;
		}
	}
}
*/

/*-----------------------------------------------------------*/
void output_ff(face,nb,projete,itranf,pf,nbf,nomax)
struct modelisation_face *face;
int nb,projete,itranf,*nbf,*nomax;
FILE *pf;
{
              /* ecrit sur fichier pf,les nb faces; contour projete si projete=1; */
              /*                                    contour dessin  si projete=1; */
              /* en appliquant Tranfo inverse_Normalise  si itranf */
              /* et en mettant a jour nb de faces du fichier, nb contour, nomax */
  struct contour *pcont;
  struct circuit *pcir;
  int i,nbcont,nbtrou;



  for(i=0;i<nb;i++) 
    { 
     if(projete) pcont=face[i].debut_projete; else pcont=face[i].debut_dessin;
     if(pcont)
       {*nbf=*nbf+1; if(face[i].nofac_fichier>*nomax) *nomax=face[i].nofac_fichier;
        nbcont=nb_contour_face(face+i,projete);
        fprintf(pf,"f%d %d\n",face[i].nofac_fichier,nbcont);
        fprintf(pf," %lf  %lf  %lf\n",face[i].vnorm[0],face[i].vnorm[1],face[i].vnorm[2]);
 
        while(pcont)
         { nbtrou=nb_trou_contour(pcont);
           pcir=pcont->debut_support;
                       /* support ; en principe 1 seul */
           fprintf(pf,"c%d\n",nbtrou);
           output_circuit_sur_fichier(pcir,pf,itranf);
           pcir=pcont->debut_interieur;
                      /* les trous */
           while(pcir)
              { fprintf(pf,"t%\n");
                output_circuit_sur_fichier(pcir,pf,itranf);
                pcir=pcir->suc;
              }
           pcont=pcont->suc;
        }
     }
   }
}

/*-----------------------------------------------------------*/
void output_cont(pcont,pf,itranf)
struct contour *pcont;
FILE *pf;
int itranf;
{
	int nbtrou;
	struct circuit *pcir;

	 nbtrou=nb_trou_contour(pcont);
     pcir=pcont->debut_support;
                       /* support ; en principe 1 seul */
     fprintf(pf,"c%d\n",nbtrou);
     output_circuit_sur_fichier(pcir,pf,itranf);
     pcir=pcont->debut_interieur;
                      /* les trous */
     while(pcir)
         { fprintf(pf,"t%\n");
           output_circuit_sur_fichier(pcir,pf,itranf);
           pcir=pcir->suc;
         }   
}
/*_________________________________________________________________*/
void format_entree()
{
  printf("\n quadrangule_face fichier_in(.cir) dimension_maille fichier_out(.cir) \n\n");
  printf(" quadrangule les contours sans trou de 4 cot�s\n\n");
  exit(0);
}


/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

// attribue_val


// D.GROLEAU juillet 2006

// Attribue une valeur constante � un contour et construit le descripteur correspondant



#include<solene.h>


// DECLARATIONS FUNCTIONS

void format_entree();
void trans_face();



/*_________________________________________________________________*/
main(argc,argv)
 int argc;char **argv;
{
 char 		buf[512],*s_dir;
 double		englob[10];
 int		nbff,nomax;
 FILE		*fp,*fpval2;
 struct modelisation_face *ff;

 int		j,k,noc;
 double		valeur;

  printf("\n\nCommande:  attribue_val\n\n");

  if(argc!=4)format_entree();

	s_dir=(char *)getenv("PWD");

  compose_nom_complet(buf,s_dir,argv[1],"cir");
  if((fp=fopen(buf,"r"))==NULL)
        { printf("\n impossible ouvrir %s\n",buf); exit(0);}
   lit_en_tete(fp,&nbff,&nomax,englob);
   ff=alloue_face(nbff,35);
   lit_fic_cir3d(fp,nbff,ff);
   fclose(fp);

   printf(" geometrie_IN : %s (%d faces)\n",buf,nbff);

   sscanf(argv[2],"%lf",&valeur);
   printf(" attribue la valeur : %f\n",valeur);

       
  compose_nom_complet(buf,s_dir,argv[3 ],"val");
  if((fpval2=fopen(buf,"w"))==NULL)
	{ printf("impossible ouvrir %s\n",buf);
	  exit(0);
	}
	
  printf(" descripteur_OUT : %s\n",buf);

  
   fprintf(fpval2,"%7d %7d %15.3f %15.3f\n",nbff,nomax,valeur,valeur);

   for(j=0;j<nbff;j++) 
    {
	  
	   // calcul le nb de contour de la face
		noc=nb_contour_face(ff+j,1);

	   // ecrit la face, son nombre de contours et la valeur pour chaque contour
	   fprintf(fpval2,"f%d %d\n",(ff+j)->nofac_fichier,noc);
	   for(k=0;k<noc;k++) 
	   { fprintf(fpval2,"%15.6f\n",valeur);
	   }

    }

/* stocke le fichier val */
	 fclose(fpval2);


	desalloue_fface(ff,nbff);
	
	creer_OK_Solene();

}

/*_________________________________________________________________*/
void format_entree()
{
  printf("\n    attribue_val  fichier_in(.cir) valeur fichier_out(.val)\n\n");
   exit(0);
}




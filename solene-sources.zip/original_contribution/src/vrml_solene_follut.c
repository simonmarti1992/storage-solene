/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/* vrml_solene.c */
/* 


cc -o vrml_solene vrml_solene.c solutile.o geomutile.o lib_solene_94.o -lm
 
*/

/* Conversion fichier vrml (.wrl) en fichier SOLENE (.cir) */
/* Convertit seulement POLY_EXTRUD */
/* met les faces consecutives de meme normale dans une seule face */
/* n'applique pas la transfo  ROTATION */

#include<solene.h>

/*---------------------------------------------------------------------------*/


FILE *fi,*fo;

//#define MAXCORD 36000
#define EPSI    0.00001

int parc;
char ligne_commande[2048],*parv[128],met_param[2048];

char   buf[512],nom_in[512],nom_out[512];
double xmin,ymin,zmin,xmax,ymax,zmax,precision;

//double x[MAXCORD],y[MAXCORD],z[MAXCORD];
//int    nopt[MAXCORD];
double *x,*y,*z;
int *nopt;

int    nbpoint;
int    nbfac_enr;
double tx,ty,tz,rot1,rot2,rot3,rot4;

int maxcord;
/*________________________________________________________*/
main(argc,argv)
int  argc;
char *argv[];    /* ou **argv */

{
 char *s_dir;
 int ilu;
 double englob[10];

	s_dir=(char *)getenv("PWD");

 if(argc<3)format_entree();

 /* initialise extremes x,y,z */
 xmin=ymin=zmin=1000000.;
 xmax=ymax=zmax=-xmin;
 zmin=0; zmax=0;

 precision=0.001;

 /* lit et traite les parametres */


            compose_nom_complet(nom_in,s_dir,argv[1],"wrl");
            if((fi=fopen(nom_in,"r"))==NULL) 
               { printf(" impossible ouvrir %s\n",nom_in);
   	         format_entree();
               }
printf("\nConvertit  %s\n",nom_in);

            compose_nom_complet(nom_out,s_dir,argv[2],"cir");
            if((fo=fopen(nom_out,"w"))==NULL) 
               { printf(" impossible ouvrir %s\n",nom_out);
   	         format_entree();
               }

printf(" en         %s\n\n",nom_out);

 maxcord =36000;
 if (argc ==4) sscanf(argv[3],"%d",&maxcord);

 printf("nombre de points allou�s : %d\n",maxcord);

 // allocation
 x = alloue_double(maxcord,4567);
 y = alloue_double(maxcord,4567);
 z = alloue_double(maxcord,4567);
 nopt = alloue_int(maxcord,4567);


nbfac_enr=1;
englob[0]=zmin; englob[1]=zmax;
englob[2]=xmin; englob[3]=ymin;
englob[4]=xmax; englob[5]=ymin;
englob[6]=xmax; englob[7]=ymax;
englob[8]=xmin; englob[9]=ymax;
  ecrit_en_tete(fo,nbfac_enr,nbfac_enr,englob);

/* cherche   DEF */
while(ilu!=2)
//  { ilu=cherche_chaine("DEF");
{ ilu=cherche_chaine("geometry");
    /*printf("retour ilu = %d\n",ilu);*/
    if(ilu == 1) 
      {  
        printf("un DEF trouve\n");
        lit_DEF();
      } 
  }

englob[0]=zmin; englob[1]=zmax;
englob[2]=xmin; englob[3]=ymin;
englob[4]=xmax; englob[5]=ymin;
englob[6]=xmax; englob[7]=ymax;
englob[8]=xmin; englob[9]=ymax;
rewind(fo);

printf("nb faces crees : %d\n",nbfac_enr-1);
  ecrit_en_tete(fo,nbfac_enr-1,nbfac_enr-1,englob);


 fclose(fi); fclose(fo);
 desalloue_double(x);
 desalloue_double(y);
 desalloue_double(z);
 desalloue_int(nopt);

   	creer_OK_Solene();


}
/*______________________________________________________*/
int lit_DEF()
{
 
  
tx=ty=tz=0;
while(1)
 {
  lit_ligne_commande(); 
  decode_ligne_commande_macro();
  gere_parametre(ligne_commande);
  //printf("nb de par %d   parv0= %s\n",parc,parv[0]);
  if( parc > 1 && (strcmp(parv[0],"translation"))==0)
   { sscanf(parv[1],"%lf",&tx);
     sscanf(parv[2],"%lf",&ty);
     sscanf(parv[3],"%lf",&tz);
     printf(" Translation %f %f %f\n",tx,ty,tz);
   }
  else if(parc > 1 && (strcmp(parv[0],"rotation"))==0)
   { sscanf(parv[1],"%lf",&rot1);
     sscanf(parv[2],"%lf",&rot2);
     sscanf(parv[3],"%lf",&rot3);
     sscanf(parv[4],"%lf",&rot4);
     printf(" Rotation %f %f %f %f\n",rot1,rot2,rot3,rot4);
   }
  else if(parc > 1 && (strcmp(parv[0],"coord"))==0)
   { 
	 //printf("coord\n");
     lit_coordonnees();
   }
 else if(parc > 1 && (strcmp(parv[0],"coordIndex"))==0)
   {
	 printf("coordIndex\n");
     lit_faces();
     break;
   }

 }

return(1);
}

/*______________________________________________________*/
int lit_coordonnees()
{
 int i,k;
 
 k=0;
 while(1)
  {
   lit_ligne_commande(); 
   decode_ligne_commande_macro();
   gere_parametre(ligne_commande);

if(parc>1)
  {

   for(i=0 ;i<parc;i+=3)
     { 
       sscanf(parv[i],"%lf", x+k);
       sscanf(parv[i+1],"%lf", y+k);
       sscanf(parv[i+2],"%lf", z+k);
	  // printf("xyz %f %f %f\n",x[k],y[k],z[k]);
       k++; /* nb de points */
       nbpoint = k;
       if(k>maxcord)
	{ printf("\n trop de coordonnees dans un poly_extrud - on arrete \n");
	  printf(" nbp = %d > %d \n\n",k,maxcord);
	  exit(0);
	}
     }
     
     /* test si la fin des coord : , ou ]=fin) */
    i= i-1;  /*printf("parv = %s\n",parv[i]);*/
    if((strchr(parv[i],']')))
      { /*printf("fin ]\n");*/
        break;
      }
   }
  else break;
    
}

 printf("translation %f %f %f\n", tx,ty,tz);
 for(i=0 ;i<nbpoint;i++)
     {   
       //printf("%f %f %f\n", x[i],y[i],z[i]);
	   /* applique Translation */
	   x[i]=x[i]+tx;
	   y[i]=y[i]+ty;
	   z[i]=z[i]+tz;
       cherche_ext(x[i],y[i],z[i]);
     }

}

/*______________________________________________________*/
int lit_faces()
{
 int i,k,j,kk,istoke,ideb,nbcontour;
 double xnn,ynn,znn,xnn1,ynn1,znn1,xx[3],yy[3],zz[3];
 
   /* lit tous les points des faces */

 k=0;
 while(1)
  {
   lit_ligne_commande(); 
   decode_ligne_commande_macro();
   gere_parametre(ligne_commande);

if(parc>1)
{

   for(i=0 ;i<parc;i++)
     { 
       sscanf(parv[i],"%d", nopt+k);
       k++; /* nb de points */
       if(k>maxcord)
	{ printf("\n trop de points dans une face de poly_extrud - on arrete \n");
	  printf(" nbp = %d > %d \n\n",k,maxcord);
	  exit(0);
	}
     }
     
     /* test si la fin des points : , ou ]=fin) */
    i= i-1;  /*printf("parv = %s\n",parv[i]);*/
    if((strchr(parv[i],']')))
      { /*printf("fin ]\n");*/
        break;
      } 
}
else break;
  }

   /* stocke les faces */
   /* calcule nbre de contours de la face a stocker si meme normale */
   /* ATTENTION, il faudrait sans doute tester si meme plan */

   nbcontour=0;
   istoke=0; ideb=0;
   for(i=0; i<k; i++)
    { 
     /*printf("%d\n",nopt[i]); */
     if(nopt[i]==-1)
        { /* c'est une face */
            nbcontour++;
          /* calcul sa normale */
            for(j=0; j<3 ;j++)
              { kk=j+ideb;
                xx[j]=x[nopt[kk]];
                yy[j]=y[nopt[kk]];
                zz[j]=z[nopt[kk]];
              }
            calcul_normale(xx,yy,zz,&xnn,&ynn,&znn);
            ideb=i+1;
            /*printf("ideb = %d ;normale = %f %f %f \n",ideb,xnn,ynn,znn);*/
       
          /* test si meme normale que precedent */
            if(nbcontour > 1)
              {     /* test si meme normale que precedent */
                if(fabs(xnn-xnn1)<EPSI && fabs(ynn-ynn1)<EPSI && fabs(znn-znn1)<EPSI)
                   {   /* si oui */
                     
                     /*printf(" meme normale nbcontour= %d\n",nbcontour);*/
                   }
                else
                   { /* si non stocke la face de nbcontour */
                     /* en demarrant a istoke */
                     printf(" enregistre face de %d contours a partir de %d\n", nbcontour-1,istoke);
                     enregistre_face(&istoke,nbcontour-1,xnn1,ynn1,znn1);

                     /* et continue */
                     nbcontour=1;
                   }
               }
          
           xnn1=xnn; ynn1=ynn; znn1=znn;
 
        }
     }
  /* stoke la derniere face de nbcontour */

   printf(" enregistre face de %d contours a partir de %d\n", nbcontour,istoke);
   enregistre_face(&istoke,nbcontour,xnn1,ynn1,znn1);
         
}




/*______________________________________________________*/
int cherche_chaine(s)
char *s;
{
 int ilu;

ilu=0;
while(ilu==0)
  {  ligne_commande[0]=0;
     ilu=lit_ligne_commande(); if(ilu){ilu=2; break;}

     
     if(ligne_commande[0]!=0)
       { decode_ligne_commande_macro();
         gere_parametre(ligne_commande);

         /*if( parc > 1)printf(" parv = %s \n",parv[0]); */
         if( parc > 1 && (strcmp(parv[0],s))==0) ilu=1;

       }

   }
 return(ilu);

}

/*______________________________________________________*/
int enregistre_face(istoke,nbcontour,xnn,ynn,znn)
int 	*istoke,nbcontour;
double xnn,ynn,znn;
{
  int i,j,irendu,nbp;

/*   if(sup_pt_proche(x,y,z,&nbp)==0)return(0); */

   
   fprintf(fo,"f%d %d\n",nbfac_enr,nbcontour);
   fprintf(fo,"%f %f %f\n",xnn,ynn,znn);

  for(j=0; j<nbcontour; j++)
   {
     nbp=0; irendu= *istoke; while(nopt[irendu]!=-1) { nbp++; irendu++; }
     fprintf(fo,"c0 \n  %d\n",nbp+1);

     for(i=*istoke;i<*istoke+nbp;i++)
	{ fprintf(fo,"%12.3f %12.3f %12.3f\n",x[nopt[i]],y[nopt[i]],z[nopt[i]]);
	}
     fprintf(fo,"%12.3f %12.3f %12.3f\n",x[nopt[*istoke]],y[nopt[*istoke]],z[nopt[*istoke]]);
     *istoke=*istoke+nbp+1;
   }
  nbfac_enr++;
   
return(1);
}

/*________________________________________________________________________*/
int calcul_normale(x,y,z,xnn,ynn,znn)
double *x,*y,*z;
double *xnn,*ynn,*znn;
{
 double x1,y1,z1,x2,y2,z2,norm;
 int i,j,k;

 /* calcul sur les  3 premiers  */
 i=0; j=1; k=2;
 x1=x[j]-x[i]; y1=y[j]-y[i]; z1=z[j]-z[i];
 x2=x[k]-x[j]; y2=y[k]-y[j]; z2=z[k]-z[j];
 *xnn=y1*z2-y2*z1;
 *ynn=-x1*z2+x2*z1;
 *znn=x1*y2-x2*y1;

 norm=sqrt(*xnn*(*xnn)+*ynn*(*ynn)+*znn*(*znn)); 
 *xnn=*xnn/norm; *ynn=*ynn/norm; *znn=*znn/norm;
}

/*________________________________________________________________________*/
int cherche_ext(x,y,z)
double x,y,z;
{ 
	if(x<xmin)xmin=x;
	if(x>xmax)xmax=x;
	if(y<ymin)ymin=y;
	if(y>ymax)ymax=y;
	if(z<zmin)zmin=z;
	if(z>zmax)zmax=z;
}
/*_________________________________________________________________*/
int lit_ligne_commande()
{
  int i;   /* lit ligne de commande ds ligne_commande sur console */

  i=-1;
  do
    { i++; 
      if((fscanf(fi,"%c",ligne_commande+i))==EOF)
		{   ligne_commande[i]=0;
			return(1);
		}
	/*printf("i= %d c=%c\n",i,ligne_commande[i]);*/
    }while(ligne_commande[i]!='\n');

  ligne_commande[i]=0;
  /*printf("ligne = %s\n",ligne_commande);*/
  return(0);

}


/*_________________________________________________________________*/
int decode_ligne_commande_macro()
{
   /* epure la ligne de commande */
   /* enleve les blancs consecutifs et met fin de chaine des que # */
  int i,j,ignore_car;

  ignore_car=0;
  i=0;   /* ieme caractere de ligne_commande */
  j=0;   /* jeme caracter de ligne epuree  */
  while(1)
    { if(ligne_commande[i]==0) break;
      if(ignore_car) i++;
      else if(ligne_commande[i]==' ')
         { if(j!=0 && ligne_commande[j-1]!=' ') 
               { ligne_commande[j]=ligne_commande[i]; 
                 j++;
               }
           i++;
         }
/* ne traite pas (ligne_commande[i]=='#' */
/*       else if(ligne_commande[i]=='#') */

      else
         { ligne_commande[j]=ligne_commande[i]; 
           j++; i++;
         }
    }
  if(ligne_commande[j-1]==' ') j--; 
  ligne_commande[j]=0;
/*if(ligne_commande[0]!=0) printf("ligne epuree = %s \n",ligne_commande);*/
}

/*_________________________________________________________________*/
int gere_parametre(ligne_commande)
char *ligne_commande;
{       
        /* etablit les parametres de ligne_commande ds *parv[] */
        /* construit un parametre jusqu'a un BLANC */
  int i,j,nb;
  
  nb=0;  /* 1er parametre */
  i=0;   /* 1er caractere de ligne_commande */
  j=0;   /* 1er caractere du parametre  */
  parv[nb]=&met_param[j];
  while(1)
    { if(ligne_commande[i]==' ')
         { met_param[i]=0; nb++; parv[nb]=&met_param[i+1];
         }
      else 
         { met_param[i]=ligne_commande[i]; 
           if(ligne_commande[i]==0 || ligne_commande[i]=='\n') break;
         }
      i++;
    }
  nb++; parc=nb;

  /*printf("nb param %d\n",parc); */
  /*for(i=0;i<nb;i++) printf("%s\n",parv[i]); */

}
/*______________________________________________________*/
int sup_pt_proche(x,y,z,nbp)
double *x,*y,*z;
int *nbp;
{
 int i,k,nbpp;
         /* suppression artificielle des pts proches avec statut <0 */

/* for(i=0;i<maxcord;i++)statut[i]=0; */

printf(" nbp = %d \n",*nbp);
 nbpp=*nbp;
 for(i=0;i<*nbp-1;i++)
   { for(k=i+1;k<*nbp;k++)
          { 
               if(fabs(x[i]-x[k])<precision && fabs(y[i]-y[k])<precision && fabs(z[i]-z[k])<precision)
                  { nbpp--; printf(" --\n");
	/*	    statut[k]=-1;  */
                    i--;
                  }
	   if(nbpp<3)return(0);
          }

   }
 return(1);
}


/*______________________________________________________*/
int format_entree()
{
 printf("\n  *vrml_solene* fic_vrml(.wrl) fic_solene(.cir) [nbmax de points dans une face (defaut 36000)] \n");
 printf("\n");   
 printf("   conversion geometrie vrml en fichier Solene\n");
 printf("\n");   
exit(0);
}

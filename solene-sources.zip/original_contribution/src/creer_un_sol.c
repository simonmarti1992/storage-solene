/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/*

cc creer_un_sol.c  solutile.o geomutile.o lib_solene_94.o -o creer_un_sol -lm

*/
/* creer_un_sol.c    */


#include<solene.h>

#include <stdlib.h>
#include <sys/stat.h>

struct modelisation_face *alloue_face();

 struct modelisation_face *ff;
 double xmin,ymin,xmax,ymax;

/*_________________________________________________________________*/
main(argc,argv)
 int argc;char **argv;
{char 	fourtou[512],buf[512],*s_dir;
 double englob[10],extrem[6],dx,dy,Zsol;
 int j,nbff;
 FILE *fp;

 if(argc<6)format_entree();

	s_dir=(char *)getenv("PWD");

  compose_nom_complet(buf,s_dir,argv[1],"cir");
  if((fp=fopen(buf,"r"))==NULL)
        { printf("\n impossible ouvrir %s\n",buf); exit(0);}
   lit_en_tete(fp,&nbff,&nomax,englob);
   ff=alloue_face(nomax,35);
   lit_fic_cir3d(fp,nbff,ff);
   fclose(fp);

  sscanf(argv[2],"%lf",&dx);
  sscanf(argv[3],"%lf",&dy);
  sscanf(argv[4],"%lf",&Zsol);
        
  /* calcul min max */ 
     
	initialise_min_max(extrem);

        for(j=0;j<nbff;j++) 
           { extremite_x_y(ff+j,extrem);
           }

    desalloue_fface(ff,nbff);

 /* constitue sol  englobant */

//  compose_nom_complet(buf,s_dir,"Xxx1","cir");

//SII Modif DFA 18-04-2006
	if( (fp=createFileTmpSolene("Xxx1T.cir","w")) == NULL ) {
		printf("\n impossible ouvrir %s\\Xxx1T.cir\n", getenv(SOLENETEMP));
		exit(0);
	}
//SII

   	englob[0]=Zsol;  englob[1]=Zsol;
	englob[2]=xmin-dx;  englob[3]=ymin-dy;
	englob[4]=xmax+dx;  englob[5]=ymin-dy;
	englob[6]=xmax+dx;  englob[7]=ymax+dy;
	englob[8]=xmin-dx;  englob[9]=ymax+dy;

   nbff=1; nomax=1;
   ecrit_en_tete(fp,nbff,nomax,englob);

   fprintf(fp,"f1 1\n");
   fprintf(fp," 0 0 1\n");
   fprintf(fp,"c0\n  5\n");

   fprintf(fp,"	%10.3f %10.3f %10.3f\n",xmin-dx,ymin-dy,Zsol);
   fprintf(fp,"	%10.3f %10.3f %10.3f\n",xmax+dx,ymin-dy,Zsol);
   fprintf(fp,"	%10.3f %10.3f %10.3f\n",xmax+dx,ymax+dy,Zsol);
   fprintf(fp,"	%10.3f %10.3f %10.3f\n",xmin-dx,ymax+dy,Zsol);
   fprintf(fp,"	%10.3f %10.3f %10.3f\n",xmin-dx,ymin-dy,Zsol);

   fclose(fp);

/* fait axon 0 0 1 */

   sprintf(buf,"axono_select %s\\Xxx1T %s  0 0 1 %s",getenv(SOLENETEMP), argv[1],argv[5]); // SII Modif DFA 18-04-2006
   printf("%s\n",buf);
   system(buf);
 
//  compose_nom_complet(fourtou,s_dir,"Xxx1","cir");
//  sprintf(buf,"rm %s",fourtou);
//  system(buf);
  


    sprintf(buf, "del %s\\Xxx1T.cir", getenv(SOLENETEMP)); // SII DFA 18-4-2006
	creer_OK_Solene();

	printf("\n");
 }
/*_________________________________________________________________*/
/*____________________________________________________________________*/
int extremite_x_y(face,extrem)
struct modelisation_face *face;
double *extrem;

{int i;
 struct contour *pcont;
 struct circuit *pcir;

    
   pcont=face->debut_projete;

      while(pcont)	   
       { pcir=pcont->debut_support; 
         for(i=0;i<pcir->nbp-1;i++)
           {
            if(pcir->x[i]< xmin) xmin=pcir->x[i];
            if(pcir->y[i]< ymin) ymin=pcir->y[i];
            if(pcir->x[i]> xmax) xmax=pcir->x[i];
            if(pcir->y[i]> ymax) ymax=pcir->y[i];
	   }
         pcont=pcont->suc; 
       } 
}
/*____________________________________________________________________*/
int initialise_min_max(extrem)
double *extrem;

{    
            xmin=99999999.9;
            ymin=99999999.9;
            xmax=-99999999.9;
            ymax=-99999999.9;
}

/*_________________________________________________________________*/
format_entree()
{
  printf("\n    *creer_un_sol* fichier_in(.cir) dx dy Zsol fichier_out(.cir)     \n\n");
  exit(0);
}

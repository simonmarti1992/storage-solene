/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */
 
/*______________________________________________________________________*/
/*                         calc_temp_iterf.c : 				*/
/*          Calcul des temperatures de paroi en regime permanent	*/
/* Algorithme iteratif: - initialisation des temperatures de paroi	*/
/*		    (&) - Radiosite dans l'IR et calcul des flux IR nets */
/* 			- Application du bilan thermique et calcul	*/
/* 			des nouvelles tempratures			*/
/*			Retour a (&)					*/
/*       Precis, mais faux pour les facettes "frontieres" du modele  	*/
/*           Car pour elles, le bilan radiatif est deficitaire  	*/
/*                        par rapport a la realite 			*/
/*______________________________________________________________________*/
/*    		Modifications apportees au programme "radiosite.c"      */
/* 		par Marie-Joelle Antoine, CERMA, EAN, 1997		*/
/*		- Prise en compte eventuelle de l'emission		*/
/*		- Separation de l'algorithme de radiosite 		*/
/*		dans une procedure a part, pour iteration		*/
/*______________________________________________________________________*/
/* Programme analogue a 'calc_temp_iter.c', sauf que le coefficient       */
/* de transfert convectif (h) et la temperature externe (Text) dependent    */
/* de la facette, et sont donc des fichiers .val contrairement aux versions */
/* precedentes */

/*   Rappel ligne de compilation

cc calc_temp_iterf.c ./UTILS/pers_util.o ./UTILS/solutile.o ./UTILS/geomutile.o ./UTILS/face_op_face.o  ./UTILS/poly_op_poly.o ./UTILS/traite.o ./UTILS/solaire.o ./UTILS/lib_solene_94.o -o calc_temp_iterf -lm

*/


/* Fichiers inclus */
#include<solene.h>
//#include<ctype.h>
//#include<unistd.h>

/* Pointeur global de fichier pour facteurs de forme */
FILE *fp;
/* Pointeur global de fichier pour sauvegarde temperatures en cours de calcul */
FILE *pf_temp;

/* Procedures auxiliaires */
void usage();
void lect_fichier();
int sauve_tableau();
void test_zeros();
void lecture_ff();
void met_a_zero();
/* Modele de ciel dans l'IR */
double IR_ciel();
/* Procedure pour radiosite "generalisee" (incluant temperatures) */
int radiog(); 
/* calcul iteratif des temperatures par application de bilans thermiques */
int calc_temp_iter();



/** Convention: dans le corps du programme, les temperatures sont en Celsius **/
/** A l'interieur des procedures, elles sont en Kelvin **/

main(argc,argv)           
int argc;
char **argv;
{
/* DECLARATIONS DE VARIABLES */
	/* I/O programme */
	/** DONNEES **/
	/*** SOLAIRE ***/
char nom_dflux_inc_sol_init[256]; 
/* fichier (lu) pour densite initiale de flux incident solaire (direct+diffus)*/
double *dflux_inc_sol_init;
/* valeurs */
char nom_refl_sol[256];
/* fichier (lu) pour reflectivites dans le "solaire" (visible + PIR) */
double *refl_sol;
/* valeurs */

	/*** IR thermique et autres ***/
char nom_refl_IR[256];
/* fichier (lu) pour reflectivites dans l'IR */
double *refl_IR;
/* valeurs */
char nom_Tint[256];
/* fichier (lu) pour valeurs de temperature "interne" CL sol et parois */
double *Tint;
/* valeurs lues (en Celsius)*/
char nom_Text[256];
/* fichier (lu) de temperatures d'air externe (en Celsius) */
double *Text;
/* valeurs */
char nom_hext[256];
/* fichier (lu) de coefficient de transfert convectif */
double *hext;
/* valeurs */
/* attention, convection uniquement, pas de transfert radiatif */
char nom_g[256];
/* fichier (lu) pour conductance des parois - murs ou sol */
double *g;
/* valeurs */
double *dflux_inc_ciel;
double dflux_inc_ciel0;
double Tciel4;
/* densite de flux incident recu dans l'IR de la part du ciel */
const double stefan = 5.67e-8;

	/*** GEOMETRIE ***/

char nom_surf[256];
/* fichier (lu) pour surfaces des facettes */
double *surf;
/* valeurs */
char nom_fform[256];
/* fichier (lu) pour facteurs de forme */
float *fform;
/* valeurs */
char nom_frac_ciel[256];
/* fichier (lu) pour fractions de ciel vu (entre 0 et 1) */
double *frac_ciel;
/* valeurs */

	/** CRITERE D'ARRET **/
	/** pour procedure iterative de calcul de temperatures **/
double delta_T_lim; 
/* difference max de temperature pour une face, entre 2 iterations */

	/** RESULTATS **/
char nom_temp[256];
/* fichier (cree) des temperatures calculees, en Celsius */
double *temp;
/* valeurs */
char nom_dflux_abs_sol[256];
/* fichier (cree) des densites de flux nettes (absorbees)solaires */
double *dflux_abs_sol;
/* valeurs */
char nom_dflux_net_IR[256];
/* fichier (cree) des densites de flux nettes (absorbees - emises) dans l'IR (parois) */
double *dflux_net_IR;
/* valeurs */

	/* variables auxiliaires */
int im = 1;		/* impression=oui */
int nbfac;		/* Nombre de faces dans modele geometrique */
int nb_contour_total; 	/* Nombre de contours total */
int *nb_cont_face;	/* Nombre de contours par face */
int *numero_face;	/* Numeros affectes aux faces */
double *exit_init;	/* Exitances (ou radiosites) initiales */
double *exit;		/* Exitances (ou radiosites) calculees */
int flag_arret = 2;	/* Arret quand moins de x% de l'energie initiale */
			/* reste a distribuer */
int epsilon;		/* Si flag_arret = 1 */
double pourc = 0.1;	/* Si flag_arret = 2 */
double seuil;		/* Si flag_arret = 3 */
int nb_iter_max;	/* Si flag_arret = 4 */
/** (pour compatibilite avec programmes existants) **/

char *s_dir;
char c;
/* Pointeur de fichier pour lecture descripteurs */
FILE *pfic;
/* Pointeurs de fichier pour ecriture descripteurs resultats */
FILE *pfic_temp;
FILE *pfic_sol;
FILE *pfic_IR;		

int gi;
int gnum;
int gk;
int nofac;
int nbcont;
double val_min, val_max;
double *auxiliaire;
int test_erreur = 0;
int OK_sauvegarde = 0;
	
	/* DEBUT PROG */
s_dir=(char *)getenv("PWD");

if(argc != 15) usage();

 
	/* lecture parametres commande */

compose_nom_complet(nom_dflux_inc_sol_init,s_dir,argv[1],"val");
printf("  densites de flux incident solaire initiales : %s \n", nom_dflux_inc_sol_init);

compose_nom_complet(nom_refl_sol,s_dir,argv[2],"val");
printf("  coefficients de reflexion solaires: %s \n", nom_refl_sol);

compose_nom_complet(nom_refl_IR,s_dir,argv[3],"val");
printf("  coefficients de reflexion IR: %s \n", nom_refl_IR);

compose_nom_complet(nom_Tint, s_dir, argv[4], "val");
printf("   temperatures internes (C): %s\n", nom_Tint);
	
compose_nom_complet(nom_Text, s_dir, argv[5], "val");
printf("   temperatures externes (C): %s\n", nom_Text);

compose_nom_complet(nom_hext, s_dir, argv[6], "val");
printf("   coefficients de transfert convectif: %s\n", nom_hext);

compose_nom_complet(nom_g, s_dir, argv[7], "val");
printf("   conductances facettes: %s\n", nom_g);

compose_nom_complet(nom_surf,s_dir,argv[8],"val");
printf("  surfaces facettes: %s \n", nom_surf);

compose_nom_complet(nom_fform,s_dir,argv[9],"fac");
printf("  facteurs de forme : %s \n", nom_fform);

compose_nom_complet(nom_frac_ciel,s_dir,argv[10],"val");
printf("  facteurs de vue du ciel : %s \n", nom_frac_ciel);

sscanf(argv[11], "%lf", &delta_T_lim);
printf("  delta limite pour temperature: %f\n", delta_T_lim); 
printf("  ---------------------------------\n");
compose_nom_complet(nom_temp,s_dir,argv[12],"val");
printf("  temperatures calculees (C): %s \n", nom_temp);

compose_nom_complet(nom_dflux_abs_sol,s_dir,argv[13],"val");
printf("  densites de flux solaire absorbe: %s \n", nom_dflux_abs_sol);

compose_nom_complet(nom_dflux_net_IR,s_dir,argv[14],"val");
printf("  densites de flux IR net: %s\n", nom_dflux_net_IR);
printf("  ---------------------------------\n");

	/* LECTURE D'UN FICHIER .val POUR NBRE DE CONTOURS TOTAL */
	/* Lecture du fichier des densites de flux incident initiales */
nb_contour_total=0;
if ((pfic=fopen(nom_dflux_inc_sol_init,"r"))==NULL)
            	{ 
		printf("\n  *** impossible ouvrir %s ***\n\n", nom_dflux_inc_sol_init); 
		goto fin;
            	}
fscanf(pfic,"%d %d %lf %lf",&nbfac,&nomax,&val_min,&val_max);	
numero_face=(int *)malloc(nbfac*sizeof(int));
nb_cont_face=(int *)malloc(nbfac*sizeof(int));
for(gi=0;gi<nbfac;gi++)
		{
		fscanf(pfic,"\n%c%d%d\n",&c,&nofac,&nbcont);
		numero_face[gi]=nofac;
		nb_cont_face[gi]=nbcont;
		nb_contour_total+=nbcont;
		auxiliaire=(double *)malloc(nbcont*sizeof(double));
		for(gk=0;gk<nbcont;gk++)
			fscanf(pfic,"%lf\n",auxiliaire+gk);
		free(auxiliaire);
		}
	
fclose(pfic);
printf("nombre total de contours: %d\n", nb_contour_total);	

	/* allocations memoire */

dflux_inc_sol_init = (double*)malloc(nb_contour_total*sizeof(double));
if (dflux_inc_sol_init==NULL)
	{printf("\n*** Probleme d'allocation flux solaire total incident.\n"); 
	goto fin;}

refl_sol = (double*)malloc(nb_contour_total*sizeof(double));
if (refl_sol==NULL)
	{printf("\n*** Probleme d'allocation albedo bande solaire.\n"); 
	goto fin;}

refl_IR = (double*)malloc(nb_contour_total*sizeof(double));
if (refl_IR==NULL)
	{printf("\n*** Probleme d'allocation albedo bande IR.\n"); 
	goto fin;}

Tint = (double*)malloc(nb_contour_total*sizeof(double));
if (Tint==NULL)
	{printf("\n*** Probleme d'allocation temperatures internes.\n"); 
	goto fin;}

Text = (double*)malloc(nb_contour_total*sizeof(double));
if (Text==NULL)
	{printf("\nProbleme d'allocation temperatures externes.\n"); 
	goto fin;}

hext = (double*)malloc(nb_contour_total*sizeof(double));
if (hext==NULL)
	{printf("\nProbleme d'allocation coefficients de transfert convectif.\n"); 
	goto fin;}

g = (double*)malloc(nb_contour_total*sizeof(double));
if (g==NULL)
	{printf("\n*** Probleme d'allocation conductances.\n"); 
	goto fin;}


surf =(double *)malloc(nb_contour_total*sizeof(double));
if (surf == NULL)
	{printf("\n*** Probleme d'allocation surfaces facettes.\n");
	 goto fin;}

fform =(float *) malloc(nb_contour_total*sizeof(float));
if (fform == NULL)
	{printf("\n*** Probleme d'allocation facteurs de forme.\n");
	goto fin;}

frac_ciel =(double *) malloc(nb_contour_total*sizeof(double));
if (frac_ciel == NULL)
	{printf("\n*** Probleme d'allocation fractions de ciel vu.\n");
	goto fin;}

temp = (double*) malloc(nb_contour_total*sizeof(double));
if (temp == NULL)
	{printf("\n*** Probleme d'allocation temperatures de parois calculees.\n");
	goto fin;}

dflux_abs_sol = (double*) malloc(nb_contour_total*sizeof(double));
if (dflux_abs_sol == NULL)
	{printf("\n*** Probleme d'allocation flux nets solaires calcules.\n");
	goto fin;}

dflux_net_IR = (double*)malloc(nb_contour_total*sizeof(double));
if (dflux_net_IR == NULL)
	{printf("\n*** Probleme d'allocation flux nets IR calcules.\n");
	 goto fin;}

dflux_inc_ciel = (double*) malloc(nb_contour_total*sizeof(double));
if (dflux_inc_ciel == NULL)
	{printf("\n*** Probleme d'allocation flux IR incident ciel.\n");
	goto fin;}

exit_init =(double *)malloc(nb_contour_total*sizeof(double));
if (exit_init == NULL)
	{printf("\n*** Probleme d'allocation vecteur de radiosites initiales.\n");
	 goto fin;}

exit =(double *)malloc(nb_contour_total*sizeof(double));
if (exit == NULL)
	{printf("\n*** Probleme d'allocation vecteur de radiosites calculees.\n");
	goto fin;}

printf("\n\nOK toutes allocations\n\n");


	/*** LECTURE DES FICHIERS POUR DONNEES ***/

	/* Lecture du fichier des densites de flux solaire incident initiales */
if ((pfic=fopen(nom_dflux_inc_sol_init,"r"))==NULL)
       { 
	printf("\n  *** impossible ouvrir %s\n\n", nom_dflux_inc_sol_init); 
	goto fin;
       	}

lect_fichier(pfic, nbfac, nomax, dflux_inc_sol_init);
fclose(pfic);

	/* Lecture des coefficients de reflexion "solaires" */
if ((pfic=fopen(nom_refl_sol,"r"))==NULL)
        { 
	printf("\n  *** impossible ouvrir %s\n\n", nom_refl_sol); 
	goto fin;
        }
lect_fichier(pfic, nbfac, nomax, refl_sol);
fclose(pfic);
test_zeros(nb_contour_total, refl_sol);

/* Lecture des temperatures d'air externe */
if ((pfic=fopen(nom_Text,"r"))==NULL)
        { 
	printf("\n  impossible ouvrir %s\n\n", nom_Text); 
	goto fin;
        }
lect_fichier(pfic, nbfac, nomax, Text);
fclose(pfic);

	/* Lecture des coefficients de transfert convectifs */
if ((pfic=fopen(nom_hext,"r"))==NULL)
        { 
	printf("\n  impossible ouvrir %s\n\n", nom_hext); 
	goto fin;
        }
lect_fichier(pfic, nbfac, nomax, hext);
fclose(pfic);

	/* Lecture des coefficients de reflexion IR */
if ((pfic=fopen(nom_refl_IR,"r"))==NULL)
   	{ 
	printf("\n  *** impossible ouvrir %s\n\n", nom_refl_IR); 
	goto fin;
        }
lect_fichier(pfic, nbfac, nomax, refl_IR);
fclose(pfic);
test_zeros(nb_contour_total, refl_IR);


	/* Lecture des temperatures internes */
if ((pfic=fopen(nom_Tint,"r"))==NULL)
        { 
	printf("\n  *** impossible ouvrir %s\n\n", nom_Tint); 
	goto fin;
        }
lect_fichier(pfic, nbfac, nomax, Tint);
fclose(pfic);


	/* Lecture des conductances */

if ((pfic=fopen(nom_g,"r"))==NULL)
      	{ 
	printf("\n  *** impossible ouvrir %s\n\n", nom_g); 
	goto fin;
        }
lect_fichier(pfic, nbfac, nomax, g);
fclose(pfic);


	/* Lecture de la surface de chaque face */
if ((pfic=fopen(nom_surf,"r"))==NULL)
        { 
	printf("\n  *** impossible ouvrir %s\n\n", nom_surf); 
	goto fin;
        }
lect_fichier(pfic, nbfac, nomax, surf);
fclose(pfic);


	/* Lecture des facteurs de forme */
if ((fp=fopen(nom_fform,"rb"))==NULL)
        { 
	printf("\n  *** impossible ouvrir %s\n\n", nom_fform); 
	goto fin;
        }

	/* Lecture des facteurs de vue du ciel */
if ((pfic=fopen(nom_frac_ciel,"r"))==NULL)
        { 
	printf("\n  *** impossible ouvrir %s\n\n", nom_frac_ciel); 
	goto fin;
        }
lect_fichier(pfic, nbfac, nomax, frac_ciel);
fclose(pfic);

	
	/*** CALCUL ET STOCKAGE DES FLUX NETS DANS LA BANDE SOLAIRE ***/
	/*** SOLAIRE = VISIBLE + PIR ***/

	/* RADIOSITE : METHODE A RAFFINEMENT PROGRESSIF */
printf("\nDebut du calcul ...");
printf("\n");

printf("Calcul du flux solaire absorbe net\n");
printf("(bande visible+proche IR)\n");

	/* Initialisation densite de flux partant */
for (gnum = 0; gnum < nb_contour_total; gnum++)
	exit_init[gnum] = dflux_inc_sol_init[gnum]*refl_sol[gnum];


	/* Lancement iterations */
	im = 0;
	test_erreur = radiog(im, nb_cont_face, numero_face, nbfac, nb_contour_total, exit_init, surf, refl_sol, fform, flag_arret, epsilon, nb_iter_max, seuil, pourc, exit);

	/* A ce stade: exitance = radiosite = densite de flux partant */
	/* de chaque facette, dans la bande visible + PIR */

	for (gnum = 0;gnum<nb_contour_total;gnum++)
		{dflux_abs_sol[gnum] = ((1/refl_sol[gnum]) - 1.0)*exit[gnum];}

	/* ecriture directe du fichier resultat: densite de flux solaire absorbe */

	OK_sauvegarde = sauve_tableau(pfic_sol, nom_dflux_abs_sol, nbfac, nomax, nb_contour_total, numero_face, nb_cont_face, 0.0,dflux_abs_sol);
	if (!OK_sauvegarde)
		{printf("*** Attention, probleme de sauvegarde pour les flux solaires nets. ***\n");
		 goto fin;}
	
	met_a_zero(nb_contour_total, exit_init);
	met_a_zero(nb_contour_total, exit);

	/*** CALCUL DES FLUX IR ET TEMPERATURES DE PAROI ***/

	/* calcul du flux IR recu de la part du ciel */
	/* Modele au choix d'apres la litterature */

/*** Attention, modif a faire pour temperature exterieure ***/
dflux_inc_ciel0 = IR_ciel(Text[0], 0);
printf("Densite de flux maximale recue du ciel dans l'IR: %lf\n\n", dflux_inc_ciel0);
Tciel4= dflux_inc_ciel0/(stefan);
printf("-->> Tciel : %lf\n", pow(Tciel4,0.25)-273);

for (gnum = 0;gnum<nb_contour_total;gnum++)
	dflux_inc_ciel[gnum] = frac_ciel[gnum]*dflux_inc_ciel0;


	im = 0;
	/* Lancement iterations sur temperatures */
	test_erreur = calc_temp_iter(im, nb_cont_face, numero_face, nbfac, nb_contour_total, surf, fform, dflux_abs_sol, refl_IR, Tint, Text, hext, g, dflux_inc_ciel, exit_init, exit, delta_T_lim, temp, dflux_net_IR);


	if (test_erreur)
		{printf("\n*** PROBLEME, le calcul des temperatures a diverge ...\n");
		 printf("Verifiez vos donnees numeriques ? ***\n");
		 goto fin;
		}

	/*** SAUVEGARDE DES RESULTATS, FLUX IR ET TEMPERATURES ***/
	/* ecriture resultats temperatures */
	printf("\n>>> Sauvegarde finale des temperatures en Celsius ... \n");
	
	OK_sauvegarde = sauve_tableau(pfic_temp, nom_temp, nbfac, nomax, nb_contour_total, numero_face, nb_cont_face, 273.0, temp);
	if (!OK_sauvegarde)
		{printf("*** Attention, probleme de sauvegarde pour les temperatures calculees. ***\n");
		 goto fin;}
	/* valeur nette pour chaque facette, dans l'IR */
	
	OK_sauvegarde = sauve_tableau(pfic_IR, nom_dflux_net_IR, nbfac, nomax, nb_contour_total, numero_face, nb_cont_face, 0.0, dflux_net_IR);
	if (!OK_sauvegarde)
		{printf("*** Attention, probleme de sauvegarde pour les flux infrarouges nets. ***\n");
		 goto fin;}



fin:;
printf("Fin\n\n");

fclose(fp);	
	
free(exit_init);
free(exit);
free(dflux_inc_sol_init);
free(refl_sol);
free(refl_IR);
free(Tint);
free(Text);
free(hext);
free(g);
free(surf);
free(fform);
free(frac_ciel);
free(dflux_inc_ciel);
free(temp);
free(dflux_abs_sol);
free(dflux_net_IR);

  creer_OK_Solene();

		
}


/********************** PROCEDURES *********************************/

/*_________________________________________________________________*/
/* Format de la fonction */
void usage()
	{
  	printf("\n   format d'entree des parametres:\n\n");
  	printf("\t*calc_temp_iterf*  flux_solaire_incident(.val) reflectivite_solaire(.val) reflectivite_IR(.val)\n");
	printf("\t temp_internes(.val) temp_externes (.val) \n");
	printf("\tcoef_convection_externe (.val) conductances_facettes(.val) surfaces(.val) \n");
	printf("\tfacteurs_forme(.fac) fac_vue_ciel(.val) delta_temp_limite \n");
	printf("\ttemperatures_calculees(.val)  flux_solaire_net(.val)  flux_IR_net(.val)\n\n");
	printf("\t>>toutes temperatures exprimees en Celsius\n");
	printf("\t>>delta_temp_limite: critere d'arret pour iterations (0.1 a 1 degre)\n");
  	exit(0);
	}

/*_________________________________________________________________*/
/* Lecture fichier au "bon" format et remplissage tableau 'valeur' */
void lect_fichier(pfic, nbfac, nomax, valeur)
FILE *pfic;
int nbfac;
int nomax;
double *valeur;
{ double val_min;
  double val_max;
  int num_cont, num_face, num_cont_liste;
  int nofac, nbcont_face;
  char c;

  fscanf(pfic,"%d %d %lf %lf",&nbfac,&nomax,&val_min,&val_max);
  num_cont_liste = 0;
  for(num_face=0;num_face<nbfac;num_face++)
	{
	fscanf(pfic,"\n%c%d%d\n",&c,&nofac,&nbcont_face);
	for(num_cont=0;num_cont<nbcont_face;num_cont++)	
		{	
		fscanf(pfic,"%lf\n",valeur+num_cont_liste);
		num_cont_liste++;
		}
	}
}
/*______________________________________________________________________________________*/
int sauve_tableau(pf, nom_fichier, nbfac, nomax, nb_contour_total, numero_face, nb_cont_face, decalage, tab)
/* Sauvegarde d'un tableau de valeurs (descripteurs) associees a un fichier de faces et contours */
/* avec eventuellement un decalage (utile pour conversion Kelvin->Celsius) */
FILE *pf;
char *nom_fichier;
int nbfac;
int nomax;
int *numero_face;
int *nb_cont_face;
double decalage;
double *tab;
{ 
double mini, maxi;
int i, k, num;
int sauvOK = 1;

if ((pf= fopen(nom_fichier,"w"))==NULL)
	sauvOK = 0;
else
	{mini=maxi=tab[0]-decalage;
	for(i=0;i<nb_contour_total;i++)
		{
		if(tab[i]-decalage<mini) mini=tab[i]-decalage;
		if(tab[i]-decalage>maxi) maxi=tab[i]-decalage;
		} 

	fprintf (pf,"%5d %5d %8.3lf %8.3lf\n", nbfac, nomax, mini, maxi);   

	num=0;
	for(i=0;i<nbfac;i++)
		{
		fprintf (pf,"f%d %d\n",numero_face[i],nb_cont_face[i]);
		for(k=0;k<nb_cont_face[i];k++)
			{
			fprintf (pf,"    %8.3f\n",tab[num]-decalage);
			num++;
			}
		}
	fclose(pf);
	}
return sauvOK;

}	
/*_____________________________*/
/* Teste si zeros dans tableau */
void test_zeros(nb_valeurs, tab)
int nb_valeurs;
double *tab;
{
int compt;

for (compt=0;compt<nb_valeurs;compt++)
	{if (tab[compt] < 1e-3) 
		{ printf("Erreur, reflectivite nulle rencontree ...\n");
		  printf("Contour no %d\n", compt);
		   exit(0); }		
	}
}

/*____________________________________________*/
/* Met toutes les valeurs d'un tableau a zero */
void met_a_zero(nb_valeurs, tab)
int nb_valeurs;
double *tab;
{int compt;

for (compt=0;compt<nb_valeurs;compt++)
	tab[compt] = 0.0;
}


/*____________________________________________*/
/* Lecture des facteurs de forme dans fichier */
/* Attention, pointeur de fichier global */
void lecture_ff(factf, ii, nb_contour_total)
float *factf;
int ii, nb_contour_total;
{
fseek(fp,(ii*nb_contour_total)*sizeof(float),SEEK_SET);
fread(factf, sizeof(float), nb_contour_total, fp);
/*** Pour comprehension algo: a supprimer ***/
/* printf("Lecture ligne %d: ", ii);
for (f=0;f<nb_contour_total;f++)
	printf("%f", factf[f]);
printf("\n"); */

}


/*______________________________________________________________________*/
/*    Radiosite "generalisee"    					*/
/* Tableau d'entree: `exit_init', tableau de sortie: 'exit' 		*/
/* Dans la bande solaire: mettre en entree la 1ere reflexion 		*/
/* du flux solaire incident 						*/
/* Dans l'IR: mettre en entree l'emission propre de chaque surface 	*/
/* On recupere en sortie l'exitance (ou la radiosite) de chaque surface */
/* pour la bande du spectre consideree 					*/

int radiog(im, nb_cont_face, numero_face, nbfac, nb_contour_total, exit_init,
surf, reflex, fform, flag_arret, epsilon, nb_iter_max, seuil, pourc, exit)

int im;
int *nb_cont_face;
int *numero_face;
int nbfac;
int nb_contour_total;
double *exit_init;
double *surf;
double *reflex;
float *fform;
int flag_arret; 
int epsilon;
int nb_iter_max;
double seuil;
double pourc;
double *exit;


{ 	int face;    
	int num_cont, contour; 
	int iteration; 
	int icont_liste_max;
	int iface_max;
	int icont_max;	
	double energie_totale; 
	double a_distribuer;
	double a_distribuer_preced;
	double a_distribuer_max;
	double *delta_exit;
	double fform_recip;
	double d_exit;
	static int nb_iter_max_abs = 50000;
	int erreur = 0;
  	

	/* Allocations dynamiques */
       	delta_exit =(double *)malloc(nb_contour_total*sizeof(double));
	if (delta_exit==NULL)
		{printf("*** Probleme allocation radiosite residuelle.\n");
		 erreur=1;
		 return erreur;}

	/* initialisations */
	for(contour=0;contour<nb_contour_total;contour++)
	  	exit[contour]=delta_exit[contour]=exit_init[contour];	


	energie_totale=0.0;
   	for(contour=0;contour<nb_contour_total;contour++) 
      		energie_totale+=delta_exit[contour]*surf[contour];
   	printf("\nEnergie totale a distribuer (W): %.2lf\n",energie_totale);
	a_distribuer_preced=energie_totale;
	a_distribuer = energie_totale;


	/* iterations */
	
	iteration=1;
	while(iteration < nb_iter_max_abs) 
   		{
   		//printf("...iteration %d...\r",iteration); 

		/* Recherche de l'element de flux maximal */
   		a_distribuer_max=0.0;
   		num_cont=0;
		for(face=0;face<nbfac;face++)
		  {
		  for(contour=0;contour<nb_cont_face[face];contour++)
		
			{if(delta_exit[num_cont]*surf[num_cont]>a_distribuer_max)
         			{
				a_distribuer_max=delta_exit[num_cont]*surf[num_cont];
				iface_max=face;     
				icont_max=contour+1;   
         			icont_liste_max=num_cont;	  
         			}		 		    
			num_cont++;
			}
		  }

   		if(im) printf("\nFlux maxi (W) en provenance de la face %d, contour %d (no %d) : %5.2f\n",numero_face[iface_max],icont_max,icont_liste_max+1,a_distribuer_max); 
 
		/* lecture des ff[ii] */
	
   		lecture_ff(fform,icont_liste_max, nb_contour_total);
 

		/* contribution de l'element de flux maximal, a tous les autres */
   		for(num_cont=0;num_cont<nb_contour_total;num_cont++) 
      			{
		
			fform_recip=fform[num_cont]*surf[icont_liste_max]/surf[num_cont];
			if(fform_recip>1.) fform_recip=1.;
		
			d_exit=reflex[num_cont]*delta_exit[icont_liste_max]*fform_recip;    
      			delta_exit[num_cont]+=d_exit;
      			exit[num_cont]+=d_exit;  
      			}
   		delta_exit[icont_liste_max]=0.0;

		a_distribuer=0.0;
   		for(num_cont=0;num_cont<nb_contour_total;num_cont++) 
      			a_distribuer+=delta_exit[num_cont]*surf[num_cont]; 
  
   		if(im) printf("energie non distribuee (W): %.2lf\n\n",a_distribuer);


		/* Sortie de boucle ? */
		/* Pas genial mais dependant des conventions adoptees dans
versions precedentes */

		if ((flag_arret == 1) && (a_distribuer < epsilon))
			break;
		if ((flag_arret == 2) && (a_distribuer <
(pourc*energie_totale/100)))
			break;
		if ((flag_arret == 3) &&
(a_distribuer_preced-a_distribuer<seuil))
			break;
		if ((flag_arret == 4) && (iteration > nb_iter_max))
			break;
		
		a_distribuer_preced=a_distribuer;
	   	iteration++;
   		}

	free(delta_exit);
	/* Les resultats a exploiter dans le corps du prog sont dans 'exit' */
	return erreur;
}

/* Calcul du flux IR envoye par le ciel		*/
/*______________________________________________*/
double IR_ciel(Ta, ind_Kelvin)
double Ta; 	/* temperature de l'air ambiant */
int ind_Kelvin; /* flag indiquant si la temperature d'entree est en Kelvin */

{ /* Calcul du flux IR maximum recu en provenance du ciel */
 /* d'apres modele J. Noilhan (Unsworth et Monteith) */
/* On peut choisir un autre modele: Angstrom, Brunt, etc ... */
/* et prendre en compte la nebulosite */

if (ind_Kelvin)
	return (double)(5.5*(Ta-273) + 213);
else
	return (double)(5.5*Ta + 213);
}
 

/* Calcul des temperatures, algo. iteratif				*/
/*______________________________________________________________________*/
int calc_temp_iter(im, nb_cont_face, numero_face, nbfac, nb_contour_total, surf, fform, dflux_abs_sol, refl_IR, Tint, Text, hext, g, dflux_inc_ciel, exit_init, exit, delta_T_lim, temp, dflux_net_IR)

int im;
int *nb_cont_face;
int *numero_face;
int nbfac;
int nb_contour_total;
double *surf;
float *fform;
double *dflux_abs_sol;
double *refl_IR;
double *Tint;
double *Text;
double *hext;
double *g;
double *dflux_inc_ciel;
double *exit_init;
double *exit;
double delta_T_lim;
double *temp;
double *dflux_net_IR;
{
int erreur;
double stefan = 5.67e-8; /* Constante de Stefan */
int flag_arret = 2;
double pourc = 1;
int epsilon = 1;
double seuil = 0.001;
int nb_iter_max = 100;
int nb_iter_max_abs = 100;
double temp_max_abs = 400; /* Precaution contre divergence algo */

int num_cont, num_cont_aux;
int num_cont_dtmax;
int iteration;
double delta_T_max;
double *Text_locale;
double *temp_suiv;

char nom_sauv_temp[256];
int OK_sauvegarde = 0;
/*** Nom fichier pour sauvegarde apres chaque iteration (ecrase la precedente) */
compose_nom_complet(nom_sauv_temp, (char *)getenv("PWD"), "TEMP_CALC_SAUVEGARDE", "val");


temp_suiv = (double*) malloc(nb_contour_total*sizeof(double));
if (temp_suiv == NULL)
	{printf("\n*** Probleme d'allocation dans calcul temperatures\n");
	 /* exit(0); */}

Text_locale = (double*) malloc(nb_contour_total*sizeof(double));
if (Text_locale == NULL)
	{printf("\n*** Probleme d'allocation dans calcul temperatures, temperatures externes\n");
	 /* exit(0); */}

/**** Initialisation de la temperature de toutes les faces ****/
	/* Attention, toutes les temperatures sont ici en Kelvin */

for (num_cont=0;num_cont<nb_contour_total;num_cont++)
	{Text_locale[num_cont] = Text[num_cont]+273;
	temp[num_cont] = Text_locale[num_cont]; }
erreur = 0;	
iteration = 1;
delta_T_max = delta_T_lim + 1;

/**** Iterations sur temperatures ***/

while ((delta_T_max > delta_T_lim) && (iteration < nb_iter_max_abs) && (!erreur)) 
	{ //printf("\n\n----- Temperatures, iteration %d\n\n\n", iteration);
          delta_T_max = 0.0;

	/*** Initialisation des radiosites dans la bande IR ***/
	printf("Initialisation et calcul radiosites IR\n");
	for (num_cont=0;num_cont<nb_contour_total;num_cont++)
		exit_init[num_cont] = (1.0 - refl_IR[num_cont])*stefan*temp[num_cont]*temp[num_cont]*temp[num_cont]*temp[num_cont];

	/*** Calcul des radiosites dans l'IR apres reflexions entre parois ***/
	
	erreur = radiog(im, nb_cont_face, numero_face, nbfac, nb_contour_total, exit_init, surf, refl_IR, fform, flag_arret, epsilon, nb_iter_max, seuil, pourc, exit);


	/*** Calcul des nouvelles temperatures par application des bilans thermiques ***/

	/** Calcul des flux IR nets **/

	/** NB: les flux nets ne sont pas calcules directement a partir  */
	/* des radiosites comme on le faisait dans la bande solaire,     */
	/* car l'expression fait intervenir l'inverse de l'albedo IR     */
	/* or, pour des albedos courants de l'ordre de 0.05, les erreurs */
	/* sont multipliees par 20 ... ce n'est pas satisfaisant 	 */
	/* du point de vue numerique.					**/


	
	for (num_cont=0;num_cont<nb_contour_total;num_cont++)
	  { 
	  dflux_net_IR[num_cont] = 0.0;

	  lecture_ff(fform, num_cont, nb_contour_total); 
 
	  for (num_cont_aux=0;num_cont_aux<nb_contour_total;num_cont_aux++)
		if (num_cont_aux != num_cont) 
			dflux_net_IR[num_cont] = dflux_net_IR[num_cont] + fform[num_cont_aux]*exit[num_cont_aux];

	  dflux_net_IR[num_cont] = (1 - refl_IR[num_cont])*(dflux_net_IR[num_cont]+dflux_inc_ciel[num_cont]);
	  dflux_net_IR[num_cont] = dflux_net_IR[num_cont] - exit_init[num_cont];

	  }

	/** Application des bilans en regime stationnaire **/

	for (num_cont=0;num_cont<nb_contour_total;num_cont++)
		{ temp_suiv[num_cont] = g[num_cont]*(Tint[num_cont]-Text[num_cont]) + dflux_abs_sol[num_cont] + dflux_net_IR[num_cont];
		  temp_suiv[num_cont] = temp_suiv[num_cont]/(g[num_cont] + hext[num_cont]);
		  temp_suiv[num_cont] = Text_locale[num_cont] + temp_suiv[num_cont];
		

//		im=1; /* Pour comprehension algo */
		if (im) 
			{printf("-- Temperature contour %d: %f K, %f C\n", num_cont, temp_suiv[num_cont], temp_suiv[num_cont] - 273);
			printf("-- Flux solaire net: %lf\n", dflux_abs_sol[num_cont]);
			printf("-- Flux IR net:      %lf\n", dflux_net_IR[num_cont]);}

		im=0;


		/* Recherche de la variation de temperature maximale */
		/* entre deux iterations, sur l'ensemble des contours */

		if (((temp_suiv[num_cont] - temp[num_cont]) > delta_T_max) || ((temp_suiv[num_cont] - temp[num_cont]) < -delta_T_max))
			{ num_cont_dtmax = num_cont;
			  if (temp_suiv[num_cont] - temp[num_cont] >0)
				delta_T_max = temp_suiv[num_cont] - temp[num_cont];
			  else
				delta_T_max = temp[num_cont] - temp_suiv[num_cont];
			
			}

		/** Controle divergence **/
		if ((temp_suiv[num_cont] > temp_max_abs) || (temp_suiv[num_cont] < -temp_max_abs))
			{erreur = 1;
			 break;}

		temp[num_cont] = temp_suiv[num_cont];
		}

	if (im && (!erreur))
		{printf("\nIteration %d, diff max de temperature %f pour contour %d\n\n", iteration, delta_T_max, num_cont_dtmax);}
	
	/* Sauvegarde des resultats temporaires (iteration courante) */
	/* avec conversion en Celsius */
	OK_sauvegarde = sauve_tableau(pf_temp, nom_sauv_temp, nbfac, nomax, nb_contour_total, numero_face, nb_cont_face, 273.0, temp);
	if (!OK_sauvegarde)
		printf("*** ATTENTION, probleme sauvegarde temporaire des temperatures iteration %d...\n", iteration);
	else
		printf("OK sauvegarde temperatures calculees iteration %d\n", iteration);

	iteration++;
	}

free(temp_suiv);
free(Text_locale);
return erreur;
}








/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/*

cc  pers.c -o pers pers_util.o  solutile.o geomutile.o face_op_face.o poly_op_poly.o lib_solene_94.o traite.o -lm 

*/

/*  PERS.C mise en perspective d'un fichier .cir solene */

#include<solene.h>
#include<ctype.h>

FILE *fp;
extern int option_calcul_z; /* option CALCUL du Z ds FACE-OP-FACE 1=oui */
extern int z_axono_pers;
struct modelisation_face *alloue_face();

/*____________________________________________________________________*/
/* declarations heliodon()  et axono()  et pers() */
char nom_out[50];
struct modelisation_face *fac1;
int nbfac1,numax;
char buf[256];
/*____________________________________________________________________*/
/* declaration pers() */
double ang,angvis,pi,tgvis,covis,sinvis;
int traitement_coupe;
/*_________________________________________________________________*/
main(argc,argv)                         /* PERSPECTIVE */
 int argc;char **argv;
{int i;
 char c[2],*s_dir;
 double xv,yv,zv;
         
         normale_orientee=1; 
         traitement_faces_cachees=1; 
         traitement_coupe=1;
         nb_etat=0;
         pi=4*atan(1.0);

         fac1=NULL;

         if(argc<10)format_entree_pers();

         s_dir=(char *)getenv("PWD");
  
         compose_nom_complet(buf,s_dir,argv[1],"cir");
         if((fp=fopen(buf,"r"))==NULL)
            { printf("\n impossible ouvrir %s\n",buf); exit(0);
            }
  	 sscanf(argv[2],"%lf",&(obs.xo));
         sscanf(argv[3],"%lf",&(obs.yo));
         sscanf(argv[4],"%lf",&(obs.zo));
  	 sscanf(argv[5],"%lf",&xv);
         sscanf(argv[6],"%lf",&yv);
         sscanf(argv[7],"%lf",&zv);
         sscanf(argv[8],"%lf",&ang);
             /* vecteur de vue */
         obs.x=obs.xo-xv; obs.y=obs.yo-yv; obs.z=obs.zo-zv;

         compose_nom_complet(nom_out,s_dir,argv[9],"cir");
         for(i=10;i<argc;i++)
            { sscanf(argv[i],"%c%c",c,c+1);
              if(c[0]!='-')format_entree_pers();
              if(c[1]=='n') normale_orientee=0;
              else if(c[1]=='t') traitement_faces_cachees=0;
              else if(c[1]=='c') traitement_coupe=0;
              else format_entree_pers();
            }
         if(traitement_faces_cachees)traitement_coupe=1;

         printf("\n CALCUL D'UNE VUE PERSPECTIVE \n");
         printf("fichier a traiter %s\n",buf);
         printf("oeil %lf %lf %lf\n",obs.xo,obs.yo,obs.zo);
         printf("vise %lf %lf %lf\n",xv,yv,zv);
         printf("vect %lf %lf %lf\n",obs.x,obs.y,obs.z);
         printf("nom du fichier de sortie %s\n",nom_out);
         printf("normale %d faces_cachees %d coupe_pyr %d angvis %lf\n",normale_orientee,traitement_faces_cachees,traitement_coupe,ang);
         angvis=pi*ang/180.;
         tgvis=tan(angvis); covis=cos(angvis); sinvis=sin(angvis);

	 tranfo();  /* rotation pour amener axe de visee en Oz ; */
	 traite_perspective();

         normale_orientee=1; traitement_faces_cachees=1;

	creer_OK_Solene();
/* liste_des_pointeurs(); */
}

/*_________________________________________________________________*/
int format_entree_pers()
{
  printf("\n   *pers* fichier_in(.cir) xo yo zo xv yv zv angle_vision fichier_out(.cir) [-n] [-t] [-c] \n\n");
  exit(0);
}

/*_________________________________________________________________*/
int traite_perspective()
{ FILE *fcop;
  int i,nbf,nomax,nbc,vu;
  double xx,yy,zz,englob[10];;

  /* lecture fichier_in */
       lit_en_tete(fp,&nbfac1,&numax,englob);
       fac1=alloue_face(nbfac1,34);
       lit_fic_cir3d(fp,nbfac1,fac1);
       fclose(fp);
printf(" NB FACES = %d\n",nbfac1);

   /* initialise fenetre affichage */
       init_fenetre_affichage();

  /* traite les faces : visibilite,tranfo,decoupe pyramide,perspective */
       if(normale_orientee) printf("VISIBILITE par normale\n");
       if(traitement_coupe) printf("DECOUPAGE par pyramide de vision\n");
       for(i=0;i<nbfac1;i++)
          { /*printf("Face no  %d\n",(fac1+i)->nofac_fichier);*/
            if((fac1+i)->debut_projete)
               { 
                       /* visibilite et transformation des faces */
                 if(normale_orientee==0) vu=1;
                 else vu=visible_pers(fac1+i,1); /* test si face vue */
                 /*if(vu)printf("face no  %d vue\n",(fac1+i)->nofac_fichier);*/

                       /* sans vu/cache et sans coupe pyramide */
                 if(vu && traitement_faces_cachees==0 && traitement_coupe==0)
                    { copie_face_projete(fac1+i,1,fac1+i,0);
                    }
                       /* vu/cache et/ou coupe pyramide */
                 else if(vu)
                    { tran_face(fac1+i,1,fac1+i,0);
                      tran_normale(fac1[i].vnorm);
                    }
                        /* decoupage des faces avec la pyramide de vision */
                 if((fac1+i)->debut_dessin && (traitement_faces_cachees || traitement_coupe)) 
                    { calcul_d_du_plan(fac1+i,0);
/*
printf("AVANT PYRAMIDE\n");
liste_face(fac1+i,0);
*/
                      face_dans_vision(fac1+i,0);
/*
printf("APRES PYRAMIDE\n");
liste_face(fac1+i,0);
*/
                    }
               }
          }
  /* TRAITEMENT */
  /* traite les faces : normalisation et traitement vu/cache */
      if(traitement_faces_cachees)
         {  
                    /* initialise fenetre affichage */
          init_fenetre_affichage();

                    /* mise en perspective */
           for(i=0;i<nbfac1;i++)
	      { if((fac1+i)->debut_dessin)
                   { pers_conic_face(fac1+i,0);
/*
printf("CONIQUE\n");
liste_face(fac1+i,0);
*/
                   }
	      }

                    /* reajuste la fenetre a angle de vision */
           fen_aff[0]=-tgvis; fen_aff[1]=-tgvis; 
           fen_aff[3]=tgvis; fen_aff[4]=tgvis; 
           cal_fen_aff();
/*for(i=0;i<7;i++)printf("aff %lf\n",fen_aff[i]);*/
                    /* attention si angvis proche de 90 */
                    /* on evite fen_aff[6]=0 */
           if(fen_aff[6]<0.008) fen_aff[6]=0.008;

                /* normalise */
            z_axono_pers=1;
            option_calcul_z=0;
            for(i=0;i<nbfac1;i++)
	      { if((fac1+i)->debut_dessin)
                   { normalise_face(fac1+i,0);
/*
printf("NORMALISE\n");
liste_face(fac1+i,0);
*/
            /* A FAIRE test sup_surf et sens face */
                     sens_face(fac1+i,0,1);
                   }
	        copie_face_projete(fac1+i,0,fac1+i,1);
	      }

                /* traite vu/cache ; resultat dans ->dessin */
printf("TRAITE VU CACHE \n");
 /*
printf("AVANT traitement\n");
for(i=0;i<nbfac1;i++)
{ if(fac1[i].debut_projete)
	{ printf("%d\n",(fac1+i)->nofac_fichier);
	 //liste_face(fac1+i,1);
	}
}
printf("\n");
 //*/
            traite_moins(fac1,nbfac1);
            z_axono_pers=0;
            option_calcul_z=1;
 /*
printf("APRES traitement\n");
for(i=0;i<nbfac1;i++)
{ if(fac1[i].debut_dessin)
	{ printf("%d\n",(fac1+i)->nofac_fichier);
	  liste_face(fac1+i,0);
	}
}
printf("\n");
//*/
                /* pers inverse et denormalise  */
           for(i=0;i<nbfac1;i++) 
               { denormalise_face(fac1+i,0);

//printf("DE_NORMALISE\n");
//if(fac1[i].debut_dessin)liste_face(fac1+i,0);

                 pers_face_inverse(fac1+i,0);

//printf("DE_PERS\n");
//if(fac1[i].debut_dessin)liste_face(fac1+i,0);

               }
	 } 

  /* et transfo inverse */
      if(traitement_coupe || traitement_faces_cachees)
         { for(i=0;i<nbfac1;i++) 
             { tran_face_inverse(fac1+i,0);
               tran_normale_inverse(fac1[i].vnorm);

//printf("DE_TRANFO\n");
//if(fac1[i].debut_dessin)liste_face(fac1+i,0);

             }
         }

  /* stockage des resultats dans fichier_out */
      fcop=fopen(nom_out,"w");
      nbf=0;   nomax=0;
      ecrit_en_tete(fcop,nbf,nomax,englob);
      output_face_sur_fichier(fac1,nbfac1,0,0,fcop,&nbf,&nomax);
      rewind(fcop);
      ecrit_en_tete(fcop,nbf,nomax,englob);
      fclose(fcop); 

      desalloue_fface(fac1,nbfac1);
      printf("\n");
}


/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/* masques_ciel_vert.c : ENERGIE RECUE DU CIEL AVEC PRISE EN COMPTE DES MASQUES */

/*
cc masques_ciel.c  pers_util.o  solutile.o  geomutile.o  face_op_face.o  solaire.o  poly_op_poly.o traite.o  lib_solene_94.o -o masques_ciel -lm
*/

// D. GROLEAU  modification mars 2004   appel a coplanaire
// F. MIGUET   modification novembre 2006  ajout option plan fictif vertical (plan de coupe)
//			avec calcul relatif � une normale verticale (calcul sur un patch horizontal appliqu� au centre de chaque maille)
//			id. ecl_plan_fictif
//			rechercher les modifs  : //MODIF nov 2006

/* POUR UN FICHIER .cir, determine, au centre de gravite de chaque contour, l'energie recue du ciel, en tenant compte des masques eventuels 

en tenant compte de plusieurs luminances de ciel	
*/


// ATTENTION  modif de mars 2004:
// Ne tient pas compte des faces situ�es dans le m�me plan que celui du contour de la face en traitement
// donc attention, si des faces int�rieures non visibles (mitoyennes), alors il faut, pour avoir un r�sultat bon su ces faces (cad soleil =0)
// fournir un masque 
// qui contiennent 2 fois les faces du masque, avec les normales dans le bon sens et invers�es.

#include<solene.h>


//Declaration Functions
float calcul_eclair_sur_plan_horizontal();
void calcul_min_max();
void imprime_en_tete_face();
void masque_ciel();
void ne_voit_rien();
void patch_gravite();
int test_si_patch_vu();
void usage_masques_ciel_vert();

//GLOBAL
struct modelisation_face *fac0 ;	/* geometrie a evaluer */
struct modelisation_face *fac1;		/* geometrie des masques */
struct modelisation_face *fac2;		/* geometrie du ciel */

FILE *pval[50];

extern int option_calcul_z;   	/* option CALCUL du Z ds FACE-OP-FACE 1=oui */
                              	/* utilise ds singul.c epure_polygone */
			      	/* et dans face_op_face.c             */
extern double coef_discol;

int im,nbre_patch_vu,nb_pas,sans_masque;
float *valeur_calcul,*valeur_sans_masc;
float *ecl_sur_plan_horizontal;
float *val;
double vnf[3];   		/* normale a la face en traitement */
double tgvis,covis,sinvis;
double *xg_patch,*yg_patch,*zg_patch,*angl_solid;
float *val_min,*val_max;

 double	 epsiloneN;  // parametre de coplanaire
 int	 facteurD;   // parametre de coplanaire

/*_________________________________________________________________*/
main(argc,argv)           /* MASQUE  pour un FICHIER DE FACES */
int argc;char **argv;
	{
	int i,j,noc,nbfac0,nbfac1,nbfac2;
	int nomax0,nomax1,nomax2,nofac,nbcont;
 	double ang;
 	char nom_in[256],nom_masc[256],nom_ciel[256],nom_lumin[256],nom_out[256],nom_angl_solid[256],buf[256];
	char *s_dir,c;
 	FILE *pfic,*pficface;
 	struct contour *pcont;
 	struct circuit *pcir;
 	int *vis;
	double englob[10],mini,maxi;
	int indice;


/* initialisation */
   	singularite=0; non_singularite=0; nb_etat=0;
   	pb_masque=0; colle_max=coef_discol*DISCOL;
   	pi=4*atan(1.);

   // initialisation pour coplan�rit�
   epsiloneN = 0.0001;
   facteurD= 1000;

	s_dir=(char *)getenv("PWD");


 if(argc<11) usage_masques_ciel_vert();
 sscanf(argv[8],"%d",&(sans_masque));
 if(sans_masque && argc<13) usage_masques_ciel_vert();



/* lecture parametres commande */

	compose_nom_complet(nom_in,s_dir,argv[1],"cir");
        printf("\n  geometrie a traiter : %s \n", nom_in);

        compose_nom_complet(nom_masc,s_dir,argv[2],"cir");  
        printf("  geometrie masque : %s \n", nom_masc);

	compose_nom_complet(nom_ciel,s_dir,argv[3],"cir");
        printf("  geometrie de ciel : %s \n", nom_ciel);

	compose_nom_complet(nom_angl_solid,s_dir,argv[4],"val");  
        printf("  angles solides : %s \n", nom_angl_solid);

        sscanf(argv[5],"%d%c%d",&nb_pas); /* doit etre >=1 <50*/
       printf("nb de pas %d\n",nb_pas);
       if(nb_pas <1 || nb_pas>50)
           { printf(" il faut <1<nbpas<50\n\n"); exit(0);
           }

	sscanf(argv[7],"%lf",&ang);
	if(ang<0 || ang>89.99 || ang<15) 
	   	{ 	
		printf("   *** 15 < angle_vision < 89.99 ***\n");
	     	exit(0);
	   	}
        ang=pi*ang/180.;
        tgvis=tan(ang); covis=cos(ang); sinvis=sin(ang);



    	im=0;   /* Pour IMPRESSION mettre  im = 1 */

/* LECTURE DES FICHIERS */
/*** Lecture du fichier CIEL - indice 2 ***/
	if ((pfic=fopen(nom_ciel,"r"))==NULL)
            	{ 
		printf("\n  impossible ouvrir %s\n\n", nom_ciel); 
		exit(0);
            	}
       	lit_en_tete(pfic,&nbfac2, &nomax2, englob);
       	fac2=alloue_face(nbfac2, 1000);
       	lit_fic_cir3d(pfic, nbfac2, fac2);
       	fclose(pfic);

	/* calcul centre gravite patch de ciel */
	
  	xg_patch=alloue_double(nbfac2,1);
  	yg_patch=alloue_double(nbfac2,2);
  	zg_patch=alloue_double(nbfac2,3);
  	patch_gravite(nbfac2);
       	desalloue_fface(fac2,nbfac2);


/*** Lecture des nb_pas LUMINANCES CIEL - indice _2 */
/* attention peut_etre fonction du temps nb_pas*/

/* alloue nbfac2*nb_pas valeurs de luminance */
       	val=alloue_float(nbfac2*nb_pas,4);

       /* le 1er fic de luminance stocke de 0 a nbfac2-1 */
       /* le 2eme fic de luminance stocke de nbfac2 a ... ; et etc */
        indice=0;
        for(i=0;i<nb_pas;i++)
         {
	  sprintf(buf,"%s%d",argv[6],i);
          compose_nom_complet(nom_lumin,s_dir,buf,"val");
          printf("  luminances ou radiances de ciel : %s \n", nom_lumin);
	  if ((pfic=fopen(nom_lumin,"r"))==NULL)
            	{ 
		printf("\n  impossible ouvrir %s\n\n", nom_lumin); 
		exit(0);
            	}
	  fscanf(pfic,"%d %d %lf %lf",&nbfac2,&nomax2,&mini,&maxi);
	  for(j=0;j<nbfac2;j++)
	   { fscanf(pfic,"\n%c%d%d\n%f\n",&c,&nofac,&nbcont,val+indice+j);
           }
          fclose(pfic);
          indice=indice+nbfac2;
         }

/* Lecture des ANGLES_SOLIDES CIEL des elements de ciel - indice _2 */
	if ((pfic=fopen(nom_angl_solid,"r"))==NULL)
            	{ 
		printf("\n  impossible ouvrir %s\n\n", nom_angl_solid); 
		exit(0);
            	}
	fscanf(pfic,"%d %d %lf %lf",&nbfac2,&i,&mini,&maxi);
       	angl_solid=alloue_double(nbfac2,5);
	for(i=0;i<nbfac2;i++)
		fscanf(pfic,"\n%c%d%d\n%lf\n",&c,&nofac,&nbcont,angl_solid+i);
       	fclose(pfic);


/*** Lecture en tete de la GEOMETRIE a traiter ***/

		//changement

       	if ((pficface=fopen(nom_in,"r"))==NULL)
            	{ 
		printf("\n impossible ouvrir %s\n\n", nom_in); 
		exit(0);
            	}
       	lit_en_tete(pficface,&nbfac0, &nomax0, englob);
       	printf("  %d faces a traiter", nbfac0);

/*** Lecture de GEOMETRIE MASQUE - indice 1 ***/
       	if ((pfic = fopen(nom_masc,"r"))==NULL)
            	{ 
		printf("\n impossible ouvrir %s\n", nom_masc); 
		exit(0);
            	}
       	lit_en_tete(pfic,&nbfac1, &nomax1, englob);
       	printf(" avec masque de %d faces\n\n", nbfac1);
       	fac1=alloue_face(nbfac1, 34);
      	lit_fic_cir3d(pfic, nbfac1, fac1);
      	fclose(pfic);


       	vis=alloue_int(nbfac1,1);


/*** OPEN LES FICHIERS VAL RESULTATS ***/
/* 0 a nbpas-1 : eclairement */
/* nbpas a 2*npas-1 :  facteur lum du jour */
/* si calcul sans masque : *
/* 2*npas a         : eclairement sans masque */
/* 3*nbpas a        : % reduction */ 

        indice=0;
	                   /** eclairement **/
	mini=0; maxi=0;
        for(i=0;i<nb_pas;i++)
         {
	  sprintf(buf,"%s%d",argv[9],i);
          compose_nom_complet(nom_out,s_dir,buf,"val");
          printf("  descripteur a creer : %s \n", nom_out);
	  if ((pval[indice]=fopen(nom_out,"w"))==NULL)
            	{ 
		printf("\n  impossible ouvrir %s\n\n", nom_out); 
		exit(0);
            	}
	  fprintf (pval[indice],"%5d %5d %10.2f %10.2f\n", nbfac0, nomax0, mini, maxi);   
    	  indice++;
         }
	                    /** facteur jour **/
	mini=0; maxi=100;
        for(i=0;i<nb_pas;i++)
         {
	  sprintf(buf,"%s%d",argv[10],i);
          compose_nom_complet(nom_out,s_dir,buf,"val");
          printf("  descripteur a creer : %s \n", nom_out);
	  if ((pval[indice]=fopen(nom_out,"w"))==NULL)
            	{ 
		printf("\n  impossible ouvrir %s\n\n", nom_out); 
		exit(0);
            	}
	  fprintf (pval[indice],"%5d %5d %10.2f %10.2f\n", nbfac0, nomax0, mini, maxi);   
    	  indice++;
         }
       
       if(sans_masque)
        {
                 	/** eclairement sans masque**/
          for(i=0;i<nb_pas;i++)
           {
	    sprintf(buf,"%s%d",argv[11],i);
            compose_nom_complet(nom_out,s_dir,buf,"val");
            printf("  descripteur : %s \n", nom_out);
	    if ((pval[indice]=fopen(nom_out,"w"))==NULL)
            	{ 
		 printf("\n  impossible ouvrir %s\n\n", nom_out); 
		 exit(0);
            	}
	    fprintf (pval[indice],"%5d %5d %10.2f %10.2f\n", nbfac0, nomax0, mini, maxi);   
    	    indice++;
           }
         	       /** % reduction eclair du aux  masques**/
	  mini=0; maxi=100;
          for(i=0;i<nb_pas;i++)
           {
			sprintf(buf,"%s%d",argv[12],i);
            compose_nom_complet(nom_out,s_dir,buf,"val");
            printf("  descripteur : %s \n", nom_out);
			if ((pval[indice]=fopen(nom_out,"w"))==NULL)
            	{ 
					printf("\n  impossible ouvrir %s\n\n", nom_out); 
					exit(0);
            	}
			fprintf (pval[indice],"%5d %5d %10.2f %10.2f\n", nbfac0, nomax0, mini, maxi);   
    	    indice++;
           }
        }

/*** Alloue les valeurs contenant les nbpas RESULTATS ***/
  	valeur_calcul=alloue_float(nb_pas,1);
  	valeur_sans_masc=alloue_float(nb_pas,1);

/*** Alloue les valeurs contenant les nbpas val_min val_max ***/
/* 0 a nbpas-1 : eclairement */
/* nbpas a 2*npas-1 :  eclairement sans masque */
        indice=2*nb_pas; if(sans_masque) indice=indice*2;
  	val_min=alloue_float(indice,1);
  	val_max=alloue_float(indice,1);
        for(i=0;i<indice;i++) 
	 { val_min[i]=1000000; val_max[i]=-val_min[i];
         }

/*** EVALUE a chaque pas L'eclairement recu sur Un plan HORIZONTAL ***/
/* stocke les nb_pas valeurs */
       	ecl_sur_plan_horizontal=alloue_float(nb_pas,4);

        indice=0;
        for(i=0;i<nb_pas;i++)
         { ecl_sur_plan_horizontal[i]=calcul_eclair_sur_plan_horizontal(indice,nbfac2);
	       indice+=nbfac2;
         }

  
/* observateur regarde vers le haut a verticale de oeil */
        obs.x=0; obs.y=0; obs.z=-1; 


/* TRAITEMENT POUR CHAQUE CONTOUR DE CHAQUE FACE DE NOM_IN */
	printf("Traitement en cours ...\n");


  /* alloue 1 seule face */   
       	fac0=alloue_face(1,1000);

        for(i=0;i<nbfac0;i++)
           	{    /* lit la face */    	
                  lit_fic_cir3d(pficface, 1, fac0);


// MODIF nov 2006
				noc=0;
//				vnf[0]=(fac0)->vnorm[0]; 
//				vnf[1]=(fac0)->vnorm[1]; 
//				vnf[2]=(fac0)->vnorm[2]; 
				vnf[0]=0; 
				vnf[1]=0; 
				vnf[2]=1; 
//


				/** imprime dans .VAL pour chaque face **/
				imprime_en_tete_face(fac0);

             	pcont=(fac0)->debut_projete; 
				while(pcont)	   
               		{ 
						pcir=pcont->debut_support;
		                centre_de_gravite(pcir, &obs.xo, &obs.yo, &obs.zo);
                 		noc++;

						//printf("FACE %d  Contour %d\n",(fac0)->nofac_fichier,noc); 
                        //printf("   %lf %lf %lf\n",obs.xo,obs.yo,obs.zo);
						/* EN COMMENTAIRE
						if(traite_coplanerite(obs.xo,obs.yo,obs.zo,fac0,fac1,nbfac1))
			              { 
					          //l'observateur est masqu� totalement
					         printf("CACHE\n");
			                 ne_voit_rien(nbfac2);
		                  }
		                else */
		                  {
 						     /**APPEL FONCTION DE CALCUL */ 
                		     masque_ciel(nbfac1,nbfac2,fac0,vis);

						     //printf("  nombre de patches de ciel vus %d\n",nbre_patch_vu);
						  }
                 		pcont=pcont->suc;

                 		if(im)
                  		{ 
							printf("  FACE %d  Contour %d\n",(fac0)->nofac_fichier,noc);
                    		printf("  %lf %lf %lf\n",obs.xo,obs.yo,obs.zo);
							printf("  nombre de patches de ciel vus %d\n",nbre_patch_vu);
						} 
               		}
                 desalloue_contour_face(fac0); 
           	}
		desalloue_double(xg_patch);
		desalloue_double(yg_patch);
		desalloue_double(zg_patch);
	    desalloue_int(vis); desalloue_float(val); desalloue_double(angl_solid);
       	desalloue_fface(fac0,1);
       	desalloue_fface(fac1,nbfac1);
    	fclose(pficface);

   /* reecrit les min max pour ... */
        indice=0;
	                   /** eclairement **/
        for(i=0;i<nb_pas;i++)
         {
	  rewind(pval[indice]);
	  fprintf (pval[indice],"%5d %5d %10.2f %10.2f\n", nbfac0, nomax0, val_min[i], val_max[i]);   
    	  indice++;
         }
        indice=2*nb_pas;
	                   /** eclairement sans masque**/
     if(sans_masque)
       { for(i=0;i<nb_pas;i++)
         {
	  rewind(pval[indice]);
	  fprintf (pval[indice],"%5d %5d %10.2f %10.2f\n", nbfac0, nomax0,val_min[nb_pas+i], val_max[nb_pas+i] );   
    	  indice++;
         }
       }

        indice=nb_pas*2; if(sans_masque) indice=indice*2;
        for(i=0;i<indice;i++)
         {
	  fclose(pval[i]);
         }

     desalloue_float(val_min); desalloue_float(val_max);
     desalloue_double(valeur_calcul); desalloue_double(valeur_sans_masc);
     free(ecl_sur_plan_horizontal);

creer_OK_Solene();
	printf("\n\nFin du Traitement masques_ciel\n");
	exit(0);
	}


/*_________________________________________________________________*/
void masque_ciel(nbfac1,nbfac2,fac0,vis)
int nbfac1,nbfac2,*vis;
struct modelisation_face *fac0;
	{
	int i,kj,vu,indice;
	double cos_ang_inc, xyz[3], ang_inc;
	float v1;

  /* TRANSFORMATION fichier "masque" et COUPE PYRAMIDE , si vu */
       tranfo();
       for(i=0;i<nbfac1;i++)
		{ //printf(" Examine avec face %d\n",(fac1+i)->nofac_fichier);
		  //if((fac1+i)->nofac_fichier != fac0->noface_fichier)
	      //if(!(coplanaire(fac0,1,fac1+i,1,0.00001)))
			if(!(coplanaire(fac0,1,fac1+i,1,epsiloneN, 0,facteurD)))

              { //printf(" qui ne sont pas coplanaire\n");
				if(visible_pers(fac1+i,1))
                   { 
					 //printf(" avec face Visible  %d\n",(fac1+i)->nofac_fichier);
					 vis[i]=1;

                     tran_face(fac1+i,1,fac1+i,0);
                     tran_normale((fac1+i)->vnorm);
                     if((fac1+i)->debut_dessin) 
                        { calcul_d_du_plan(fac1+i,0);
                          face_dans_vision(fac1+i,0);
                        }
                   }
                 else vis[i]=0;
               }
             else vis[i]=0;
          }


  /* PERSPECTIVE */
       init_fenetre_affichage();
       for(i=0;i<nbfac1;i++)
	  { if((fac1+i)->debut_dessin)
               { pers_conic_face(fac1+i,0);
               }
	  }

  /* reajuste la fenetre a angle de vision */
       fen_aff[0]=-tgvis; fen_aff[1]=-tgvis; 
       fen_aff[3]=tgvis; fen_aff[4]=tgvis; 
       cal_fen_aff();
              /* attention si angvis proche de 90 */
              /* on evite fen_aff[6]=0 */
       if(fen_aff[6]<0.008) fen_aff[6]=0.008;

  /* NORMALISATION */
       for(i=0;i<nbfac1;i++)
	  { if((fac1+i)->debut_dessin)
               { normalise_face(fac1+i,0);
               }
          }


/** ANALYSE DES PATCHES DE CIEL **/
	for(kj=0;kj<nb_pas;kj++)
 	 { valeur_sans_masc[kj]=0.0;
  	   valeur_calcul[kj]=0.0;
     }
	nbre_patch_vu=0;
           /* considere chaque patch avec sa luminance a chaque pas (nb-pas) */
  	for(i=0;i<nbfac2;i++)
      {  
		xyz[0]=xg_patch[i], xyz[1]=yg_patch[i], xyz[2]=zg_patch[i];
		cos_ang_inc=vincid(vnf,xyz,&ang_inc);
		if (cos_ang_inc>0)
		   { vu=test_si_patch_vu(nbfac1,xg_patch[i],yg_patch[i],zg_patch[i]);
		     nbre_patch_vu+=vu;
		     indice=0;
             for(kj=0;kj<nb_pas;kj++)
 		      {
			
       			valeur_calcul[kj]+=vu*val[i+indice]*cos_ang_inc*angl_solid[i];  
  
                          /*sans tenir compte du masque */
			    valeur_sans_masc[kj]+=val[i+indice]*cos_ang_inc*angl_solid[i];
 			    indice+=nbfac2;
 		      }
		   }
	/*	printf("\n%d  %lf  a=%lf",i,cos_ang_inc,a);*/
      }

/* calcul des min_max pour la face en traitement */
   for(kj=0;kj<nb_pas;kj++)
    { 
          calcul_min_max(valeur_calcul[kj],val_min+kj,val_max+kj);
          calcul_min_max(valeur_sans_masc[kj],val_min+kj+nb_pas,val_max+kj+nb_pas);
    }

/* ECRITURE Des FICHIERS .val */

        indice=0;
	                   /** eclairement **/
        for(i=0;i<nb_pas;i++)
         {
	      fprintf (pval[indice],"%10.2f\n",  valeur_calcul[i]);   
    	  indice++;
         }
	                    /** facteur jour **/
        for(i=0;i<nb_pas;i++)
         {
	      fprintf (pval[indice],"%10.2f\n", 100* (valeur_calcul[i]/ecl_sur_plan_horizontal[i]));   
    	  indice++;
         }
       
       if(sans_masque)
        {
                 	/** eclairement sans masque**/
          for(i=0;i<nb_pas;i++)
           {
	        fprintf (pval[indice],"%10.2f\n", valeur_sans_masc[i]);   
    	    indice++;
           }
         	       /** % reduction eclair du aux  masques**/
          for(i=0;i<nb_pas;i++)
           { if(valeur_sans_masc[i])
		      { v1 = 100*(valeur_sans_masc[i]-valeur_calcul[i])/valeur_sans_masc[i];
		        if(v1 < 0 ) v1 = 0;
		        if(v1 > 100) v1 = 100;
		      }
		     else v1 = 0;
	         fprintf (pval[indice],"%10.2f\n", v1);   
    	    indice++;
           }
        }
		

/* reinverse la normale et desallocation face->dessin */  
         for(i=0;i<nbfac1;i++)
	  { if(vis[i])
              { tran_normale_inverse((fac1+i)->vnorm);
                vis[i]=0;
              }
            if((fac1+i)->debut_dessin)
              { desalloue_chaine_contour((fac1+i)->debut_dessin);
                (fac1+i)->debut_dessin=NULL;
              }

          }
}
/*-----------------------------------------------------------------------------*/
int test_si_patch_vu(nbfac1,xg,yg,zg)
int nbfac1;
double xg,yg,zg;
	{
	int in,ij;
 	double xyz[3];
	double xp, yp, zp;

       	tranp(xg,yg,zg,xyz,xyz+1,xyz+2);
/* coupe par pyramide : retient ou non le point */

       	if(xyz[2]<0 && fabs(xyz[0]/xyz[2])<tgvis && fabs(xyz[1]/xyz[2])<tgvis) 
          	{ 
/* met en pers */
                xp=-xyz[0]/xyz[2];
                yp=-xyz[1]/xyz[2];
                zp=0;
                normalise_point(xp,yp,zp,&xp,&yp,&zp);
                 /* test si dans masque */
               	in=0;
               	for(ij=0;ij<nbfac1;ij++)
                 	{  
			if((fac1+ij)->debut_dessin)
                       		{ 
				in=point_dans_face(xp,yp,fac1+ij,0);
                         	if(in) return(0);
                       		}
                 	}
                /*printf("xp= %lf yp= %lf in= %d\n",xp,yp,in);*/
		return(1);
	   	}
 	return(0);
	}


/*-----------------------------------------------------------------------------*/
void patch_gravite(nbfac2)
int nbfac2;
	{
	int i,k;
 	struct contour *pcont;
 	struct circuit *pcir;

        for(i=0;i<nbfac2;i++)
           	{ 
             	pcont=(fac2+i)->debut_projete;
	        pcir=pcont->debut_support;

                xg_patch[i]=0; yg_patch[i]=0; zg_patch[i]=0; 

                for(k=0;k<pcir->nbp-1;k++) 
                       	{ 
			xg_patch[i]+=pcir->x[k];
                    	yg_patch[i]+=pcir->y[k];
                    	zg_patch[i]+=pcir->z[k];

                /*printf("%d : %lf %lf %lf\n",k+1,pcir->x[k],pcir->y[k],pcir->z[k]);*/
                       	}

                xg_patch[i]=xg_patch[i]/(pcir->nbp-1);
                yg_patch[i]=yg_patch[i]/(pcir->nbp-1);
                zg_patch[i]=zg_patch[i]/(pcir->nbp-1);  
/*	printf ("\n%d  %lf %lf %lf",i, xg_patch[i],yg_patch[i],zg_patch[i]); 
      	printf ("\n%d  %lf",i, 180/pi*acos(zg_patch[i]/sqrt(xg_patch[i]*xg_patch[i]+yg_patch[i]*yg_patch[i]+zg_patch[i]*zg_patch[i]))); */
     		}
	}

/*_________________________________________________________________*/

float calcul_eclair_sur_plan_horizontal(indice,nbfac2)
int indice,nbfac2;
{

float ecl_sur_plan_horizontal;
int i,nbre_patch_vu;
double xyz[3],ang_inc,cos_ang_inc;

	nbre_patch_vu=0;
        ecl_sur_plan_horizontal=0;
        vnf[0]=0; vnf[1]=0; vnf[2]=1;

           /* considere chaque patch avec sa luminance a chaque pas (nb-pas) */
  	for(i=0;i<nbfac2;i++)
    		{  
		xyz[0]=xg_patch[i], xyz[1]=yg_patch[i], xyz[2]=zg_patch[i];
		cos_ang_inc=vincid(vnf,xyz,&ang_inc);
		if (cos_ang_inc>0)
		   {   
                          /*sans tenir compte du masque */
			ecl_sur_plan_horizontal+=val[i+indice]*cos_ang_inc*angl_solid[i];
			nbre_patch_vu++;
		   }
    		}
	printf("Nbre patch vus %d  ecl_horizontal %f\n",nbre_patch_vu,ecl_sur_plan_horizontal);

return(ecl_sur_plan_horizontal);
}

/*_________________________________________________________________*/

void calcul_min_max(valeur,val_min,val_max)
float valeur;
float *val_min,*val_max;
{ if(valeur<*val_min) *val_min=valeur;
  if(valeur>*val_max) *val_max=valeur;
}

/*_________________________________________________________________*/
void imprime_en_tete_face(fac0)
struct modelisation_face *fac0;
{
  int i,indice;

        indice=0;
	                   /** eclairement **/
        for(i=0;i<nb_pas;i++)
         {
	  fprintf (pval[indice],"f%d %d\n",(fac0) ->nofac_fichier,nb_contour_face(fac0,1));   
    	  indice++;
         }
	                    /** facteur jour **/
        for(i=0;i<nb_pas;i++)
         {
	  fprintf (pval[indice],"f%d %d\n",(fac0) ->nofac_fichier,nb_contour_face(fac0,1));   
    	  indice++;
         }
       
       if(sans_masque)
        {
                 	/** eclairement sans masque**/
          for(i=0;i<nb_pas;i++)
           {
	  fprintf (pval[indice],"f%d %d\n",(fac0) ->nofac_fichier,nb_contour_face(fac0,1));   
    	    indice++;
           }
         	       /** % reduction eclair du aux  masques**/
          for(i=0;i<nb_pas;i++)
           {
	  fprintf (pval[indice],"f%d %d\n",(fac0) ->nofac_fichier,nb_contour_face(fac0,1));   
    	    indice++;
           }
        }
}
/*_________________________________________________________________*/
void ne_voit_rien(nbfac2)
int nbfac2;
{
 int kj,i,indice,indice_s;
 float v1;
 double cos_ang_inc, xyz[3], ang_inc;

 for(kj=0;kj<nb_pas;kj++)
   { valeur_sans_masc[kj]=0.0;
  	 valeur_calcul[kj]=0.0;
   }
 nbre_patch_vu=0;

/* ECRITURE Des FICHIERS .val */

 indice=0;
	                   /** eclairement **/
 for(i=0;i<nb_pas;i++)
   {
	 fprintf (pval[indice],"%10.2f\n",  valeur_calcul[i]);   
     indice++;
   }
	                   /** facteur jour **/
 for(i=0;i<nb_pas;i++)
   {
	 fprintf (pval[indice],"%10.2f\n", 100* (valeur_calcul[i]/ecl_sur_plan_horizontal[i]));   
     indice++;
   }
       
 if(sans_masque)
   {           /* considere chaque patch avec sa luminance a chaque pas (nb-pas) */

  	for(i=0;i<nbfac2;i++)
      {  
		xyz[0]=xg_patch[i], xyz[1]=yg_patch[i], xyz[2]=zg_patch[i];
		cos_ang_inc=vincid(vnf,xyz,&ang_inc);
		if (cos_ang_inc>0)
		   { 
		     indice_s=0;
             for(kj=0;kj<nb_pas;kj++)
 		      {  
                          /*sans tenir compte du masque */
			    valeur_sans_masc[kj]+=val[i+indice_s]*cos_ang_inc*angl_solid[i];
 			    indice_s+=nbfac2;
 		      }
		   }
	   }
	  
	/// stocke le reultat
                       /** eclairement sans masque**/
    for(i=0;i<nb_pas;i++)
       {
	     fprintf (pval[indice],"%10.2f\n", valeur_sans_masc[i]); 
    	 indice++;
       }
         	       /** % reduction eclair du aux  masques**/
    for(i=0;i<nb_pas;i++)
       { if(valeur_sans_masc[i])
		  { v1 = 100*(valeur_sans_masc[i]-valeur_calcul[i])/valeur_sans_masc[i];
		    if(v1 < 0 ) v1 = 0;
		    if(v1 > 100) v1 = 100;
		  }
		 else v1 = 0;
	     fprintf (pval[indice],"%10.2f\n", v1);   
    	 indice++;
       }
   }
		
}

/*_________________________________________________________________*/
/* Format de la fonction masques_ciel */
void usage_masques_ciel_vert()
	{
 printf("\n   *masques_ciel_vert*   geometrie_in(.cir)  geom_masque(.cir)  ciel(.cir)    angl_solid_ciel(.val)  nb_de_luminances a traiter NOM_fichier_luminance_ciel(0,1,2.val)  angle_vision calcul_aussi_sans_masque eclair_dir_out(.val) fac_lum_jour(.val) [ ecl_dir_sans_masque_out(.val) %%reduc_eclair_du_aux_masques]n\n");
 printf("\n      la fonction a comme parametre ENTREE :\n\n");
 printf("\t geometrie_a_simuler_in(.cir)\n"); 
 printf("\t geometrie_masque_in(.cir)\n");
 printf("\t geometrie_de_ciel_in(.cir)\n"); 
 printf("\t angle_solide_de_ciel_in(.val)\n"); 
 printf("\t nb de luminances de ciel a traiter (<50)\n"); 
 printf("\t NOM generique des fichiers de luminance de ciel (0 1 2 .val)\n");
 printf("\t angle_vision\n"); 
 printf("\t calcul_sans_masque(1 oui; 0 non)\n");
   
 printf("\n           comme parametres en SORTIE, les descripteurs .val :\n\n");
   
 printf("\t eclairement direct en povenance du ciel(0 1 2.val)\n"); 
 printf("\t facteur de lumiere du jour : composante directe(0 1 2.val)\n"); 
 printf("          si calcul_sans_masque\n");
 printf("\t eclairement direct en provenance du ciel sans masque(0 1 2.val)\n"); 
 printf("\t %%reduction eclairement du aux masques(0 1 2.val)\n\n"); 
  	exit(0);
	}



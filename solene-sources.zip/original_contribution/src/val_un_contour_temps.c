/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

//  val_un_contour_temps


// D.GROLEAU avril 2003
// D. GROLEAU MODIF fev 2006  sortie excel , voir MODIF fev 2006

// A faire : g�n�raliser la sortie Dplot (titres notamment, valeur abscisses)

// //
// trace une valeur fonction du temps pour un contour 

#include<solene.h>

// DECLARE FUNCTIONS

void format_entree();
void met_extension ();
void test_min_max();


/*_________________________________________________________________*/
main(argc,argv) 
int argc;char **argv;

{
FILE *fpval1, *pg, *pgE;
char buf[256],nom_val1[256],*s_dir,c;
int hh1,hh2,pas,minute;
int nbfac,nomax,nofac,nbcont;
int i,j,gk,temps,indice;
double vmin_gen,vmax_gen;
int miny,maxy,interv_y;

float xh_heure;
int h_heure,m_minute ,nb_pas;
char extension[32];

double v1, valeurG[1024], v_bidon;
int no_de_face,no_de_contour;

 if(argc != 8) { format_entree(); exit(0); }

	s_dir=(char *)getenv("PWD");

printf("Commande Solene: val_un_contour_temps\n\n");
		
	 	sscanf(argv[1],"%d",&no_de_face);
	 	sscanf(argv[2],"%d",&no_de_contour);

	//  heures debut et fin , pas
         sscanf(argv[4],"%d%c%d",&hh1,&c,&minute);
         hh1=hh1*60+minute;
         sscanf(argv[5],"%d%c%d",&hh2,&c,&minute); 
         hh2=hh2*60+minute;
         sscanf(argv[6],"%d%c%d",&pas,&c,&minute);
         pas=pas*60+minute;
         printf(" de hh1 %d a hh2 %d par pas de %d\n",hh1,hh2,pas);
 
 /* calcul du nombre de pas */
   nb_pas=1;
   i=hh1;
   while(i<hh2)
    { nb_pas++;
      i=i+pas;
    }
printf("nb de pas %d\n",nb_pas);


/* constitue le fichier grf correspondant */
/* avec les valeurs en fonction du temps */

			/* calcule min_max pour le pas i  */
			
			vmin_gen=10000000.; vmax_gen=-vmin_gen;

  temps=hh1;
   for(i=0;i<nb_pas;i++)
     { 
		xh_heure= (float)temps/60;
		h_heure= (int) xh_heure;
		m_minute= temps-h_heure*60;
		printf(" heure_minute %2d H %2d\n",h_heure,m_minute);

		// appel extension 
		  met_extension(temps,extension);

		// ouvre val  en Input pour cette heure
		  sprintf(buf,"%s%s",argv[3],extension);
          compose_nom_complet(nom_val1,s_dir,buf,"val");
          printf("  descripteur val1 : %s \n", nom_val1);
	      if ((fpval1=fopen(nom_val1,"r"))==NULL)
            { 
				printf("\n  impossible ouvrir %s\n\n", nom_val1); 
				exit(0);
            }

		// Lit et stocke  le resultat pour no_de_face no_de_contour
			fscanf(fpval1,"%d %d %lf %lf",&nbfac,&nomax,&v_bidon,&v_bidon);	
        indice=0;
        for(j=0;j<nbfac;j++)
           { 
			fscanf(fpval1,"\n%c%d%d\n",&c,&nofac,&nbcont);
				 for(gk=0;gk<nbcont;gk++) 
					{ fscanf(fpval1,"%lf\n",&v1);
					  if(nofac == no_de_face && (gk+1) == no_de_contour)
					  { valeurG[i] = v1;
					    test_min_max(v1,&vmin_gen,&vmax_gen);
					  }
					  indice++;
					}
            }
		fclose(fpval1);		
		temps+=pas;
      }  // fin for i (nb de pas)

   // STOCKAGE des valeurs pour affichage avec Dplot (.grf) et Excel (.xls)
   // fichier graphique en sortie Dplot
          compose_nom_complet(buf,s_dir,argv[7],"grf");
	      if ((pg=fopen(buf,"w"))==NULL)
            { 
				printf("\n  impossible ouvrir %s\n\n", buf); 
				exit(0);
            }
	printf(" \n Ecriture du graphe DPLOT : %s\n",buf);

// MODIF fev 2008
          compose_nom_complet(buf,s_dir,argv[7],"txt");
	      if ((pgE=fopen(buf,"w"))==NULL)
            { 
				printf("\n  impossible ouvrir %s\n\n", buf); 
				exit(0);
            }
	printf(" \n Ecriture du graphe pour Excel : %s\n",buf);
// FIN MODIF fev 2008


	// fait le graphique

	fprintf(pg,"DPLOT/W v1.2\ndata\n1\n");
	fprintf(pg,"%d\n",nb_pas);
    temps=hh1;
    for(i=0; i<nb_pas; i++)
	{
// MODIF fev 2008
//		xh_heure= (float)((pas*i)/60.);	// de 0 � n	
//		fprintf(pg,"%f,%f\n",xh_heure,valeurG[i]);

		xh_heure= (float)temps/60;

		fprintf(pg,"%f,%f\n",xh_heure,valeurG[i]);

		h_heure= (int) xh_heure;
		m_minute= temps-h_heure*60;
		fprintf(pgE,"%2d %2d %10.3f\n",h_heure,m_minute,valeurG[i]);
		temps+=pas;
// FIN MODIF fev 2008

	}

	fprintf(pg," 1    0\n\n\n");
	// titre 1
	fprintf(pg," %s\n\n",argv[3]);
	// axe x
	fprintf(pg," temps en heures \n");
	// axe y

// MODIF fev 2008
//	fprintf(pg," Temperature\n");
	fprintf(pg,"    \n");
// FIN MODIF fev 2008

	fprintf(pg,"     1\n");
	fprintf(pg,"0,0\n");
	fprintf(pg,"Grid Type\n");
	fprintf(pg,"01\n");
	fprintf(pg,"LineWidths\n");
	fprintf(pg," 30\n");
	// echelle en Y
	miny= vmin_gen; maxy=vmax_gen;
	printf("\nvaleurs min et max : %f %f \n",vmin_gen,vmax_gen);
	if((maxy-miny) > 100) interv_y= 50;
	else interv_y= 2;
	fprintf(pg,"Manual Scale\n");

// MODIF fev 2008
//	fprintf(pg,"0.0 %d\n",miny);
	temps=hh1;
	fprintf(pg,"%f %d\n",(float)temps/60,miny);
//	fprintf(pg,"%f %d\n",(float)((nb_pas-1)*pas/60.),maxy);
	temps=hh1+(nb_pas*60);
	fprintf(pg,"%f %d\n",(float)temps/60,maxy);
// FIN MODIF fev 2008

	fprintf(pg,"TickInterval\n");
	fprintf(pg,"2,%d\n",interv_y);
	fprintf(pg,"PointSizes\n");
	fprintf(pg," 7\n");
	fprintf(pg," 10 18 14 14 14 14 10\n");
	fprintf(pg,"SymbolSizes\n");
	fprintf(pg," 125\n");
	fprintf(pg,"Stop\n");
	fclose(pg);

creer_OK_Solene();
printf("\nFin val_un_contour_temps\n\n");

}


/*_________________________________________________________________*/
void test_min_max(x,vmin_gen,vmax_gen)
double x;
double *vmin_gen,*vmax_gen;
{
		 if(x < *vmin_gen) *vmin_gen =  x;
         if(x > *vmax_gen) *vmax_gen =  x;
}


//_____________________________________________________
void met_extension (temps,extension)
int temps;
char *extension;
{  // modele energie diffuse meteo
	float xh_heure;
	int h_heure, m_minute;

		xh_heure= (float)temps/60;
		h_heure= (int) xh_heure;
		m_minute= temps-h_heure*60;
		//printf(" heure_minute %d H %d\n",h_heure,m_minute);
		//construit extension pour fichier val heure
		if(h_heure>=10 && m_minute >=10)
		{
		 sprintf(extension,"_%dH%d",h_heure,m_minute);
		}
		else if(h_heure>=10 && m_minute <10)
		{
		 sprintf(extension,"_%dH0%d",h_heure,m_minute);
		} 
		else if(h_heure<10 && m_minute >=10)
		{
		 sprintf(extension,"_0%dH%d",h_heure,m_minute);
		} 
		else if(h_heure <10 && m_minute <10)
		{
		 sprintf(extension,"_0%dH0%d",h_heure,m_minute);
		} 
		//printf("extension %s\n",extension);
}


/*_________________________________________________________________*/

void format_entree()
{
 printf("\n la fonction val_un_contour_temps\n a comme parametre ENTREE :\n\n");
 printf("\t no_de_face \n");
 printf("\t no_de_contour \n");
 printf("\t nom_generique_fichier_val(.val)\n");
 printf("\t hh1:mm1\n");
 printf("\t hh2:mm2\n");
 printf("\t pas(hh:mn)\n");

 printf("\n comme parametres en SORTIE:\n\n");
 printf("\t fichier_graphique(.grf pour DPLOT et .txt pour EXCEL)\n");
  
 printf("\nNOTA: Le programme ajoute une extension _hhHmm au nom de fichier correspondant � l'heure du calcul\n");
 printf("\n");
 exit(0);
  
}

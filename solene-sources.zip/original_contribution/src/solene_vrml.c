/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/* 
cc -o solene_vrml  solene_vrml.c ~marenne/newsolene/solutile.o ~marenne/newsolene/geomutile.o ~marenne/newsolene/lib_solene_94.o -lm
*/


/*transmet les faces .cir  pour VRML extension .wrl */
/* mais que le 1er contour */


#include<solene.h>


/*_______________________________________*/
/*declaration application */

FILE *fpcir1,*fpgl;

int nbfac1,nomax1;

struct modelisation_face *fs,*fac1;

/************************************************/
main(argc,argv)
int argc;char **argv;
{
 char buf[512],c[2],*s_dir;
 int 	i;
 float	v;
 double englob[10];

  if(argc!=3){ format_entree(); exit(0);}


	s_dir=(char *)getenv("PWD");


 compose_nom_complet(buf,s_dir,argv[1],"cir");
  if((fpcir1=fopen(buf,"r"))==NULL)
	{ printf("impossible ouvrir %s\n",buf);
	  exit(0);
	}
	
 compose_nom_complet(buf,s_dir,argv[2 ],"wrl");
  if((fpgl=fopen(buf,"w"))==NULL)
	{ printf("impossible ouvrir %s\n",buf);
	  exit(0);
	}
	
   lit_en_tete(fpcir1,&nbfac1,&nomax1,englob);
   fac1=alloue_face(nbfac1,1000);
   lit_fic_cir3d(fpcir1,nbfac1,fac1); 
   fclose(fpcir1);

	exporte();
 

 	 creer_OK_Solene();

 printf("\n\nFin du Traitement solene_vrml\n");

}
/*------------------------------------------------------------*/
int exporte()
{
 int 	i,j,nofac,id;
 char c;
 struct contour    	*pcont;
 struct circuit 	*pcir; 
 double xnf,ynf,znf;

  fprintf(fpgl,"#VRML V2.0 utf8\n\n");
  fprintf(fpgl,"# conversion SOLENE (CERMA) en VRML V2.0 utf8\n\n");
/*  fprintf(fpgl,"WorldInfo {\n  title "test pour solene"\n}\n");
*/
	for(i=0;i<nbfac1;i++)
	 {  
  printf("face i= %d\n",i);
  fprintf(fpgl,"DEF poly_extrud Transform {\n");
  fprintf(fpgl,"  children [\n");

     fprintf(fpgl,"  Shape {\n");
     fprintf(fpgl,"    appearance Appearance {\n");
     fprintf(fpgl,"      material Material {\n");
     fprintf(fpgl,"        diffuseColor 0.549 0.3451 0.8824\n");
     fprintf(fpgl,"      }\n");
     fprintf(fpgl,"     }\n");

     fprintf(fpgl,"     geometry DEF poly_extrud-FACES IndexedFaceSet {\n");
     fprintf(fpgl,"       ccw FALSE\n");
     fprintf(fpgl,"       solid FALSE\n");
     fprintf(fpgl,"       coord DEF poly_extrud-COORD Coordinate { point [\n");
     /* les coordonnees */

           j=0;
	   pcont=(fac1+i)->debut_projete;
           while(pcont)	   
             { pcir=pcont->debut_support; 
   if(j)fprintf(fpgl,",\n");

               ajoute_contour_coord(pcir,j);

               j++;
               pcont=pcont->suc; 
             } 
    fprintf(fpgl,"]\n");
    fprintf(fpgl,"       }\n");

    fprintf(fpgl,"       coordIndex [\n");

    /* les indices des faces */
           j=0; id=0;
	   pcont=(fac1+i)->debut_projete;
           while(pcont)	   
             { pcir=pcont->debut_support; 
   if(j)fprintf(fpgl,",\n");
               ajoute_contour_face(pcir,j,&id);
               j++;
               pcont=pcont->suc; 
             } 

    fprintf(fpgl,"]\n");
    fprintf(fpgl,"       }\n");
    fprintf(fpgl,"     }\n");


  fprintf(fpgl,"]\n");
  fprintf(fpgl,"}\n");

         }
}

/*________________________________________________________________________*/

int ajoute_contour_coord(pcircuit,no_cir)
struct circuit 	*pcircuit; 
int no_cir; 
{
  int 	j;

/* les coordonnees */

  for(j=0;j<pcircuit->nbp-1;j++)
	{ 
  if(j != pcircuit->nbp-2) fprintf(fpgl,"  %10.3f   %10.3f %10.3f,\n",pcircuit->x[j],pcircuit->y[j],pcircuit->z[j]);
 else
  fprintf(fpgl,"  %10.3f   %10.3f %10.3f\n",pcircuit->x[j],pcircuit->y[j],pcircuit->z[j]);

        }
}

/*________________________________________________________________________*/

int ajoute_contour_face(pcircuit,no_cir,id)
struct circuit 	*pcircuit; 
int no_cir,*id; 
{
  int 	j;

/* les indices */

  for(j=0;j<pcircuit->nbp-1;j++)
	{ 
          fprintf(fpgl," %d,",*id);
          *id=*id+1;
        }
  fprintf(fpgl," -1\n");

}

/*------------------------------------------------------------*/
int format_entree()
{
  printf("\n   *solene_vrml*  fichier_cir(.cir)   fichier_out(.wrl)  \n\n");
  printf("\n exporte fichier solene.cir  dans fichier vrml.wrl \n");

}



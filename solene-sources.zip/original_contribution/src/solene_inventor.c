/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/* 
cc -o solene_opengl  solene_opengl.c solutile.o geomutile.o lib_solene_94.o -lm
*/


/*transmet les faces .cir et un .val pour OPENGL extension .iv */
/* mais que le 1er contour */
#include <stdio.h>
#include <math.h>
#include <string.h>

/*_______________________________________*/
/* STRUCTURE  SOLENE */

int nb_etat;

struct modelisation_face { int nofac_fichier;
			   double vnorm[4];
			   double fen[6];
                           int inverse;
                           struct contour *debut_projete  ;
	                   struct contour *debut_dessin;
	                 };

struct contour{ int *etat;
	        struct circuit *debut_support;
		struct circuit *debut_interieur;
		struct contour *suc;
	      };

struct circuit{ int nbp;
                  int statut;  /* 0:face plane 1:face non plane 2:ligne 2D  3:ligne 3D */
		  float transp;
		  float visible;
                  double fen[6];
                  double vnorm[4]; /* A VOIR pourrait etre supprime si on avait le no de la face */
		  double *x;	            
		  double *y;
	          double *z;
		  struct circuit *suc;
		 };


/* DECLARATION des fonctions */

struct modelisation_face *alloue_face();
struct contour *alloue_contour();
struct circuit *alloue_circuit();


/*_______________________________________*/
/*declaration application */

FILE *fpcir1,*fpgl;

int nbfac1,nomax1;

struct modelisation_face *fs,*fac1;

/************************************************/
main(argc,argv)
int argc;char **argv;
{
 char buf[512],c[2],*s_dir;
 int 	i;
 float	v;
 double englob[10];

  if(argc!=3){ format_entree(); exit(0);}


	s_dir=(char *)getenv("PWD");


 compose_nom_complet(buf,s_dir,argv[1],"cir");
  if((fpcir1=fopen(buf,"r"))==NULL)
	{ printf("impossible ouvrir %s\n",buf);
	  exit(0);
	}
  printf("\n\nConversion fichier solene : %s\n", buf);
	
 compose_nom_complet(buf,s_dir,argv[2 ],"iv");
  if((fpgl=fopen(buf,"w"))==NULL)
	{ printf("impossible ouvrir %s\n",buf);
	  exit(0);
	}
  printf("en fichier openInventor : %s\n", buf);
	
   lit_en_tete(fpcir1,&nbfac1,&nomax1,englob);
   fac1=alloue_face(nbfac1,1000);
   lit_fic_cir3d(fpcir1,nbfac1,fac1); 
   fclose(fpcir1);

	exporte();

	creer_OK_Solene();

	printf("Fin solene_inventor\n\n");

}
/*------------------------------------------------------------*/
int format_entree()
{
  printf("\n   *solene_opengl*  fichier_cir(.cir)   fichier_out(.iv)  \n\n");
  printf("\n conversion fichier solene .cir  en fichier openInventor .iv \n");

}


/*------------------------------------------------------------*/
int exporte()
{
 int 	i,j,nofac;
 char c;
 struct contour    	*pcont;
 struct circuit 	*pcir; 
 double xnf,ynf,znf;

 fprintf(fpgl,"#Inventor V1.0 ascii\n\n");
  fprintf(fpgl,"Separator {\n\tTransform {\n\t\ttranslation 0 0 0\n\t\tscaleFactor 1 1 1\n\t}\n\tGroup { \n\t\tNormalBinding {\n\t\t\tvalue PER_FACE \n\t\t}\n\t\tLightModel {\n\t\t\tmodel PHONG\n\t\t}\n\t\tGroup {");

	for(i=0;i<nbfac1;i++)
	 {  
		//printf("face i= %d\n",i);
	    xnf=(fac1+i)->vnorm[0];
	    ynf=(fac1+i)->vnorm[1];
	    znf=(fac1+i)->vnorm[2];
           j=0;
	   pcont=(fac1+i)->debut_projete;
           while(pcont)	   
             { pcir=pcont->debut_support; 
               ajoute_contour(pcir,j,xnf,ynf,znf);
               j++;
               pcont=pcont->suc; 
             } 
         }

fprintf(fpgl,"\t\t}\n");
fprintf(fpgl,"\t}\n");
fprintf(fpgl,"}\n");


}

/*________________________________________________________________________*/

int ajoute_contour(pcircuit,no_cir,xnf,ynf,znf)
struct circuit 	*pcircuit; 
int no_cir; 
double xnf,ynf,znf;
{
  int 	j;
  char c ='"';

/*printf("%c\n",c);*/

  fprintf(fpgl,"\n\t\t\tSeparator {\n\t\t\t\tLabel {\n\t\t\t\t\tlabel ");
  fprintf(fpgl,"%c",c);
  fprintf(fpgl,"face contour");
  fprintf(fpgl,"%c",c);
  fprintf(fpgl,"\n\t\t\t\t}\n\t\t\t\tCoordinate3 {\n\t\t\t\t\t point [");
/*printf("OK\n",c,c);*/

/* les coordonnees */

  for(j=0;j<pcircuit->nbp-1;j++)
	{ 
/* printf("%15.3f %15.3f %15.3f,\n",pcircuit->x[j],pcircuit->y[j],pcircuit->z[j]);*/

if(j==0)
  fprintf(fpgl,"%15.3f %15.3f %15.3f,\n",pcircuit->x[j],pcircuit->y[j],pcircuit->z[j]);

else if(j==pcircuit->nbp-2)
  fprintf(fpgl,"\t\t\t\t\t\t%15.3f %15.3f %15.3f]\n",pcircuit->x[j],pcircuit->y[j],pcircuit->z[j]);

else
  fprintf(fpgl,"\t\t\t\t\t\t%15.3f %15.3f %15.3f,\n",pcircuit->x[j],pcircuit->y[j],pcircuit->z[j]);
	}
fprintf(fpgl,"\t\t\t\t}\n");

/* les normales au contour */

 fprintf(fpgl,"\t\t\t\tNormal {\n\t\t\t\t\tvector [ %15.3f %15.3f %15.3f ]\n\t\t\t\t}\n",xnf,ynf,znf);

/* la  face du contour */

 fprintf(fpgl,"\t\t\t\tIndexedFaceSet {\n\t\t\t\t\tcoordIndex [ ");
 for(j=0;j<pcircuit->nbp-1;j++)
	{ fprintf(fpgl," %d,",j);
        }

 fprintf(fpgl," -1 ]\n\t\t\t\t}\n");
/* fin d'un contour */

fprintf(fpgl,"\t\t\t}\n");

}

/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

//  val_temperature


// D.GROLEAU janvier 2003

// //
// calcul temperature de surface de parois en permanent
// applicable � la double peau de BPA (Noble, TETRARC)

#include<solene.h>

// DECLARE FUNCTIONS 

void format_entree();
void test_min_max();


/*_________________________________________________________________*/
main(argc,argv) 
int argc;char **argv;

{
FILE *fpval1,*fpval2,*fpvalr;
char nom_val1[256],nom_val2[256],nom_valr[256],*s_dir,c;
int nbfac,nomax,nofac,nbcont;
int j,gk;
double vmin_gen,vmax_gen;

double valeur,v1;
double tri,tp,tpmax,tpmin,ti,te,hp,he,kve,kvi,absorbe,absorbi,fa,xext;
double fluxmax,fluxmin;
double dt, df;
int ext;

 if(argc != 15) { format_entree(); exit(0); }

	s_dir=(char *)getenv("PWD");

printf("Commande : val_temperature\n\n");

/*
 1 flux_incident(.val) :	
 2 taux_de_flux_transmis :	tri 
 3 temperature_peau:		tpmax
 4 temperature_peau:		tpmin
 5 temperature_int:			ti
 6 temperature_ext:			te
 7 h_peau:					hp
 8 h_ext:					he
 9 U_de_la_vitre ext:			kve
10 taux_absorption_solaire_de_la_vitre_ext:		absorbe
11 U_de_la_vitre ext:			kve
12 taux_absorption_solaire_de_la_vitre_ext:		absorbi
13 vitre_exterieure(1) ou interieure(0)\n"): ext (fichier.val)

1' nom_fichier_temperature(.val)
*/

// lit les param�tres de la vitre
         sscanf(argv[2],"%lf",&tri);
         sscanf(argv[3],"%lf",&tpmax);
         sscanf(argv[4],"%lf",&tpmin);
         sscanf(argv[5],"%lf",&ti);
         sscanf(argv[6],"%lf",&te);
         sscanf(argv[7],"%lf",&hp);
         sscanf(argv[8],"%lf",&he);
         sscanf(argv[9],"%lf",&kve);
         sscanf(argv[10],"%lf",&absorbe);
         sscanf(argv[11],"%lf",&kvi);
         sscanf(argv[12],"%lf",&absorbi);


// ouvre val des flux incidents en Input
          compose_nom_complet(nom_val1,s_dir,argv[1],"val");
          printf(" flux incident (INPUT)  : %s\n", nom_val1);
	      if ((fpval1=fopen(nom_val1,"r"))==NULL)
            { 
				printf("\n  impossible ouvrir %s\n\n", nom_val1); 
				exit(0);
            }
// ouvre val descripteurs peau_int�rieure (0) peau_ext�rieur (1) en Input
          compose_nom_complet(nom_val2,s_dir,argv[13],"val");
          printf(" descripteur(int/ext) (INPUT)  : %s\n", nom_val2);
	      if ((fpval2=fopen(nom_val2,"r"))==NULL)
            { 
				printf("\n  impossible ouvrir %s\n\n", nom_val2); 
				exit(0);
            }

// ouvre val resultat en Output
          compose_nom_complet(nom_valr,s_dir,argv[14],"val");
          printf(" temperature val resultat (OUTPUT) : %s\n", nom_valr);
	      if ((fpvalr=fopen(nom_valr,"w"))==NULL)
            { 
				printf("\n  impossible ouvrir %s\n\n", nom_valr); 
				exit(0);
            }

// Lit le flux incident en effectuant le calcul de temp�rature et �crit le resultat
		fscanf(fpval1,"%d %d %lf %lf",&nbfac,&nomax,&fluxmin,&fluxmax);	
		fscanf(fpval2,"%d %d %lf %lf",&nbfac,&nomax,&vmin_gen,&vmax_gen);	

		// evalue delta temperature de la double peau et delta flux (max et min)
		dt= tpmax-tpmin;
		df= fluxmax-fluxmin;

		/* calcule min_max   */
		vmin_gen=10000000.; vmax_gen=-vmin_gen;
		fprintf(fpvalr,"%6d %6d %15.4f %15.4f\n",nbfac,nomax,vmin_gen,vmax_gen);	

        for(j=0;j<nbfac;j++)
           { 
			fscanf(fpval1,"\n%c%d%d\n",&c,&nofac,&nbcont);
			fscanf(fpval2,"\n%c%d%d\n",&c,&nofac,&nbcont);
			fprintf(fpvalr,"f%d %d\n",nofac,nbcont);
				 for(gk=0;gk<nbcont;gk++) 
					{ fscanf(fpval1,"%lf\n",&v1);
				      fscanf(fpval2,"%lf\n",&xext);
					  ext=(int) xext;

					  // evalue temperature de la double peau en f(flux)
					  tp= tpmin + dt * (v1-fluxmin)/ df;
					  
					  if(ext)			
					  { // temperature de surface: vitre ext�rieure
						fa = v1*absorbe ; // flux absorb�
						valeur=  (hp*tp - kve*(tp-te-fa/he))/hp;
					  }
					  else
					  { // temperature de surface: vitre ext�rieure
						fa = v1*tri*absorbi ; // flux absorb�
						valeur=  (hp*tp + fa + kvi*( ti-tp-fa/hp))/ hp;

					  }
					  //valeur = valeur + 273;
					  test_min_max(valeur,&vmin_gen,&vmax_gen);
					  fprintf(fpvalr,"%12.4f\n",valeur);
					}
            }
		fclose(fpval1);
		fclose(fpval2);
        rewind(fpvalr);
   		fprintf(fpvalr,"%6d %6d %15.4f %15.4f\n",nbfac,nomax,vmin_gen,vmax_gen);	
		fclose(fpvalr);
		
creer_OK_Solene();
printf("\nFin val_temperature\n\n");

}


/*_________________________________________________________________*/
void test_min_max(x,vmin_gen,vmax_gen)
double x;
double *vmin_gen,*vmax_gen;
{
		 if(x < *vmin_gen) *vmin_gen =  x;
         if(x > *vmax_gen) *vmax_gen =  x;
}


/*_________________________________________________________________*/

void format_entree()
{
 printf("\n la fonction val_temperature\n a comme parametre ENTREE :\n\n");
 printf("\t flux_incident(.val) \n");
 printf("\t transmission solaire (entre 0 et 1) de la peau exterieure\n"); 
 printf("\t temperature_dans_la_doublepeau (obtenue pour le max de flux)\n");
 printf("\t temperature_dans_la_doublepeau (obtenue pour le min de flux)\n");
 printf("\t temperature_int\n");
 printf("\t temperature_ext\n");
 printf("\t h_peau\n");
 printf("\t h_ext\n");
 printf("\t U_de_la_vitre ext�rieure\n");
 printf("\t taux_absorption_solaire_de_la_vitre_exterieure\n");
 printf("\t U_de_la_vitre interieure\n");
 printf("\t taux_absorption_solaire_de_la_vitre_exterieure\n");

 printf("\t descripteur_int_ext(.val)  (vitre_exterieure(1) ou interieure(0))\n");

 printf("\n comme parametres en SORTIE:\n\n");
 printf("\t nom_fichier_temperature(.val)\n");
  
 printf("\n");
 exit(0);
  
}

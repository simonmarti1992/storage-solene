/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

#ifndef _TRAITE_H_
#define _TRAITE_H_

#include "tc_solene_structures.h"

int traite_moins(int,struct modelisation_face*);
int traite_moins_hel(struct modelisation_face*, int, struct modelisation_face*, int);
int devder(int , int , struct modelisation_face *);
int traite_union_nouveau(struct modelisation_face *, int , struct modelisation_face *);
int traite_union(int, struct modelisation_face *);
int traite_inter(int, int);

#endif

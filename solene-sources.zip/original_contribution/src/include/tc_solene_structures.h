/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

#ifndef _TC_SOLENE_STRUCTURES_H_
#define _TC_SOLENE_STRUCTURES_H_

struct circuit{
  int nbp;
  int statut;  /* 0:face plane 1:face non plane 2:ligne 2D  3:ligne 3D */
  float transp;
  float visible;
  double fen[6];
  double vnorm[4]; /* A VOIR pourrait etre supprime si on avait le no de la face */
  double *x;                
  double *y;
  double *z;
  struct circuit *suc;
} cir0,cir1;
/* cir0:circuit situe derriere */
/* cir1:circuit situe devant   */

struct contour{
  int *etat;
  struct circuit *debut_support;
  struct circuit *debut_interieur;
  struct contour *suc;
};

struct modelisation_face {
  int nofac_fichier;
  double vnorm[4];
  double fen[6];
  int inverse;
  struct contour *debut_projete  ;
  struct contour *debut_dessin;
}*face;

#endif

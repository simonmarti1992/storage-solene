/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */


// face_appartenance 
 
//			(solutile.o geomutile.o lib_solene_94)

// D.GROLEAU   mars 2003

/*
 cherche appartenace d'une face  par rapport � un fichier de faces
 ( test si face dans face)
*/


#include<solene.h>

// FUNCTIONS
void format_entree();
int point_ds_poly_et_ds_face();
int point_interieur();
void traite();

//GLOBAL
extern double coef_discol;
FILE *pfic1,*pfic2,*pval;
int nbfac1,nbfac2;
struct modelisation_face *fac1,*fac2;
double mini,maxi;

/*_________________________________________________________________*/
main(argc,argv)                         /* APPARTENANCE */
int argc;char **argv;
{
 char buf[256],*s_dir;
 int nomax1,nomax2;
 double englob1[10],englob2[10];
 struct modelisation_face *fac1,*fac2;
         
         if(argc!=4)format_entree();

    singularite=0; non_singularite=0; nb_etat=0;
    s_dir=(char *)getenv("PWD");

	printf("Fonction Solene : face_appartenance\n\n");

/* open */     
         compose_nom_complet(buf,s_dir,argv[1],"cir");
         if((pfic1=fopen(buf,"r"))==NULL)
            { printf("\n impossible ouvrir %s\n",buf); exit(0);}
         printf("\n Cherche appartenance des faces de %s\n",buf);

         compose_nom_complet(buf,s_dir,argv[2],"cir");
         if((pfic2=fopen(buf,"r"))==NULL)
            { printf("\n impossible ouvrir %s\n",buf); exit(0);}
         printf(" par rapport aux faces de %s\n",buf);

         compose_nom_complet(buf,s_dir,argv[3],"val");
         if((pval=fopen(buf,"w"))==NULL)
	    { printf("impossible ouvrir %s\n",buf);
	      exit(0);
	    }
         printf(" Resultat dans %s\n",buf);

/* lecture  pfic1 */
       lit_en_tete(pfic1,&nbfac1,&nomax1,englob1);
       printf("\nTraite %d faces\n",nbfac1);
       fac1=alloue_face(nbfac1,34);
       lit_fic_cir3d(pfic1,nbfac1,fac1);
       fclose(pfic1);

/* lecture  pfic2 */
       lit_en_tete(pfic2,&nbfac2,&nomax2,englob2);
       printf("par rapport a %d faces\n",nbfac2);
       fac2=alloue_face(nbfac2,34);
       lit_fic_cir3d(pfic2,nbfac2,fac2);
       fclose(pfic2);

/* Traite */
       mini=1; maxi=-1;
       fprintf (pval,"%5d %5d %10.2f %10.2f\n", nbfac1, nomax1, mini, maxi); 

       traite(fac1,fac2);

/* Met a jour min max */
       rewind(pval);
       fprintf (pval,"%5d %5d %10.2f %10.2f\n", nbfac1, nomax1, mini, maxi); 

printf("Fin face_appartenance\n\n");

creer_OK_Solene();

}
/*_________________________________________________________________*/
void traite(fac1,fac2)
struct modelisation_face *fac1,*fac2;
{
 int i,j,l,nbcontour,ok;
 double xp,yp,valeur;

 for(i=0;i<nbfac1;i++)
  {
    printf(" Face no %d",(fac1+i)->nofac_fichier);

	   /* cherche nb de contours */
    nbcontour=nb_contour_face(fac1+i,1);	

    fprintf(pval,"f%d %d\n",(fac1+i)->nofac_fichier,nbcontour); 

    /* cherche un point interieur a la face */
    if((point_interieur(fac1+i,&xp,&yp)))
     {
       /* cherche appartenance pt interieur de fac1 a fac2 */
       ok=0;
       for(j=0;j<nbfac2;j++)
         { 
	   if((point_dans_face(xp,yp,fac2+j,1)))
             { printf(" dans face %d\n",(fac2+j)->nofac_fichier);
               valeur=(fac2+j)->nofac_fichier;
               if(valeur>maxi) maxi=valeur;
               if(valeur<mini) mini=valeur;
	       for(l=0;l<nbcontour;l++) fprintf(pval,"%15.6f\n",valeur);
               ok=1;
               break;
             }
          
         }

        /* ne trouve pas d'appartenance */
        if(ok==0)
           { printf(" NE TROUVE PAS d'APPARTENANCE\n");
             for(l=0;l<nbcontour;l++) fprintf(pval,"0.0\n");
             if(mini>0) mini=0;
             if(maxi<0) maxi=0;
           }

     }

    else
     { printf(" NE TROUVE PAS  de pt interieur\n");
       for(j=0;j<nbcontour;j++) fprintf(pval,"0.0\n");
       if(mini>0) mini=0;
       if(maxi<0) maxi=0;

     }
  }
}

/*_________________________________________________________________*/
int point_interieur(face,xp,yp)
struct modelisation_face *face;
double *xp,*yp;
{
 struct contour *pcont;
 struct circuit *pcir;
 double xx,yy,zz;
 int k;

  xx=0;
  yy=0;
  pcont=(face)->debut_projete; 

  if((face)->vnorm[2]==0)
  {
	// si face verticale, prend le centre de gravit� du contour
	pcir=pcont->debut_support;
	centre_de_gravite(pcir,&xx,&yy,&zz);
	*xp=xx;
    *yp=yy;
    return(1);
  }

  // sinon cherche un point int�rieur
  pcir=pcont->debut_support;
  for(k=0;k<pcir->nbp-1;k++) 
     { xx+=pcir->x[k];
       yy+=pcir->y[k];
     }
  xx=xx/(pcir->nbp-1);
  yy=yy/(pcir->nbp-1);

           /* test si dans la face */

  if((point_ds_poly_et_ds_face(&xx,&yy,pcir,face)))
    { *xp=xx;
      *yp=yy;
      return(1);
    }
  else 
    { /*printf(" NE TROUVE PAS  de pt interieur, met 0\n");*/
      return(0);
    }
}

/*______________________________________________________*/
int point_ds_poly_et_ds_face(xg,yg,pcir,face)
double *xg,*yg;
struct circuit *pcir;
struct modelisation_face *face;
{ 
 int isur,idedan,nb;
 double xs,ys,dx,dy,fac;
/*
int i;
printf("%f %f \n",*xg,*yg);
for(i=0;i<pcir->nbp;i++)
     printf("%f %f \n",pcir->x[i],pcir->y[i]);
*/

  xs=*xg; ys=*yg;
  
  nb=0;
  fenetre_circuit(pcir);
  fac=10;

  while(1 && nb<100)
   {
	  dx=(pcir->fen[3]-pcir->fen[0]);

	  xs=*xg; ys=*yg;
	  while(xs < pcir->fen[3])
	   { xs=xs+dx/fac; 
	     inpoly(&idedan,&isur,xs,ys,pcir);
	     if(idedan)
               {
                 if((point_dans_face(xs,ys,face,1)))
                  { *xg=xs;
                    return(1);
                  }
               }
	   }  
	  xs=*xg; ys=*yg;
	  while(xs > pcir->fen[0])
	   { xs=xs-dx/fac; 
	     inpoly(&idedan,&isur,xs,ys,pcir);
	     if(idedan)
               {
                 if((point_dans_face(xs,ys,face,1)))
                  { *xg=xs;
                    return(1);
                  }
               }

	   }
	 dy=(pcir->fen[4]-pcir->fen[1]);

	 xs=*xg; ys=*yg;
	 while(ys < pcir->fen[4])
	   { ys=ys+dy/fac; 
	     inpoly(&idedan,&isur,xs,ys,pcir);
	     if(idedan)
               {
                 if((point_dans_face(xs,ys,face,1)))
                  { *xg=xs;
                    return(1);
                  }
               }

	   }
	 xs=*xg; ys=*yg;
	 while(ys > pcir->fen[1])
	   { ys=ys-dy/fac; 
	     inpoly(&idedan,&isur,xs,ys,pcir);
	     if(idedan) 
               {
                 if((point_dans_face(xs,ys,face,1)))
                  { *xg=xs;
                    return(1);
                  }
               }

	   }

         fac=fac*2; nb++;
	 
   }
 printf("    pas reussi a trouver pt interieur  \n");
}
	
/*_________________________________________________________________*/
void format_entree()
{
  printf("\n   format d'entree des parametres \n\n");
  printf("*face_appartenance* fichier_in(.cir) fichier_appart(.cir)  val_out(.cir) \n\n");
 printf(" Operation 2D ( les faces sont horizontales)\n");
 printf(" Cherche appartenance (inclusion geometrique) des faces de fichier_in\n");
 printf(" par rapport au faces de fichier_appart\n");
 printf(" val_out.val contient les no des faces d'appartenance\n\n");
  exit(0);
}

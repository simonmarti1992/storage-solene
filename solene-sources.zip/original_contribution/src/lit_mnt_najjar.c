/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/*

lit_mnt_najjar

D. GROLEAU mars 2004
D. GROLEAU avril 2004 modifi�, on lit la taille de maille en entr�e

  lit fichier de terrain donn� par Najjar comme une liste de lignes
  x y z val1 val2

  et construit sur une maille de 4 m le terrain.cir 
  et terrain.txt (liste des points x y z , par ordre croissant  y et x)

ATTENTION; calcul bas� sur unr maille de 4m, lu en entree
*/



#include<solene.h>


// DECLARATIONS FUNCTIONS

void calcul_normale();
int ecrit_en_tete();
void format_entree();



/*_________________________________________________________________*/
main(argc,argv)
 int argc;char **argv;
{
 char 	buf[512],*s_dir;
 FILE	*fp,*fp1;
 int	i,j, k,kk, id, nbp, nbvaleur, k1,k2, id1,id2,id3,id4;
 int	nb_ligne, nb_colonne;
 float	*x, *y, *z,bidon,dmaille;
 float	x1,y1,z1,x2,y2,z2,x3,y3,z3,x4,y4,z4;
 double xx[3],yy[3],zz[3];
 double nx,ny,nz;

 float	xmin, xmax, ymin, ymax, zmin, zmax;

 double	englob[10];
 int	nbff,nof;


 printf("Fonction Solene : lit_mnt_najjar\n\n");


 for(i=0;i<10;i++) englob[i]=0;

 if(argc<3)format_entree();

	s_dir=(char *)getenv("PWD");

	sscanf(argv[2],"%f",&dmaille);
	printf("Taille de la maille : %f\n",dmaille);
//__________________________________________________
// Lit le fichier original, compte le nb de points et stocke seulement x,y,z des points
// lit fichier mnt
  compose_nom_complet(buf,s_dir,argv[1],"mnt");
  if((fp=fopen(buf,"r"))==NULL)
        { printf("\n impossible ouvrir %s\n",buf); exit(0);}
 printf("fichier input mnt : %s\n",buf);

// r�ecrit  le fichier XXXX.TXT temporaireen conservant : x y z
   compose_nom_complet(buf,s_dir,"XXXX","txt");
   fp1=fopen(buf,"w");
    if(fp1==NULL) 
	{ printf("impossible creer %s\n",buf);
	  exit(0);
	}
 printf("fichier temporaire : %s\n",buf);

// lit et compte nb de points
 xmin=100000000; xmax=-xmin;
 ymin=xmin; ymax=-xmin;
 zmin=xmin; zmax=-xmin;
 nbp =0;
 while(1)
  {
	  id= fscanf(fp,"%f %f %f %f %f", &x1,&y1,&z1, &bidon,&bidon);
	  if(id==EOF) break;
	  fprintf(fp1,"%10.2f %10.2f %10.2f\n",x1,y1,z1);
	  // cherche xmin, xmax, ymin, ymax, zmin, zmax
	  if(x1 < xmin) xmin=x1;
	  if(y1 < ymin) ymin=y1;
	  if(z1 < zmin) zmin=z1;
	  if(x1 > xmax) xmax=x1;
	  if(y1 > ymax) ymax=y1;
	  if(z1 > zmax) zmax=z1;
	  nbp++;
  }

  printf("\nNb de points lus :%d\n", nbp);
  printf("min max en x : %10.2f %10.2f\n",xmin,xmax);
  printf("min max en y : %10.2f %10.2f\n",ymin,ymax);
  printf("min max en z : %10.2f %10.2f\n",zmin,zmax);

  fclose(fp);
  fclose(fp1);


//_______________________________________
// Tri de coordonn�es en y et x (ligne et colonne)
// relit le fichier Txt
// et alloue les points en m�moire 

   compose_nom_complet(buf,s_dir,"XXXX","txt");
   fp=fopen(buf,"r");
    if(fp==NULL) 
	{ printf("impossible creer %s\n",buf);
	  exit(0);
	}
  printf("relit fichier Temporaire : %s\n",buf);

// et alloue les points en m�moire 
 x=  alloue_float(nbp,13);
 y=  alloue_float(nbp,13);
 z=  alloue_float(nbp,13);

 i =0;
 while(1)
  {
	  id= fscanf(fp,"%f %f %f", x+i,y+i,z+i);
	  if(id==EOF) break;
	  i++;
  }
 printf("Nb de points lus :%d\n", i);

 fclose(fp);

 system("del XXXX.TXT");


 // tri suivant les y
 for (i=0;i<nbp-1;i++)
 {
	 for (j=i+1; j<nbp; j++)
	 { if(y[i] > y[j])
		{ //printf("inverse\n");
		  // inverse y
		  bidon= y[i];
		  y[i]= y[j];
		  y[j]= bidon;
		  // inverse x
		  bidon= x[i];
		  x[i]= x[j];
		  x[j]= bidon;
		  // inverse z
		  bidon= z[i];
		  z[i]= z[j];
		  z[j]= bidon;
		}
	 }
 }

 // pour une meme valeur de y, tri suivant les x
 nbvaleur=0;
 for(i=0;i<nbp-1;i++)
 {
	 for(j=i+1; j<nbp; j++)
	 { if(y[i] == y[j])
		{ nbvaleur++;
		}
	   else
		{ // tri les x de i � i+nbvaleur-1;
		   for(k=i; k<i+nbvaleur-2; k++)
		   { for (kk=k+1; kk<i+nbvaleur-1;kk++)
				{ 
				  if(x[k] > x[kk])
					{
					  // inverse x
					  bidon= x[k];
					  x[k]= x[kk];
					  x[kk]= bidon;
					  // inverse z
					  bidon= z[k];
					  z[k]= z[kk];
					  z[kk]= bidon;
					}
				}
		   }
		   i+=nbvaleur;
		   nbvaleur=0;
		   break;
		}
	 }
}

 // �crit le r�sultat TXT tri� en conservant : x y z
   compose_nom_complet(buf,s_dir,argv[3],"txt");
   fp1=fopen(buf,"w");
    if(fp1==NULL) 
	{ printf("impossible creer %s\n",buf);
	  exit(0);
	}
 printf("fichier resultat txt : %s\n",buf);

 for (i=0;i<nbp;i++)
 { fprintf(fp1,"%10.2f %10.2f %10.2f\n",x[i],y[i],z[i]);
 }
 fclose(fp1);


 //_____________________________
 // Constitue les mailles Solene
 // nb de lignes et de colonnes
 nb_ligne = (ymax-ymin)/dmaille +1;
 nb_colonne = (xmax-xmin)/dmaille +1;

 printf("nb de lignes   : %d\n",nb_ligne);
 printf("nb de colonnes : %d\n",nb_colonne);

 /* stocke le fichier .cir du sol */

   compose_nom_complet(buf,s_dir,argv[3],"cir");
   printf("Fichier de sol � cr�er : %s \n",buf);

   fp=fopen(buf,"w");
    if(fp==NULL) 
	{ printf("impossible creer %s\n",buf);
	  exit(0);
	}

    // nb de faces � cr�er
	nbff= (nb_ligne-1)*(nb_colonne-1)*2;
	nof=0;

    ecrit_en_tete(fp,nbff,nbff,englob);
 for(i=0;i<nb_ligne-1;i++)
 {
	 // indice du premier point sur la ligne i et i+1
	 //printf("ligne %d\n",i);
	 k1 = i  * nb_colonne;
	 k2 = k1 + nb_colonne;
   for(j=0;j<nb_colonne-1;j++)
	 {
	   	 //printf("    colonne %d ",j);
     // indice des points de la maille � consid�rer
	   id1 = k1  + j;
	   id2 = id1 + 1;
	   id3 = k2  + j;
	   id4 = id3 + 1;
	   //printf("indice des points de la maille %8d %8d %8d %8d\n",id1,id2,id3,id4);

	   // coordonn�es des 4 points de la maille
	   x1=x[id1]; y1=y[id1]; z1=z[id1];
	   x2=x[id2]; y2=y[id2]; z2=z[id2];
	   x3=x[id3]; y3=y[id3]; z3=z[id3];
	   x4=x[id4]; y4=y[id4]; z4=z[id4];

		  // constitue face triangle 1,2,3
		  xx[0]= x1; yy[0]= y1; zz[0]= z1;
		  xx[1]= x2; yy[1]= y2; zz[1]= z2;
		  xx[2]= x3; yy[2]= y3; zz[2]= z3;
		 calcul_normale(xx,yy,zz,&nx,&ny,&nz);
		 nof++;
		 fprintf(fp,"f%d 1\n",nof) ;
		 fprintf(fp,"%f %f %f\n",nx,ny,nz) ;
		 fprintf(fp,"c0\n") ;
		 fprintf(fp,"4\n") ;

		 fprintf(fp,"%f %f %f\n",x1,y1,z1) ;
		 fprintf(fp,"%f %f %f\n",x2,y2,z2) ;
		 fprintf(fp,"%f %f %f\n",x3,y3,z3) ;
		 fprintf(fp,"%f %f %f\n",x1,y1,z1) ;

		  // constitue face triangle 2,4,3
		  xx[0]= x2; yy[0]= y2; zz[0]= z2;
		  xx[1]= x4; yy[1]= y4; zz[1]= z4;
		  xx[2]= x3; yy[2]= y3; zz[2]= z3;
		 calcul_normale(xx,yy,zz,&nx,&ny,&nz);
		 nof++;
		 fprintf(fp,"f%d 1\n",nof) ;
		 fprintf(fp,"%f %f %f\n",nx,ny,nz) ;
		 fprintf(fp,"c0\n") ;
		 fprintf(fp,"4\n") ;

		 fprintf(fp,"%f %f %f\n",x2,y2,z2) ;
		 fprintf(fp,"%f %f %f\n",x4,y4,z4) ;
		 fprintf(fp,"%f %f %f\n",x3,y3,z3) ;
		 fprintf(fp,"%f %f %f\n",x2,y2,z2) ;
	 }
 }
   printf("nb de faces cr��es : %d\n",nof);

 // desalloue
 desalloue_float(x);
 desalloue_float(y);
 desalloue_float(z);

 fclose(fp);


   
 printf("\nFin de  lit_mnt_najjar\n\n");

}

/*________________________________________________________________________*/
void calcul_normale(x,y,z,xnn,ynn,znn)
double *x,*y,*z;
double *xnn,*ynn,*znn;
{
 double x1,y1,z1,x2,y2,z2,norm;
 int i,j,k;

// calcul la normale sur les 3 points 
	i=0; j=1; k=2;
    x1=x[j]-x[i]; y1=y[j]-y[i]; z1=z[j]-z[i];
    x2=x[k]-x[j]; y2=y[k]-y[j]; z2=z[k]-z[j];
    *xnn=y1*z2-y2*z1;
    *ynn=-x1*z2+x2*z1;
    *znn=x1*y2-x2*y1;

    norm=sqrt(*xnn*(*xnn)+*ynn*(*ynn)+*znn*(*znn));
    if(norm)
     {
      *xnn=*xnn/norm; *ynn=*ynn/norm; *znn=*znn/norm;
	  if(*znn<0)
	  { *xnn=-*xnn;
		*ynn=-*ynn;
		*znn=-*znn;
	  }
     }
}

/*_________________________________________________________________*/
void format_entree()
{
  printf("\n    lit_mnt_najjar  fichier_in(.mnt)  dmaille fichier_out(.txt et .cir)\n\n");
   exit(0);
}

/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/*

cc test_materiau

*/
// D.GROLEAU  nov 2002

// test structure paroi avec plusieurs couches de materiaux

#include<solene.h>



// structure des parois
struct paroi { 
			   int nb_couches;
			   struct materiau *materiau_couches;
				}*pparoi;

struct materiau {
				 double *epaisseur;	            
				 double *lambda;
				 double *cp;
				 double *rho;
		 };

// declarations FUNCTION

void caracteristiques_materiau();
void desalloue_paroi();
void format_entree();
struct paroi *alloue_paroi();
struct materiau *alloue_materiau();
int nb_couches_materiau ();

/*_________________________________________________________________*/
main(argc,argv)
 int argc;char **argv;
{

 int i,j;
 int nb_paroi,no_liste,no_couche;
 char buf[512],*s_dir;
 FILE *fi;
 char nom_paroi[32];
 int nb_couches;
 double epaisseur,lambda, cp, rho;
 struct materiau *pmateriau;

 if(argc<2){format_entree(); exit(0);}

	s_dir=(char *)getenv("PWD");

	// open et lit fichier mat�riau
	compose_nom_complet(buf,s_dir,argv[1],"txt");
    if((fi=fopen(buf,"r"))==NULL) 
		{ printf(" impossible ouvrir %s\n",buf);
   	      format_entree();
        }
    fscanf(fi,"%d", &nb_paroi);
	printf("%d\n",nb_paroi);
	pparoi= alloue_paroi(nb_paroi,1234);

	for(i=0;i<nb_paroi;i++)
	{
		fscanf(fi,"%s",nom_paroi);
			printf("%s\n",nom_paroi);

		fscanf(fi,"%d",&nb_couches);
			printf("%d\n",nb_couches);

			(pparoi+i)->nb_couches=nb_couches;
			 pmateriau= alloue_materiau(nb_couches,4567);
			(pparoi+i)->materiau_couches=pmateriau;

				for(j=0;j<nb_couches;j++)
				{ fscanf(fi,"%lf",&epaisseur);
					printf("%f\n",epaisseur);

				  fscanf(fi,"%lf",&lambda);
					printf("%f\n",lambda);
				  fscanf(fi,"%lf",&cp);
					printf("%f\n",cp);
				  fscanf(fi,"%lf",&rho);
					printf("%f\n",rho);

					pmateriau->epaisseur[j] = epaisseur;
					pmateriau->lambda[j] = lambda;
					pmateriau->cp[j] = cp;
					pmateriau->rho[j] = rho;
				}					
	}
	fclose (fi);

	// test stockage
	for(i=0;i<nb_paroi;i++)
	{ 
	  pmateriau= (pparoi+i)-> materiau_couches;
	  nb_couches = (pparoi+i)-> nb_couches;
	  for (j=0;j<nb_couches;j++)
	  { 
		  printf("%f ", pmateriau->epaisseur[j]);
		  printf("%f ", pmateriau->lambda[j]);
		  printf("%f ", pmateriau->cp[j]);
		  printf("%f\n", pmateriau->rho[j]);
	  }
	}

	// test de lecture des parois
	printf("test\n");
	no_liste= 2;
	nb_couches = nb_couches_materiau (no_liste);
	printf("nb couches %d \n", nb_couches);
		no_couche =1;
		caracteristiques_materiau (no_liste, no_couche, &epaisseur,&lambda,&cp,&rho);
		printf("%f %f %f %f\n",epaisseur,lambda,cp,rho);
	no_liste= 1;
	nb_couches = nb_couches_materiau (no_liste);
	printf("nb couches %d \n", nb_couches);
		no_couche =1;
		caracteristiques_materiau (no_liste, no_couche, &epaisseur,&lambda,&cp,&rho);
		printf("%f %f %f %f\n",epaisseur,lambda,cp,rho);
		no_couche =2;
		caracteristiques_materiau (no_liste, no_couche, &epaisseur,&lambda,&cp,&rho);
		printf("%f %f %f %f\n",epaisseur,lambda,cp,rho);

		// desalloue
	desalloue_paroi(pparoi,nb_paroi);

	exit(0);

}

/*-----------------------------------------------------------------------------*/

struct paroi *alloue_paroi(nbf,err)
int nbf,err;
{    /* alloue et initialise nbf parois */
  struct paroi *pparoi;
  int i;
     pparoi=(struct paroi *)malloc(nbf*sizeof(*pparoi));
     if(pparoi==NULL) pb_allocation(err); 
     for(i=0;i<nbf;i++)
        {
		 pparoi[i].nb_couches=0;
		 pparoi[i].materiau_couches=NULL; 
		} 

     return(pparoi);
}
/*-----------------------------------------------------------------------------*/

struct materiau *alloue_materiau(nbf,err)
int nbf,err;
{    /* alloue les materiaux d'une paroi de nbf couches */
  struct materiau *pmateriau;
     pmateriau=(struct materiau *)malloc(nbf*sizeof(*pmateriau));
     if(pmateriau==NULL) pb_allocation(err);
	 pmateriau->epaisseur = alloue_double (nbf,12345);
	 pmateriau->lambda = alloue_double (nbf,12345);
	 pmateriau->cp  = alloue_double (nbf,12345);
	 pmateriau->rho = alloue_double (nbf,12345);
     

     return(pmateriau);
}

/*-----------------------------------------------------------------------------*/
void desalloue_paroi(pparoi,nbf)
  struct paroi *pparoi;
  int nbf;
{
int i;
struct materiau *pmateriau;

   if(pparoi)
    { for(i=0;i<nbf;i++)
		{ pmateriau = (pparoi+i)->materiau_couches;
			free(pmateriau->epaisseur);
			free(pmateriau->lambda);
			free(pmateriau->cp);
			free(pmateriau->rho);
			free(pmateriau);
      }
    free(pparoi);
    }

}

/*-----------------------------------------------------------------------------*/
int nb_couches_materiau (no_liste)
int no_liste;
{
	no_liste = no_liste-1;
	return((pparoi+no_liste)->nb_couches);
}
/*-----------------------------------------------------------------------------*/
void caracteristiques_materiau (no_liste, no_couche, epaisseur,lambda,cp,rho)
int no_liste,no_couche;
double *epaisseur,*lambda,*cp,*rho;
{
	struct materiau *pmateriau;
	no_liste = no_liste-1;
	no_couche = no_couche-1;
	pmateriau=(pparoi+no_liste)->materiau_couches;
	*epaisseur = pmateriau->epaisseur[no_couche];
	*lambda = pmateriau->lambda[no_couche];
	*cp = pmateriau->cp[no_couche];
	*rho = pmateriau->rho[no_couche];
}


/*_________________________________________________________________*/
void format_entree()
{
  printf("\n    test_materiau   fichier_paroi (.txt)  \n\n");
}


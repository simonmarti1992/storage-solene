/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/* volume.c : genere des volumes parallelepipediques */
/*            sur un fichier volume.cir              */

/* 

cc volume.c geomutile.o solutile.o lib_solene_94.o -o volume  -lm 

*/

#include <solene.h>

#include <stdlib.h>
#include <sys/stat.h>

FILE *fp;

/* int enr_face(int,float *,float *,float *,float,float,float); */

int noenr;

/*----------------------------------------------------------------------*/
main(argc,argv)
int argc;char **argv;
{
 char buf[512],*s_dir; 
 double xo,yo,zo,dx,dy,dz;
 double x[6],y[6],z[6],vx,vy,vz;
 int i,j,k;
 double englob[10],xmin,ymin,zmin,xmax,ymax,zmax;

 if(argc<8) format_entree_volume();

	s_dir="";//(char *)getenv("PWD");

 noenr=0;

 compose_nom_complet(buf,s_dir,argv[1],"cir");
 printf("\nModelisation d'un prisme droit\n");
 printf("sur %s\n",buf);

 sscanf(argv[2],"%lf",&xo);
 sscanf(argv[3],"%lf",&yo);
 sscanf(argv[4],"%lf",&zo);
 sscanf(argv[5],"%lf",&dx);
 sscanf(argv[6],"%lf",&dy);
 sscanf(argv[7],"%lf",&dz);
 j=0;

 fp=fopen(buf,"w"); 
    if(fp==NULL) 
	{ printf("impossible creer %s\n",buf);
	  exit(0);
	}

 for(i=0;i<10;i++)englob[i]=0;
 ecrit_en_tete(fp,6,6,englob);

 xmin=999999; ymin=xmin; zmin=xmin; xmax=-xmin; ymax=-xmin; zmax=-xmin;


                            /* horiz */
     if(dx>0){xmin=dmin(xo,xmin); xmax=dmax(xo+dx,xmax);}
     else    {xmin=dmin(xo+dx,xmin); xmax=dmax(xo,xmax);}

     if(dy>0){ymin=dmin(yo,ymin); ymax=dmax(yo+dy,ymax);}
     else    {ymin=dmin(yo+dy,ymin); ymax=dmax(yo,ymax);}

     if(dz>0){zmin=dmin(zo,zmin); zmax=dmax(zo+dz,zmax);}
      else   {zmin=dmin(zo+dz,zmin); zmax=dmax(zo,zmax);} 


     x[0]=xo;y[0]=yo;z[0]=zo+dz;
     x[1]=xo+dx;y[1]=yo;z[1]=zo+dz;
     x[2]=xo+dx;y[2]=yo+dy;z[2]=zo+dz;
     x[3]=xo;y[3]=yo+dy;z[3]=zo+dz;
     x[4]=xo;y[4]=yo;z[4]=z[0];
     vx=0;vy=0;vz=1;
     enr_face(5,x,y,z,vx,vy,vz);
     j++;
     x[0]=xo;y[0]=yo;z[0]=zo;
     x[1]=xo;y[1]=yo+dy;z[1]=zo;
     x[2]=xo+dx;y[2]=yo+dy;z[2]=zo;
     x[3]=xo+dx;y[3]=yo;z[3]=zo;
     x[4]=xo;y[4]=yo;z[4]=z[0];
     vx=0;vy=0;vz=-1;
     enr_face(5,x,y,z,vx,vy,vz);
     j++;
     z[0]=zo;z[1]=zo;z[2]=zo+dz;z[3]=zo+dz;z[4]=zo;  /* vert */
     x[0]=xo;y[0]=yo;
     x[1]=xo+dx;y[1]=yo;
     x[2]=xo+dx;y[2]=yo;  
     x[3]=xo;y[3]=yo;
     x[4]=x[0];y[4]=y[0];
     vx=0;vy=-1;vz=0; 
     enr_face(5,x,y,z,vx,vy,vz);
     j++;
     x[0]=xo+dx;y[0]=yo; 
     x[1]=xo+dx;y[1]=yo+dy;
     x[2]=xo+dx;y[2]=yo+dy;
     x[3]=xo+dx;y[3]=yo;
     x[4]=x[0];y[4]=y[0]; 
     vx=1;vy=0;vz=0;
     enr_face(5,x,y,z,vx,vy,vz);
     j++;
     x[0]=xo+dx;y[0]=yo+dy; 
     x[1]=xo;y[1]=yo+dy;
     x[2]=xo;y[2]=yo+dy;
     x[3]=xo+dx;y[3]=yo+dy; 
     x[4]=x[0];y[4]=y[0];
     vx=0;vy=1;vz=0;
     enr_face(5,x,y,z,vx,vy,vz);
     j++;
     x[0]=xo;y[0]=yo+dy; 
     x[1]=xo;y[1]=yo;
     x[2]=xo;y[2]=yo;
     x[3]=xo;y[3]=yo+dy; 
     x[4]=x[0];y[4]=y[0];
     vx=-1;vy=0;vz=0;
     enr_face(5,x,y,z,vx,vy,vz);
     j++;
 

 rewind(fp);
 englob[0]=zmin;  englob[1]=zmax;
 englob[2]=xmin;  englob[3]=ymin;
 englob[4]=xmax;  englob[5]=ymin;
 englob[6]=xmax;  englob[7]=ymax;
 englob[8]=xmin;  englob[9]=ymax;
 ecrit_en_tete(fp,6,6,englob);

 printf("Nb de faces generees : %d (numerotees de 1 a %d)\n\n",noenr,noenr);

 creer_OK_Solene();

 printf("\n\nFin du Traitement volume\n");
}

/*-----------------------------------------------------*/
int enr_face(nbp,x,y,z,vx,vy,vz)
  int nbp;
  double *x,*y,*z;
  double vx,vy,vz;
{
 int i;
  noenr++;
  fprintf(fp,"f%d  1\n",noenr);
   fprintf(fp,"    %7.2f %7.2f %7.2f\n",vx,vy,vz);
  fprintf(fp," c0\n",noenr);
  fprintf(fp,"   %d\n",nbp);
  for(i=0;i<nbp;i++) fprintf(fp,"    %7.2f %7.2f %7.2f\n",x[i],y[i],z[i]);
}

/*_________________________________________________________________*/
int format_entree_volume()
{
  printf("\n   *volume*  fichier_out(.cir) xo yo zo dx dy dz\n\n");
  exit(0);
}

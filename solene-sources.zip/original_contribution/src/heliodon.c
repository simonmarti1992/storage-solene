/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/*

cc heliodon.c  solaire.o solutile.o geomutile.o lib_solene_94.o -o heliodon -lm

*/

/* execute dans une fenetre les fonctions "solene" ou "unix" */
/* contenues dans un fichier de commande */

#include<solene.h>
#include<ctype.h>

extern double coef_discol;


/*_________________________________________________________________*/
main(argc,argv)			/* HELIODON */
 int argc;char **argv;
{int i;
char c[2];
char buf[256],*s_dir;
  int nojour,nomois,hh,minute;
  double lati;
  double xyzsol[3],a,h;
  double heure;

         //s_dir=(char *)getenv("PWD");
	s_dir="";
   normale_orientee=1; traitement_faces_cachees=1;

         obs.xo=0; obs.yo=0; obs.zo=0;

         if(argc<6)format_entree_heliodon();
         printf("\n CALCUL D'UN VUE HELIODON \n");
  	 sscanf(argv[3],"%d%c%d",&nojour,c,&nomois);
         if(c[0]!='/')format_entree_heliodon();
         printf("\n nojour = %d nomois = %d ",nojour,nomois);

         sscanf(argv[4],"%d%c%d",&hh,c,&minute);
	 if(c[0]!=':')format_entree_heliodon();
         if(nojour<1|| nojour>31||nomois<1||nomois>12)format_entree_heliodon();
         if(hh<0||hh>24||minute<0||minute>60)format_entree_heliodon();
         printf("\n hh = %d minute = %d ",hh,minute);

         sscanf(argv[5],"%lf",&(lati));
         printf("\n lati = %lf ",lati);
         info_solaire(lati,nojour,nomois,hh,minute,xyzsol,&a,&h);
         printf(" soleil : a=%lf h=%lf\n",angdeg(a),angdeg(h));

         obs.x=xyzsol[0]; obs.y=xyzsol[1]; obs.z=xyzsol[2];

	  normale_orientee=1;
         for(i=7;i<argc;i++)
            { sscanf(argv[i],"%c%c",c,c+1);
              if(*c!='-')format_entree_heliodon();
              if(*(c+1)=='n') normale_orientee=0;
	      else if(*(c+1)=='t') traitement_faces_cachees=0;
              else format_entree_heliodon();
            }

  /* COMPOSE LA COMMANDE pour AXONO */

if(test_egalite_de_2_chaines(argv[1],argv[2]))
	{printf(" le fichier_select et le fichier de base sont identiques\n");
         if(normale_orientee==1)sprintf(buf,"axono %s %lf %lf %lf %s",argv[1],obs.x,obs.y,obs.z,argv[6]);
	 else sprintf(buf,"axono %s %lf %lf %lf %s -n",argv[1],obs.x,obs.y,obs.z,argv[6]);
 	}
else    {if(normale_orientee==1)sprintf(buf,"axono_select %s %s %lf %lf %lf %s",argv[1],argv[2],obs.x,obs.y,obs.z,argv[6]);
	 else sprintf(buf,"axono_select %s %s %lf %lf %lf %s -n",argv[1],argv[2],obs.x,obs.y,obs.z,argv[6]);
	}

	printf("\n commande = %s\n",buf);
         system(buf);

    //test si la commande decompose_face s'est bien passe */
	//Modif SII DFA 24-4-2006
	if( ! existOkSolene() ) {
		 printf("\n PB execution de axono ou axono_select\n");
	     exit(0);
	}
    cleanOkSolene();

	creer_OK_Solene();
	printf("\n\nFin du Traitement heliodon\n");

/*  liste_des_pointeurs();  */
}

/*_________________________________________________________________*/
format_entree_heliodon()
{
  printf("\n   format d'entree des parametres \n");
  printf("\n  *heliodon* fichier_select_in(.cir) fichier_in(.cir) jour/mois hh:mm latitude fichier_out(.cir) [-n] [-t]\n\n");
  exit(0);
}

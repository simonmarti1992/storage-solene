/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

// energie_solaire_bassin.c 

/*
D.GROLEAU
M.ROBITU
9 janvier 2003
*/

// Evaluation du rayonnement solaire a la surface et a l'interieur d'un bassin d'eau */


#include<solene.h>


// declare functions
void calcul_min_max();
void evalue_out();
void met_extension();
void usage();


// EN GLOBAL


/*_________________________________________________________________*/
main(argc,argv)           /* energie solaire sur et dans un bassin */
int argc;char **argv;
	{
	int i,j,k,nb_pas,nbfac,nomax;
	int nofac,nbcont;

 	char nom_flux[256],nom_incid[256],buf[256];
 	char nom_out1[256],nom_out2[256];
	char *s_dir,c;
 	FILE *pflux,*pincid;
 	FILE *pout1,*pout2;
	int hh1,hh2,pas,minute,temps;
	char extension[16];

	double mini,maxi;
	double flux,incid;
	double out1,out2;
	double min_out1, max_out1;
	double min_out2, max_out2;

	printf("\n\nCommande :  energie_solaire_bassin\n\n");

	s_dir=(char *)getenv("PWD");

 if(argc != 7) usage();
 
/* lecture parametres commande */

    //  heure debut et fin ; pas
    sscanf(argv[3],"%d%c%d",&hh1,&c,&minute);
    printf("evalue de  %dH%d",hh1,minute);
    hh1=hh1*60+minute;
    sscanf(argv[4],"%d%c%d",&hh2,&c,&minute); 
    printf(" a  %dH%d",hh2,minute);
    hh2=hh2*60+minute;
    sscanf(argv[5],"%d%c%d",&pas,&c,&minute);
    printf(" par pas de  %dH%d\n",pas,minute);
    pas=pas*60+minute;

    // calcul du nbre de pas
    nb_pas=1;
    i=hh1;
    while(i<hh2)
    { nb_pas++;
      i=i+pas;
    }
    printf("nb de pas %d\n",nb_pas);


// INITIALISATION des min et max en sortie
  min_out1 = 1000000.; 
  max_out1 = -min_out1;
  min_out2 = 1000000.; 
  max_out2 = -min_out2;

// EVALUATION des flux dans bassin � chaque pas de temps

  printf("Traitement en cours ...\n");

  temps = hh1;
  for(j=0;j<nb_pas;j++)
  {
	printf("\n");
    met_extension(temps,extension);

	// open flux en Lecture
    sprintf(buf,"%s%s",argv[1],extension);
    compose_nom_complet(nom_flux,s_dir,buf,"val");
    printf("  open flux : %s \n", nom_flux);
	if ((pflux=fopen(nom_flux,"r"))==NULL)
     { printf("\n  impossible ouvrir %s\n\n", nom_flux); 
	   exit(0);
     }
	fscanf (pflux,"%d %d %f %f", &nbfac, &nomax, &mini, &maxi);  
	// open incidence en Lecture
    sprintf(buf,"%s%s",argv[2],extension);
    compose_nom_complet(nom_incid,s_dir,buf,"val");
    printf("  open incidence : %s \n", nom_incid);
	if ((pincid=fopen(nom_incid,"r"))==NULL)
     { printf("\n  impossible ouvrir %s\n\n", nom_incid); 
	   exit(0);
     }
	fscanf (pincid,"%d %d %f %f", &nbfac, &nomax, &mini, &maxi);  

		// open out1 en Ecriture
    sprintf(buf,"%s_out1%s",argv[6],extension);
    compose_nom_complet(nom_out1,s_dir,buf,"val");
    printf("  open out1 : %s \n", nom_out1);
	if ((pout1=fopen(nom_out1,"w"))==NULL)
     { printf("\n  impossible ouvrir %s\n\n", nom_out1); 
	   exit(0);
     }
	fprintf (pout1,"%5d %5d %10.2f %10.2f\n", nbfac, nomax, min_out1,max_out1);  
		// open out2 en Ecriture
    sprintf(buf,"%s_out2%s",argv[6],extension);
    compose_nom_complet(nom_out2,s_dir,buf,"val");
    printf("  open out2 : %s \n", nom_out2);
	if ((pout2=fopen(nom_out2,"w"))==NULL)
     { printf("\n  impossible ouvrir %s\n\n", nom_out2); 
	   exit(0);
     }
	fprintf (pout2,"%5d %5d %10.2f %10.2f\n", nbfac, nomax, min_out2,max_out2);  

	// TRAITE chaque contour du plan de surface du bassin

        for(i=0;i<nbfac;i++)
          {    
			// lit la face : numero de face et nb de contours de la face 
			fscanf(pflux,"\n%c%d%d\n",&c,&nofac,&nbcont);
			fscanf(pincid,"\n%c%d%d\n",&c,&nofac,&nbcont);
			//printf("traite face %d (de %d contours)\n",nofac, nbcont);

			// ecrit face : numero de face et nb de contours de la face pour tous les fichiers out**/
			fprintf(pout1,"f%d %d\n",nofac,nbcont);
			fprintf(pout2,"f%d %d\n",nofac,nbcont);

			// lit pour chaque contour : flux et angle incident    	
		    for(k=0;k<nbcont;k++)	   
            {
			 //printf("     contour %d \n",k+1);

			 // lit pour le contour : valeu flux et incidence
			 fscanf(pflux,"%lf",&flux);
			 fscanf(pincid,"%lf",&incid);


			 // EVALUE valeurs de sortie
			 evalue_out(flux,incid,&out1,&out2);

			 // met a jour min et max pour chaque fichier out
			 calcul_min_max(out1,&min_out1,&max_out1);
			 calcul_min_max(out2,&min_out2,&max_out2);

			 // ecrit valeurs out du contour k 
			fprintf(pout1,"%10.2f\n",out1);
			fprintf(pout2,"%10.2f\n",out2);

			} //fin de for k (contour)
				
		} //fin de for i (face)

    rewind(pout1);
    fprintf (pout1,"%5d %5d %10.2f %10.2f\n", nbfac, nomax, min_out1,max_out1);
	fclose(pout1);
    rewind(pout2);
    fprintf (pout2,"%5d %5d %10.2f %10.2f\n", nbfac, nomax, min_out2,max_out2);   
	fclose(pout2);
	
	temps+=pas; // pas suivant
  } // fin de for j (pas de temps)


 creer_OK_Solene();
 printf("\n\nFin du Traitement energie_solaire_bassin\n");
 exit(0);
}


/*_________________________________________________________________*/
void evalue_out(flux,incid,out1,out2)
double flux, incid;
double *out1,*out2;
{
	*out1=2*flux;
	*out2=3*incid;
}

/*_________________________________________________________________*/
void calcul_min_max(valeur,val_min,val_max)
double valeur;
double *val_min,*val_max;
{ if(valeur<*val_min) *val_min=  valeur;
  if(valeur>*val_max) *val_max=  valeur;
}


//_____________________________________________________
void met_extension (temps,extension)
int temps;
char *extension;
{
	float xh_heure;
	int h_heure, m_minute;

		xh_heure= (float)temps/60;
		h_heure= (int) xh_heure;
		m_minute= temps-h_heure*60;
		//printf(" heure_minute %d H %d\n",h_heure,m_minute);
		//construit extension pour fichier val heure
		if(h_heure>=10 && m_minute >=10)
		{
		 sprintf(extension,"_%dH%d",h_heure,m_minute);
		}
		else if(h_heure>=10 && m_minute <10)
		{
		 sprintf(extension,"_%dH0%d",h_heure,m_minute);
		} 
		else if(h_heure<10 && m_minute >=10)
		{
		 sprintf(extension,"_0%dH%d",h_heure,m_minute);
		} 
		else if(h_heure <10 && m_minute <10)
		{
		 sprintf(extension,"_0%dH0%d",h_heure,m_minute);
		} 
		//printf("extension %s\n",extension);
}


/*_________________________________________________________________*/
/* Format de la fonction energie_solaire_bassin */
void usage()
{
 printf("\n   energie_solaire_bassin\n");
 printf("\n      la fonction a comme parametre en ENTREE :\n\n");
 printf("\t NOM generique des fichiers de flux solaires incidents (.val)\n");
 printf("\t NOM generique des fichiers d'angles d'incidence solaires (.val)\n");
 printf("\t hh1:mn1 (heure de d�but)\n");
 printf("\t hh2:mn2 (heure de fin)\n");
 printf("\t pas_hh:pas_mn (pas de calcul)\n");
   
 printf("\n           comme parametres en SORTIE, \n\n");

 printf("\t NOM generique des fichiers de sortie (.val)\n\n");
 printf("\t\t pour constituer les fichiers suivants:\n");
 printf("\t\t NOM_GENERIQUE_flux_absorbe_couche0(.val)\n");
 printf("\t\t NOM_GENERIQUE_flux_absorbe_couche1(.val)\n\n");
   
 printf("\nNOTA: le programme ajoute une extension _hhHmm au NOM GENERIQUE des fichier correspondants � l'heure du calcul\n\n");
 exit(0);
}



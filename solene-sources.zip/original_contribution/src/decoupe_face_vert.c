/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */
 
/*

 decoupe_face_vert.c   

*/
// D.GROLEAU
//		Novembre 2002

// Decoupe faces dans meme plan 
// si faces a et b, retient a-b et b-a

//si recompile, v�rifier nb de param�tres de coplanaire (sens de la normale)

#include<solene.h>

// declaration de fonctions
int coplanaire1();
double ecart_entre_2_plan();
int ecrit_en_tete();
void format_entree();

//GLOBAL
struct modelisation_face *alloue_face();


/*___________________________________________________________________*/
main(argc,argv)         
int argc;char **argv;
{
 int i,j;
 double englob[10];
 char 	nom_in[512],nom_out[512];
 int nbff,noma,nbf1,noma1;
 struct modelisation_face *fs,*fres,*fsauve_i;
 FILE *pf1,*pf2;
 char *s_dir;
 double vnx_j, vny_j, vnz_j;
 double EPSILONE;   // pour comparer vecteur normal d'abord
 double EPSILONE_D;  // et ecart z des 2 plans pour verifier coplanerit�

   nb_etat=0;
   EPSILONE=0.001;
   EPSILONE_D = 10*EPSILONE;

   s_dir="";

   if(argc<3) format_entree();
 
   printf("decoupe_face_vert\n\n");
   if(argc >=4)   sscanf(argv[3],"%lf",&EPSILONE);
   printf("epsilone = %f\n",EPSILONE);
   if(argc ==5)   sscanf(argv[4],"%lf",&EPSILONE_D);
   printf("epsilone = %f\n",EPSILONE_D);


 /* OPen la geometrie ENTREE */

 	/* fichier .cir en entree */
            compose_nom_complet(nom_in,s_dir,argv[1],"cir");
			printf("geometrie IN  : %s\n",nom_in);
            if((pf1=fopen(nom_in,"r"))==NULL) 
               { printf(" impossible ouvrir %s\n",nom_in);
   	             format_entree();
               }
 /* OPen  geometrie SORTIE */
	/* fichier .cir decoup�s szi n�cessaire */
            compose_nom_complet(nom_out,s_dir,argv[2],"cir");
			printf("geometrie OUT : %s\n",nom_out);
            if((pf2=fopen(nom_out,"w"))==NULL) 
               { printf(" impossible ouvrir %s\n",nom_out);
   	             format_entree();
               }

  /* lit fichier IN */
   lit_en_tete(pf1,&nbff,&noma,englob);
   printf("\n       nombre de faces du fichier = %d\n",nbff);
   fs=alloue_face(nbff,1000);
   lit_fic_cir3d(pf1,nbff,fs); 
   fclose(pf1);

   // ecrit entete fichier OUT
   nbf1=0,noma1=0;
   ecrit_en_tete(pf2,nbff,noma,englob);


     printf("Decoupe en cours ...\n");

	 // en principe fichier de faces verticales
     for(i=0;i<nbff;i++)
     { 
		// la face i peut etre decoupee par plusieurs faces j
		//printf("face %d\n",(fs+i)->nofac_fichier);

		// sauve l'original de la face i
		fsauve_i=alloue_face(1,1234);
		copie_face_projete(fs+i,1,fsauve_i,1);

		// projette suivant la normale
		obs.x=(fs+i)->vnorm[0];
		obs.y=(fs+i)->vnorm[1];
		obs.z=(fs+i)->vnorm[2];
	  	obs.xo=0; obs.yo=0; obs.zo=0; 
		//transformation
		tranfo();

		// alloue_face resultat
		fres=alloue_face(1,1234);

	    for(j=0;j<nbff;j++)
		{ //printf("    par rapport a face %d\n",(fs+j)->nofac_fichier);
			if(j!= i)
			{// test si coplanaires
				if(coplanaire1(fs+i,1,fs+j,1,EPSILONE,EPSILONE_D,0)) 
				{ 	
				   //printf("    coplanaire avec %d\n",(fs+j)->nofac_fichier);
				   // sauve normale de j
				   vnx_j=(fs+j)->vnorm[0];
				   vny_j=(fs+j)->vnorm[1];
				   vnz_j=(fs+j)->vnorm[2];

				   init_fenetre_affichage();

				   	// transfo face  i et j
				   tran_face(fs+i,1,fs+i,0);
				   tran_normale((fs+i)->vnorm);
				   tran_face(fs+j,1,fs+j,0);
				   tran_normale((fs+j)->vnorm);

				   // calcul fenetre de calcul
				   cal_fen_aff();
				   // normalise (et calcul d du plan et met normales aux circuits de la face)
				   normalise_face(fs+i,0);
				   normalise_face(fs+j,0);

				   // decoupe i par j
				   printf("decoupe %4d - %4d\n",(fs+i)->nofac_fichier,(fs+j)->nofac_fichier);
				   face1_moins_face2(fs+i,0,fs+j,0,fres,0);
				   //printf("apres decoupe %4d - %4d\n",(fs+i)->nofac_fichier,(fs+j)->nofac_fichier);

				   // copie face i decoup�e fres dans fs projete
				   fres->nofac_fichier= (fs+i)->nofac_fichier;
				   copie_face_projete(fres,0,fs+i,1);

				   if((fs+i)->debut_projete)
				   { // denormalise et reinverse face i
					 denormalise_face(fs+i,1);
				     // tranfo inverse
				     tran_face_inverse(fs+i,1);
				   }
				   // desalloue face i dessin
				   desalloue_chaine_contour((fs+i)->debut_dessin,1035);
				   (fs+i)->debut_dessin=NULL;

				   //desalloue face res dessin
				    desalloue_chaine_contour(fres->debut_dessin,1034);
				   (fres)->debut_dessin=NULL;

				   // remet la normale de face i
				   (fs+i)->vnorm[0]= obs.x;
				   (fs+i)->vnorm[1]= obs.y;
				   (fs+i)->vnorm[2]= obs.z;
				   	// remet la normale de face  j
				   (fs+j)->vnorm[0]= vnx_j;
				   (fs+j)->vnorm[1]= vny_j;
				   (fs+j)->vnorm[2]= vnz_j;
				   // desalloue face j dessin
				   desalloue_chaine_contour((fs+j)->debut_dessin,1034);
				   (fs+j)->debut_dessin=NULL;
				}	
			}
		// on poursuit face i d�coup�e avec autre face j (i-j)
		// s'il en reste
		if(	(fs+i)->debut_projete ==NULL) break;
		//printf("au suivant\n");

		} //fin for j
	
	   // ecrit la face i dans fichier out
       if((fs+i)->debut_projete)output_face_sur_fichier(fs+i,1,1,0,pf2,&nbf1,&noma1);
	   // desalloue face resultat
	   desalloue_face(fres);

		// restitue la face i originale pour faire j-i
		copie_face_projete(fsauve_i,1,fs+i,1);
	    desalloue_face(fsauve_i);
	     
     } // fin for i

  printf("fin des %d faces\n",nbff);
  // reecrit entete
  rewind(pf2);
  ecrit_en_tete(pf2,nbf1,noma1,englob);
  fclose(pf2);

 

   desalloue_fface(fs,nbff);
   
   printf("\nFin decoupe_face_vert\n\n");

   creer_OK_Solene();
}

/*----------------------------------------------------------------*/
/*----------------------------------------------------------------*/
// PRIS DE SOLUTILE MAIS MODIFIE AVEC UN PARAMETRE DE PLUS pour l'�cart sur d

//coplanaire de SOLUTILE a ete retest� en avril 2004, il serait bien de retravailler avec la fonction de SOLUTILE
int coplanaire1(f1,projete1,f2,projete2,epsilone,epsilone_d,avec_meme_sens_normale)
struct modelisation_face *f1,*f2;
int projete1,projete2;
double epsilone, epsilone_d;
int avec_meme_sens_normale;
{
	double x1,y1,z1,x2,y2,z2,pv;
	double ecartZ;
	
	// retourne 1 
	//		si les faces sont coplanaires  a epsilone pres
	//	et	si l'�cart du plan est < 10 * epsilone pres



	// les faces peuvent �tre coplanaires et avoir leur normales oppos�es
	// donc
	// avec_meme_sens_normale = 1 : coplanaire et meme sens de normale
	// avec_meme_sens_normale = 0 :	coplanaire quelque soit le sens de normale
	//ATTENTION, les normales sont normalisees

	/*
	printf("les 2 normales : \n");
	printf("%f %f %f\n",f1->vnorm[0],f1->vnorm[1],f1->vnorm[2]);
	printf("%f %f %f\n",f2->vnorm[0],f2->vnorm[1],f2->vnorm[2]);
	*/
	
	x1 = f1->vnorm[0]; y1 = f1->vnorm[1]; z1 = f1->vnorm[2];
	x2 = f2->vnorm[0]; y2 = f2->vnorm[1]; z2 = f2->vnorm[2];
	// produit scalaire = 1 si meme vecteur normal, -1 si oppos�
	pv=x1*x2 + y1*y2 + z1*z2;

	 if(fabs(pv-1.0) <= epsilone) //pv=1 normales identiques
	   { 
		 //printf("Normale identique avec face %d\n", f2->nofac_fichier);
		 ecartZ= ecart_entre_2_plan(f1,f2);
		 if(ecartZ <= epsilone_d)
		  {//printf("coplanaire  %lf\n",f1->vnorm[3] - f2->vnorm[3]);
		   return(1);
		  }
	   }
	 else if(fabs(pv+1.0) <= epsilone) //pv=-1 normales opposees
	   { //printf("Normale opposee avec face %d\n", f2->nofac_fichier);
		 if(avec_meme_sens_normale == 1) return(0);
         else
		 {
		   ecartZ= ecart_entre_2_plan(f1,f2);
		   if(ecartZ <= epsilone_d)
		   {//printf("coplanaire  %lf\n",f1->vnorm[3] - f2->vnorm[3]);
		    return(1);
		   }
		 }
	   }
	return(0);
}

/*______________________________________________________*/
double ecart_entre_2_plan(f1,f2)
struct modelisation_face *f1,*f2;
{
	int i;
	struct contour *pcont;
	struct circuit *pcir;
	double z1,z2;

	// les faces sont dans dessin

	// calcul �cart entre les 2 plans en projetant les deux faces 
	// suivant la normale de l'une des faces

	// applique tranfo connue
	tran_face(f1,1,f1,0);
	tran_face(f2,1,f2,0);
	//liste_face(f1,0);
	//liste_face(f2,0);
	// calcul �cart moyen sur le z dans f1 et f2
	z1=0;
	pcont=f1->debut_dessin;
	pcir= pcont->debut_support;
	for(i=0;i<pcir->nbp-1;i++)
	{ z1+= pcir->z[i];
	}
	z1= z1/(pcir->nbp-1);

	z2=0;
	pcont=f2->debut_dessin;
	pcir= pcont->debut_support;
	for(i=0;i<pcir->nbp-1;i++)
	{ z2+= pcir->z[i];
	}
	z2= z2/(pcir->nbp-1);
	//printf("z1= %f\n",z1);
	//printf("z2= %f\n",z2);
	//printf("ecart z= %f\n",fabs(z1-z2));

	// desalloue face  dessin
	desalloue_chaine_contour(f1->debut_dessin,1034);
	f1->debut_dessin=NULL;
	desalloue_chaine_contour(f2->debut_dessin,1034);
	f2->debut_dessin=NULL;
	return(fabs(z1-z2));
}

/*_________________________________________________________________*/
/* Format de la fonction TRIANGULE_FACE */
void format_entree()
{
  printf("\n   *decoupe_face_vert*  fichier_in(.cir) fichier_out(.cir) [epsilone] [epsilone_d]\n\n");
  printf("\n   s'applique � un fichier de faces d'inclinaison quelconque\n\n");
  printf("\n   s'applique � un fichier de faces d'inclinaison quelconque\n\n");
  printf("\n   la d�coupe a lieu quand 2 faces sont dans la meme plan � epsilone pr�s (d�faut 0.001)\n\n");
  printf("\n   et l'�cart sur d inf�rieur � 10*epsilone (d�faut 0.01)\n\n");
  exit(0);
}

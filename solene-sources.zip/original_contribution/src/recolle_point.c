/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/*

recolle_point

D. GROLEAU fevrier 2004


  Recolle les points d'un fichier geom.cir � Epsilone pr�s
  soit en 2D sur X et Y
  soit en 3D sur X,Y,Z

*/


#include<solene.h>


// DECLARATIONS FUNCTIONS

void compare_point();
ecrit_en_tete();
void format_entree();
void recolle_face();
void trans_face();

// Global
double *xp,*yp,*zp;
int np_dif;

/*_________________________________________________________________*/
main(argc,argv)
 int argc;char **argv;
{
 char 	buf[512],*s_dir;
 double englob[10],epsi;
 int j,nb, nbff,nomax,dim;
 FILE *fp;
 struct modelisation_face *ff;
 struct contour *pcont;
 struct circuit *pcir;

 printf("Fonction Solene : recolle_point\n\n");
 if(argc!=5)format_entree();

	s_dir=(char *)getenv("PWD");

	// INPUT
  compose_nom_complet(buf,s_dir,argv[1],"cir");
  if((fp=fopen(buf,"r"))==NULL)
        { printf("\n impossible ouvrir %s\n",buf); exit(0);}
   lit_en_tete(fp,&nbff,&nomax,englob);
   ff=alloue_face(nbff,35);
   lit_fic_cir3d(fp,nbff,ff);
   fclose(fp);
   printf("Geometrie_in: %s\n",buf);

  sscanf(argv[2],"%d",&dim);
  if(dim==2)
  { printf("Recolle sur x et y\n");
  }
  else if(dim==3)
  { printf("Recolle sur x y et z\n");
  }
  else format_entree();

  sscanf(argv[3],"%lf",&epsi);
  printf("Distance de recollement= %f \n",epsi);

  // calcul nb de points du fichier
     np_dif=0;
     for(j=0;j<nbff;j++) 
	 {  pcont=(ff+j)->debut_projete;
	       while(pcont)	   
		   { pcir=pcont->debut_support; 
			 np_dif+=pcir->nbp-1;
			 pcont=pcont->suc; 
		   } 
	 }
	 printf("\nnb total de points du fichiers : %d\n",np_dif);
  // alloue le nb de points
	 xp= alloue_double(np_dif, 1);
	 yp= alloue_double(np_dif, 2);
	 zp= alloue_double(np_dif, 3);
        
  /* r�alise le recollement */ 
   np_dif=0;  
   for(j=0;j<nbff;j++) 
    {  
	    recolle_face(ff+j,1,dim,epsi);
    }

  /* stocke le fichier */

   compose_nom_complet(buf,s_dir,argv[4],"cir");
   printf("\nGeometrie_out: %s\n",buf);
  
   fp=fopen(buf,"w");
   if(fp==NULL) 
	{ printf("impossible creer %s\n",buf);
	  exit(0);
	}

   ecrit_en_tete(fp,nbff,nomax,englob);
   output_face_sur_fichier(ff,nbff,1,0,fp,&nb,&nomax);
   fclose(fp);

   printf("\nnb total de points diff�rents : %d\n",np_dif);

   printf("\nFin recolle_point\n");
  		creer_OK_Solene();

	desalloue_fface(ff,nbff);
}

/*____________________________________________________________________*/
void recolle_face(face,projete,dim,epsi)
struct modelisation_face *face;
int projete;
int dim;
double epsi;
{
 int i;
 struct contour *pcont;
 struct circuit *pcir;

   // ne consid�re pas les trous
   if(projete)pcont=face->debut_projete; else pcont=face->debut_dessin;

      while(pcont)	   
       { pcir=pcont->debut_support; 
         for(i=0;i<pcir->nbp-1;i++)
			{ compare_point (pcir,i,dim,epsi);
			}
		 i=pcir->nbp-1;
		 pcir->x[i] = pcir->x[0] ;
		 pcir->y[i] = pcir->y[0] ;
		 pcir->z[i] = pcir->z[0] ;
         pcont=pcont->suc; 
       } 
}

/*____________________________________________________________________*/
void compare_point(pcir,id,dim,epsi)
struct circuit *pcir;
int id;
int dim;
double epsi;
{
 int i, oui;
 double xg,yg,zg;

 oui=0;
 xg=pcir->x[id] ;
 yg=pcir->y[id] ;
 zg=pcir->z[id] ;

	 for (i =0 ; i< np_dif; i++)
	 {
		 if(dim==3)  // en 3D
		 {
			//printf("    %f %f %f\n", x_n3s[i],y_n3s[i],z_n3s[i]);
			if(fabs(xg - xp[i]) < epsi && fabs(yg - yp[i]) < epsi && fabs(zg - zp[i]) < epsi)
				{ 
			      pcir->x[id]= xp[i];
			      pcir->y[id]= yp[i];
			      pcir->z[id]= zp[i];
				  oui=1;
				  break;
				}
		 }
		 else			// en 2D
		 { 	if(fabs(xg - xp[i]) < epsi && fabs(yg - yp[i]) < epsi)
				{ 
			      pcir->x[id]= xp[i];
			      pcir->y[id]= yp[i];
				  oui=1;
				  break;
				}
		 }
	 }

	 if(oui==0) // retient le point
	 { xp[np_dif]= xg;
	   yp[np_dif]= yg;
	   zp[np_dif]= zg;
	   np_dif++;
	 }
}

/*_________________________________________________________________*/
void format_entree()
{
  printf("\nrecolle_point\n\n");
  printf("IN	  fichier_in(.cir)       // fichier geom\n");
  printf("IN	  dimension              // 2 ou 3, recolle (x,y) ou (x,y,z)\n");
  printf("IN	  epsilone               // distance de recollement\n");
  printf("OUT	  fichier_out(.cir)      // fichier geom apr�s recollement des points\n");
   exit(0);
}


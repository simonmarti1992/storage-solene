/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

// glo_plan_fictif_temps.c : EVALUE Flux GLO emis par une scene SUR un PLAN FICTIF triangul�
//                           pour une S�quence de temps Horaire donn�e


// D. GROLEAU juillet 2006
// 
// sur le mod�le de radiosite_temps, fait des appels successifs � glo_plan_fictif pour une s�quence horaire de temps


#include<solene.h>

void format_glo();
void met_extension_heure();

/*_________________________________________________________________*/
main(argc,argv)           
int argc;
char **argv;
{
 int 	i,nb_pas;
 char   buf[2048], c;
 int hh1,hh2,pas,minute,temps;
 char extension_heure[16];

    if(argc!=10 && argc!=11) format_glo();

	printf("Fonction Solene : glo_plan_fictif_temps\n\n");

    //  heure debut et fin ; pas
    sscanf(argv[1],"%d%c%d",&hh1,&c,&minute);
    printf("evalue de  %dH%d",hh1,minute);
    hh1=hh1*60+minute;
    sscanf(argv[2],"%d%c%d",&hh2,&c,&minute); 
    printf(" a  %dH%d",hh2,minute);
    hh2=hh2*60+minute;
    sscanf(argv[3],"%d%c%d",&pas,&c,&minute);
    printf(" par pas de  %dH%d\n",pas,minute);
    pas=pas*60+minute;

    // calcul du nbre de pas
    nb_pas=1;
    i=hh1;
    while(i<hh2)
    { nb_pas++;
      i=i+pas;
    }
    printf("nb de pas %d\n",nb_pas);

 /* APPEL glo_plan_fictif */
  temps = hh1;
  for(i=0;i<nb_pas;i++)
   {
	 met_extension_heure(temps,extension_heure);
      
      /* compose ligne de commande */
       if(argc==10)     sprintf(buf,"glo_plan_fictif %s %s %s %s %s%s %s%s",   argv[4],argv[5],argv[6],argv[7],argv[8],extension_heure,argv[9],extension_heure);
       else if(argc==11)sprintf(buf,"glo_plan_fictif %s %s %s %s %s%s %s%s %s",argv[4],argv[5],argv[6],argv[7],argv[8],extension_heure,argv[9],extension_heure,argv[10]);

       printf("%s\n",buf);

      /* appel de ecl_plan_fictif */

       system(buf);

 		  
	temps+=pas;
  }

creer_OK_Solene();

printf("\nFin glo_plan_fictif_temps\n");
printf("______________________________\n\n");

}


/*_________________________________________________________________*/
void format_glo()
{
  	printf("\n   format d'entree des parametres \n\n");

  	printf("\n  glo_plan_fictif_temps  \n\n");

 printf("\n      la fonction a comme parametre ENTREE :\n\n");
 printf("\t hh1:mn1\n");
 printf("\t hh2:mn2\n");
 printf("\t pas(hh:mn)\n");

 printf("\t geometrie_plan_fictif_in(.cir)\n"); 
 printf("\t geometrie_masque_in(.cir)\n");
 printf("\t geometrie_masque_triangule_in (.cir)\n");
 printf("\t emissivite_geometrie_masque_triangule (.val)\n");
 printf("\t NOM g�n�rique du fichier temperature_surface_geometrie_masque_triangule (.val)\n");


 printf("\n                comme parametres en SORTIE :\n\n");
 printf("\t NOM g�n�rique du fichier glo_plan_fictif (.val)\n\n");

 printf("\n                comme parametres FACULTATIF en ENTREE :\n\n");
 printf("\t 1/2angle devision\n\n");


  exit(0);
	
}

/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */
 
/*__________________________  df_visib_facform.c   ________________________________  */
/*                          
/*______________________________________________________________________  */
/* Pour traitement pbs visibilite D. Follut 				              */
/* Ce programme determine pour les patchs d'un fichier "test"  visibles   */
/* (d'un fichier .vis) et par rapport � un fichier .cir d'observateurs    */
/* les valeurs des facteurs de forme                                      */
/* le resultat est un fichier de type .faf contenant les valeurs 0        */
/* (si non visible) ou facteur de forme (si  visible)                     */
/* a la ligne l, colonne c: visibilite du patch numero c du fichier test  */
/* depuis le patch numero l du fichier reference                          */
/* ce fichier de valeurs peut ensuite etre exploite en conjonction avec   */
/* un certain nombre de fichiers de descripteurs                          */
/*______________________________________________________________________  */
// le calcul prend appui sur l'evaluation des fac de forme dans facformn
// incluant le traitement des triangles et des quadrangles

/* Rappel ligne de compilation */
/*
cc df_visib_facform.c ./UTILS/solutile.o ./UTILS/lib_solene_94.o ./UTILS/geomutile.o  -o df_visib_facform -lm
*/


#include<solene.h>
#include<ctype.h>
#include<malloc.h>
#include<math.h>



/* Declarations de structures */

struct vertex { double x, y, z; };
struct vector { double cx, cy, cz; };
struct triangle { struct vertex a, b, c; };

/* Fonctions */
extern int option_calcul_z;   /* option CALCUL du Z ds FACE-OP-FACE 1=coincidence_faces */
                              /* utilise ds singul.c epure_polygone */
			      /* et dans face_op_face.c             */
extern 	double coef_discol;
extern 	int z_axono_pers;

//declaration fonctions

void affiche_tri();
double calcul_ff(); 
void centre_de_gravite();
struct circuit* alloue_cir();
int cosinus_vect3D();
void desalloue_cir();
double distance_entre_patchs();
void divise_triangle();
double fform_yamanouti();
void format_usage();
void lect_ff_param();
double longueur_arete_max();
double longueur_arete_poly();
int nbcontours_total();
int nb_contour_face();
double norme_vect3D();
double prod_scal_3D();
void prod_vect_3D();
int sinus_vect3D();
double surface_tri();
void traitement_faces();
double  traite_quadrangle();
double  traite_triangle();
struct vertex average();


/* Variables globales */
/* n'ayant pu etre supprimees: */

FILE *pfacvis, *pfang;		/* fichier de visibilit� et d'angle solide */

/*_________________________________________________________________*/
main(argc,argv)           
int argc;char **argv;
	{

/* Fichiers et structures de donnees */
	char nom_in[256];	/* plan d'observation */
	char nom_test[256];	/* fichier regarde (maille) */
	char nom_fvis[256];	/* fichier IN de facteurs de visibilite */
	char nom_fang[256];	/* fichier OUT des angles solides  */

	int nbfac,nbfac_test;           /* Nombres de faces */
	int  nc_total_test;	            /* Nombres de contours test*/ 

	struct modelisation_face *fac,*fac_test;
 	FILE *pfic,*pfict;
	int nomax, nomaxt;
	double englob[10];

	float *vis, *ang;
/* Autres */
	int im = 0;
	char *s_dir;

/* initialisation */
   	pi=4*atan(1.);


/* lecture parametres commande */
	s_dir = (char *)getenv("PWD");  

   	if(argc!=5) format_usage();
 
    compose_nom_complet(nom_in,s_dir,argv[1],"cir");  
    printf("\n\nAngle solide visible a partir du fichier a traiter : %s \n",nom_in);

    compose_nom_complet(nom_test,s_dir,argv[2],"cir");  
    printf("vers fichier test: %s \n",nom_test);

    compose_nom_complet(nom_fvis,s_dir,argv[3],"vis");  
    printf("avec fichier de visibilite: %s \n",nom_fvis);

    compose_nom_complet(nom_fang,s_dir,argv[4],"faf");  
    printf("Resultat fichier des angles solide : %s \n",nom_fang);

/* ouvre les fichiers a traiter et ecrit en tete fichier resultat */

       if((pfic=fopen(nom_in,"r"))==NULL)
		{ printf("\n impossible ouvrir %s\n",nom_in); 
		  exit(0);
		}
                      
       if((pfict=fopen(nom_test,"r"))==NULL)
		{ printf("\n impossible ouvrir %s\n",nom_test); 
		  exit(0);
		}

       if((pfacvis=fopen(nom_fvis,"rb"))==NULL)
		{ printf("\n impossible ouvrir %s\n",nom_fvis); 
		  exit(0);
		}

	   if((pfang=fopen(nom_fang,"wb"))==NULL)
		{ printf("\n impossible ouvrir %s\n", nom_fang); 
		  exit(0);
		}

/* lecture fichier a traiter */
       lit_en_tete(pfic,&nbfac,&nomax,englob);
       fac=alloue_face(nbfac,34);
       lit_fic_cir3d(pfic,nbfac,fac);
       fclose(pfic);

/* lecture  fichier test */
       lit_en_tete(pfict,&nbfac_test,&nomaxt,englob);
       fac_test=alloue_face(nbfac_test,34);
       lit_fic_cir3d(pfict,nbfac_test,fac_test);
       fclose(pfict);

/* lancement du calcul */

	   /* Comptage des contours des faces test */
       nc_total_test =  nbcontours_total(fac_test, nbfac_test);
	   printf("nc_total_test %d\n",nc_total_test);

	   /* alloue autant de valeurs float pour visibilite (in) et angle solide (out) */
	   vis = alloue_float(nc_total_test,4534);
	   ang= alloue_float(nc_total_test,4532);

	   /* traite */
	   
       traitement_faces(nbfac, fac, nbfac_test, fac_test, vis, ang, nc_total_test);

	fclose(pfacvis);
	fclose(pfang);

	desalloue_float(vis);
	desalloue_float(ang);
    desalloue_fface(fac,nbfac);
    desalloue_fface(fac_test,nbfac_test);

	printf("Fin du traitement df_visib_facform\n");
	exit(0);
}

/*___________________________________________________________________________________*/
void traitement_faces(nbfac, fac, nbfac_test, fac_test, vis, ang, nc_total)
int nbfac;
struct modelisation_face *fac;
int nbfac_test;
struct modelisation_face *fac_test;
float *vis, *ang; 
int  nc_total;
{ 
int nf,noc,comptc,i,j,k,jecompte;
struct contour *pcont, *pcont_test;
struct circuit *cir_emetteur, *cir_test;
struct vector normale_emetteur;

comptc=0;
for(nf=0;nf<nbfac;nf++) //passe en revue chaque contour de geometrie � traiter
  {	
	noc=0;

	normale_emetteur.cx = (fac+nf)->vnorm[0];
	normale_emetteur.cy = (fac+nf)->vnorm[1];
	normale_emetteur.cz = (fac+nf)->vnorm[2];

    pcont=(fac+nf)->debut_projete;

    while(pcont) 	/* Balayage des contours de la face courante */   
      { 
		obs.xo=0; obs.yo=0; obs.zo=0; 
		cir_emetteur=pcont->debut_support;   /* Pointeur sur le contour courant */
		noc++; 
		comptc++;
		//printf("Face numero %d, contour numero %d >>>> indice contour interne %d\n", (fac+nf)->nofac_fichier, noc, comptc); 


       /* initialise nc_total valeurs d'angles solides */
		for (i=0;i<nc_total;i++) ang[i]=0.;

		/* lit une ligne du fichier de visibilit� correspondant a nc_total contours des faces test */
		lect_ff_param(pfacvis, vis, nc_total, comptc-1, -1);

		/* si Visibilite avec les contours des faces tests */
		/* calcul des facteurs de forme du contour courant emetteur */
		/* vers les contours des autres faces du fichier */
		jecompte=0;
        for(j=0;j<nbfac_test;j++)
		  {
	        pcont_test=(fac_test+j)->debut_projete;
            while(pcont_test) 	/* Balayage des contours de la face test */   
             { 
		       cir_test=pcont_test->debut_support;   /* Pointeur sur le contour courant */
			   if(vis[jecompte])
			     { 
				   //ang[jecompte] = traite_nusselt(cir_test);
				   /* Envoi du contour courant a la fonction de calcul du f.f. */
				   ang[jecompte]=(float)calcul_ff(cir_emetteur, normale_emetteur, cir_test); 

				   //printf("%f\n",ang[jecompte]);
			     }
			   jecompte++;
		       pcont_test=pcont_test->suc; /* Passage au contour suivant de la face test courante */
		     }
		  }

		// ecrit les nb_contour_face_test valeurs d'angle solide
        fwrite(ang,sizeof(float),nc_total,pfang);

        // ecrit les nb_contour_face valeurs de face_test
		/*
        for(k=0;k<nc_total;k++)
          {  printf("%f ",ang[k]);
          }
		 */

		pcont=pcont->suc; /* Passage au contour suivant de la face courante */
	  }	
   }

}

/*_____________________________________________________________________*/
/* Lecture des facteurs de visibilite dans fichier */

void lect_ff_param(pff, ligne_ff, nb_contour, i, j)
FILE *pff;
float *ligne_ff;
int nb_contour;
int i; /* Ligne */
int j; /* colonne */
/* Lit une ligne specifiee dans un fichier de facteurs */
/* arranges en Fij , i et j variant de 0 a nb_contour-1 */
/* si j positif, donne la seule valeur Fij */
/* sinon donne toute la ligne i */
{int f;
fseek(pff,(i*nb_contour)*sizeof(float),SEEK_SET);
fread(ligne_ff, sizeof(float), nb_contour, pff);

/* if (j<0)
	{printf("Ligne %d ", i+1);
	for (f=0;f<nb_contour;f++)
		printf(" %f ", ligne_ff[f]);
	printf("\n"); 
	}
else
	{printf("Valeur F de %d vers %d: %f\n", i+1,j+1,ligne_ff[j]); 
	}
*/

}


/*_________________________________________________________________*/
/*_________________________________________________________________*/
/*_________________________________________________________________*/
// pris de facformn

/*_________________________________________________________________*/

/****** Modifs MJA 1998 *****/

/*_________________________________________________________________*/
struct circuit* alloue_cir(nb_points)
int nb_points;
{ struct circuit *pcir_nouv;
  int OK_alloc_points;
pcir_nouv=(struct circuit*)malloc(sizeof(struct circuit));
if (pcir_nouv==NULL)
	{ printf("--- Probleme allocation nouveau circuit ...\n");
	  return NULL;}

/* Allocation points du circuit */

pcir_nouv->nbp=nb_points; 
OK_alloc_points = alloue_point_circuit(pcir_nouv, 1);
if (!OK_alloc_points) {printf("--- Probleme allocation points nouveau circuit...\n");
				 return NULL;}
			 
pcir_nouv->suc = NULL;
return pcir_nouv;
}

/*_________________________________________________________________*/
void desalloue_cir(pcir)
struct circuit *pcir;
{ if (pcir->nbp)
	{free(pcir->x);
	 free(pcir->y);
	 free(pcir->z);
	}
 pcir->nbp=0;
 pcir->x = NULL;
 pcir->y=NULL;
 pcir->z=NULL;

 free(pcir);
 pcir=NULL;
}


/*_________________________________________________________________*/
double distance_entre_patchs(pcir1, pcir2)
struct circuit *pcir1, *pcir2;
{ double dpp;
double xg1, yg1, zg1;
double xg2, yg2, zg2;

xg1=0.0;yg1=0.0;zg1=0.0;
xg2=0.0;yg2=0.0;zg2=0.0;

centre_de_gravite(pcir1, &xg1, &yg1, &zg1); /* REF */
centre_de_gravite(pcir2, &xg2, &yg2, &zg2); /* PCIR */


dpp = 0.0;
dpp = (xg1-xg2)*(xg1-xg2) + (yg1-yg2)*(yg1-yg2) + (zg1-zg2)*(zg1-zg2);
dpp = sqrt(dpp);

return dpp;

}


/*_________________________________________________________________*/
double longueur_arete_max(pcir)
struct circuit *pcir;
{double lga, lga_mx;
 int k;

lga_mx=0.0;
		 	
for(k=0;k<pcir->nbp-1;k++) 
        { 
	lga=longueur_arete_poly(pcir->x[k],pcir->y[k],pcir->z[k],pcir->x[k+1],pcir->y[k+1],pcir->z[k+1]);
	if(lga>lga_mx)lga_mx=lga;
        }
return lga_mx;
}

/*_________________________________________________________________*/
void affiche_tri(tri)
struct circuit *tri;
{int i;
for (i=0;i<=2;i++)
	printf("Point %d: X=%lf, Y=%lf, Z=%lf\n", i, tri->x[i], tri->y[i], tri->z[i]);
}
/*_________________________________________________________________*/
double norme_vect3D(x, y, z)
double x, y, z;
{return sqrt(x*x+y*y+z*z);}
/*_________________________________________________________________*/
void prod_vect_3D(x1, y1, z1, x2, y2, z2, x, y, z)
double x1, y1, z1;
double x2, y2, z2;
double *x, *y, *z;
{/* Calcule les composantes du produit vectoriel de 2 vecteurs '1' et '2' */
*x = y1*z2-y2*z1;
*y = z1*x2-z2*x1;
*z = x1*y2-y1*x2;
}
/*_________________________________________________________________*/
double prod_scal_3D(x1, y1, z1, x2, y2, z2)
double x1, y1, z1;
double x2, y2, z2;

{/* Calcule le produit scalaire de 2 vecteurs '1' et '2' */
return x1*x2 + y1*y2 + z1*z2;
}

/*_________________________________________________________________*/
int sinus_vect3D(x1, y1, z1, x2, y2, z2, sinus) /* Renvoie 1 si calcul OK */
double x1, y1, z1;
double x2, y2, z2;
double *sinus;
{
 double norm1, norm2;
 double x,y,z;
 double eps = 1e-8;
 int calculOK=1;

norm1 = norme_vect3D(x1, y1, z1);
norm2 = norme_vect3D(x2, y2, z2);

if (norm1< eps) 
	{printf("Erreur, 1er vecteur de norme nulle dans calcul sinus 3D ...\n");
	calculOK=0;
	}
if (norm2< eps) 
	{printf("Erreur, 2nd vecteur de norme nulle dans calcul sinus 3D ...\n");
	 calculOK=0;
	}
if (calculOK)
	{x = 0.0; y=0.0; z=0.0;
	 prod_vect_3D(x1,y1,z1,x2,y2,z2, &x,&y,&z);

	 *sinus = norme_vect3D(x,y,z)/(norm1*norm2);
	 }
else
	{*sinus=0;}

return calculOK;
}



/*_________________________________________________________________*/
double surface_tri(tri)
struct circuit *tri;
{ 
  double sin_angle=0.0;
  int OK=1;
  double cote1, cote2;
  double v1x, v1y, v1z, v2x, v2y, v2z;

if (tri->nbp != 4)
	{printf("Erreur, circuit non triangulaire ...\n");
	 exit(0);
	}

v1x = tri->x[1]-tri->x[0];
v1y = tri->y[1]-tri->y[0];
v1z = tri->z[1]-tri->z[0];
v2x = tri->x[2]-tri->x[0];
v2y = tri->y[2]-tri->y[0];
v2z = tri->z[2]-tri->z[0];

cote1 = norme_vect3D(v1x,v1y,v1z);
cote2 = norme_vect3D(v2x,v2y,v2z);

OK = sinus_vect3D(v1x, v1y, v1z, v2x, v2y, v2z, &sin_angle);

if (OK) return (0.5*cote1*cote2*sin_angle);
else return 0.0;
}

/*_________________________________________________________________*/
int cosinus_vect3D(x1, y1, z1, x2, y2, z2, cosinus) /* Renvoie 1 si calcul OK */

double x1, y1, z1;
double x2, y2, z2;
double *cosinus;
{ 
 double norm1, norm2;
 double eps = 1e-8;
 int calculOK=1;

norm1 = norme_vect3D(x1, y1, z1);
norm2 = norme_vect3D(x2, y2, z2);

if (norm1<eps) 
	{printf("Erreur, 1er vecteur de norme nulle dans calcul cosinus 3D ...\n");
	 calculOK=0; 
	}
if (norm2<eps) 
	{printf("Erreur, 2nd vecteur de norme nulle dans calcul cosinus 3D ...\n");
	 calculOK=0;
	}

if (calculOK) *cosinus = prod_scal_3D(x1,y1,z1,x2,y2,z2)/(norm1*norm2);
else *cosinus=0;

return calculOK;
}

/*_________________________________________________________________*/
void arrange_points(cir_ref, tri1, tri2)
struct circuit *cir_ref, *tri1, *tri2;
/* Remplit coordonnees points de 2 triangles */
/* crees a partir du contour de depart (ici, un quadrangle) */
/* peut etre generalise a n sommets */
{ if (cir_ref->nbp == 5)
	{tri1->x[0] = cir_ref->x[0];
	 tri1->x[1] = cir_ref->x[1];
	 tri1->x[2] = cir_ref->x[2];
	 tri1->x[3] = cir_ref->x[0];
	 tri1->y[0] = cir_ref->y[0];
	 tri1->y[1] = cir_ref->y[1];
	 tri1->y[2] = cir_ref->y[2];
	 tri1->y[3] = cir_ref->y[0];
	 tri1->z[0] = cir_ref->z[0];
	 tri1->z[1] = cir_ref->z[1];
	 tri1->z[2] = cir_ref->z[2];
	 tri1->z[3] = cir_ref->z[0];

	 tri2->x[0] = cir_ref->x[0];
	 tri2->x[1] = cir_ref->x[2];
	 tri2->x[2] = cir_ref->x[3];
	 tri2->x[3] = cir_ref->x[0];
	 tri2->y[0] = cir_ref->y[0];
	 tri2->y[1] = cir_ref->y[2];
	 tri2->y[2] = cir_ref->y[3];
	 tri2->y[3] = cir_ref->y[0];
	 tri2->z[0] = cir_ref->z[0];
	 tri2->z[1] = cir_ref->z[2];
	 tri2->z[2] = cir_ref->z[3];
	 tri2->z[3] = cir_ref->z[0];
	}
 else
	{printf("Attention, circuit non quadrangulaire ...\n");}
}
	 

/*_________________________________________________________________*/
double calcul_ff(cir_emetteur, normale_emetteur, pcir)
struct circuit *cir_emetteur;
struct vector normale_emetteur;
struct circuit *pcir;
/* Calcul du facteur de forme entre deux contours: 	*/
/* le contour de reference 'cir_emetteur' 		*/
/* et le contour courant 'pcir' 			*/
{ double facf; 
  
  if (cir_emetteur->nbp == 4)
	{/*printf("Interface: triangle\n");*/ 
	 facf = traite_triangle(cir_emetteur, normale_emetteur, pcir);}

  else if (cir_emetteur->nbp == 5)
	{/*printf("Interface: quadrangle\n"); */
         facf = traite_quadrangle(cir_emetteur, normale_emetteur, pcir);
	 }
  else
	{/*printf("Interface: nb de points superieur a 4\n"); */
	 facf = 0.0;}

  return facf;
}
/*_________________________________________________________________*/
double traite_triangle(cir_ref, normale_emetteur, pcir)
struct circuit *cir_ref;
struct vector normale_emetteur;
struct circuit *pcir;
{ /* C'est l'ancienne fonction 'traite_nusselt' */
  /* Le circuit de reference est maintenant passe en parametre */

  int i,recurs, nbdivise=1;
  struct triangle t;
  double valg;
  double xg, yg, zg;
  double distance_pp, arete_max;

  /* Methode de YAMANOUTI */
 

/* triangle parent */
/* ne fonctionne que pour patch triangulaire */

  if (cir_ref->nbp != 4)
	{printf("Erreur, circuit non triangulaire ...\n");
	 return 0.0;}

  t.a.x=cir_ref->x[0],t.a.y=cir_ref->y[0], t.a.z=cir_ref->z[0];
  t.b.x=cir_ref->x[1],t.b.y=cir_ref->y[1], t.b.z=cir_ref->z[1];
  t.c.x=cir_ref->x[2],t.c.y=cir_ref->y[2], t.c.z=cir_ref->z[2];

  centre_de_gravite(cir_ref, &xg, &yg, &zg);
  arete_max = longueur_arete_max(cir_ref);
  distance_pp = distance_entre_patchs(cir_ref, pcir);
 
  if(distance_pp > 5*arete_max) /* Critere d'application de Yamanouti */
	{ 
	valg=fform_yamanouti(xg,yg,zg, normale_emetteur,pcir);
	recurs=0;
	}
  else if(distance_pp > 5*arete_max/2) recurs=1;
  else if(distance_pp > 5*arete_max/4) recurs=2;
  else recurs=3;

  /* printf("Traite_triangle: niveau de recursivite %d\n", recurs); */

  if(recurs)
   	{ 
	valg=0.0;

	/* divise le triangle parent en triangles plus petits */
	/* et calcule le facteur de forme en sommant les contributions correspondantes */

	divise_triangle(&t, recurs, normale_emetteur, pcir, &valg); 

	/* Moyenne sur les 'nbdivise' triangles crees */
	for (i=0;i<recurs;i++)
		nbdivise *= 4;
	valg=valg/nbdivise;
   	}    

return(valg);
}

/*________________________________________________________________________*/
double traite_quadrangle(cir_ref, normale_emetteur, pcir)
struct circuit *cir_ref;
struct vector normale_emetteur;
struct circuit *pcir;
{ double valg, facft1, facft2;
  double aire_t1, aire_t2;
  struct circuit *tri_aux1, *tri_aux2;
  double eps = 1e-8;
  
/* On forme deux triangles a partir du quadrangle de depart */
/* et on ajoute les facteurs de forme */

  tri_aux1 = alloue_cir(4);
  tri_aux2 = alloue_cir(4);
 
  arrange_points(cir_ref, tri_aux1, tri_aux2);
  aire_t1 = surface_tri(tri_aux1);   
  aire_t2 = surface_tri(tri_aux2);   
  facft1 = traite_triangle(tri_aux1, normale_emetteur, pcir);   
  facft2 = traite_triangle(tri_aux2, normale_emetteur, pcir); 
/* Moyenne ponderee par la surface des 2 triangles */
  if ((aire_t1+aire_t2)<eps) 	valg = 0.0;
  else 				valg = (aire_t1*facft1 + aire_t2*facft2)/(aire_t1+aire_t2);
  
/*  printf("ff calcule: %lf\n", valg); */

  desalloue_cir(tri_aux1);
  desalloue_cir(tri_aux2);

return valg;
}

/*________________________________________________________________________*/
/* divise un triangle en 4 triangles plus petits */
/* et calcule les facteurs de forme 'elementaires' correspondants */
/* 'valg' n'st plus une variable globale, mais est passee en parametre */

void divise_triangle(t, profond, normale_emetteur, pcir, valg)
struct triangle *t;
int profond;
struct vector normale_emetteur;
struct circuit *pcir;
double *valg;

	{
	int subt; 
	double cdgx,cdgy,cdgz,val;
	struct triangle new_t[4];
	double x[3], y[3], z[3];	
	
	val=0;
	
	/* Creation des 4 nouveaux triangles */
	new_t[0].a = t->a;
	new_t[1].b = t->b;
	new_t[2].c = t->c;
	new_t[0].c = new_t[2].a = new_t[3].b = average(&t->a, &t->c);
	new_t[0].b = new_t[1].a = new_t[3].c = average(&t->a, &t->b);
	new_t[1].c = new_t[2].b = new_t[3].a = average(&t->c, &t->b);
	
	/* recommence si profond n'est pas atteint */
	if (--profond != 0)
		{for(subt = 0; subt < 4; subt++)
			divise_triangle(&new_t[subt], profond, normale_emetteur, pcir, valg);}
	else            
	    	{
	    	for(subt = 0; subt < 4; subt++)
			{
	        	x[0]=new_t[subt].b.x, x[1]=new_t[subt].a.x, x[2]=new_t[subt].c.x;
	        	y[0]=new_t[subt].b.y, y[1]=new_t[subt].a.y, y[2]=new_t[subt].c.y;
	        	z[0]=new_t[subt].b.z, z[1]=new_t[subt].a.z, z[2]=new_t[subt].c.z;
			/* centre de gravite */
			cdgx=(x[0]+x[1]+x[2])/3,cdgy=(y[0]+y[1]+y[2])/3,cdgz=(z[0]+z[1]+z[2])/3;
			/* facteur de forme */
			val+=fform_yamanouti(cdgx,cdgy,cdgz,normale_emetteur,pcir);
			}
	    	(*valg)+=val;
	    	}
	}


/*-----------------------------------------------------------*/
double fform_yamanouti(xppp, yppp, zppp,normale_emetteur,pcir)

double xppp,yppp,zppp; /* Les coordonnees du centre de gravite de l'emetteur */
struct vector normale_emetteur;
struct circuit *pcir;	/* Le contour recepteur */
{
  int i;
  double aire,ga,gb;
  double poab[4],xt[3],yt[3],zt[3];
  double normal_x, normal_y, normal_z;
  int OKalpha=1;
  int OKbeta=1;
  int OKcalcul=1;
  double facf=0.0;

/* Implementation de l'expression du calcul du facteur de forme */
/* Approximation point-polygone */

  aire=0;

  xt[2]=xppp;  yt[2]=yppp; zt[2]=zppp;
  normal_x = normale_emetteur.cx;
  normal_y = normale_emetteur.cy;
  normal_z = normale_emetteur.cz;

  for(i=0;i<pcir->nbp-1;i++)
    { 	/* traite une arete ab (i,i+1) */

	OKalpha=1; OKbeta=1;

       	xt[0]=pcir->x[i]; yt[0]=pcir->y[i]; zt[0]=pcir->z[i];  
       	xt[1]=pcir->x[i+1]; yt[1]=pcir->y[i+1]; zt[1]=pcir->z[i+1]; 
 
      	/* normale du plan oab */       
       	normale_avec_3pts(xt,yt,zt,poab);
	
      	/* calcul alpha  : cos entre 2 vecteurs poab et normale normale_x y z */\
	
 	ga=0.0;
       	OKalpha=cosinus_vect3D(poab[0],poab[1],poab[2],normal_x,normal_y,normal_z,&ga);

	gb=0.0;
	OKbeta=cosinus_vect3D(xt[0]-xt[2],yt[0]-yt[2],zt[0]-zt[2],xt[1]-xt[2],yt[1]-yt[2],zt[1]-zt[2],&gb);
	
	if (gb > 1.0) gb = 1.0;
	if (gb <-1.0) gb = -1.0; 
	
	if (OKalpha*OKbeta)
     		aire+=ga*acos(gb); 

	OKcalcul = OKcalcul*OKalpha*OKbeta;
		 
    }

  if (OKcalcul) 
	facf=fabs(aire/2)/pi;
  else 
	facf=0.0;

   return facf;
}
/****** Fin des modifs MJA 1998 *****/
/*________________________________________________________________________*/
/* milieu de 2 points */
struct vertex average(v1, v2)
struct vertex *v1;
struct vertex *v2;
	{
	struct vertex m;

	m.x = (v1->x + v2->x) / 2;
	m.y = (v1->y + v2->y) / 2;
	m.z = (v1->z + v2->z) / 2;

	return m;
	}

/*________________________________________________________________________*/
double longueur_arete_poly(x1,y1,z1,x2,y2,z2)
double x1,y1,z1,x2,y2,z2;
{
 double longueur;
 longueur=(sqrt((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1)+(z2-z1)*(z2-z1)));
/*printf("longueur arete %f\n",longueur);*/
 return(longueur);
 
}



/*_________________________________________________________________*/
void format_usage()
{
   printf("\n   format d'entree des parametres \n\n");
   printf("df_visib_facform  fichier_des_obs_in(.cir)  fichier_test_in(.cir)\n"); 
   printf("fichier_facteurs_visibilite_in(.vis)  fichier_facteurs_facform_out(.faf)\n\n");
	
   exit(0);
}

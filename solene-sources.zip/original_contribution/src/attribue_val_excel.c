/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */
 
/* 
cc -o attribue_val_excel  attribue_val_excel.c solutile.o geomutile.o lib_solene_94.o -lm
*/

// D.GROLEAU juin 2002

/*transmet les valeurs d'un fichier excel aux faces d'une g�ometrie */
/*  le fichier excel est constitu� d'une suite de lignes comprenant
no_face_solene valeur _�_attribuer
no_face_solene valeur _�_attribuer
...
 */

#include <solene.h>



// DECLARE FUNCTIONS

void format_entree();
void lit_et_transmet();
int lit_val_excel();

/*_______________________________________*/
/*declaration application */

FILE *fpval1,*fpval2;

int nbligne;
double 	valeur1,valeur2;
double val[21000];
int nosolene[21000];
double val_excel[21000];

/************************************************/
main(argc,argv)
int argc;char **argv;
{
 char buf[512],*s_dir;
 int i;

  if(argc!=4){ format_entree(); exit(0);}


	s_dir=(char *)getenv("PWD");

 printf("\n\nCommande:  attribue_val_excel\n\n");

 compose_nom_complet(buf,s_dir,argv[1],"dat");
  if((fpval1=fopen(buf,"r"))==NULL)
	{ printf("impossible ouvrir %s\n",buf);
	  exit(0);
	}
	 printf(" valeurs � attribuer : %s\n",buf);

   // lit fichier transmis par excel
    nbligne= lit_val_excel();  // fpval1
	fclose(fpval1);

	//for(i=0; i<nbligne; i++) printf("ligne %d %d %f\n",i,nosolene[i],val_excel[i]);


 compose_nom_complet(buf,s_dir,argv[2],"val");
  if((fpval1=fopen(buf,"r"))==NULL)
	{ printf("impossible ouvrir %s\n",buf);
	  exit(0);
	}
	 printf(" suivant modele de valeurs: %s\n",buf);

 compose_nom_complet(buf,s_dir,argv[3 ],"val");
  if((fpval2=fopen(buf,"w"))==NULL)
	{ printf("impossible ouvrir %s\n",buf);
	  exit(0);
	}
	
	 printf(" valeurs transmises dans : %s\n",buf);

 // attribue les valeurs
	lit_et_transmet();
 

 creer_OK_Solene();

 printf("\n\nFin du Traitement attribue_val_excel\n");

}
/*------------------------------------------------------------*/
void format_entree()
{
  printf("\n   attribue_val_excel  fichier_excel(.dat)  fichier_in2(.val) fichier_out(.val)  \n\n");
  printf("\n Transmet les valeurs du fichier_excel.val dans fichier out.val\n");
  printf(" suivant le no de face et la structure de fichier_in2.val \n\n");
  printf(" le fichier excel est constitu� d'une suite de lignes comprenant\n");
  printf("     no_face_solene  valeur_�_attribuer\n");
  printf("     no_face_solene  valeur_�_attribuer\n");
  printf(" .....  \n\n");


}

/*------------------------------------------------------------*/
int lit_val_excel()
{
int i,id;
float xnof;
	i=0;
	while(1)
	{ if (i > 20000)
		{ printf("trop de lignes dans le fichier excel\n\n");
		  exit(0);
		}
	  id= fscanf(fpval1,"%f %lf", &xnof, val_excel+i);
	  if(id==EOF) break;
	  nosolene[i]=(int)xnof;
	  i++;
	}
	//printf("nombre de lignes lues dans fichier .dat: %d\n",i);
	return(i);

}


/*------------------------------------------------------------*/
void lit_et_transmet()
{
 int 	i,j,k, nbcontour,nbfac,nomax,nofac;
 double  valor, bidon;
 char c;

   fscanf(fpval1,"%d %d %f %f",&nbfac,&nomax,&valor,&valor);
   fprintf(fpval2,"%7d %7d %15.3f %15.3f\n",nbfac,nomax,valeur1,valeur2);

	for(i=0;i<nbfac;i++)
	 { 
	   fscanf(fpval1,"\n%c %d %d ",&c,&nofac,&nbcontour); 
	   //printf("lit noface %d\n",nofac);
	   fprintf(fpval2,"f%d %d\n",nofac,nbcontour);

	   // cherche son correspondant nofac dans le fichier excel et la valeur � attribuer
	   valor=-999.999;
	   for(k=0;k<nbligne;k++)
	   { if(nosolene[k] == nofac) 
		{ 
		  valor = val_excel[k];
		  break;
		}
	   }
		// attribue la valeur aux contours
	   for(j=0;j<nbcontour;j++) 
             { fscanf(fpval1,"%lf",&bidon);
		       fprintf(fpval2,"%15.6f\n",valor);
             }
     }
}


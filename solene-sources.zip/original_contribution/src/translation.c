/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/*

cc translation.c  solutile.o geomutile.o lib_solene_94.o

*/
/* translation.c  translation d'un .cir */

// modele rot_.c

#include<solene.h>


// DECLARATIONS FUNCTIONS

void format_entree();
void trans_face();



/*_________________________________________________________________*/
main(argc,argv)
 int argc;char **argv;
{
 char 	buf[512],*s_dir;
 double tx,ty,tz,englob[10];
 int j,nb, nbff,nomax;
 FILE *fp;
 struct modelisation_face *ff;

 if(argc<6)format_entree();

	s_dir=(char *)getenv("PWD");

 
  sscanf(argv[2],"%lf",&tx);
  printf("\n translation en x = %f ",tx);
  sscanf(argv[3],"%lf",&ty);
  printf("\n translation en y = %f ",ty);
  sscanf(argv[4],"%lf",&tz);
  printf("\n translation en z = %f ",tz);


  compose_nom_complet(buf,s_dir,argv[1],"cir");
  if((fp=fopen(buf,"r"))==NULL)
        { printf("\n impossible ouvrir %s\n",buf); exit(0);}
   lit_en_tete(fp,&nbff,&nomax,englob);
   ff=alloue_face(nbff,35);
   lit_fic_cir3d(fp,nbff,ff);
   fclose(fp);
        
  /* calcul de la translation */ 
     
   for(j=0;j<nbff;j++) 
    {
	  
	    trans_face(tx, ty, tz,ff+j,1);
    
    }

/* stocke le fichier */

   compose_nom_complet(buf,s_dir,argv[5],"cir");
   fp=fopen(buf,"w");
    if(fp==NULL) 
	{ printf("impossible creer %s\n",buf);
	  exit(0);
	}
   ecrit_en_tete(fp,nbff,nomax,englob);
   output_face_sur_fichier(ff,nbff,1,0,fp,&nb,&nomax);
   fclose(fp);
   printf("\n");
  		creer_OK_Solene();

	desalloue_fface(ff,nbff);
}

/*_________________________________________________________________*/
void format_entree()
{
  printf("\n    *translation*  fichier_in(.cir) Tx Ty Tz fichier_out(.cir)\n\n");
   exit(0);
}
/*_________________________________________________________________*/
/*____________________________________________________________________*/
void trans_face(tx,ty,tz,face,projete)
struct modelisation_face *face;
int projete;
double tx,ty,tz;
{int i;
 struct contour *pcont;
 struct circuit *pcir;

   
   if(projete)pcont=face->debut_projete; else pcont=face->debut_dessin;

      while(pcont)	   
       { pcir=pcont->debut_support; 
         for(i=0;i<pcir->nbp;i++)
           {
            pcir->x[i] = pcir->x[i] + tx;
            pcir->y[i] = pcir->y[i] + ty;
            pcir->z[i] = pcir->z[i] + tz;
			}
	     pcir=pcont->debut_interieur;
         while(pcir)
			{for(i=0;i<pcir->nbp;i++)
				{
					pcir->x[i] = pcir->x[i] + tx;
					pcir->y[i] = pcir->y[i] + ty;
					pcir->z[i] = pcir->z[i] + tz;
				}
			pcir=pcir->suc;
			}
         pcont=pcont->suc; 
       } 
}



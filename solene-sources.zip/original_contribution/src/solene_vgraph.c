/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/*
e_vgraph.c  solutile.o geomutile.o lib_solene_94.o -o rotz -lm

*/
// D. Groleau 15 mai 2002

/* transforme ficheir de solene en un fichier XML
 pour Vgraph (biblioth�que de calcul de la visibilit� par garphe de visibilit�)
 d�velopp� par Francois Sarradin
 d�velopp� pour analyse de tissus (Hadja Boukhezer)
*/
// le fichier solene est un fichier 2D (Z=cte) constitu� d"un sol perc� par des emprises de constructions
// ATTENTION
// l'origine du fichier solene doit etre proche de 0,0 et les coordonn�es X et Y >0


#include<solene.h>

// declare functions
void format_entree();
void vgraph_face();

//
struct modelisation_face *alloue_face();

 struct modelisation_face *ff;
 int nbff, numero;
 char  axe;

FILE *fp;
/*_________________________________________________________________*/
main(argc,argv)
int argc;char **argv;
{char 	buf[512],*s_dir;
 double pi,englob[10];
 int j;
 
 if(argc<2)format_entree();

	s_dir=(char *)getenv("PWD");

     init_verif_pteur_solene();
     nb_etat=0;
     pi=4*atan(1.); 

	numero=0;

  // in fichier
  compose_nom_complet(buf,s_dir,argv[1],"cir");
  if((fp=fopen(buf,"r"))==NULL)
        { printf("\n impossible ouvrir %s\n",buf); exit(0);}
   lit_en_tete(fp,&nbff,&nomax,englob);
   ff=alloue_face(nbff,35);
   lit_fic_cir3d(fp,nbff,ff);
   fclose(fp);
        
   printf("solene_vgraph\n\n");
   printf(" Transforme %s en .vgr\n\n",buf);

   /* out stocke le fichier */

   compose_nom_complet(buf,s_dir,argv[1],"vgr");
   //printf("  %s\n", buf);

   fp=fopen(buf,"w");
    if(fp==NULL) 
	{ printf("impossible creer %s\n",buf);
	  exit(0);
	}
 

  /* solene_vgraph */ 

	fprintf(fp,"<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>\n");
	fprintf(fp,"<!DOCTYPE environment SYSTEM \"environment.dtd\">\n");
	fprintf(fp,"<environment copyright=\"\">\n");
	fprintf(fp,"  <title>\n");
	//   	printf("  %s\n", buf);

	fprintf(fp,"  %s\n", buf);
	fprintf(fp,"  </title>\n");
	fprintf(fp,"  <author>\n");
	fprintf(fp,"  </author>\n");
	fprintf(fp,"  <description>\n");
	fprintf(fp,"   fichier cr�� par SOLENE\n");
	fprintf(fp,"  </description>\n");

     // normalement , on a une seule face perc� de trous
    for(j=0;j<nbff;j++) 
    {
	 vgraph_face(ff+j,1);  
    }

 	fprintf(fp,"</environment>\n");
  
   fclose(fp);
   printf("Fin de la conversion\n");
  		creer_OK_Solene();

	desalloue_fface(ff,nbff);
}

/*_________________________________________________________________*/
void format_entree()
{
  printf("\n    solene_vgraph  fichier_in_out(.cir  en .vgr)   \n\n");
 printf(" transforme une face solene avec trous en une face vgraph \n");
  exit(0);
}
/*_________________________________________________________________*/
/*____________________________________________________________________*/
void vgraph_face(face,projete)
struct modelisation_face *face;
int projete;
{int i;
 struct contour *pcont;
 struct circuit *pcir;

     
   if(projete)pcont=face->debut_projete; else pcont=face->debut_dessin;

      while(pcont)	   
	  {  // traite la face support des trous
		  pcir=pcont->debut_support; 
	      numero++;
		  fprintf(fp,"  <set-bound>\n");
		  fprintf(fp,"    <polygon>\n");

          for(i=0;i<pcir->nbp-1;i++)
          {
            fprintf(fp,"     <point coord=\"%f %f\"/>\n",pcir->x[i],pcir->y[i]);
		  }
		  fprintf(fp,"    </polygon>\n");
		  fprintf(fp,"  </set-bound>\n");

		 // on  traite  les trous
	      pcir=pcont->debut_interieur;
		  while(pcir)
		  {
		   fprintf(fp,"  <add-hole>\n");
		   fprintf(fp,"    <polygon>\n");

           for(i=0;i<pcir->nbp-1;i++)
           {
            fprintf(fp,"     <point coord=\"%f %f\"/>\n",pcir->x[i],pcir->y[i]);
		   }
		   fprintf(fp,"    </polygon>\n");
		   fprintf(fp,"  </add-hole>\n");
	       pcir=pcir->suc;
		  }
		// normalement pas d'autres contours
          pcont=pcont->suc; 
       } 
}



/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/* energie_solaire_diffuse_meteo.c :

  D. GROLEAU aout 2002
  D. GROLEAU modifi� nov 2002  (fichier meteo.txt et non .dat)
  D. GROLEAU modifi� juin 2003 ( si fichier meteo.txt vide, calcule avec les valeurs Solene)
  D. GROLEAU   modification mars 2004   appel a coplanaire

 ENERGIE solaire RECUE DU CIEL AVEC PRISE EN COMPTE DES MASQUES
 en tenant compte de valeurs de r�f�rences relev�es in situ sur un plan horizontal

*/
// sur le modele de masques_ciel.c, de energie_solaire_diffuse et energie_solaire_directe_meteo

/* POUR UN FICHIER .cir, determine, au centre de gravite de chaque contour,
 l'energie recue du ciel, en tenant compte des masques eventuels 
 en tenant compte de plusieurs radiances de ciel	
*/


// ATTENTION  modif de mars 2004:
// Ne tient pas compte des faces situ�es dans le m�me plan que celui du contour de la face en traitement
// donc attention, si des faces int�rieures non visibles (mitoyennes), alors il faut, pour avoir un r�sultat bon su ces faces (cad soleil =0)
// fournir un masque 
// qui contiennent 2 fois les faces du masque, avec les normales dans le bon sens et invers�es.

#include<solene.h>


// DECLARE FUNCTIONS

float calcul_eclair_sur_plan_horizontal();
void calcul_min_max();
void fac_reduction();
void imprime_en_tete_face();
int lit_fic_meteo();
float lit_val_meteo();
void masque_ciel();
void met_extension();
void ne_voit_rien();
void patch_gravite();
int test_si_patch_vu();
void usage_energie_solaire_diffuse_meteo();


// EN GLOBAL

#define HMAX 288  // donnees meteo entrees par pas de 5 minutes au maximum

struct modelisation_face *fac1;		/* geometrie des masques */
struct modelisation_face *fac2;		/* geometrie du ciel */
FILE *pval[HMAX];

extern int option_calcul_z;   	/* option CALCUL du Z ds FACE-OP-FACE 1=oui */
                              	/* utilise ds singul.c epure_polygone */
			      	/* et dans face_op_face.c             */
extern double coef_discol;

int im,nbre_patch_vu,nb_pas;
float *valeur_calcul, *facteur_reduc;
float *val;
double vnf[3];   		/* normale a la face en traitement */
double tgvis,covis,sinvis;
double *xg_patch,*yg_patch,*zg_patch,*angl_solid;
float *val_min,*val_max;
int nb_val_meteo;
double meteo_heure[HMAX], meteo_minute[HMAX], meteo_flux_hor[HMAX]; // PAS UTILISE

 double	 epsiloneN;  // parametre de coplanaire
 int	 facteurD;   // parametre de coplanaire


/*_________________________________________________________________*/
main(argc,argv)           /* MASQUE  pour un FICHIER DE FACES */
int argc;char **argv;
	{
	int i,j,noc,nbfac0,nbfac1,nbfac2;
	int nomax0,nomax1,nomax2,nofac,nbcont;
 	double ang;
 	char nom_in[256],nom_masc[256],nom_ciel[256],nom_lumin[256],nom_out[256],nom_angl_solid[256],buf[256];
	char *s_dir,c;
 	FILE *pfic,*pficface,*fpmeteo;

	struct modelisation_face *fac0 ;	/* geometrie a evaluer */
 	struct contour *pcont;
 	struct circuit *pcir;
 	int *vis,*nbc_face;
	double englob[10],mini,maxi;
    int indice,no_contour,nb_contour;
	int hh1,hh2,pas,minute,temps;
	char extension[16];

	int		nb_val_meteo;
	int		meteo_temps[HMAX];
	float	meteo_flux_hor[HMAX];
	int		h_trans;


		printf("\n\nCommande :  energie_solaire_diffuse_meteo\n");

/* initialisation */
   	singularite=0; non_singularite=0; nb_etat=0;
   	pb_masque=0; colle_max=coef_discol*DISCOL;
   	pi=4*atan(1.);

   // initialisation pour coplan�rit�
   epsiloneN = 0.0001;
   facteurD= 1000;

	s_dir=(char *)getenv("PWD");

 if(argc != 12 && argc != 13) usage_energie_solaire_diffuse_meteo();
 
/* lecture parametres commande */

	compose_nom_complet(nom_in,s_dir,argv[1],"cir");
        printf("\n  geometrie a traiter : %s \n", nom_in);

    compose_nom_complet(nom_masc,s_dir,argv[2],"cir");  
        printf("  geometrie masque : %s \n", nom_masc);

	compose_nom_complet(nom_ciel,s_dir,argv[3],"cir");
        printf("  geometrie de ciel : %s \n", nom_ciel);

	compose_nom_complet(nom_angl_solid,s_dir,argv[4],"val");  
        printf("  angles solides : %s \n", nom_angl_solid);

	// argv[5] : nom gen�rique des fichiers de radiance du ciel
	
    //  heure debut et fin ; pas
    sscanf(argv[6],"%d%c%d",&hh1,&c,&minute);
    printf("evalue de  %dH%d",hh1,minute);
    hh1=hh1*60+minute;
    sscanf(argv[7],"%d%c%d",&hh2,&c,&minute); 
    printf(" a  %dH%d",hh2,minute);
    hh2=hh2*60+minute;
    sscanf(argv[8],"%d%c%d",&pas,&c,&minute);
    printf(" par pas de  %dH%d\n",pas,minute);
    pas=pas*60+minute;

    // calcul du nbre de pas
    nb_pas=1;
    i=hh1;
    while(i<hh2)
    { nb_pas++;
      i=i+pas;
    }
    printf("nb de pas %d\n",nb_pas);
	if(nb_pas > HMAX)
	{ printf("trop de fichiers en sortie max %d\n",HMAX);
	  exit(0);
	}

	// angle de vision
	sscanf(argv[9],"%lf",&ang);
	if(ang<0 || ang>89.99 || ang<15) 
	   	{ 	
		printf("   *** 15 < angle_vision < 89.99 ***\n");
	     	exit(0);
	   	}
        ang=pi*ang/180.;
        tgvis=tan(ang); covis=cos(ang); sinvis=sin(ang);

	// fichier de donn�es METEO : heure minute flux_diffus_au_sol
    compose_nom_complet(buf,s_dir,argv[10],"txt");
	printf("  fichier meteo : %s \n", buf);

    if((fpmeteo=fopen(buf,"r"))==NULL)
        { printf("\n impossible ouvrir %s\n",buf); exit(0);
        }
	nb_val_meteo = lit_fic_meteo(fpmeteo,meteo_temps,meteo_flux_hor);
	fclose(fpmeteo);

		if(nb_val_meteo ==0)
		 { printf("fichier meteo vide : ne prend pas en compte le fichier meteo\n");
		 }

			// translation en heure en sortie
		 h_trans=0;
		 if(argc ==13)
		 {  sscanf(argv[12],"%d",&h_trans);
		 }


/* LECTURE DES FICHIERS */
/*** Lecture du fichier CIEL - indice 2 ***/
	if ((pfic=fopen(nom_ciel,"r"))==NULL)
            	{ 
		printf("\n  impossible ouvrir %s\n\n", nom_ciel); 
		exit(0);
            	}
       	lit_en_tete(pfic,&nbfac2, &nomax2, englob);
       	fac2=alloue_face(nbfac2, 1000);
       	lit_fic_cir3d(pfic, nbfac2, fac2);
       	fclose(pfic);

	/* calcul centre gravite patch de ciel */
	
  	xg_patch=alloue_double(nbfac2,1);
  	yg_patch=alloue_double(nbfac2,2);
  	zg_patch=alloue_double(nbfac2,3);
  	patch_gravite(nbfac2);

    desalloue_fface(fac2,nbfac2);


/*** Lecture des nb_pas RADIANCES CIEL - indice _2 */
/* attention peut_etre fonction du temps nb_pas*/

/* alloue nbfac2*nb_pas valeurs de luminance */
       	val=alloue_float(nbfac2*nb_pas,4);

       /* le 1er fic de luminance stocke de 0 a nbfac2-1 */
       /* le 2eme fic de luminance stocke de nbfac2 � ... et ainsi de suite */
        indice=0;
		temps = hh1;
        for(i=0;i<nb_pas;i++)
         {
		  met_extension(temps,extension);
		  sprintf(buf,"%s%s",argv[5],extension);
          compose_nom_complet(nom_lumin,s_dir,buf,"val");
          printf("  luminances ou radiances de ciel : %s \n", nom_lumin);
			if ((pfic=fopen(nom_lumin,"r"))==NULL)
            	{ 
					printf("\n  impossible ouvrir %s\n\n", nom_lumin); 
					exit(0);
            	}
			fscanf(pfic,"%d %d %lf %lf",&nbfac2,&nomax2,&mini,&maxi);
			for(j=0;j<nbfac2;j++)
				{ fscanf(pfic,"\n%c%d%d\n%f\n",&c,&nofac,&nbcont,val+indice+j);
				}
			fclose(pfic);
			indice=indice+nbfac2;
			temps+=pas;
         }

/* Lecture des ANGLES_SOLIDES CIEL des elements de ciel - indice _2 */
	if ((pfic=fopen(nom_angl_solid,"r"))==NULL)
           { 
			printf("\n  impossible ouvrir %s\n\n", nom_angl_solid); 
			exit(0);
           }
	fscanf(pfic,"%d %d %lf %lf",&nbfac2,&i,&mini,&maxi);
    angl_solid=alloue_double(nbfac2,5);
	for(i=0;i<nbfac2;i++)
		{	fscanf(pfic,"\n%c%d%d\n%lf\n",&c,&nofac,&nbcont,angl_solid+i);
	    }
    fclose(pfic);

	/*** Alloue les valeurs contenant les nbpas RESULTATS ***/
  	valeur_calcul=alloue_float(nb_pas,1);

    /*** Alloue les valeurs contenant les nbpas val_min val_max ***/
        indice= nb_pas;
  		val_min=alloue_float(indice,1);
  		val_max=alloue_float(indice,1);
        for(i=0;i<indice;i++) 
			{ val_min[i]=1000000.; 
			  val_max[i]=-val_min[i];
            }
  
	/*** Alloue les fac_de reduction meteo a appliquer pour les nbpas  ***/
  	facteur_reduc=alloue_float(nb_pas,1);


    // PRISE EN COMPTE DES DONNEES METEO
	//calculer � chaque heure, le facteur de r�duction � appliquer 
	// aux r�sultats de Solene
	fac_reduction(nbfac2,hh1,pas,nb_val_meteo,meteo_temps,meteo_flux_hor);


/*** Lecture en tete de la GEOMETRIE a traiter ***/

		//chargement

       	if ((pficface=fopen(nom_in,"r"))==NULL)
            { 
				printf("\n impossible ouvrir %s\n\n", nom_in); 
				exit(0);
            }
       	lit_en_tete(pficface,&nbfac0, &nomax0, englob);
       	printf("  %d faces a traiter\n", nbfac0);   

        nbc_face =alloue_int(nbfac0,1023);
		nb_contour=0;

			/* alloue les faces */
		fac0=alloue_face(nbfac0,34);
       	lit_fic_cir3d(pficface, nbfac0, fac0);
       	fclose(pficface);

		 for(i=0;i<nbfac0;i++)
			{
			 nbc_face[i]=nb_contour_face(fac0+i,1);
			 //printf("nbcontour %d\n",nbc_face[i]);
			 nb_contour+=nbc_face[i];
			}

/*** Lecture de GEOMETRIE MASQUE - indice 1 ***/
       	if ((pfic = fopen(nom_masc,"r"))==NULL)
            { 
				printf("\n impossible ouvrir %s\n", nom_masc); 
				exit(0);
            }
       	lit_en_tete(pfic,&nbfac1, &nomax1, englob);
       	printf(" avec masque de %d faces\n\n", nbfac1);
       	fac1=alloue_face(nbfac1, 34);
      	lit_fic_cir3d(pfic, nbfac1, fac1);
      	fclose(pfic);


       	vis=alloue_int(nbfac1,1);


/*** OPEN LES FICHIERS VAL RESULTATS ***/
/* 0 a nbpas-1        : energie solaire diffuse Incident */

    indice=0;
	mini=0; maxi=0;

/** energie diffuse Incidente **/
      temps = hh1 + h_trans*60;
       for(i=0;i<nb_pas;i++)
         {
		  met_extension(temps,extension);
		  sprintf(buf,"%s%s",argv[11],extension);
          compose_nom_complet(nom_out,s_dir,buf,"val");
          printf("  descripteur a creer : %s \n", nom_out);
	      if ((pval[indice]=fopen(nom_out,"w"))==NULL)
            { 
				printf("\n  impossible ouvrir %s\n\n", nom_out); 
				exit(0);
            }
		  fprintf (pval[indice],"%5d %5d %10.2f %10.2f\n", nbfac0, nomax0, mini, maxi);   
    	  indice++;
		  temps+=pas;
         }

/* observateur regarde vers le haut a verticale de oeil */
        obs.x=0; obs.y=0; obs.z=-1; 


/* TRAITEMENT POUR CHAQUE CONTOUR DE CHAQUE FACE DE NOM_IN */
	printf("Traitement en cours ...\n");


  /* les faces sont allouees */   
		no_contour=0;

        for(i=0;i<nbfac0;i++)
          {    /* lit la face */    	

			noc=0;
	     	 //printf("  traitement de la face no %d\n",(fac0+i) ->nofac_fichier);
			vnf[0]=(fac0+i)->vnorm[0]; 
			vnf[1]=(fac0+i)->vnorm[1]; 
			vnf[2]=(fac0+i)->vnorm[2]; 

			/** imprime dans .VAL pour chaque face **/
			imprime_en_tete_face(fac0+i);

			pcont=(fac0+i)->debut_projete; 
			while(pcont)	   
               { 
				pcir=pcont->debut_support;

		        centre_de_gravite(pcir, &obs.xo, &obs.yo, &obs.zo);
                noc++;

				//printf("FACE %d  Contour %d\n",(fac0)->nofac_fichier,noc); 
                //printf("   %lf %lf %lf\n",obs.xo,obs.yo,obs.zo);
				/* EN COMMENTAIRE
                if(traite_coplanerite(obs.xo,obs.yo,obs.zo,fac0+i,fac1,nbfac1))
			       { 
					 //l'observateur est masqu� totalement
					 printf("CACHE\n");
			         ne_voit_rien(nbfac2,no_contour);
		           }
		        else */
		           {
 					 /**APPEL FONCTION DE CALCUL */ 
                	 masque_ciel(nbfac1,nbfac2,(fac0+i),vis,no_contour);

					 //printf("  nombre de patches de ciel vus %d\n",nbre_patch_vu);
				   }
				no_contour++;

                pcont=pcont->suc;

               }//fin de while
           }//fin de for 

	desalloue_double(xg_patch);	desalloue_double(yg_patch);	desalloue_double(zg_patch);
	desalloue_int(vis); desalloue_float(val); desalloue_double(angl_solid);
    
       	desalloue_fface(fac1,nbfac1);
		desalloue_fface(fac0,nbfac0);

   /* reecrit les min max pour ... */
      indice=0;
   /** energie diffuse Incidente **/
           for(i=0;i<nb_pas;i++)
            {
			  rewind(pval[indice]);
			  fprintf (pval[indice],"%5d %5d %10.2f %10.2f\n", nbfac0, nomax0, val_min[indice], val_max[indice]);   
    		  indice++;
            }

        indice=nb_pas; 
        for(i=0;i<indice;i++)
         { fclose(pval[i]);
         }

     desalloue_float(val_min); desalloue_float(val_max);
     desalloue_double(valeur_calcul);

	creer_OK_Solene();
	printf("\n\nFin du Traitement energie_solaire_diffuse_meteo\n");
	exit(0);
}


/*_________________________________________________________________*/
void masque_ciel(nbfac1,nbfac2,fac0,vis,nocontour)
int nbfac1,nbfac2,*vis,nocontour;
struct modelisation_face *fac0;
{
	int i,kj,vu,indice;
	double cos_ang_inc, xyz[3], ang_inc;

 /* TRANSFORMATION fichier "masque" et COUPE PYRAMIDE , si vu */
       tranfo();
       for(i=0;i<nbfac1;i++)
			{ //printf(" Examine avec face %d\n",(fac1+i)->nofac_fichier);
		      //if((fac1+i)->nofac_fichier !=fac0->nofac_fichier )
		      //if(!(coplanaire(fac0,1,fac1+i,1,0.00001)))
			    if(!(coplanaire(fac0,1,fac1+i,1,epsiloneN, 0,facteurD)))

				{ //printf("  Non coplanaire avec face %d\n",(fac1+i)->nofac_fichier);
				  if(visible_pers(fac1+i,1))
                   { 
					 //printf("     Visible avec face %d\n",(fac1+i)->nofac_fichier);
					 vis[i]=1;

                     tran_face(fac1+i,1,fac1+i,0);

                     tran_normale((fac1+i)->vnorm);
                     if((fac1+i)->debut_dessin) 
                        { calcul_d_du_plan(fac1+i,0);

                          face_dans_vision(fac1+i,0);
                        }
                   }
                 else vis[i]=0;
               }
             else vis[i]=0;
          }


  /* PERSPECTIVE */
       init_fenetre_affichage();
       for(i=0;i<nbfac1;i++)
	  { if((fac1+i)->debut_dessin)
               { pers_conic_face(fac1+i,0);
               }
	  }

  /* reajuste la fenetre a angle de vision */
       fen_aff[0]=-tgvis; fen_aff[1]=-tgvis; 
       fen_aff[3]=tgvis; fen_aff[4]=tgvis; 
       cal_fen_aff();
              /* attention si angvis proche de 90 */
              /* on evite fen_aff[6]=0 */
       if(fen_aff[6]<0.008) fen_aff[6]=0.008;

  /* NORMALISATION */
       for(i=0;i<nbfac1;i++)
	  { if((fac1+i)->debut_dessin)
               { normalise_face(fac1+i,0);
               }
          }


/** ANALYSE DES PATCHES DE CIEL **/

	for(kj=0;kj<nb_pas;kj++)
 	 { 
  	   valeur_calcul[kj]=0.0;
     }
	nbre_patch_vu=0;
           /* considere chaque patch avec sa luminance a chaque pas (nb-pas) */
  	for(i=0;i<nbfac2;i++)
    	  {  
		xyz[0]=xg_patch[i], xyz[1]=yg_patch[i], xyz[2]=zg_patch[i];
		cos_ang_inc=vincid(vnf,xyz,&ang_inc);
		if (cos_ang_inc>0)
		   { vu=test_si_patch_vu(nbfac1,xg_patch[i],yg_patch[i],zg_patch[i]);
		     nbre_patch_vu+=vu;
		     indice=0;
             for(kj=0;kj<nb_pas;kj++)
 		      {
       			valeur_calcul[kj]+=vu*val[i+indice]*cos_ang_inc*angl_solid[i];  
 				indice+=nbfac2;
 		      }
		   }
	/*	printf("\n%d  %lf  a=%lf",i,cos_ang_inc,a);*/
    	  }

/* ECRITURE Des FICHIERS .val */
/* et calcul des min_max pour la face en traitement */
        indice=0;
	                   /** energie solaire diffuse Incidente **/
        for(i=0;i<nb_pas;i++)
		{ // on applique le facteur de reduction meteo � chaque pas
		  if(valeur_calcul[i] < 0.) valeur_calcul[i] = 0;
		  valeur_calcul[i]= valeur_calcul[i] * facteur_reduc[i];
          calcul_min_max(valeur_calcul[i],val_min+indice,val_max+indice);
		  fprintf (pval[indice],"%10.2f\n",  valeur_calcul[i]);   
    	  indice++;
         }

/* reinverse la normale et desallocation face->dessin */  
    for(i=0;i<nbfac1;i++)
	  { if(vis[i])
              { tran_normale_inverse((fac1+i)->vnorm);
                vis[i]=0;
              }
        if((fac1+i)->debut_dessin)
              { desalloue_chaine_contour((fac1+i)->debut_dessin);
                (fac1+i)->debut_dessin=NULL;
              }
      }
}
/*-----------------------------------------------------------------------------*/
int test_si_patch_vu(nbfac1,xg,yg,zg)
int nbfac1;
double xg,yg,zg;
	{
	int in,ij;
 	double xyz[3];
	double xp, yp, zp;

       	tranp(xg,yg,zg,xyz,xyz+1,xyz+2);
/* coupe par pyramide : retient ou non le point */

       	if(xyz[2]<0 && fabs(xyz[0]/xyz[2])<tgvis && fabs(xyz[1]/xyz[2])<tgvis) 
          	{ 
/* met en pers */
                xp=-xyz[0]/xyz[2];
                yp=-xyz[1]/xyz[2];
                zp=0;
                normalise_point(xp,yp,zp,&xp,&yp,&zp);
                 /* test si dans masque */
               	in=0;
               	for(ij=0;ij<nbfac1;ij++)
                 	{  
			if((fac1+ij)->debut_dessin)
                       		{ 
				in=point_dans_face(xp,yp,fac1+ij,0);
                         	if(in) return(0);
                       		}
                 	}
                /*printf("xp= %lf yp= %lf in= %d\n",xp,yp,in);*/
		return(1);
	   	}
 	return(1);
	}


/*-----------------------------------------------------------------------------*/
void patch_gravite(nbfac2)
int nbfac2;
	{
	int i,k;
 	struct contour *pcont;
 	struct circuit *pcir;

        for(i=0;i<nbfac2;i++)
           	{ 
             	pcont=(fac2+i)->debut_projete;
	        pcir=pcont->debut_support;

                xg_patch[i]=0; yg_patch[i]=0; zg_patch[i]=0; 

                for(k=0;k<pcir->nbp-1;k++) 
                       	{ 
			xg_patch[i]+=pcir->x[k];
                    	yg_patch[i]+=pcir->y[k];
                    	zg_patch[i]+=pcir->z[k];

                /*printf("%d : %lf %lf %lf\n",k+1,pcir->x[k],pcir->y[k],pcir->z[k]);*/
                       	}

                xg_patch[i]=xg_patch[i]/(pcir->nbp-1);
                yg_patch[i]=yg_patch[i]/(pcir->nbp-1);
                zg_patch[i]=zg_patch[i]/(pcir->nbp-1);  
/*	printf ("\n%d  %lf %lf %lf",i, xg_patch[i],yg_patch[i],zg_patch[i]); 
      	printf ("\n%d  %lf",i, 180/pi*acos(zg_patch[i]/sqrt(xg_patch[i]*xg_patch[i]+yg_patch[i]*yg_patch[i]+zg_patch[i]*zg_patch[i]))); */
     		}
	}

/*_________________________________________________________________*/

void calcul_min_max(valeur,val_min,val_max)
float valeur;
float *val_min,*val_max;
{ if(valeur<*val_min) *val_min= (float) valeur;
  if(valeur>*val_max) *val_max= (float) valeur;
}

/*_________________________________________________________________*/
void imprime_en_tete_face(fac0)
struct modelisation_face *fac0;
{
  int i, indice;

    indice=0;
	                   /** energie solaire diffuse Incidente **/
	for(i=0;i<nb_pas;i++)
         {
	      fprintf (pval[indice],"f%d %d\n",(fac0) ->nofac_fichier,nb_contour_face(fac0,1));   
    	  indice++;
         }
}

/*_________________________________________________________________*/
void ne_voit_rien(nbfac2,nocontour)
int nbfac2,nocontour;
{
 int kj,i,indice;

 for(kj=0;kj<nb_pas;kj++)
   { 
  	 valeur_calcul[kj]=0.0;
   }
 nbre_patch_vu=0;

 indice=0;
	                   /** energie solaire diffuse Incidente **/
 for(i=0;i<nb_pas;i++)
         {
          calcul_min_max(valeur_calcul[i],val_min+indice,val_max+indice);
		  fprintf (pval[indice],"%10.2f\n",  valeur_calcul[i]);   
    	  indice++;
         }
}

/*------------------------------------------------------------*/
float lit_val_meteo(temps,nb_val_meteo,meteo_temps,meteo_val)
int		temps, nb_val_meteo;
int		*meteo_temps;
float	*meteo_val;
{
int i, ecart_t, delta_t;
float ecart_v, valeur;
// soit trouve la valeur au temps (en minutes) exact, soit interpole entre 2 valeurs encadrant le temps choisi

//printf("lit_val pour %d H %d\n",heure,minute);

	for (i=0;i<nb_val_meteo;i++)
	{
	  
	  if(temps == meteo_temps[i]) return(meteo_val[i]);
	  if(temps < meteo_temps[i])
	  { if (i ==0) return(meteo_val[0]);
	    else
		{ ecart_t = meteo_temps[i] - meteo_temps[i-1];
		  delta_t = temps - meteo_temps[i-1];
		  ecart_v = meteo_val[i] - meteo_val[i-1];
		  valeur = meteo_val[i-1] + (ecart_v * delta_t)/ecart_t;
		  return(valeur);
		}
	  }
	}
	return(meteo_val[nb_val_meteo-1]);
}


/*------------------------------------------------------------*/
int lit_fic_meteo(fp,meteo_temps,meteo_valeur)
FILE	*fp;
int		*meteo_temps;
float	*meteo_valeur;
{
int i,id, hh, mm;
	i=0;
	while(1)
	{ if (i > HMAX)
		{ printf("trop de lignes dans le fichier meteo (max %d)\n\n",HMAX);
		  exit(0);
		}
	  id= fscanf(fp,"%d %d %f", &hh,&mm,meteo_valeur+i);

	  //printf("i =%d %d %d \n",i,hh,mm);
	  if(id==EOF) break;
	  if(meteo_valeur[i] < 0) meteo_valeur[i] = 0; // radiance de solene fournit -1 la nuit
	  meteo_temps[i]= 60*hh + mm;
	  i++;
	}
	printf("	nombre de lignes lues dans le fichier de meteo : %d\n",i);
	return(i);

}

//_____________________________________________________
void met_extension (temps,extension)
int temps;
char *extension;
{
	float xh_heure;
	int h_heure, m_minute;

		xh_heure= (float)temps/60;
		h_heure= (int) xh_heure;
		m_minute= temps-h_heure*60;
		//printf(" heure_minute %d H %d\n",h_heure,m_minute);
		//construit extension pour fichier val heure
		if(h_heure>=10 && m_minute >=10)
		{
		 sprintf(extension,"_%dH%d",h_heure,m_minute);
		}
		else if(h_heure>=10 && m_minute <10)
		{
		 sprintf(extension,"_%dH0%d",h_heure,m_minute);
		} 
		else if(h_heure<10 && m_minute >=10)
		{
		 sprintf(extension,"_0%dH%d",h_heure,m_minute);
		} 
		else if(h_heure <10 && m_minute <10)
		{
		 sprintf(extension,"_0%dH0%d",h_heure,m_minute);
		} 
		//printf("extension %s\n",extension);
}

//______________________________________________________________
void fac_reduction(nbfac2, temps, pas, nb_val_meteo,meteo_temps,meteo_flux_hor)
int nbfac2, temps, pas;
int nb_val_meteo;
int *meteo_temps;
float *meteo_flux_hor;

	// calculer � chaque heure, le facteur de r�duction � appliquer 
	// aux r�sultats de Solene
{
int i,kj,indice;
float val_meteo;
double xyz[3], cos_ang_inc, ang_inc;

	// consid�re face horizontale
	vnf[0] =0; vnf[1] =0; vnf[2] =1;
	obs.xo =0; obs.yo =0; obs.zo =0; 

	/** calcul eclairement envoy� par chaque patch de ciel � chaque pas **/

	for(kj=0;kj<nb_pas;kj++)
 	{ 
  	   valeur_calcul[kj]=0.0;
    }
	nbre_patch_vu=0;
    /* considere chaque patch avec sa luminance a chaque pas (nb-pas) */
  	for(i=0;i<nbfac2;i++)
    {  
		xyz[0]=xg_patch[i], xyz[1]=yg_patch[i], xyz[2]=zg_patch[i];
		cos_ang_inc=vincid(vnf,xyz,&ang_inc);
		if (cos_ang_inc>0)
		   { 
		     nbre_patch_vu++;
		     indice=0;
             for(kj=0;kj<nb_pas;kj++)
 		      {
       			valeur_calcul[kj]+= val[i+indice]*cos_ang_inc*angl_solid[i];  
 				indice+=nbfac2;
 		      }
		   }
	//	printf("\n%d  %lf  a=%lf",i,cos_ang_inc,a);*/
    }

	if(nb_val_meteo)
	{
		// calcul le facteur de r�duction pour les heures simul�es
		for(kj=0;kj<nb_pas;kj++)
		{
			val_meteo = lit_val_meteo(temps,nb_val_meteo,meteo_temps,meteo_flux_hor);
			//printf("val_meteo %f\n",val_meteo);
			facteur_reduc[kj]= val_meteo/valeur_calcul[kj];
			temps+=pas;
		}
	}
	else  
	{	// fichier meteo vide, ne fait ps de correction
		for(kj=0;kj<nb_pas;kj++)
		{
			facteur_reduc[kj]= 1;
			temps+=pas;
		}

	}

}

/*_________________________________________________________________*/
/* Format de la fonction energie_solaire_diffuse_meteo */
void usage_energie_solaire_diffuse_meteo()
	{
 printf("\n   energie_solaire_diffuse_meteo\n");
 printf("\n      la fonction a comme parametre en ENTREE :\n\n");
 printf("\t geometrie_a_simuler_in(.cir)\n"); 
 printf("\t geometrie_masque_in(.cir)\n");
 printf("\t geometrie_de_ciel_in(.cir)\n"); 
 printf("\t angle_solide_de_ciel_in(.val)\n");
 printf("\t NOM generique des fichiers de radiance de ciel (.val)\n");
 printf("\t hh1:mn1\n");
 printf("\t hh2:mn2\n");
 printf("\t pas(hh:mn)\n");
 printf("\t angle_vision\n"); 
 printf("\t fichier_donnees_meteo(.txt)\n");
  
 printf("\n           comme parametres en SORTIE, \n\n");
   
 printf("\t energie_solaire_diffuse_meteo_Incidente(.val)\n"); 
 printf("\n           comme parametres FACULTATIF:\n\n");
 printf("\t translation_en_heure\n");

 printf("\nNOTA: le programme ajoute une extension _hhHmm au nom de fichier correspondant � l'heure du calcul\n");
 printf("\nNOTA: en tenant compte d'une translation en heures si souhait�\n");
 printf("\nNOTA: fichier meteo sous la forme d'une liste de lignes \n");
 printf("				heure minute diffus_au_sol\n");
 printf("				heure minute diffus_au_sol\n");
 printf("				.......\n\n");
 exit(0);
	}



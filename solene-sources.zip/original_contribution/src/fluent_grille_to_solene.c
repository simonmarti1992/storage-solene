/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/*

fluent_grille_to_solene

D. GROLEAU juin 2004

  lit fichier points sur une grille donn� par Fluent
  nop x y z val1 
  et constitue fichier maille de cette grille avec un fichier val associ�

  attention: la grille peut contenir des trous
  et en 2D

  
*/



#include<solene.h>


// DECLARATIONS FUNCTIONS

double arrondi_valeur();
int ecrit_en_tete();
void format_entree();


/*_________________________________________________________________*/
main(argc,argv)
 int argc;char **argv;
{
 char 	buf[512],*s_dir;

 double	englob[10];
 int	nof;

 FILE	*fp,*fpval;
 int	i,j,id,n,no;
 double xi,yi,xf,yf,dx,dy;
 int	nbp,nbpx,nbpy;
 double	*x, *y, *z, *val;
 double arrondi,min,max;
 double x1,x2,x3,x4,y1,y2,y3,y4,z1,valeur,dx2,dy2;


 printf("Fonction Solene : fluent_grille_to_solene\n\n");

 for(i=0;i<10;i++) englob[i]=0;

 if(argc!=10)format_entree();

	s_dir=(char *)getenv("PWD");

	sscanf(argv[2],"%lf",&xi);
	sscanf(argv[3],"%lf",&yi);
	sscanf(argv[4],"%lf",&xf);
	sscanf(argv[5],"%lf",&yf);
	sscanf(argv[6],"%lf",&dx);
	sscanf(argv[7],"%lf",&dy);
	printf("Origine de la grille   : %f, %f\n",xi,yi);
	printf("Extr�mit� de la grille : %f, %f\n",xf,yf);
	printf("pas en x et y          : %f, %f\n",dx,dy);
//__________________________________________________
// OPEN le fichier grille fluent 
  compose_nom_complet(buf,s_dir,argv[1],"gri");
  if((fp=fopen(buf,"r"))==NULL)
        { printf("\n impossible ouvrir %s\n",buf); exit(0);}
 printf("fichier grille fluent (.gri)  : %s\n",buf);


//____________________________________________________
// info de la grille th�orique
  nbpx= 1 + (xf-xi)/dx;
  nbpy= 1 + (yf-yi)/dy;
  nbp= nbpx * nbpy;
  printf("nb de points de la grille th�orique :%d\n",nbp);

  x= alloue_double(nbp,56);
  y= alloue_double(nbp,56);
  z= alloue_double(nbp,56);
  val= alloue_double(nbp,56);

  n=0;

  for(i=0;i<nbpx;i++)
  { 
	for(j=0;j<nbpy;j++)
		{ x[n]= xi+ i*dx;
	      y[n]= yi+ j*dy;
		  z[n]=0;
		  val[n]= -999.999;
		  //printf("%10.2f %10.2f %10.2f %10.2f\n",x[n],y[n],z[n],val[n]);
		  n++;
		}
  }

//_____________________________________________
// place les points de la grille fluent sur la grille th�orique

 arrondi = pow(10.,2.);  // 1O a la puissance n (nb de decimales: 2)

 //lit ligne en-tete
 printf("\n Lit en tete du fichier fluent\n");
 fscanf(fp,"%s",buf); printf("%s ",buf);
 fscanf(fp,"%s",buf); printf("%s ",buf);
 fscanf(fp,"%s",buf); printf("%s ",buf);
 fscanf(fp,"%s",buf); printf("%s ",buf);
 fscanf(fp,"%s",buf); printf("%s \n\n",buf);

 n=0;
 while(1)
  {
	  id= fscanf(fp,"%d %lf %lf %lf %lf", &no, &x1,&y1,&z1, &valeur);
	  if(id==EOF) break;

	  // arrondi x, y et z
	  x1=arrondi_valeur(arrondi,x1);
	  y1=arrondi_valeur(arrondi,y1);
	  z1=arrondi_valeur(arrondi,z1);
	  // trouve l'indice du point dans la grille th�orique
	  i= (x1-xi)/dx;
	  j= (y1-yi)/dy;
	  id= i*nbpy + j;
	  if(val[id]!=-999.999)
	  {
	    printf("PB, d�j� quelqu'un: x,y,z,val : %10.2f %10.2f %10.2f %10.2f indice:%d\n",x1,y1,z1,valeur,id);
	  }
	  // place la valeur et z
	  z[id]=z1;
	  val[id]=valeur;
      n++;
 }
 fclose(fp);
 printf("nb de points de la grille Fluent :%d\n",n);


  // imprime grille th�orique
  /*
  printf("grille th�orique avec valeurs associ�es\n");
  n=0;
  for(i=0;i<nbpx;i++)
  { 
	for(j=0;j<nbpy;j++)
		{ printf("%10.2f %10.2f %10.2f %10.2f\n",x[n],y[n],z[n],val[n]);
		  n++;
		}
  }
  */

 //_____________________________
 // Constitue les mailles Solene et le val associ�

   compose_nom_complet(buf,s_dir,argv[8],"cir");
   printf("Fichier de grille solene � cr�er : %s \n",buf);
   fp=fopen(buf,"w");
    if(fp==NULL) 
	{ printf("impossible creer %s\n",buf);
	  exit(0);
	}

   compose_nom_complet(buf,s_dir,argv[9],"val");
   printf("Fichier de valeurs � cr�er : %s \n",buf);
   fpval=fopen(buf,"w");
    if(fpval==NULL) 
	{ printf("impossible creer %s\n",buf);
	  exit(0);
	}

    // nb de faces � cr�er ? en th�orie nbp
    ecrit_en_tete(fp,nbp,nbp,englob);
	min=100000; max=-min;
	nof=0;
    fprintf(fpval,"%8d %8d %12.3f %12.3f \n", nof, nof, min, max);

	// constitue seulement les faces ayant une valeur
 dx2=dx/2; dy2=dy/2;
 n=0;
 nof=0;
 for(i=0;i<nbpx;i++)
 {
   for(j=0;j<nbpy;j++)
	 {
	   if(val[n]!=-999.999)
	   { 
	     // coordonn�es des 4 points de la maille
	     x1=x[n]-dx2;	y1=y[n]-dy2;	z1=z[n];
	     x2=x[n]+dx2;	y2=y[n]-dy2; 
	     x3=x[n]+dx2;	y3=y[n]+dy2;
	     x4=x[n]-dx2;	y4=y[n]+dy2; 

		 nof++;
		 fprintf(fp,"f%d 1\n",nof) ;
		 fprintf(fp,"0 0 1\n") ;
		 fprintf(fp,"c0\n") ;
		 fprintf(fp,"5\n") ;

		 fprintf(fp,"%f %f %f\n",x1,y1,z1) ;
		 fprintf(fp,"%f %f %f\n",x2,y2,z1) ;
		 fprintf(fp,"%f %f %f\n",x3,y3,z1) ;
		 fprintf(fp,"%f %f %f\n",x4,y4,z1) ;
		 fprintf(fp,"%f %f %f\n",x1,y1,z1) ;

		 fprintf (fpval,"f%d 1\n", nof);   
		 fprintf (fpval,"  %12.3f\n", val[n]); 
		 if(val[n] < min) min = val[n];
		 if(val[n] > max) max = val[n];

	   }
	  n++;
	 }
 }
   printf("nb de faces cr��es : %d\n",nof);
   rewind(fp);
   ecrit_en_tete(fp,nof,nof,englob);
   fclose(fp);
   rewind(fpval);
   fprintf(fpval,"%8d %8d %12.3f %12.3f", nof, nof, min, max);
   fclose(fpval);


 // desalloue
 desalloue_float(x);
 desalloue_float(y);
 desalloue_float(z);
 desalloue_float(val);
   
 printf("\nFin de fluent_grille_to_solene\n\n");

}


/*____________________________________________________________________*/
double arrondi_valeur(arrondi,valeur)
double arrondi;
double valeur;
{
double val_arrondi, x2,x3;
int val_int;

 x2 = valeur * arrondi;
 val_int = x2;
 x3 = val_int;
 if( fabs(x2-x3) >= 0.5) 
 {
	  if (valeur > 0) val_arrondi = x3 + 1;
	  else val_arrondi = x3 - 1;
 }
 else val_arrondi = x3;


return(val_arrondi / arrondi);
}
/*_________________________________________________________________*/
void format_entree()
{
  printf("\n  fluent_grille_to_solene  fichier_in(.gri)  xi yi xf yf dx dy fichier_grille_out(.cir) fichier_val(.val)\n\n");
   exit(0);
}

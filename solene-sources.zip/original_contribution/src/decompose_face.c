/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */
 
/*
cc decompose_face.c  solutile.o geomutile.o poly_op_poly.o face_op_face.o lib_solene_94.o -o decompose_face  -lm
*/
// D. GROLEAU Modif avril 2006 nb de fichiers 64

/* liste des fonctions qui font appel a decompose_face */
/*
cc decompose_face_heure.c  solaire.o solutile.o geomutile.o lib_solene_94.o -o decompose_face_heure -lm
cc decompose_face_heure_hel.c  solaire.o solutile.o geomutile.o lib_solene_94.o -o decompose_face_heure_hel -lm
cc decompose_face_jour.c  solaire.o solutile.o geomutile.o lib_solene_94.o -o decompose_face_jour -lm
cc decompose_face_jour_hel.c  solaire.o solutile.o geomutile.o lib_solene_94.o -o decompose_face_jour_hel -lm
*/

#include<solene.h>



struct table_etat{int *etat;};
int nb_etat;
FILE *ficetat,*fcop,*fp;
char buf[256];
struct modelisation_face *ff[64];
struct modelisation_face *alloue_face();
int nbf,nbfmax;
struct table_etat *fetat;

/*_________________________________________________________________*/
main(argc,argv)
char *argv[];
int argc;
{double englob[10],englob1[10];
 int no,i,j,nofic,nbff[64],k;
  char *s_dir;

  printf("\n DECOMPOSITION DE CHAQUE FACE EN SURFACES HOMOGENES \n");
  
           s_dir= "";//(char *)getenv("PWD");


if(argc>64||argc<4){format_entree_decompose_face();exit(0);}
  nb_etat=argc-2;
 /* lit tous les fichiers d'etats */
  nbfmax=-1; nofic=0; i=1;
  while(i<=argc-2)
    {
     sprintf(buf,"%s.cir",argv[i]);
	 //compose_nom_complet(buf,s_dir,argv[i],"cir");
   /*  printf("fichier a traiter %s \n\n",buf); */
     if((fp=fopen(buf,"r"))==NULL)
        { printf("\n impossible ouvrir %s\n",buf); exit(0);}
	if(i==1)lit_en_tete(fp,&nbff[nofic],&no,englob);
	else lit_en_tete(fp,&nbff[nofic],&no,englob1);
        nbfmax=imax(nbfmax,no);
        ff[nofic]=alloue_face(nbff[nofic],35);
        lit_fic_cir3d(fp,nbff[nofic],ff[nofic]);
        fclose(fp);
        nofic++;i++;
    }
  /* allocation de la table de correspondance */
   fetat=(struct table_etat *)malloc((nbfmax+1)*sizeof(*fetat));
   if(fetat==NULL)
	{printf("\n pb allocation fetat \n"); exit(0);}
  for(i=0;i<(nbfmax+1);i++)
	{(fetat+i)->etat=(int *)malloc(nb_etat*sizeof(int));
	 if((fetat+i)->etat==NULL)
		{printf("\n pb allocation des etats de fetat \n"); exit(0);}
         for(j=0;j<nb_etat;j++)(fetat+i)->etat[j]=-1;
	}

  /* remplit la table */
   for(i=0;i<nb_etat;i++)
	{for(k=0;k<(nbfmax+1);k++)
	  {if(k<nbff[i])
            {j=(ff[i]+k)->nofac_fichier;
             if(j!=0)(fetat+j)->etat[i]=k;
	    }
	  }
	}
/*
 for(i=0;i<nb_etat;i++)
	{for(k=1;k<(nbfmax+1);k++)
           printf("\n etat = %d face = %d corres = %d ",i,k,(fetat+k)->etat[i]);
        }
*/

/* ouvre et initialise le fichier des faces resultats */
     
    sprintf(buf,"%s.cir",argv[argc-1]);
//   compose_nom_complet(buf,s_dir,argv[argc-1],"cir");
     fcop=fopen(buf,"w");
     nbf=0;    nomax=0;
      ecrit_en_tete(fcop,nbf,nomax,englob);
/* ouvre et initialise le fichier des etats */
    sprintf(buf,"%s.eta",argv[argc-1]);
	  //compose_nom_complet(buf,s_dir,argv[argc-1],"eta");
     ficetat=fopen(buf,"w");
     fprintf(ficetat," %4d %4d %4d\n",nbf,nomax,nb_etat-1);

/* traite successivement chacune des faces */
     for(i=1;i<(nbfmax+1);i++)
	{if((fetat+i)->etat[0]>=0)traite_decompose_face(i);}

/* ferme le fichier des faces resultats */
    rewind(fcop);
    ecrit_en_tete(fcop,nbf,nomax,englob);
    fclose(fcop); 
/* ferme le fichier des faces etats */
    rewind(ficetat);
    fprintf(ficetat," %4d %4d %4d\n",nbf,nomax,nb_etat-1);
    fclose(ficetat); 

 /*************  desallocation ****************************/

 printf("\n FIN de Decomposition\n");
 for(j=0;j<nofic;j++)desalloue_fface(ff[j],nbff[j]);

	creer_OK_Solene();
	printf("\n\nFin du Traitement\n");

/* liste_des_pointeurs();*/

}
/*_________________________________________________________________*/
traite_decompose_face(no)
int no;
{struct modelisation_face *face,*f1;
 struct contour *pc;
 double norm[3],nor[3];
 int i,j,k,kk;

    face=alloue_face(nb_etat,10);

 /* remplit la structure avec tous les etats de la face considere */
    kk=0;
    for(i=0;i<nb_etat;i++)
	{k=(fetat+no)->etat[i];
         if(k>=0){kk=1;
		  copie_face_projete(ff[i]+k,1,face+i,0);
	  	  norm[0]=(face+i)->vnorm[0];
	          norm[1]=(face+i)->vnorm[1];
	          norm[2]=(face+i)->vnorm[2];
		 }
	 else  (face+i)->nofac_fichier=no;
	}
   if(kk==0)return;
 /* printf(" TRAITE la face no %d %d\n",no,face->nofac_fichier); */
/* on regarde la face suivant sa normale */
   obs.x=norm[0];  obs.y=norm[1];  obs.z=norm[2];
   tranfo();
   init_fenetre_affichage();
   for(i=0;i<nb_etat;i++)tran_face(face+i,0,face+i,1);
   /* ajuste les normales */
   tranp(norm[0],norm[1],norm[2],&nor[0],&nor[1],&nor[2]);
   for(i=0;i<nb_etat;i++)
	{(face+i)->vnorm[0]=nor[0];
         (face+i)->vnorm[1]=nor[1];
         (face+i)->vnorm[2]=nor[2];
        }

  /* calcul des coefficients de normalisation */
   cal_fen_aff();
  /* normalise */
   for(i=0;i<nb_etat;i++)
	{normalise_face(face+i,1);
	 pc=(face+i)->debut_projete;
         while(pc){pc->etat[i]=1;pc=pc->suc;}
	}

 /* traitement */
   
   for(i=1;i<nb_etat;i++)
	{ /* initialise etat final = etat initial */
	 /*  printf(" traite etat %d \n",i);   */
          if((face+i)->debut_projete)
            {copie_face_projete(face+i,1,face+i,0);
	     for(j=i+1;j<nb_etat;j++)
		{if((face+j)->debut_projete)
                    {/* printf("AVEC  l'etat %d \n",j); */
		     f1=alloue_face(1,10);
                     /* copie de nofac et de la normale dans f1 */
		     f1->nofac_fichier=face->nofac_fichier;
		     f1->vnorm[0]=face->vnorm[0]; f1->vnorm[1]=face->vnorm[1];
	             f1->vnorm[2]=face->vnorm[2]; f1->vnorm[3]=face->vnorm[3];

                  /* face1_moins_face2(face+i,0,face+j,1,f1,0);*/
	          /* etat1_moins_etat2(face+i,0,f1,0);*/
                     face1_moins_face2_contour(face+i,0,face+j,1,f1,0);
/*
 if(no==25)printf("RESULTAT du MOINS\n");
 if(no==25){liste_face(f1,0);liste_etat(f1,0); }
*/
		  /* face1_inter_face2(face+i,0,face+j,1,f1,1);*/
	          /* etat1_inter_etat2(face+i,0,face+j,1,f1,1);*/
                   face1_inter_face2_contour(face+i,0,face+j,1,f1,1,j);
/*		  
 if(no==25)printf("RESULTAT du INTER\n"); 
 if(no==25){liste_face(f1,1);liste_etat(f1,1);}
*/                

	             copie_face_projete(f1,0,face+i,0);
	             concatene_fface(f1,1,face+i,0);
/*                    
if(no==25) printf("\n ETAT %d MODIFIE\n");
if(no==25){liste_face(face+i,0);liste_etat(face+i,0);}
*/		    
                    face1_moins_face2(face+j,1,face+i,1,f1,1);
	          /* etat1_moins_etat2(face+j,1,f1,1);*/
                     ajoute_etat(f1,1,j);
                     copie_face_projete(f1,1,face+j,1);

                     desalloue_fface(f1,1); 
		    }
		}
	   }
	  else copie_face_projete(face+i,1,face+i,0);
	}

/* calcul de la partie complementaire aux etats concernes */
   for(i=1;i<nb_etat;i++)
	{
	 face1_moins_face2(face,1,face+i,1,face,1);
	}

/* concatene les face resultats - etat final(dessin) - dans une meme face f1 */
     f1=alloue_face(1,10);
     copie_face_projete(face,1,f1,0);
     for(i=1;i<nb_etat;i++){concatene_fface(face+i,0,f1,0);}

  desalloue_fface(face,nb_etat);

 /* ramene la face f1 dans l'espace */
       denormalise_face(f1,0);
       tran_face_inverse(f1,0);
       tran_normale_inverse(f1->vnorm);
/*
if(no==25)printf(" fin\n");
if(no==25)liste_face(f1,1);
*/
 /* stocke la face f1 sur le fichier resultat */
    output_face_sur_fichier(f1,1,0,0,fcop,&nbf,&nomax);
    output_etat_sur_fichier(f1,1,0,ficetat,nb_etat-1,1);

    desalloue_fface(f1,1);

}
/*_________________________________________________________________*/

format_entree_decompose_face()
{
  printf("\n   format d'entree des parametres \n\n");
  printf("  decompose_face fichier_orig fichier1 fichier2 ----- fichiern------fichier_sortie\n");
  printf("\n  nombre maximum de fichiers = 64 \n");
  exit(0);
}

/*_________________________________________________________________*/
output_etat_sur_fichier(face,nbface,projete,fp,netat,etat_debut)
struct modelisation_face *face;
int nbface,projete,netat,etat_debut;
FILE *fp;
{int i,j,nbcont;
 struct contour *pc;
 for(i=0;i<nbface;i++) 
    { nbcont=nb_contour_face(face+i,projete);
      fprintf(fp,"f%d %d\n",face[i].nofac_fichier,nbcont);
      if(projete)pc=face->debut_projete;
      else pc=face->debut_dessin;
      while(pc)
         {fprintf(fp,"c");
          for(j=0;j<netat;j++)
	       fprintf(fp," %d",pc->etat[j+etat_debut]);
          fprintf(fp,"\n");
	  pc=pc->suc;
	 }
    }
}
/*_________________________________________________________________*/
etat1_moins_etat2(f1,proj1,f3,proj3)
struct modelisation_face *f1,*f3;
int proj1,proj3;
{int i;
 struct contour *pc1,*pc3;

  if(proj1)pc1=f1->debut_projete;
  else pc1=f1->debut_dessin;
  if(proj3)pc3=f3->debut_projete;
  else pc3=f3->debut_dessin;

  if(pc3==NULL)return;
while(pc3)
  {for(i=0;i<nb_etat;i++)pc3->etat[i]=pc1->etat[i];
   pc3=pc3->suc;
  }
}
/*_________________________________________________________________*/
etat1_inter_etat2(f1,proj1,f2,proj2,f3,proj3)
struct modelisation_face *f1,*f2,*f3;
int proj1,proj2,proj3;
{int i;
 struct contour *pc1,*pc2,*pc3;

  if(proj1)pc1=f1->debut_projete;
  else pc1=f1->debut_dessin;
  if(proj2)pc2=f2->debut_projete;
  else pc2=f2->debut_dessin;
  if(proj3)pc3=f3->debut_projete;
  else pc3=f3->debut_dessin;
 if(pc3==NULL)return;
while(pc3)
  {for(i=0;i<nb_etat;i++)
          {pc3->etat[i]=pc1->etat[i];
	   if(pc3->etat[i]==0)pc3->etat[i]=pc2->etat[i];
	  }
     pc3=pc3->suc;
  }
}
/*_________________________________________________________________*/
liste_etat(face,projete)
struct modelisation_face *face;
int projete;
{int kk,i;
 struct contour *pc;
       if(projete)pc=face->debut_projete;
       else pc=face->debut_dessin;
       i=1;
       while(pc)
         {printf("\n contour no %d \n",i);
          for(kk=0;kk<nb_etat;kk++)printf(" etat = %d f1->->etat[kk] = %d \n",kk,pc->etat[kk]);
          pc=pc->suc; i++;
	 }
}

/*_________________________________________________________________*/
/*_________________________________________________________________*/
/* DEVELOPPEMRENT D.GROLEAU 15 mars 1992                           */
/*_________________________________________________________________*/

ajoute_etat(f,proj,noetat)
struct modelisation_face *f;
int proj,noetat;
{int i;      /* ajoute etat noetat */
 struct contour *pc;
   if(proj)pc=f->debut_projete;
   else pc=f->debut_dessin;
   while(pc)
      {	pc->etat[noetat]=1;
        pc=pc->suc;
      }
}

/*_________________________________________________________________*/
met_etat_du_contour(fac,projete,pctraite)
struct modelisation_face *fac;
int projete;
struct contour *pctraite;
{
 int i;
 struct contour *pc;

   if(projete)pc=fac->debut_projete;
   else pc=fac->debut_dessin;
   while(pc)
      {	for(i=0;i<nb_etat;i++) pc->etat[i]=pctraite->etat[i];
        pc=pc->suc;
      }   
}

/*_________________________________________________________________*/
isole_un_contour(fac,projete,no,f1,projete1)
struct modelisation_face *fac,*f1;
int projete,projete1,no;
{
 int i;
 struct contour *pc,*pc1;
   if(projete)pc=fac->debut_projete;
   else pc=fac->debut_dessin;
   i=0;
   while(pc)
     { if(i==no)
         {  /* constitue f1 avec ce contour */
           pc1=NULL;
           pc1=copie_contour(pc,pc1);
           if(projete1)f1->debut_projete=pc1;
           else f1->debut_dessin=pc1; 
           fen_face(f1,projete1);   
           f1->vnorm[0]=fac->vnorm[0]; f1->vnorm[1]=fac->vnorm[1];
           f1->vnorm[2]=fac->vnorm[2]; f1->vnorm[3]=fac->vnorm[3];
           return(1);
         }
       pc=pc->suc; i++;
    }
   return(0);
}

/*_________________________________________________________________*/
face1_moins_face2_contour(face1,proj1,face2,proj2,f1,projete1)
struct modelisation_face *face1,*face2,*f1;
int proj1,proj2,projete1;
{
 int k;
 struct modelisation_face *ftemp,*fres;
   ftemp=alloue_face(1,100);
   k=0;
   while((isole_un_contour(face1,proj1,k,ftemp,0)))
     {
       fres=alloue_face(1,100);
         /* moins un contour avec face2 */
    fres->vnorm[0]=face1->vnorm[0];  fres->vnorm[1]=face1->vnorm[1];
    fres->vnorm[2]=face1->vnorm[2];  fres->vnorm[3]=face1->vnorm[3];
       face1_moins_face2(ftemp,0,face2,proj2,fres,0);
         /*met etat du contour ftemp aux contours fres */
       met_etat_du_contour(fres,0,ftemp->debut_dessin);

         /* concatene fres a resultat final f1 */

       concatene_fface(fres,0,f1,projete1);
       fen_face(f1,projete1);  
       desalloue_face(fres);
       desalloue_face(ftemp);
       ftemp=alloue_face(1,100);
       k++;      
     }
   desalloue_face(ftemp);
}

/*_________________________________________________________________*/
face1_inter_face2_contour(face1,proj1,face2,proj2,f1,projete1,noetat)
struct modelisation_face *face1,*face2,*f1;
int proj1,proj2,projete1,noetat;
{
 int k;
 struct modelisation_face *ftemp,*fres;
   /* liste_face(face1,proj1); liste_face(face2,proj2);*/
   ftemp=alloue_face(1,100);
   k=0;
   while((isole_un_contour(face1,proj1,k,ftemp,0)))
     {
       fres=alloue_face(1,100);

         /* inter un contour avec face2 */
    fres->vnorm[0]=face1->vnorm[0];  fres->vnorm[1]=face1->vnorm[1];
    fres->vnorm[2]=face1->vnorm[2];  fres->vnorm[3]=face1->vnorm[3];

       face1_inter_face2(ftemp,0,face2,proj2,fres,0);

         /* met etat du contour ftemp aux contours fres */
         /* et ajoute etat noetat */
       met_etat_du_contour(fres,0,ftemp->debut_dessin);
       ajoute_etat(fres,0,noetat);
       
         /* concatene fres a resultat final f1 */
       concatene_fface(fres,0,f1,projete1);
       fen_face(f1,projete1);  

       desalloue_face(fres);
       desalloue_face(ftemp);
       ftemp=alloue_face(1,100);
     
       k++;      
     }
   desalloue_face(ftemp);
}

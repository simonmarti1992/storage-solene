/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */
           
// de solene.h
struct modelisation_face { int nofac_fichier;
						   double vnorm[4];
						   double fen[6];
                           int inverse;
                           struct contour *debut_projete  ;
	                   struct contour *debut_dessin;
	                 }*face;

struct contour{ int *etat;
	    struct circuit *debut_support;
		struct circuit *debut_interieur;
		struct contour *suc;
	      };

struct circuit{ int nbp;
                  int statut;  /* 0:face plane 1:face non plane 2:ligne 2D  3:ligne 3D */
		  float transp;
		  float visible;
          double fen[6];
          double vnorm[4]; /* A VOIR pourrait etre supprime si on avait le no de la face */
		  double *x;	            
		  double *y;
	      double *z;
		  struct circuit *suc;
		 }cir0,cir1; /* cir0:circuit situe derriere */
                             /* cir1:circuit situe devant   */
struct point{ double x;
	      double y;
              double z;
              int statut;
              struct point *suc;
	    };




// place un polygone dans un circuit solene

			pcir=alloue_circuit(1003);
            pcir->suc=NULL;
            for(k=0;k<3;k++)pcir->vnorm[k]=face[kk].vnorm[k]; // vecteur normal
            fscanf(fp,"%d",&(pcir->nbp));  // nb de pts
            /*printf("  nb de pts %d\n",pcir->nbp);*/
            alloue_point_circuit(pcir,1004);
            for(k=0;k<pcir->nbp;k++)
                 {fscanf(fp,"%lf%lf%lf",&(pcir->x[k]),&(pcir->y[k]),&(pcir->z[k]));}
            fenetre_circuit(pcir);  

// appel pour op�ration entre cir0 et cir1 (cir0-cir1)
			pcont-resultat=alloue_contour(6); 
			if(res==NULL)pb_allocation(40);

			int masque(pcont_resultat,ornotand) // 1 2 ou 3

// r�cup�re le contour avec ses circuits 
while(pcont)	   
       { pcir=pcont->debut_support; 
         printf("\n fenetre support");
         for(i=0;i<6;i++)printf(" %lf ",pcir->fen[i]);
         printf("\n equation du plan ");
         for(i=0;i<4;i++)printf(" %lf ",pcir->vnorm[i]);
         printf("\n");
         for(i=0;i<pcir->nbp;i++) printf(" %lf %lf %lf\n",pcir->x[i],pcir->y[i],pcir->z[i]);
			//lit les poly trous
		 pcir=pcont->debut_interieur;
         while(pcir)
	    { printf("\n fenetre trou");
              for(i=0;i<6;i++)printf(" %lf ",pcir->fen[i]);
              printf("\n equation du plan ");
              for(i=0;i<4;i++)printf(" %lf ",pcir->vnorm[i]);
              printf("\n");
              for(i=0;i<pcir->nbp;i++) printf(" %lf %lf %lf\n",pcir->x[i],pcir->y[i],pcir->z[i]);
	      pcir=pcir->suc;
	    }
         pcont=pcont->suc; 
       } 

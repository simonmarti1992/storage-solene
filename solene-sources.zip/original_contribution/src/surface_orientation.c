/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/*

cc surface_orientation.c -o rugosite_typo ~marenne/newsolene/solutile.o ~marenne/newsolene/geomutile.o ~marenne/newsolene/face_op_face.o ~marenne/newsolene/poly_op_poly.o ~marenne/newsolene/lib_solene_94.o -lm


  D.GROLEAU 
	modifi� 6 juin 2004 (statistique d'exposition des fa�ades)

    mod�le rugosite_typo
*/
// s'applique � des contours 3D avec leur surfaces et l'orienation de leur normales
/*_________________________________________*/
/* DESCRIPTION
  pour un fichier .cir , 

*/
#include <solene.h>

// d�claration Functions
int classe_dir_exp();
void exposition_face();
void imprime_classe_exp();
void format_entree();
void traite();

//extern int option_calcul_z; 

int 	nbclasse_exp;

/*_________________________________________*/
/* declarations */

FILE *fsource,*fval;
int nbfac1;
struct modelisation_face	*fac1;


struct dir_arete { double angle;
	 	   double longar;
		 } classar_exp[8];
double total_longar_exp;

/*________________________________________________________________________*/
main(argc,argv)
char **argv;
int  argc ;
{
char 	buf[512],*s_dir;
double	englob[10];
int nomax1,nbfs;
float v1;

 if(argc!=3)
   { format_entree();
     exit(0);
   }

 nbclasse_exp=8;

printf("Fonction : surface_orientation \n\n");
 s_dir=(char *)getenv("PWD");

 // Open et lit fichier geom
 compose_nom_complet(buf,s_dir,argv[1],"cir");
 if((fsource = fopen(buf, "r"))==NULL)
	{ printf("\n impossible ouvrir %s\n",buf);
	  exit(0);
    }
 printf("fichier Geometrie %s\n",buf);

   lit_en_tete(fsource,&nbfac1,&nomax1,englob);
   fac1=alloue_face(nbfac1,1000);
   lit_fic_cir3d(fsource,nbfac1,fac1); 
   fclose(fsource);

 // Open le fichier des surfaces */
   compose_nom_complet(buf,s_dir,argv[2],"val");
   if((fval=fopen(buf,"r"))==NULL)
    { printf("\nimpossible ouvrir %s\n",buf);
	  exit(0);
	}
   printf("fichier Surfaces %s\n",buf);

   fscanf(fval,"%d %d %f %f",&nbfs,&nomax1,&v1,&v1);

/*printf("nbf %d\n",nbfs);*/

   if(nbfac1!=nbfs)
    {printf("\n les 2 fichiers ne comportent pas le meme nombre de faces\n");
     fclose(fval);exit(0);
    }
  /* initialise valeurs globales */

 total_longar_exp=0;

  /* TRAITE  chaque face */

  printf(" traitement en cours\n");
//  option_calcul_z=1;

  traite();

  desalloue_fface(fac1,nbfac1);

 /* imprime r�sultat */

 printf("\nLES TOTAUX : \n");

 imprime_classe_exp();



    creer_OK_Solene();

 printf("fin du traitement\n");


 }

/*________________________________________________________________________*/
void traite()
{
 int 	i,nofac,nbcont;
 double surf;
 struct contour *pcont;
 struct circuit *pcir;
 char c;


 for(i=0;i<8;i++)
   { (classar_exp+i)->longar=0; 
   }

 for(i=0;i<nbfac1;i++)
    { 
      //printf("\nFACE no =%d\n",(fac1+i)->nofac_fichier);
      fscanf(fval,"\n%c %d %d ",&c,&nofac,&nbcont);

	  pcont=(fac1+i)->debut_projete;
      while(pcont)
	  {
  	    pcir=pcont->debut_support;
	    fscanf(fval,"%lf",&surf);
        exposition_face(surf,(fac1+i)->vnorm[0],(fac1+i)->vnorm[1],(fac1+i)->vnorm[2]);

		pcont=pcont->suc;
	  }
    }
}

/*________________________________________________________________________*/
void exposition_face(surf,xnn,ynn,znn)
double surf,xnn,ynn,znn;

{ int j;
  double cosang,ang_exp;

    // angle avec direction Nord (function de solaire.c);
	cosang = incid(0.,1.,0.,xnn,ynn,znn,&ang_exp);
	ang_exp = angdeg(ang_exp); // en degr�
	if(xnn<0) ang_exp= 360-ang_exp;

    j=classe_dir_exp(ang_exp);  
    //printf(" angle %6.2lf  surface %10.3lf, CLASSE  : %d\n",ang_exp,surf,j);
    (classar_exp+j-1)->longar += surf;
    total_longar_exp+=surf;
}


/*________________________________________________________________________*/
int classe_dir_exp(angle)
double angle;
{
 double delta, deltam;
 int classe;  
  /* return valeur de 1 a 8 */

  delta=360./nbclasse_exp;
  deltam=delta/2;
  if(angle < deltam | angle >= 360-deltam) return(1);
  classe = (int) ((angle-deltam) / delta);
  return(classe+2);
}



/*________________________________________________________________________*/
void imprime_classe_exp()
{
 double delta,valp;

  delta=360./nbclasse_exp;
printf("\n Classes d'exposition en pourcentage (par secteur d'�tendue de %5.2f)\n",delta);

// n'est valable que pour 8 classes
    valp= ((classar_exp+0)->longar/total_longar_exp)*100;
	printf(" CLASSE  1 (Nord)       %5.2f \n", valp);
    valp= ((classar_exp+1)->longar/total_longar_exp)*100;
	printf(" CLASSE  2 (Nord-Est)   %5.2f \n", valp);
    valp= ((classar_exp+2)->longar/total_longar_exp)*100;
	printf(" CLASSE  3 (Est)        %5.2f \n", valp);
    valp= ((classar_exp+3)->longar/total_longar_exp)*100;
	printf(" CLASSE  4 (Sud-Est     %5.2f \n", valp);
    valp= ((classar_exp+4)->longar/total_longar_exp)*100;
	printf(" CLASSE  5 (Sud)        %5.2f \n", valp);
    valp= ((classar_exp+5)->longar/total_longar_exp)*100;
	printf(" CLASSE  6 (Sud-Ouest)  %5.2f \n", valp);
    valp= ((classar_exp+6)->longar/total_longar_exp)*100;
	printf(" CLASSE  7 (Ouest)      %5.2f \n", valp);
    valp= ((classar_exp+7)->longar/total_longar_exp)*100;
	printf(" CLASSE  8 (Nord-Ouest) %5.2f \n", valp);
	
}



/*________________________________________________________________________*/
void format_entree()
{
  printf("\n   surface_orientation  fichier_in(.cir) surf_in(.val) \n\n");
}


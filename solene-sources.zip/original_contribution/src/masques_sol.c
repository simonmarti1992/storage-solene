/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/*

cc masques_sol.c  pers_util.o solutile.o geomutile.o lib_solene_94.o face_op_face.o poly_op_poly.o -o masques_sol -lm -lmalloc

*/

//D. GROLEAU modifi� mars 2004 (modifier le test de coplan�rit�)


/* POUR UN FICHIER .cir */
/* determine pour chaque point ,centre de gravite de chaque contour de chaque face */
/* les periodes d'ensoleillement avec PAS de 5 Minutes */

// Ne tient pas compte des faces situ�es dans le m�me plan que celui du contour de la face en traitement
// donc attention, si des faces int�rieures non visibles (mitoyennes), alors il faut, pour avoir un r�sultat bon su ces faces (cad soleil =0)
// fournir un masque 
// qui contiennent 2 fois les faces du masque, avec les normales dans le bon sens et invers�es.


#include<solene.h>

// FUNCTIONS
void format_entree_masques_sol();
void imprime_periode();
void masque_sol();
void periode_soleil();

// GLOBAL
struct modelisation_face *fac1;

FILE *pmas;
int nb_per,dh[50],dm[50],fh[50],fm[50];

extern int option_calcul_z;   /* option CALCUL du Z ds FACE-OP-FACE 1=oui */
                              /* utilise ds singul.c epure_polygone */
			      /* et dans face_op_face.c             */
extern double coef_discol;

double tgvis,covis,sinvis;
double vnf[3];   /* normale de la  face en traitement */
int im;
int nb_date,jour[100],mois[100],minpas;

/*_________________________________________________________________*/
main(argc,argv)           /* MASQUE  pour un FICHIER DE FACES */
int argc;char **argv;
{int i,k,noc,nbfac,nbfac1,nomax,il;
 double latitude,ang;
 char nom_in[256],nom_masc[256],nom_out[256],c[2],*s_dir;
 FILE *pfic;
 struct modelisation_face *fac ;
 struct contour *pcont;
 struct circuit *pcir;
 int *vis;
double englob[10];

 double	 epsiloneN;
 int	 facteurD;
//   struct mallinfo mem;


      /* initialisation */
   singularite=0; non_singularite=0; nb_etat=0;
   pb_masque=0; colle_max=coef_discol*DISCOL;
   pi=4*atan(1.);

   // initialisation pour coplan�rit�
   epsiloneN = 0.0001;
   facteurD= 1000;

   if(argc<6) format_entree_masques_sol();
 
   	printf("\n\nFonction Solene:  masques_sol\n\n");

      /* lecture parametres commande */

         s_dir=""; //(char *)getenv("PWD");

		 sprintf(nom_in,"%s.cir",argv[1]);
         //compose_nom_complet(nom_in,s_dir,argv[1],"cir");
		 printf("fichier a traiter : %s \n",nom_in);

		 sprintf(nom_masc,"%s.cir",argv[2]);
        // compose_nom_complet(nom_masc,s_dir,argv[2],"cir");  
         printf("fichier masque : %s \n",nom_masc);

 		 sprintf(nom_out,"%s.mas",argv[3]);
		 //compose_nom_complet(nom_out,s_dir,argv[3],"mas");  
         printf("fichier resultat (.mas) : %s \n",nom_out);

         sscanf(argv[4],"%lf",&ang);
	 if(ang<0 || ang>89.99 || ang<15) 
	   { printf("   *** 15 < angle_vision < 89.99 ***\n");
	     exit(0);
	   }
         ang=pi*ang/180.;
         tgvis=tan(ang); covis=cos(ang); sinvis=sin(ang);


         sscanf(argv[5],"%lf",&latitude);
	 if(latitude<-66 || latitude>66) 
	   { printf("   *** -66 < latitude < 66 ***\n");
	     exit(0);
	   }
         latitude=latitude*pi/180.;

    /* impression */
      im=0;
/* lit le pas en minute d'analyse */
    sscanf(argv[6],"%d",&minpas);
    printf("   pas d'analyse en minutes : %d\n",minpas);

/* lit les dates a examiner */

    nb_date=0;
    for(i=7;i<argc;i++)
	{  	 
	  sscanf(argv[i],"%d%c%d",jour+nb_date,c,mois+nb_date);
//        if(c[0]!='/')format_entree_masques_sol();
          if(c[0]!='/')
		  { // lire en optionnel epsilone et facteurd pour coplan�rit�

	        sscanf(argv[i],"%lf",&epsiloneN);
	        sscanf(argv[i+1],"%d",&facteurD);
			printf("   approximation sur coplan�rit�: %f %d\n",epsiloneN,facteurD);

			  break;
		  }
	  if(jour[nb_date]<1|| jour[nb_date]>31)
		{ printf(" Erreur dans le jour : %d/%d\n",jour[nb_date],mois[nb_date]);
		  format_entree_masques_sol();
		}
	  if(mois[nb_date]<1||mois[nb_date]>12)
		{ printf(" Erreur dans le mois : %d/%d\n",jour[nb_date],mois[nb_date]);
		  format_entree_masques_sol();
		}
	  printf("   simule pour le jour: %d/%d\n",jour[nb_date],mois[nb_date]);
	  nb_date++;
	}
    if(nb_date==0)
	{ printf("\n   AUCUNE DATE a simuler\n");
	  format_entree_masques_sol();
	}

      /* le fichier a traiter */
      /* et ecrit en tete fichier resultat */

       if((pfic=fopen(nom_in,"r"))==NULL)
            { printf("\n impossible ouvrir %s\n",nom_in); exit(0);
            }
       pmas=fopen(nom_out,"w");
       if(pmas==NULL)
           { printf("\n impossible ouvrir %s\n",nom_out); exit(0);
           }

  /* lecture en_tete pfic */
       lit_en_tete(pfic,&nbfac,&nomax,englob);
       printf("Traite %d faces\n",nbfac);
       fac=alloue_face(nbfac,34);
       lit_fic_cir3d(pfic,nbfac,fac);
       fclose(pfic);

   /* ecriture en tete du .mas */
       /*fprintf(pmas," 3 21 12  21 3  21 6 \n");*/
       /*fprintf(pmas," 7 21 12 21 1 21 2 21 3 21 4 21 5 21 6\n");*/
	
	fprintf(pmas,"%d ",nb_date);
	for(i=0;i<nb_date;i++)
	  { fprintf(pmas," %d %d",jour[i],mois[i]);
	  }
       fprintf(pmas,"\n");

       fprintf(pmas,"%4d %4d\n",nbfac,nomax);

      /* lit le fichier masque */
   
         if((pfic=fopen(nom_masc,"r"))==NULL)
            { printf("\n impossible ouvrir %s\n",nom_masc); exit(0);
            }
  /* lecture en_tete pfic */
       lit_en_tete(pfic,&nbfac1,&nomax,englob);
       printf("avec Masque de %d faces\n\n",nbfac1);
       fac1=alloue_face(nbfac1,34);
       lit_fic_cir3d(pfic,nbfac1,fac1);
       fclose(pfic);

       vis=(int *)malloc(nbfac1*sizeof(int));



      /* observateur regarde vers le haut a verticale de oeil */
        obs.x=0; obs.y=0; obs.z=-1; 


      /* traitement pour chaque contour de chaque face de nom_in */
		 printf("Traitement en cours ...\n");

         for(i=0;i<nbfac;i++)
           { noc=0;
             pcont=(fac+i)->debut_projete; 
/*
mem=mallinfo();
printf(" space in ordinary blocs in use : %d\n",mem.uordblks);
*/

			 vnf[0]=(fac+i)->vnorm[0]; 
			 vnf[1]=(fac+i)->vnorm[1]; 
			 vnf[2]=(fac+i)->vnorm[2]; 
			 fprintf(pmas,"f%d %d\n",(fac+i) ->nofac_fichier,nb_contour_face(fac+i,1)); 
             while(pcont)	   
               { pcir=pcont->debut_support;
				 fprintf(pmas,"c\n");
                 obs.xo=0; obs.yo=0; obs.zo=0; 

		         centre_de_gravite(pcir, &obs.xo, &obs.yo, &obs.zo);
                 noc++;

                 //printf(" FACE %d  Contour %d\n",(fac+i)->nofac_fichier,noc);
                 //printf(" %lf %lf %lf\n",obs.xo,obs.yo,obs.zo);
		          
				 /* traitement pr�liminaire des coplanerit�s pour traiter le cas
				 frequent o� 2 faces sont confondues en partie (2 pignons de b�timents par ex)
                 */

				 /*
					if(traite_coplanerite(obs.xo,obs.yo,obs.zo,fac+i,fac1,nbfac1))
					 { 
					   //l'observateur est masqu� totalement
					   // periodes de soleil = 0 pour les nb_date dates 
						
                        for(il=0;il<nb_date;il++)
	                      { 
	                         fprintf(pmas," 0\n");
						  }
						printf("CACHE\n");
					 }
					else */
					 { 
					   masque_sol(nbfac1,latitude,vis,(fac+i),epsiloneN,facteurD);
					 }
				  
                 pcont=pcont->suc;
               } 
           }

       desalloue_fface(fac,nbfac);
       desalloue_fface(fac1,nbfac1);
    fclose(pmas);

	desalloue_point_circuit_cir(&cir0,1);
	desalloue_point_circuit_cir(&cir1,1);

//printf("\n liste des pointeurs \n");
//liste_des_pointeurs();

creer_OK_Solene();
	printf("\n\nFin du Traitement masques_sol\n");


}


/*_________________________________________________________________*/
void masque_sol(nbfac1,latitude,vis,fac0,epsiloneN, facteurD)
int nbfac1,*vis;
double latitude;
struct modelisation_face	*fac0;
double epsiloneN;
int facteurD;
{  int i,j;
//   struct mallinfo mem;

/*
mem=mallinfo();
printf(" space in ordinary blocs in use : %d\n",mem.uordblks);
*/
//printf("coupe_pyramide\n");
  /* TRANSFORMATION fichier "masque" et COUPE PYRAMIDE , si vu */
       tranfo();
       for(i=0;i<nbfac1;i++)
	    { 		  
	      if(!(coplanaire(fac0,1,fac1+i,1,epsiloneN, 0,facteurD)))
              { //printf(" qui n'est pas coplanaire avec face %d\n",(fac1+i)->nofac_fichier);
				 if(visible_pers(fac1+i,1))
                   { 
					 //printf(" qui voit la face %d\n",(fac1+i)->nofac_fichier);
					 vis[i]=1;
					 //liste_face(fac1+i,1);

                     tran_face(fac1+i,1,fac1+i,0);
                     tran_normale((fac1+i)->vnorm);
                     if((fac1+i)->debut_dessin) 
                        { calcul_d_du_plan(fac1+i,0);
					      //printf("Apres transfo\n");
					 	  //liste_face(fac1+i,0);
                          face_dans_vision(fac1+i,0);
					      //printf("Apres dans vision\n");
						  //liste_face(fac1+i,0);

                        }
                   }
                 else vis[i]=0;
               }
            else vis[i]=0;
          }

//printf("perspective\n");
  /* PERSPECTIVE */
       init_fenetre_affichage();
       for(i=0;i<nbfac1;i++)
	  { if((fac1+i)->debut_dessin)
               { pers_conic_face(fac1+i,0);
				 //printf(" APRES PERS avec face %d\n",(fac1+i)->nofac_fichier);
				 //liste_face(fac1+i,0);
               }
	  }
  /* reajuste la fenetre a angle de vision */
       fen_aff[0]=-tgvis; fen_aff[1]=-tgvis; 
       fen_aff[3]=tgvis; fen_aff[4]=tgvis; 
       cal_fen_aff();
              /* attention si angvis proche de 90 */
              /* on evite fen_aff[6]=0 */
       if(fen_aff[6]<0.008) fen_aff[6]=0.008;

  /* NORMALISATION */
       for(i=0;i<nbfac1;i++)
	   { if((fac1+i)->debut_dessin)
               { normalise_face(fac1+i,0);
	   			 //printf(" APRES NORMALISE avec face %d\n",(fac1+i)->nofac_fichier);
                 //liste_face(fac1+i,0);
               }
          }

  /* periodes de soleil pour les nb_date dates */
      for(i=0;i<nb_date;i++)
	  { nb_per=0;
        periode_soleil(latitude,jour[i],mois[i],fac1,nbfac1);
	    fprintf(pmas,"%2d",nb_per);
        for(j=0;j<nb_per;j++)
   	   	  { fprintf(pmas," %2d %2d %2d %2d 100",dh[j],dm[j],fh[j],fm[j]);
   	      }
	  fprintf(pmas,"\n");

	 }


  /*  reinverse la normale et desallocation face->dessin */  
        for(i=0;i<nbfac1;i++)
	    { if(vis[i])
              { tran_normale_inverse((fac1+i)->vnorm);
                vis[i]=0;
              }
          if((fac1+i)->debut_dessin)
              { desalloue_chaine_contour((fac1+i)->debut_dessin);
                (fac1+i)->debut_dessin=NULL;
              }
          }

}
/*-----------------------------------------------------------------------------*/
void periode_soleil(latitude,jour,mois,fac1,nbfac1)
double latitude;
int jour,mois,nbfac1;
struct modelisation_face *fac1;
{
 int i,in,hdeb,mindeb,hfin,minfin,hh,minute,in_prec,ij;
 double heure_lever,declin,xyz[3],xp,yp,zp,ang_inc,bidon;
 long deb,fin,debut_sol,fin_sol;

    /*minpas=5; */ /* pas d'investigation en minutes donne en parametre */
/*printf("le %2d/%d\n",jour,mois);*/
    i=numjour(jour,mois);
    i=(i-1)%365+1;          
    declin=declinaison(i);   
    heure_lever=anglev(declin,latitude);
    anglehoraire_EN_heure_et_minute(heure_lever,&hdeb,&mindeb);
    anglehoraire_EN_heure_et_minute(-heure_lever,&hfin,&minfin);
 /*
printf("jour %d declinaison = %lf\n",i,angdeg(declin));
printf("heure de lever = %lf soit %dH%d\n\n",angheure(heure_lever),hdeb,mindeb);
printf("heure de coucher = %lf soit %dH%d\n\n",angheure(-heure_lever),hfin,minfin);
*/
 /* transforme en minutes */
   deb=60*hdeb; fin=60*hfin+minfin;
   while(deb<60*hdeb+mindeb)deb+=minpas;
   in_prec=-1; debut_sol=0;

   while(deb<fin)
     {
       hh=deb/60; minute=deb%60;
          /* position du soleil */

       xyz_soleil(latitude,declin,hh,minute,xyz);
       //printf("xyz %lf %lf %lf\n",xyz[0],xyz[1],xyz[2]);

         /* test si face ensoleillee ang_inc >0 */
      ang_inc=vincid(vnf,xyz,&bidon);


       tranp(xyz[0],xyz[1],xyz[2],xyz,xyz+1,xyz+2);
         /* coupe par pyramide : retient ou non le point */
       if(xyz[2]<0 && fabs(xyz[0]/xyz[2])<tgvis && fabs(xyz[1]/xyz[2])<tgvis) 
          { 
	    if(ang_inc>0)
              {
                 /* met en pers */
                xp=-xyz[0]/xyz[2];
                yp=-xyz[1]/xyz[2];
                zp=0;
                normalise_point(xp,yp,zp,&xp,&yp,&zp);
                 /* test si dans masque */
               in=0;
               for(ij=0;ij<nbfac1;ij++)
                 {  if((fac1+ij)->debut_dessin)
                       { 
				         in=point_dans_face(xp,yp,fac1+ij,0);
						 //printf(" test in pour face %d in= %d\n",(fac1+ij)->nofac_fichier,in);
                         if(in) break;
                       }
                 }
                /*printf("xp= %lf yp= %lf in= %d\n",xp,yp,in);*/
               }
	     else in=1;  /* a l'ombre du a la face */

             if(in==0)
               { /* du soleil */
                 if(in_prec)
                   { /* debut de periode soleil */
                     debut_sol=deb;
                     in_prec=0;
                   }
                 else
                   { /* poursuit periode soleil */
                   }
               }
             else
               { /* de l'ombre */
                 if(in_prec==0)
                    { /* fin de periode soleil */
                      fin_sol=deb;
                      imprime_periode(debut_sol,fin_sol);
                      in_prec=1; debut_sol=0;
                    }
               }
          }
       else
          { if(in_prec==0)
                    { /* fin de periode soleil */
                      fin_sol=deb;
                      imprime_periode(debut_sol,fin_sol);
                      in_prec=1; debut_sol=0;
                   }
          } 
       deb+=minpas;
     }
  if(debut_sol) { fin_sol=deb-minpas;
                  imprime_periode(debut_sol,fin_sol);
                }
}
/*-----------------------------------------------------------------------------*/
void imprime_periode(debut_sol,fin_sol)
int debut_sol,fin_sol;
{ int hh,minute;
 
   hh=debut_sol/60; minute=debut_sol%60;
   dh[nb_per]=hh; dm[nb_per]=minute;
 
   hh=fin_sol/60; minute=fin_sol%60;
   fh[nb_per]=hh; fm[nb_per]=minute;

   nb_per++;
   if(nb_per>50) { printf(" trop de periode\n"); exit(0); }
}

/*_________________________________________________________________*/
void format_entree_masques_sol()
{
  printf("masques_sol\n\n");
  printf("             a comme param�tres : \n\n");

  printf("	IN	   fichier_in(.cir)\n");
  printf("	IN	   fichier_masque_in(.cir)\n");
  printf("	OUT	   fichier_out(.mas)\n");
  printf("	IN	   angle_vision\n");
  printf("	IN	   latitude\n");
  printf("	IN	   precision_minute\n");
  printf("	IN	   jour/mois\n");
  printf("	[IN]   [jour/mois]    // optionnel date a simuler\n");
  printf("	[IN]   [jour/mois]    // optionnel date a simuler\n");
  printf("	[IN]   ...            // optionnel date a simuler\n");
  printf("	[IN]   [epsiloneN]    // optionnel pour coplanerite: defaut 0.0001\n");
  printf("	[IN]   [facteurD]     // optionnel pour coplanerite; defaut  1000\n");
  
  exit(0);
}

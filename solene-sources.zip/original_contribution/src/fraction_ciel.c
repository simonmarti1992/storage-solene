/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/* fraction_ciel.c : FRACTION DE CIEL VUE PAR CHACUN DES CONTOURS	*/
/*______________________________________________________________________*/

//D. GROLEAU modifi� mars 2004 // modification appel � coplanaire
							   // defaut epsiloneN=0.0001 et defautD=1000
/*
cc fraction_ciel.c pers_util.o solutile.o geomutile.o face_op_face.o poly_op_poly.o traite.o lib_solene_94.o solaire.o -o fraction_ciel -lm
*/

//si recompile, v�rifier nb de param�tres de coplanaire (sens de la normale)


/* POUR UN FICHIER .cir, determine, pour une face et un contour donnes,	la portion de ciel */
/* vue depuis le centre de gravite de ce contour, en tenant compte des masques eventuels 
Evaluation avec et sans Masque eventuellement  */

// ne tient pas compte des faces situ�s dans le m�me plan que celui du contour en traitement

#include<solene.h>

// FONCTIONS
int test_si_patch_vu();
void usage_fraction_ciel();
void patch_gravite();     
double masque_ciel();
void ne_voit_rien();
void  traite_fraction_ciel();

// GLOBAL
struct modelisation_face *fac0 ;	/* geometrie a evaluer */
struct modelisation_face *fac1;		/* geometrie des masques */
struct modelisation_face *fac2;		/* geometrie du ciel */

FILE *pval,*pval1,*pval2;


extern int option_calcul_z;   	/* option CALCUL du Z ds FACE-OP-FACE 1=oui */
                              	/* utilise ds singul.c epure_polygone */
			      	/* et dans face_op_face.c             */
extern double coef_discol;



int im,nbre_patch_vu,sans_masque;
double vnf[3];   		/* normale a la face en traitement */
double tgvis,covis,sinvis;
double mini,maxi,*xg_patch,*yg_patch,*zg_patch,*angl_solid;
double *vnf2_x,*vnf2_y,*vnf2_z;

double epsiloneN;   	// pour appel coplanaire
int    defautD;			// pour appel coplanaire


/*_________________________________________________________________*/
main(argc,argv)           /* MASQUE  pour un FICHIER DE FACES */
int argc;char **argv;
	{
	int i,nbfac0,nbfac1,nbfac2,nb_contour;
	int nomax0,nofac,nbcont;
	double val_min,val_max;
 	double ang;

 	char nom_in[256],nom_masc[256],nom_ciel[256],nom_out[256],nom_angl_solid[256];
	char *s_dir,c;

 	FILE *pfic;
	double englob[10];

	/* initialisation */
   	singularite=0; non_singularite=0; nb_etat=0;
   	pb_masque=0; colle_max=coef_discol*DISCOL;
   	pi=4*atan(1.);
	
	// pour appel coplanaire
	epsiloneN=0.0001;
	defautD=1000;


	s_dir=(char *)getenv("PWD");

   	if(argc<8) usage_fraction_ciel();
    sscanf(argv[6],"%d",&sans_masque);
   	if(sans_masque && argc<10) usage_fraction_ciel();
 
/* lecture parametres commande */
	compose_nom_complet(nom_in,s_dir,argv[1],"cir");
    printf("\n  fichier a traiter : %s \n", nom_in);

    compose_nom_complet(nom_masc,s_dir,argv[2],"cir");  
    printf("  fichier masque : %s \n", nom_masc);

	compose_nom_complet(nom_ciel,s_dir,argv[3],"cir");
    printf("  discretisation du ciel : %s \n", nom_ciel);
	
	compose_nom_complet(nom_angl_solid,s_dir,argv[4],"val");  
    printf("  angles solides : %s \n", nom_angl_solid);

    sscanf(argv[5],"%lf",&ang);
			printf("angle_de_vision = %f \n",ang);

	if(ang<0 || ang>89.99 || ang<15) 
	  { 	
		printf("   *** 15 < angle_vision < 89.99 ***\n");
	    exit(0);
	  }
    ang=pi*ang/180.;
    tgvis=tan(ang); covis=cos(ang); sinvis=sin(ang);
		printf("tgvis = %f\n",tgvis);



/****LECTURE DES FICHIERS*** */
/** Lecture du fichier CIEL - indice 2 **/
	if ((pfic=fopen(nom_ciel,"r"))==NULL)
      { 
		printf("\n  impossible ouvrir %s\n\n", nom_ciel); 
		exit(0);
      }
    lit_en_tete(pfic,&nbfac2, &i, englob);
    fac2=alloue_face(nbfac2, 1000);
    lit_fic_cir3d(pfic, nbfac2, fac2);

    fclose(pfic);

	/* calcul centre gravite patch de ciel */
  	xg_patch=alloue_double(nbfac2,123);
  	yg_patch=alloue_double(nbfac2,124);
  	zg_patch=alloue_double(nbfac2,125);
  	patch_gravite(nbfac2);
    desalloue_fface(fac2,nbfac2);

/* Lecture des angles solides des elements de ciel - indice 2 */
	if ((pfic=fopen(nom_angl_solid,"r"))==NULL)
      { 
		printf("\n  impossible ouvrir %s\n\n", nom_angl_solid); 
		exit(0);
      }
	fscanf(pfic,"%d %d %lf %lf",&nbfac2,&i,&val_min,&val_max);
    angl_solid=alloue_double(nbfac2,126);
	for(i=0;i<nbfac2;i++)
	  {	fscanf(pfic,"\n%c%d%d\n%lf\n",&c,&nofac,&nbcont,angl_solid+i);
	  }

    fclose(pfic);

 /*** Lecture du fichier GEOM a traiter  ***/

    if ((pfic=fopen(nom_in,"r"))==NULL)
      { 
	    printf("\n impossible ouvrir %s\n\n", nom_in); 
	    exit(0);
      }

    lit_en_tete(pfic,&nbfac0, &nomax0, englob);

	/* alloue les faces  a traiter*/
   fac0=alloue_face(nbfac0,34);
   lit_fic_cir3d(pfic,nbfac0,fac0);
   fclose(pfic);

   nb_contour= nbcontours_total(fac0, nbfac0);

   printf("\n Traite %d faces,  soit %d contours\n",nbfac0,nb_contour);

/*** Lecture du fichier GEOM MASQUE - indice 1 */
    if ((pfic = fopen(nom_masc,"r"))==NULL)
      { 
	    printf("\n impossible ouvrir %s\n", nom_masc); 
	    exit(0);
      }
    lit_en_tete(pfic,&nbfac1, &i, englob);
    printf(" avec masque de %d faces\n\n", nbfac1);
    fac1=alloue_face(nbfac1, 34);
    lit_fic_cir3d(pfic, nbfac1, fac1);
    fclose(pfic);

	/* stocke les normales de fac1 */
	vnf2_x=alloue_double(nbfac1,127);
	vnf2_y=alloue_double(nbfac1,128);
	vnf2_z=alloue_double(nbfac1,129);

    for(i=0;i<nbfac1;i++)
      { 
		vnf2_x[i]=(fac1+i)->vnorm[0];
		vnf2_y[i]=(fac1+i)->vnorm[1];
		vnf2_z[i]=(fac1+i)->vnorm[2]; 
	  }


/*** Les fichiers RESULTATS ***/
        
	mini=0; maxi=100;
	compose_nom_complet(nom_out,s_dir,argv[7],"val");  
    printf("  fichier resultat 1 : %s \n\n", nom_out);
	if ((pval = fopen(nom_out,"w")) ==NULL)
      { 	
		printf("\n impossible ouvrir %s\n", nom_out); 
		exit(0);
       }
	fprintf (pval,"%5d %5d %10.2f %10.2f\n", nbfac0, nomax0, mini, maxi);   

    if(sans_masque)
     {
	   compose_nom_complet(nom_out,s_dir,argv[8],"val");  
       printf("  fichier resultat 2 : %s \n\n", nom_out);
	   if ((pval1 = fopen(nom_out,"w")) ==NULL)
         { 	
		   printf("\n impossible ouvrir %s\n", nom_out); 
		   exit(0);
         }
	    fprintf (pval1,"%5d %5d %10.2f %10.2f\n", nbfac0, nomax0, mini, maxi);   

	    compose_nom_complet(nom_out,s_dir,argv[9],"val");  
        printf("  fichier resultat 3 : %s \n\n", nom_out);
	    if ((pval2 = fopen(nom_out,"w")) ==NULL)
          { 	
		    printf("\n impossible ouvrir %s\n", nom_out); 
		    exit(0);
          }
	    fprintf (pval2,"%5d %5d %10.2f %10.2f\n", nbfac0, nomax0, mini, maxi);   

      }


/* observateur regarde vers le haut a verticale de oeil */
    obs.x=0; obs.y=0; obs.z=-1; 


/* TRAITEMENT POUR CHAQUE CONTOUR DE CHAQUE FACE de GEOM */

    printf("Traitement en cours ...\n");
    traite_fraction_ciel(nbfac0,nbfac1,nbfac2);

/* FIN du TRAITEMENT                                     */

    desalloue_fface(fac1,nbfac1);
	desalloue_fface(fac0,nbfac0);

	desalloue_double(xg_patch);
	desalloue_double(yg_patch);
	desalloue_double(zg_patch);
	desalloue_double(angl_solid);

    desalloue_double(vnf2_x);
    desalloue_double(vnf2_y);
    desalloue_double(vnf2_z);

    fclose(pval); 
	if(sans_masque)
	  {
		fclose(pval1); fclose(pval2);
	  }

	creer_OK_Solene();
	printf("\n\nFin de Fraction_ciel\n");
	exit(0);
}

/*_________________________________________________________________*/
void traite_fraction_ciel(nbfac0,nbfac1,nbfac2)
int nbfac0,nbfac1,nbfac2;
{
int i,nb_contour,noc;
struct contour *pcont;
struct circuit *pcir;
double valeur_calcul;


    for(i=0;i<nbfac0;i++)
      { 
	    //printf("Traitement de la face no %d\n",(fac0+i)->nofac_fichier);
        noc=0;

		vnf[0]=(fac0+i)->vnorm[0];
		vnf[1]=(fac0+i)->vnorm[1];
		vnf[2]=(fac0+i)->vnorm[2]; 

		nb_contour=nb_contour_face(fac0+i,1);
		fprintf(pval,"f%d %d\n",(fac0+i)->nofac_fichier,nb_contour); 
        if(sans_masque)
          {
		    fprintf(pval1,"f%d %d\n",(fac0+i)->nofac_fichier,nb_contour); 
		    fprintf(pval2,"f%d %d\n",(fac0+i)->nofac_fichier,nb_contour); 
		  } 
         pcont=(fac0+i)->debut_projete; 
         while(pcont)	   
            { pcir=pcont->debut_support;

		      centre_de_gravite(pcir, &obs.xo, &obs.yo, &obs.zo);
              noc++;
			  //printf("Contour %d\n",noc);
              //printf("  %lf %lf %lf\n",obs.xo,obs.yo,obs.zo); 
			  
			  /* traitement pr�liminaire des coplanerit�s pour traiter le cas
				 frequent o� 2 faces sont confondues en partie (2 pignons de b�timents par ex)
              */
			  /*
			  if(traite_coplanerite(obs.xo,obs.yo,obs.zo,fac0+i,fac1,nbfac1))
			     { 
					//l'observateur est masqu� totalement
					printf("CACHE\n");
			        ne_voit_rien(nbfac2);
		         }
		      else */
		         {
                    valeur_calcul=masque_ciel(nbfac1,nbfac2,(fac0+i));
					//printf("  nombre de patches de ciel vus %d\n",nbre_patch_vu); 
			        //printf("  pourcent ciel vu %.1f\n",valeur_calcul*100);
		         }
			  pcont=pcont->suc;
			} 
        }
}

/*_________________________________________________________________*/
double masque_ciel(nbfac1,nbfac2,fac0)
int nbfac1,nbfac2;
struct modelisation_face *fac0;
{
	int i,vu;
	double cos_ang_inc, xyz[3], ang_inc;
	double valeur_calcul,valeur_sans_masc;
	double v1;

	
  /* TRANSFORMATION fichier "masque" et COUPE PYRAMIDE , si vu */
   tranfo();
   for(i=0;i<nbfac1;i++)
	 { //if((fac1+i)->nofac_fichier !=noface)
	   	if(!(coplanaire(fac0,1,fac1+i,1,epsiloneN,0,defautD)))
          { if(visible_pers(fac1+i,1))
               { 
                 tran_face(fac1+i,1,fac1+i,0);
                 tran_normale((fac1+i)->vnorm);
                 if((fac1+i)->debut_dessin) 
                    { calcul_d_du_plan(fac1+i,0);
                      face_dans_vision(fac1+i,0);
                    }
               }
           }
      }

  /* PERSPECTIVE */
   init_fenetre_affichage();
   for(i=0;i<nbfac1;i++)
	  { if((fac1+i)->debut_dessin)
           { pers_conic_face(fac1+i,0);
           }
	  }

  /* reajuste la fenetre a angle de vision */
   fen_aff[0]=-tgvis; fen_aff[1]=-tgvis; 
   fen_aff[3]=tgvis; fen_aff[4]=tgvis; 
   cal_fen_aff();
          /* attention si angvis proche de 90 */
          /* on evite fen_aff[6]=0 */
   if(fen_aff[6]<0.008) fen_aff[6]=0.008;

   
   /* NORMALISATION */
   for(i=0;i<nbfac1;i++)
	  { if((fac1+i)->debut_dessin)
           { normalise_face(fac1+i,0);
           }
      }

/* ANALYSE DES PATCHES DE CIEL */
    valeur_sans_masc=0.0;
	valeur_calcul=0.0;
	nbre_patch_vu=0;
	for(i=0;i<nbfac2;i++)
      {  
		xyz[0]=xg_patch[i]; xyz[1]=yg_patch[i]; xyz[2]=zg_patch[i];
		cos_ang_inc=vincid(vnf,xyz,&ang_inc);
		if (cos_ang_inc>0)
		 {
       	   vu=test_si_patch_vu(nbfac1,xg_patch[i],yg_patch[i],zg_patch[i]);
		  //printf("patch_ciel=%d vu=%d angl_solid=%f\n",i,vu,angl_solid[i]);
       	   valeur_calcul+=vu*angl_solid[i]; 
		   nbre_patch_vu+=vu;

           /* sans tenir compte du masque */ 
		   valeur_sans_masc+=angl_solid[i];
		 }
		//printf("\n%d  %lf ",cos_ang_inc);
    		}
	valeur_calcul=valeur_calcul/(2*pi);
	valeur_sans_masc=valeur_sans_masc/(2*pi);

/* ECRITURE DU FICHIER .val */
	fprintf (pval,"      %10.2f\n", valeur_calcul*100);
    if(sans_masque)
       { fprintf (pval1,"      %10.2f\n", valeur_sans_masc*100);
		 if(valeur_sans_masc)
			{ v1 = 100*(valeur_sans_masc-valeur_calcul)/valeur_sans_masc;
			  if(v1 < 0) v1 = 0;
			  if(v1 > 100) v1 = 100;
			}
		  else v1=0;
		  fprintf (pval2,"      %10.2f\n", v1);
        }  
		

/* reinverse la normale et desallocation face->dessin */  
    for(i=0;i<nbfac1;i++)
	  { (fac1+i)->vnorm[0] = vnf2_x[i];
        (fac1+i)->vnorm[1] = vnf2_y[i];
		(fac1+i)->vnorm[2] = vnf2_z[i];
        if((fac1+i)->debut_dessin)
              { desalloue_chaine_contour((fac1+i)->debut_dessin);
                (fac1+i)->debut_dessin=NULL;
              }
      }
return(valeur_calcul);
}
/*-----------------------------------------------------------------------------*/
int test_si_patch_vu(nbfac1,xg,yg,zg)
int nbfac1;
double xg,yg,zg;
{
	int in,ij;
 	double xyz[3];
	double xp, yp, zp;

    tranp(xg,yg,zg,xyz,xyz+1,xyz+2);
/* coupe par pyramide : retient ou non le point */

    if(xyz[2]<0 && fabs(xyz[0]/xyz[2])<tgvis && fabs(xyz[1]/xyz[2])<tgvis) 
        { 
                /* met en pers */
                xp=-xyz[0]/xyz[2];
                yp=-xyz[1]/xyz[2];
                zp=0;
				//printf("xp,yp %f %f \n",xp,yp);

                normalise_point(xp,yp,zp,&xp,&yp,&zp);

                 /* test si dans masque */
               	in=0;
               	for(ij=0;ij<nbfac1;ij++)
                 	{  
			          if((fac1+ij)->debut_dessin)
                       	{ 
				            in=point_dans_face(xp,yp,fac1+ij,0);
                         	if(in) return(0);
                       	}
                 	}
                /*printf("xp= %lf yp= %lf in= %d\n",xp,yp,in);*/
		        return(1);
	   	}
 //	return(1); Pourquoi? c'est une erreur (voir masques_ciel)
 	return(0); // corrig� en 2004
}

/*-----------------------------------------------------------------------------*/
void ne_voit_rien(nbfac2)
int nbfac2;
{
int i;
double valeur_sans_masc, xyz[3],cos_ang_inc, ang_inc;
float v1;

 fprintf (pval,"      %10.2f\n", 0.0);

	/* ANALYSE DES PATCHES DE CIEL vus sans le masque*/
 if(sans_masque)
  { // evalue sans masque 
    valeur_sans_masc=0.0;
	for(i=0;i<nbfac2;i++)
      {  
		xyz[0]=xg_patch[i]; xyz[1]=yg_patch[i]; xyz[2]=zg_patch[i];
		cos_ang_inc=vincid(vnf,xyz,&ang_inc);
		if (cos_ang_inc>0)
		 {
           /* sans tenir compte du masque */ 
		   valeur_sans_masc+=angl_solid[i];
		 }
		//printf("\n%d  %lf ",cos_ang_inc);
       }
	valeur_sans_masc=valeur_sans_masc/(2*pi);

    /* ECRITURE DU FICHIER .val */
    fprintf (pval1,"      %10.2f\n", valeur_sans_masc*100);
	if(valeur_sans_masc)
		{ v1 = 100.0;
		}
	else v1=0.0;

    fprintf (pval2,"      %10.2f\n", v1);
  }
}
		
/*-----------------------------------------------------------------------------*/
void patch_gravite(nbfac2)
int nbfac2;
	{
	int i;
 	struct contour *pcont;
 	struct circuit *pcir;

    for(i=0;i<nbfac2;i++)
        { 
            pcont=(fac2+i)->debut_projete;
	        pcir=pcont->debut_support;
		    centre_de_gravite(pcir, xg_patch+i,yg_patch+i,zg_patch+i);
     	}
	}


/*_________________________________________________________________*/
/* Format de la fonction fraction_ciel */
void usage_fraction_ciel()
	{
  	printf(" *fraction_ciel*   geom_in(.cir)  geom_masque(.cir)  ciel(.cir)  angl_solid_ciel(.val)  angle_vision  calcul_aussi_sans_masque %%ciel_visible(.val) [%%ciel_visible_sans_masque %%reduction_du_aux_masques] \n\n");

 printf("\n la fonction a comme parametres en ENTREE :\n");
 printf("\t geometrie_in(.cir)\n"); 
 printf("\t geometrie_du_masque_in(.cir)\n"); 
 printf("\t ciel_in(.cir)\n"); 
 printf("\t angle_solide_ciel_in(.val)\n"); 
 printf("\t angle_de_vision <90\n"); 
 printf("\t calcul aussi sans masque (1 oui; 0 non)\n"); 
 
 printf("\n              comme parametres en SORTIE :\n");
 printf("\t descripteur : %%_ciel_visible\n\n"); 
 printf("               et si calcul sans masque\n"); 
 printf("\t descripteur : %%_ciel_visible_sans_masque\n"); 
 printf("\t descripteur : %%_reduction_ciel_visible_du_aux_masques\n\n"); 
	exit(0);
	}



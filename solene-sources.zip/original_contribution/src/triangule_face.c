/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */




/*

cc triangule_face.c   solutile.o geomutile.o  -o triangule_face lib_solene_94.o -lm

*/
/* POUR les FACES de .cir de la Geometrie */
/* triangule avec logiciel du Carnegie Mellon University "triangle" */
/* et produit un nouveau fichier de faces triangulees */

// attention cette version cr�e des points interm�daire sur les aretes

//#include<solene.h>


#include<solene.h>

// declaration de fonctions
void constitue_fic_triangule();
void constitue_fic_contour_triangule();
int ecrit_en_tete();
void format_entree();
float longueur_arete();
int nb_points_sur_arete();
int place_pt_int1();
int point_ds_poly();


struct modelisation_face *alloue_face();
double dmail, dist_maille; // dmail c'est la surface de la maille souhait�e
// et dist_maille est la longueur de l'arete du triangle equilat�ral de surface dmail
int nb_total_triangle;
FILE *pf1,*pf2;
char *s_dir;
float surf_du_contour;
/*___________________________________________________________________*/
main(argc,argv)       /* triangule_face : cree fichier .cir triagule */
int argc;char **argv;
{
 int j;
 double englob[10];
 char 	nom_in[512],nom_out[512];
 int nbff,noma;
 struct modelisation_face *fs;

   nb_etat=0;

   s_dir="";

   if(argc<4) format_entree();
 
 /* LIT LES ENTREES */

 	/* fichier .cir en entree */
            compose_nom_complet(nom_in,s_dir,argv[1],"cir");
            if((pf1=fopen(nom_in,"r"))==NULL) 
               { printf(" impossible ouvrir %s\n",nom_in);
   	             format_entree();
               }
	/* fichier .cir triangules en sortie */
            compose_nom_complet(nom_out,s_dir,argv[2],"cir");
            if((pf2=fopen(nom_out,"w"))==NULL) 
               { printf(" impossible ouvrir %s\n",nom_out);
   	             format_entree();
               }

   if((pf1=fopen(nom_in,"r"))==NULL)
       { printf("\n   le fichier %s n'existe pas\n",nom_in);
	 exit(0);
       }
   if((pf2=fopen(nom_out,"w"))==NULL)
       { printf("\n   impossible open de %s\n",nom_out);
	 exit(0);
       }

  /* lit fichier IN */
   lit_en_tete(pf1,&nbff,&noma,englob);
   printf("\n       nombre de faces du fichier = %d\n",nbff);
   fs=alloue_face(nbff,1000);
   lit_fic_cir3d(pf1,nbff,fs); 
   fclose(pf1);

   ecrit_en_tete(pf2,nbff,noma,englob);

     /* taille des triangles : dmail=  */
   sscanf(argv[3],"%lf",&dmail);
  printf("surf maille = %lf\n",dmail);


    // distance entre pts interm�diaire sur arete
   dist_maille = sqrt(dmail*2.3)/2;
  printf("dim maille = %lf\n",dist_maille);




  /* TRIANGULE toutes les faces de la geometrie */

     printf("Triangulation des faces en cours ...\n");

     nb_total_triangle=0;
            for(j=0;j<nbff;j++)
                { 
                     /*printf("Triangule face %d\n",(fs+j)->nofac_fichier);*/
                     constitue_fic_triangule(fs+j);
		     
                }
  
      
     printf("NB TOTAL DE TRIANGLES CREES: %d\n",nb_total_triangle);
     fclose(pf2);

        /* Desalloue faces */
   desalloue_fface(fs,nbff); 
   printf("\nFin triangule_face\n\n");

   creer_OK_Solene();
}



/*_________________________________________________________________*/
void constitue_fic_triangule(face)
struct modelisation_face *face;
{
  FILE *pftemp;
  struct contour *pcont;
  char  buf[128];
  int i,nb_cont_triangle;
  double x,y,z;
  struct circuit *pcir;


 /*  projection suivant normale a face  */
   obs.x=face->vnorm[0]; obs.y=face->vnorm[1]; obs.z=face->vnorm[2];
   obs.xo=0; obs.yo=0; obs.zo=0; 
   tranfo();  
   tran_face(face,1,face,0);
   tran_normale(face->vnorm);
   calcul_d_du_plan(face,0);

  /*   on travaille Contour par Contour                    */
  /*   on stocke temporairement les points ds Fichier xxxx */  
  /*-------------------------------------------------------*/

   if((pftemp=createFileTmpSolene("xxxxTS","w"))==NULL)
       { printf("\n   impossible open de %s\\xxxxTS\n",getenv(SOLENETEMP));
	 exit(0);
       }

  nb_cont_triangle=0;

  pcont=face->debut_dessin;
  while(pcont)
    { 
	  // evalue sa surface
	  //pcir=pcont->debut_support;
	  //surf_du_contour= fabs(surface(pcir->nbp,pcir->x,pcir->y));
	  //printf("surf contour = %f\n",surf_du_contour);
      constitue_fic_contour_triangule(face,pcont,pftemp,&nb_cont_triangle);
      pcont=pcont->suc; 
    }

   fclose(pftemp);

  /* relit les pts des contours triangules            */
  /* et  ecrit la face triangulee                            */
  /*-------------------------------------------------------*/

   if((pftemp=createFileTmpSolene("xxxxTS","r"))==NULL)
       { printf("\n   impossible open de %s\\xxxxTS\n",getenv(SOLENETEMP));
	 exit(0);
       }
   fprintf(pf2,"f%d %d\n",face->nofac_fichier,nb_cont_triangle);
   fprintf(pf2,"  %lf %lf %lf\n",obs.x,obs.y,obs.z);


  /* printf(" nb triangles crees %d\n",nb_cont_triangle);*/
   nb_total_triangle+=nb_cont_triangle;

   for(i=0;i<nb_cont_triangle;i++)
     {
	      fprintf(pf2," c0\n");
              fprintf(pf2,"  4\n"); /* lit et ecrit 4 points */

  	      fscanf(pftemp,"  %lf %lf %lf\n",&x,&y,&z);
  	       fprintf(pf2,"  %10.3lf %10.3lf %10.3lf\n",x,y,z);
  	      fscanf(pftemp,"  %lf %lf %lf\n",&x,&y,&z);
  	       fprintf(pf2,"  %10.3lf %10.3lf %10.3lf\n",x,y,z);
  	      fscanf(pftemp,"  %lf %lf %lf\n",&x,&y,&z);
  	       fprintf(pf2,"  %10.3lf %10.3lf %10.3lf\n",x,y,z);
  	      fscanf(pftemp,"  %lf %lf %lf\n",&x,&y,&z);
  	       fprintf(pf2,"  %10.3lf %10.3lf %10.3lf\n",x,y,z);
     }

   fclose(pftemp);
   sprintf(buf,"del %s\\xxxxTS\n",getenv(SOLENETEMP)); //SII modif DFA 18-04-2006
   system(buf);

} 

/*_________________________________________________________________*/

void   constitue_fic_contour_triangule(face,pcont,pftemp,nb_cont_triangle)
struct modelisation_face *face;
struct contour *pcont;
FILE *pftemp;
int *nb_cont_triangle;
{
  FILE *fp;
  FILE *fi,*fi2;
  struct circuit *pcir;
  char 	nom_in[512],nom_in1[512];
  char  buf[128];
  int  i,j,nb,nbp_t,trou,nop;
  int 	nb_pt,dimension,nb_attribut,nb_marker;
  double  attribut,marker;
  int	nb_triangle,nb_pt_triangle,nb_att;
  int 	no,no1,no2,no3;
  double *x,*y,*z,xi,yi,zi,zplan,xg,yg;

  /*   constitue fichier .poly 2D pour triangule */
  /*   pour le contour pcont                     */
  /*---------------------------------------------*/

/*printf(" traite un contour \n");*/

//   sprintf(buf,"face_%d",face->nofac_fichier);
//   compose_nom_complet(nom_in,s_dir,buf,"poly");
//   compose_nom_complet_sans_ext(nom_in1,s_dir,buf);
sprintf(nom_in,"%s\\face_%d.poly",getenv(SOLENETEMP), face->nofac_fichier);
sprintf(nom_in1,"%s\\face_%d",getenv(SOLENETEMP), face->nofac_fichier);
//sprintf(nom_in,"C:\\Solene\\face_%d.poly",face->nofac_fichier);
//sprintf(nom_in1,"C:\\Solene\\face_%d",face->nofac_fichier);

/*printf("cree   %s\n",nom_in);*/
/*printf("cree   %s\n",nom_in1);*/
   if((fp=fopen(nom_in,"w"))==NULL)
       { printf("\n   impossible open de %s\n",buf);
	 exit(0);
       }

 /* evalue le nb de points, nb de trous */
 /*_____________________________________*/

  nbp_t=0; trou=0;

      pcir=pcont->debut_support;
	  // calcule le nb de points � mettre sur chaque ar�te et cumule
	  for(i=0;i<pcir->nbp-1;i++)
	  { //nombre de points sur l'arete
		  nbp_t += nb_points_sur_arete(pcir,i,dist_maille);
	  }
//	  printf("nbp_total %d\n", nbp_t);

      pcir=pcont->debut_interieur;

		/* les trous */
      while(pcir)
         { 
		   // calcule le nb de points � mettre sur chaque ar�te et cumule
	       for(i=0;i<pcir->nbp-1;i++)
		   { //nombre de points sur l'arete
		     nbp_t += nb_points_sur_arete(pcir,i,dist_maille);
		   }
		  
	       trou++;
           pcir=pcir->suc;
         }
  fprintf(fp,"%d 2 0 0\n",nbp_t);

 /* ecrit les coordonnees avec les points interm�diaires*/
 /*_____________________________________________________*/

  nb=0;
      pcir=pcont->debut_support;
      zplan=pcir->z[0];
      for(i=0;i<pcir->nbp-1;i++) 
        { 
		  nb += place_pt_int1(pcir,i,dist_maille,fp,nb);
        }

      pcir=pcont->debut_interieur;
		/* les trous */
      while(pcir)
        { for(i=0;i<pcir->nbp-1;i++) 
			{ 
			  nb += place_pt_int1(pcir,i,dist_maille,fp,nb);
			}
          pcir=pcir->suc;
        }

 /* ecrit les segments  entre les points gener�s  */
 /*________________________________________________*/
  fprintf(fp,"%d 0\n",nbp_t);
  nb=0;
      pcir=pcont->debut_support;
      nop=nb+1;
	  	  // pour le circuit, calcule le nb de point sur chaque ar�te et cumule
	  nbp_t=0;
	  for(i=0;i<pcir->nbp-1;i++)
	  { //nombre de points sur l'arete
		  nbp_t += nb_points_sur_arete(pcir,i,dist_maille);
	  }
      for(i=0;i<nbp_t-1;i++) 
        { nb++;
          fprintf(fp," %d  %d %d\n",nb,nb,nb+1);
        }
      nb++;
      fprintf(fp," %d  %d %d\n",nb,nb,nop);

      pcir=pcont->debut_interieur;
		/* les trous */
      while(pcir)
        { nop=nb+1;
          	  	  // pour le circuit, calcule le nb de point sur chaque ar�te et cumule
	      nbp_t=0;
	      for(i=0;i<pcir->nbp-1;i++)
		  { //nombre de points sur l'arete
		    nbp_t += nb_points_sur_arete(pcir,i,dist_maille);
		  }
          for(i=0;i<nbp_t-1;i++) 
		  { nb++;
            fprintf(fp," %d  %d %d\n",nb,nb,nb+1);
		  }
          nb++;
          fprintf(fp," %d  %d %d\n",nb,nb,nop);

          pcir=pcir->suc;
        }

 /* ecrit les centres de gravites des trous */
 /*_________________________________________*/

   if(trou==0)
     {     fprintf(fp,"0\n\n\n");
     }
   else
     {  fprintf(fp,"%d\n",trou);
        nb=0;
 
           pcir=pcont->debut_interieur;
		/* les trous */
           while(pcir)
            { nb++; xg=yg=0;
	      for(i=0;i<pcir->nbp-1;i++) 
               { xg+=pcir->x[i]; yg+=pcir->y[i];
               }
  	      xg=xg/(pcir->nbp-1); yg=yg/(pcir->nbp-1);
	      point_ds_poly(&xg,&yg,pcir);
 	      fprintf(fp," %d  %12.3f %12.3f  \n",nb,xg,yg);
              pcir=pcir->suc;
            }
     }


  fclose(fp);


  /// ON ARRETE ICI POUR VOIR

  //exit(0);

 /* lance la triangulation pour ce contour de face      */
 /*-----------------------------------------------------*/
  printf("avant carnegie\n");

  // ATTENTION : choix des param�tres de triangulation
  // modele de triangulation respecte le d�coupge des aretes mitoyennes
 sprintf(buf,"triangle_carnegie -pBPQIa%f %s",dmail,nom_in1);
  // modif DG le 30/10/2007
  // sprintf(buf,"triangle_carnegie -pq30BPYQIa%f %s",dmail,nom_in1);

  printf("execute %s\n",buf);
  system(buf);
  printf("fin triangule carnegie\n");
  sprintf(buf,"del %s\n",nom_in);
  system(buf);


 /* recupere la face triangulee                 */
 /*---------------------------------------------*/


	/* fichier .node des points */
       //sprintf(buf,"face_%d",face->nofac_fichier);
       //compose_nom_complet(nom_in,s_dir,buf,"node");

  sprintf(nom_in,"%s\\face_%d.node",getenv(SOLENETEMP), face->nofac_fichier); //SII Modif DFA 18-04-2006
  //sprintf(nom_in,"C:\\Solene\\face_%d.node",face->nofac_fichier);

            /*printf("OUVRE %s\n",nom_in);*/
            if((fi=fopen(nom_in,"r"))==NULL) 
               { printf(" impossible ouvrir %s\n",nom_in);
   	         format_entree();
               }

	/* lecture des points dans .node */

	   fscanf(fi,"%d %d %d %d",&nb_pt,&dimension,&nb_attribut,&nb_marker);
           /*printf("nbp %d\n",nb_pt);*/
	   x=(double *)malloc(nb_pt*sizeof(*x));
	   if(x==NULL) { printf("PB allocation cmu_solene\n"); exit(0);}
	   y=(double *)malloc(nb_pt*sizeof(*y));
	   if(y==NULL) { printf("PB allocation cmu_solene\n"); exit(0);}
	   z=(double *)malloc(nb_pt*sizeof(*z));
	   if(z==NULL) { printf("PB allocation cmu_solene\n"); exit(0);}

	   for(i=0;i<nb_pt;i++)
		{ fscanf(fi,"%d %lf %lf",&no,x+i,y+i);
			/* transfo inverse */
		  z[i]=0;
		  tranp_inverse(x[i],y[i],zplan,&xi,&yi,&zi);
                  /*printf("%f %f %f\n",xi,yi,zi);*/
		  x[i]=xi; y[i]=yi; z[i]=zi;

		  for(j=0;j<nb_attribut;j++)
			{ fscanf(fi,"%lf",&attribut);
			}
		  for(j=0;j<nb_marker;j++)
			{ fscanf(fi,"%lf",&marker);
			}
		}

           fclose(fi);
           sprintf(buf,"del %s\n",nom_in);
           system(buf);

	/* fichier .ele des elements triangles */

            //sprintf(buf,"face_%d",face->nofac_fichier);
            //compose_nom_complet(nom_in,s_dir,buf,"ele");

     sprintf(nom_in,"%s\\face_%d.ele",getenv(SOLENETEMP), face->nofac_fichier); //SII Modif DFA 18-04-2006
   //  sprintf(nom_in,"C:\\Solene\\face_%d.ele",face->nofac_fichier);

 	    /*printf("OUVRE %s\n",nom_in);*/
            if((fi2=fopen(nom_in,"r"))==NULL) 
               { printf(" impossible ouvrir %s\n",nom_in);
   	         format_entree();
               }

        /* lecture des elements triangules et       */
        /*  stocke temporairement dans xxxxTS (ftemp) */

           fscanf(fi2,"%d %d %d",&nb_triangle,&nb_pt_triangle,&nb_att);
 
           *nb_cont_triangle+=nb_triangle; /* cumul le nb de triangles pour face */

           for(i=0;i<nb_triangle;i++)
	    { fscanf(fi2,"%d %d %d %d",&no,&no1,&no2,&no3);
              /*printf("%d %d %d\n",no1,no2,no3);*/
	      no1--; no2--; no3--; 
	      for(j=0;j<nb_att;j++)
	        { fscanf(fi2,"%lf",&attribut);
	        }

  	      fprintf(pftemp,"  %10.3lf %10.3lf %10.3lf\n",x[no1],y[no1],z[no1]);
  	      fprintf(pftemp,"  %10.3lf %10.3lf %10.3lf\n",x[no2],y[no2],z[no2]);
  	      fprintf(pftemp,"  %10.3lf %10.3lf %10.3lf\n",x[no3],y[no3],z[no3]);
  	      fprintf(pftemp,"  %10.3lf %10.3lf %10.3lf\n",x[no1],y[no1],z[no1]);
            }


        fclose(fi2);
	free(x); free(y); free(z);
        sprintf(buf,"del %s\n",nom_in);
        system(buf);
}

/*_______________________*/
int point_ds_poly(xg,yg,pcir)
double *xg,*yg;
struct circuit *pcir;
{ 		/* UTILISE AUSSI DS RICARDO_ARC_INFO */
 int isur,idedan,nb;
 double xs,ys,dx,dy,fac;

  	  xs=*xg; ys=*yg;
inpoly(&idedan,&isur,xs,ys,pcir);
  if(idedan)
   { /*printf("dedans\n"); */ return(1);
   }
  
  nb=0;
  fenetre_circuit(pcir);
  fac=10;

  while(1 && nb<100)
   {
	  dx=(pcir->fen[3]-pcir->fen[0]);

	  xs=*xg; ys=*yg;
	  while(xs < pcir->fen[3])
	   { xs=xs+dx/fac; 
	     inpoly(&idedan,&isur,xs,ys,pcir);
	     if(idedan) { *xg=xs; return(1); }
	   }
	  xs=*xg; ys=*yg;
	  while(xs > pcir->fen[0])
	   { xs=xs-dx/fac; 
	     inpoly(&idedan,&isur,xs,ys,pcir);
	     if(idedan) { *xg=xs; return(1); }
	   }

	 dy=(pcir->fen[4]-pcir->fen[1]);

	 xs=*xg; ys=*yg;
	 while(ys < pcir->fen[4])
	   { ys=ys+dy/fac; 
	     inpoly(&idedan,&isur,xs,ys,pcir);
	     if(idedan) { *yg=ys; return(1); }
	   }
	 xs=*xg; ys=*yg;
	 while(ys > pcir->fen[1])
	   { ys=ys-dy/fac; 
	     inpoly(&idedan,&isur,xs,ys,pcir);
	     if(idedan) { *yg=ys; return(1); }
	   }

         fac=fac*2; nb++;
   }
 printf(" pas trouver pt interieur pour trou \n");
}

/*_________________________________________________________________*/
int nb_points_sur_arete(pcir,k,dim_maille)
struct circuit *pcir;
int k; // indice de l'arete
double dim_maille;
{
 int nb;
 double ddd;

 //printf("dim_maille %f\n",dim_maille);

	ddd=longueur_arete(pcir->x[k],pcir->y[k],pcir->z[k],pcir->x[k+1],pcir->y[k+1],pcir->z[k+1]);
    nb= ddd/dim_maille;

	// on exclut le point fin de l'ar�te
      
  if(nb==0) nb=1;
  //printf("arete long  = %f\n",ddd);
  //printf("nbpt = %d\n",nb);
  
  return(nb);
}

/*________________________________________________________________________*/
float longueur_arete(x1,y1,z1,x2,y2,z2)
double x1,y1,z1,x2,y2,z2;
{
 float longueur;
 longueur=(sqrt((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1)+(z2-z1)*(z2-z1)));
/*printf("longueur arete %f\n",longueur);*/
 return(longueur);
 
}

/*________________________________________________________________________*/
int place_pt_int1(pcir,k,dim_maille,fp,idemarre)
struct circuit *pcir;
int k; // indice de l'arete
double dim_maille;
FILE *fp;

{

 int nb,i,indice;
 double ddd,dx,dy,xp,yp;
//printf("dim_maille %f\n",dim_maille);
 
	ddd=longueur_arete(pcir->x[k],pcir->y[k],pcir->z[k],pcir->x[k+1],pcir->y[k+1],pcir->z[k+1]);
    nb= ddd/dim_maille;
	if (nb==0) nb=1;
  //printf("arete long  = %f\n",ddd);
  //printf("nbpt = %d\n",nb);

	// on exclut le point fin de l'ar�te
      
  dx= (pcir->x[k+1]-pcir->x[k])/(nb);
  dy= (pcir->y[k+1]-pcir->y[k])/(nb);
  //printf("dx dy %f %f\n", dx, dy);

  //place pt k et pts intermediares sauf k+1;
  indice = idemarre;
  for(i=0; i<nb; i++)
   {
	xp = pcir->x[k] + i*dx;
	yp = pcir->y[k] + i*dy;
    fprintf(fp," %d  %f %f  \n",indice+1,xp,yp);
    //printf(" %d  %f %f  \n",indice+1,xp,yp);


	indice = indice + 1;
   }
  return(nb);

}

/*_________________________________________________________________*/
/* Format de la fonction TRIANGULE_FACE */
void format_entree()
{
  printf("\n   *triangule_face*  fichier_in(.cir) fichier_out(.cir) surf_maille \n\n");
  exit(0);
}

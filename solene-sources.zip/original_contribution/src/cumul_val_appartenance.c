/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */
 
/* 
cumul_val_appartenance

	 solutile.o geomutile.o lib_solene_94.o 
*/

// D. GROLEAU mars 2003

// Cumule les valeurs de fichier_in1.val 
//       suivant les valeurs d'appartenance de fichier_in2.val
//    et suivant la structure de fichier_in3.val
//  dans le fichier out.val

/*
Exemple
 cumul la surface des batiments (in1)
  suivant appartenance (in2 de meme structure que in1)
  dans les parcelles (out , de structure in3)
*/

//____________________________________________________________

#include <solene.h>



// FUNCTIONS

void calcul_cumul();
void format_entree();
int test_si_nom_existe();
void transmet_cumul();

/*declaration application */

FILE *fpval1,*fpval2,*fpval3;


double	*val_cumul;
int		*nb_cumul;
double min,max;

/************************************************/
main(argc,argv)
int argc;char **argv;
{
 char buf[512],*s_dir;


  if(argc!=6){ format_entree(); exit(0);}


	s_dir=(char *)getenv("PWD");

printf("Fonction SOLENE:  cumul_val_appartenance\n\n");

 compose_nom_complet(buf,s_dir,argv[1],"val");
  if((fpval1=fopen(buf,"r"))==NULL)
	{ printf("impossible ouvrir %s\n",buf);
	  exit(0);
	}

 compose_nom_complet(buf,s_dir,argv[2],"val");
  if((fpval2=fopen(buf,"r"))==NULL)
	{ printf("impossible ouvrir %s\n",buf);
	  exit(0);
	}

 compose_nom_complet(buf,s_dir,argv[3],"val");
 if(!(test_si_nom_existe(buf)))
	{ printf("impossible ouvrir %s\n",buf);
	  exit(0);
	}
	

/* TRAITE LE CUMUL */
/* lit les appartenances et cumul les valeurs */

	calcul_cumul();
	fclose(fpval1);
	fclose(fpval2);
	
/* AFFECTE LE CUMUL */

  compose_nom_complet(buf,s_dir,argv[3],"val");
  if((fpval1=fopen(buf,"r"))==NULL)
	{ printf("impossible ouvrir %s\n",buf);
	  exit(0);
	}
  compose_nom_complet(buf,s_dir,argv[4],"val");
  if((fpval2=fopen(buf,"w"))==NULL)
	{ printf("impossible ouvrir %s\n",buf);
	  exit(0);
	}
  compose_nom_complet(buf,s_dir,argv[5],"val");
  if((fpval3=fopen(buf,"w"))==NULL)
	{ printf("impossible ouvrir %s\n",buf);
	  exit(0);
	}

  transmet_cumul();
 
  fclose(fpval1);
  fclose(fpval2);
  fclose(fpval3);

printf("Fin cumul_val_appartenance\n\n");

creer_OK_Solene();

}

/*------------------------------------------------------------*/
void calcul_cumul()
{
 int 	i,j,nbfac1,nomax1,nofac,nbcontour;
 int    nbfac2,nomax2,no_app,no_app_min,no_app_max;
 double valor,valeur1,valeur2,valeur_min2,valeur_max2,appartenance;
 char c;

   fscanf(fpval1,"%d %d %lf %lf",&nbfac1,&nomax1,&valeur1,&valeur2);
   fscanf(fpval2,"%d %d %lf %lf",&nbfac2,&nomax2,&valeur_min2,&valeur_max2);

   no_app_min = (int) valeur_min2;
   no_app_max = (int) valeur_max2;
   val_cumul=alloue_double(no_app_max+1,1111);
   nb_cumul=alloue_int(no_app_max+1,22222);
 
/*printf("OK %d\n",no_app_max);*/


   if(val_cumul==NULL) { printf (" PB de Memoire allocation \n"); exit(0); }
   if(nb_cumul==NULL) { printf (" PB de Memoire allocation \n"); exit(0); }

   for(i=no_app_min;i<=no_app_max;i++) { val_cumul[i]=0; nb_cumul[i]=0;}


   min=9999999.; max=-min;
	for(i=0;i<nbfac1;i++)
	 { 
	   fscanf(fpval1,"\n%c %d %d ",&c,&nofac,&nbcontour); 
	   fscanf(fpval2,"\n%c %d %d ",&c,&nofac,&nbcontour); 

	   for(j=0;j<nbcontour;j++)
             {  fscanf(fpval1,"%lf",&valor);
				fscanf(fpval2,"%lf",&appartenance);
                no_app= (int) appartenance;
                val_cumul[no_app]+=valor;
                nb_cumul[no_app]++;
             }

         }
}

/*------------------------------------------------------------*/
void transmet_cumul()
{
 int 	i,j,nbcontour,nbfac,nomax,nofac;
 double  valor;
 char c;

   fscanf(fpval1,"%d %d %lf %lf",&nbfac,&nomax,&valor,&valor);
   fprintf(fpval2,"%7d %7d %15.3f %15.3f\n",nbfac,nomax,min,max);
   fprintf(fpval3,"%7d %7d %15.3f %15.3f\n",nbfac,nomax,min,max);

	for(i=0;i<nbfac;i++)
	 { 
	   fscanf(fpval1,"\n%c %d %d ",&c,&nofac,&nbcontour); 
	   fprintf(fpval2,"f%d %d\n",nofac,nbcontour);
	   fprintf(fpval3,"f%d %d\n",nofac,nbcontour);


	   for(j=0;j<nbcontour;j++) 
             { fscanf(fpval1,"%lf",&valor);
                             
               fprintf(fpval2,"%15.6f\n",val_cumul[nofac]);
               fprintf(fpval3,"%d\n",nb_cumul[nofac]);
             }
         }
}

/*------------------------------------------------------------*/
void format_entree()
{
  printf("\n   *cumul_val_appartenance*  fichier_in1(.val) fichier_in2(.val) fichier_in3(.val) cumul_val_out(.val) cumul_nb_out(.val) \n\n");
  printf("\n Cumule les valeurs de fichier_in1.val \n");
  printf(" suivant les valeurs d'appartenance de fichier_in2.val\n");
  printf(" et suivant la structure de fichier_in3.val,\n");
  printf(" dans le fichier fichier_val_out.val\n");
  printf(" Cumul_nb_out(.val) contient le nb d'�l�ments cumul�s par appartenance\n\n");

}

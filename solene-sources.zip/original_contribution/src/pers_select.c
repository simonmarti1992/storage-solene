/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/*

cc  pers_select.c -o pers_select pers_util.o  solutile.o geomutile.o face_op_face.o poly_op_poly.o lib_solene_94.o traite.o -lm 


*/

/*  PERS.C mise en perspective d'un fichier .cir solene */
/* les faces traitees sont celles contenues dans le fichier select */

#include<solene.h>
#include<ctype.h>

FILE *fp, *hfp;
extern int option_calcul_z; /* option CALCUL du Z ds FACE-OP-FACE 1=oui */
extern int z_axono_pers;
struct modelisation_face *alloue_face();

/*____________________________________________________________________*/
/* declarations heliodon()  et axono()  et pers() */
char nom_out[50];
struct modelisation_face *fac1,*fac2;
int nbfac1,nbfac2,numax;
char buf[256];
/*____________________________________________________________________*/
/* declaration pers() */
double ang,angvis,pi,tgvis,covis,sinvis;

/*_________________________________________________________________*/
main(argc,argv)                         /* PERSPECTIVE */
 int argc;char **argv;
{int i;
 char c[2],*s_dir;
 double xv,yv,zv;
         
         nb_etat=0;
         pi=4*atan(1.0);

         fac1=NULL;
         fac2=NULL;

         if(argc!=11)format_entree_pers();

         s_dir=(char *)getenv("PWD");
  
	/* fichier de selection */
         compose_nom_complet(buf,s_dir,argv[1],"cir");
         if((fp=fopen(buf,"r"))==NULL)
            { printf("\n impossible ouvrir %s\n",buf); exit(0);
            }
         printf("fichier a traiter %s\n",buf);

 	/* fichier global */
         compose_nom_complet(buf,s_dir,argv[2],"cir");
         if((hfp=fopen(buf,"r"))==NULL)
            { printf("\n impossible ouvrir %s\n",buf); exit(0);
            }
         printf("fichier a traiter %s\n",buf);

  	 sscanf(argv[3],"%lf",&(obs.xo));
         sscanf(argv[4],"%lf",&(obs.yo));
         sscanf(argv[5],"%lf",&(obs.zo));
  	 sscanf(argv[6],"%lf",&xv);
         sscanf(argv[7],"%lf",&yv);
         sscanf(argv[8],"%lf",&zv);
         sscanf(argv[9],"%lf",&ang);
             /* vecteur de vue */
         obs.x=obs.xo-xv; obs.y=obs.yo-yv; obs.z=obs.zo-zv;

         compose_nom_complet(nom_out,s_dir,argv[10],"cir");
 
         printf("\n CALCUL D'UNE VUE PERSPECTIVE \n");
         printf("fichier a traiter %s\n",buf);
         printf("oeil %lf %lf %lf\n",obs.xo,obs.yo,obs.zo);
         printf("vise %lf %lf %lf\n",xv,yv,zv);
         printf("vect %lf %lf %lf\n",obs.x,obs.y,obs.z);
         printf("nom du fichier de sortie %s\n",nom_out);
         angvis=pi*ang/180.;
         tgvis=tan(angvis); covis=cos(angvis); sinvis=sin(angvis);

	 tranfo();  /* rotation pour amener axe de visee en Oz ; */
	 traite_perspective();


creer_OK_Solene();

/* liste_des_pointeurs();*/

}

/*_________________________________________________________________*/
int format_entree_pers()
{
  printf("\n   *pers_select* fichier_select(.cir) fichier_in(.cir) xo yo zo xv yv zv angle_vision fichier_out(.cir) \n");
  exit(0);
}

/*_________________________________________________________________*/
int traite_perspective()
{ FILE *fcop;
  int i,nbf,nomax;
  double englob[10],englob1[10];

  /* initialise fenetre affichage */
       init_fenetre_affichage();

  /* lecture des fichiers */
        lit_fichier_entree(fp,&fac1,&nbfac1,&numax,englob);
        lit_fichier_entree(hfp,&fac2,&nbfac2,&numax,englob1);


  /* traite les faces : visibilite,tranfo,decoupe pyramide,perspective */

       traite_vis_decoupe(fac1,nbfac1);
       traite_vis_decoupe(fac2,nbfac2);


  /* TRAITEMENT */

          /* initialise fenetre affichage */
          init_fenetre_affichage();

       traitement_pers(fac1,nbfac1);
       traitement_pers(fac2,nbfac2);

 
          /* reajuste la fenetre a angle de vision */
           fen_aff[0]=-tgvis; fen_aff[1]=-tgvis; 
           fen_aff[3]=tgvis; fen_aff[4]=tgvis; 
           cal_fen_aff();
                    /* attention si angvis proche de 90 */
                    /* on evite fen_aff[6]=0 */
           if(fen_aff[6]<0.008) fen_aff[6]=0.008;

                /* normalise */
            z_axono_pers=1;
            option_calcul_z=0;

	normalise_et_sens(fac1,nbfac1);
	normalise_et_sens(fac2,nbfac2);


                /* traite vu/cache ; resultat dans ->dessin */
printf("TRAITE VU CACHE \n");

            traite_moins_hel(fac1,nbfac1,fac2,nbfac2);

/*printf("\n liste de FAC1\n");
            liste_les_faces_dessin(fac1,nbfac1);
*/
            z_axono_pers=0;
            option_calcul_z=1;
                /* pers inverse et denormalise  */
      for(i=0;i<nbfac1;i++) 
               { denormalise_face(fac1+i,0);
                 pers_face_inverse(fac1+i,0);
               }


  /* et transfo inverse */
   for(i=0;i<nbfac1;i++) 
             { tran_face_inverse(fac1+i,0);
               tran_normale_inverse(fac1[i].vnorm);
             }

  /* stockage des resultats dans fichier_out */
      fcop=fopen(nom_out,"w");
      nbf=0;   nomax=0;
      ecrit_en_tete(fcop,nbf,nomax,englob);
      output_face_sur_fichier(fac1,nbfac1,0,0,fcop,&nbf,&nomax);
      rewind(fcop);
      ecrit_en_tete(fcop,nbf,nomax,englob);
      fclose(fcop); 

      desalloue_fface(fac1,nbfac1);
      desalloue_fface(fac2,nbfac2);
      printf("\n");
}

/*_________________________________________________________________*/
int lit_fichier_entree(hp,fac,nbfac,num,eng)
FILE *hp;
struct modelisation_face **fac;
int *nbfac,*num;
double *eng;
{int i;
       
       lit_en_tete(hp,nbfac,num,eng);
       *fac=alloue_face(*nbfac,34);
       lit_fic_cir3d(hp,*nbfac,*fac);
       fclose(hp);
       printf(" NB FACES = %d\n",*nbfac);
}

/*_________________________________________________________________*/
int  traite_vis_decoupe(fac,nbfac)
struct modelisation_face *fac;
int nbfac;
{int i,vu;

  printf(" traite_vis_decoupe nbfac = %d \n",nbfac);
       for(i=0;i<nbfac;i++)
          { /* printf(" i = %d \n",i);
               printf("Face no  %d\n",(fac+i)->nofac_fichier);
	    */

            if((fac+i)->debut_projete)
               { 
                  /* visibilite et transformation des faces */
                  vu=visible_pers(fac+i,1); /* test si face vue */

                 if(vu)
                    { tran_face(fac+i,1,fac+i,0);
                      tran_normale(fac[i].vnorm);
                    }
                 /* decoupage des faces avec la pyramide de vision */
                 if((fac+i)->debut_dessin) 
                    { calcul_d_du_plan(fac+i,0);
                      face_dans_vision(fac+i,0);
                    }
               }
          }
}

/*_________________________________________________________________*/
int traitement_pers(fac,nbfac)
struct modelisation_face *fac;
int nbfac;
{int i;   
printf(" traitement_pers \n");
     /* mise en perspective */
           for(i=0;i<nbfac;i++)
	      { if((fac+i)->debut_dessin)
                   { pers_conic_face(fac+i,0);
                   }
	      }
}
/*_________________________________________________________________*/
int normalise_et_sens(fac,nbfac)
struct modelisation_face *fac;
int nbfac;
{int i; 
  printf(" normalise_et_sens \n");
            for(i=0;i<nbfac;i++)
	      { if((fac+i)->debut_dessin)
                   { normalise_face(fac+i,0);
            /* A FAIRE test sup_surf et sens face */
                     sens_face(fac+i,0,1);
                   }
	        copie_face_projete(fac+i,0,fac+i,1);
	      }
}
/*_________________________________________________________________*/
/*_________________________________________________________________*/

int liste_les_faces_dessin(fac,nbfac)
struct modelisation_face *fac;
int nbfac;
{int i;
     for(i=0;i<nbfac;i++)
           {  printf(" i = %d \n",i);
	      printf("Face no  %d\n",(fac+i)->nofac_fichier);
	      if((fac1+i)->debut_dessin==NULL)printf(" face dessin vide\n");
              if((fac1+i)->debut_dessin)liste_face(fac,0);
	   }
}

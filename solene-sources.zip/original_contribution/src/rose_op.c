/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/* 
rose_op
*/


// D. GROLEAU juillet 2003

/*********************************************************/
/* effectue op�ration de moyenne sur la rose directionnelle sur les contours d'une face d'un fichier .ros
	et attribue la rose moyenne � l'ensemble des contours de la face
	et imprime la rose moyenne de l'ensemble de la g�om�trie
*/
/*********************************************************/

#include<solene.h>

// DECLARE FUNCTIONS

void format_entree();
void lit_fic_rose();
void moyenne_rose();
void traite_direction();

/*----------------------------------------------------------------------*/
main(argc,argv)
int argc;char **argv;
{
 char	nom_fic[256], *s_dir; 

 FILE *prose_in,*prose_out;
 int nbfc,nb_dir,nb_val;
 int direction;


 if(argc!=3 && argc!=5){format_entree(); exit(0);}
 s_dir=(char *)getenv("PWD");

 
 printf("Fonction Solene: rose_op\n\n");

 
//_________________________________________________

 /* Open le fichier rose INPUT */
  compose_nom_complet(nom_fic,s_dir,argv[1],"ros");
  if((prose_in=fopen(nom_fic,"r"))==NULL)
    { printf("\nimpossible ouvrir %s\n",nom_fic);
	  exit(0);
	}
  printf("\nfichier  rose INPUT: %s\n",nom_fic);
  //
  fscanf(prose_in,"%d %d %d\n",&nbfc,&nb_dir,&nb_val);

 /* Open le fichier rose OUTPUT */
  compose_nom_complet(nom_fic,s_dir,argv[2],"ros");
  if((prose_out=fopen(nom_fic,"w"))==NULL)
    { printf("\nimpossible ouvrir %s\n",nom_fic);
	  exit(0);
	}
  printf("\nfichier  rose OUTPUT: %s\n",nom_fic);
  //
  fprintf(prose_out,"%d %d %d\n",nbfc,nb_dir,nb_val);



 // TRAITEMENT MOYENNE
  printf("\n      execution en cours ....\n");

// moyenne par face des roses des contours de la face
   moyenne_rose(prose_in,prose_out,nbfc,nb_dir,nb_val);
   fclose(prose_out);

// AJOUTE TRAITEMENT DIRECTION

   if(argc==5)
   { 

     sscanf(argv[3],"%d",&direction);
	/* Open le fichier val OUTPUT */
	compose_nom_complet(nom_fic,s_dir,argv[4],"val");
	if((prose_out=fopen(nom_fic,"w"))==NULL)
    { printf("\nimpossible ouvrir %s\n",nom_fic);
	  exit(0);
	}
	printf("\nfichier  descripteur (direction %d): %s\n",direction,nom_fic);
	//
	fprintf(prose_out,"%d %d  0 90\n",nbfc,nbfc);

	rewind(prose_in);
	fscanf(prose_in,"%d %d %d\n",&nbfc,&nb_dir,&nb_val);


	traite_direction(prose_in,prose_out,nbfc,nb_dir,nb_val,direction);
    fclose(prose_out);

   }

 fclose(prose_in);

 // TEST : lecture du fichier .ros
 /*
 printf("\n test lecture rose\n");
  compose_nom_complet(nom_fic,s_dir,argv[1],"ros");
  if((prose_in=fopen(nom_fic,"r"))==NULL)
    { printf("\nimpossible ouvrir %s\n",nom_fic);
	  exit(0);
	}
 lit_fic_rose(prose_in);
 */
 //

printf("Fin rose_op\n\n");

creer_OK_Solene();

}

/*____________________________________________________________________*/
void moyenne_rose(prose_in, prose_out,nbf,nb_dir,nb_val)
FILE *prose_in,*prose_out;
int nbf,nb_dir,nb_val;
{
	// moyenne sans pond�ration par la surface
  int angle;
  float val1m[36],val1m_geo[36];
//  float val2m[36],val3m[36];
  float val1;
//  float val2,val3;
  char c;
  int nofac,nbcont,noc,nbcont_geo;
  int i,j,k;
  float ang_delta;


  	ang_delta= (float) (360/nb_dir);
	nbcont_geo=0;

 // initialise la rose moyenne de la geometrie
	 for(j=0;j<nb_dir;j++)
	 { val1m_geo[j]=0; 
	   //val2m[j]=0;
	   //val3m[j]=0;
	 }

  for(i=0;i<nbf;i++)
  { // traite face i
	 fscanf(prose_in,"\n%c%d%d\n",&c,&nofac,&nbcont);
	 fprintf(prose_out,"f%d %d\n",nofac,nbcont);
	 nbcont_geo+=nbcont;

    // traite les contours

	// initialise la rose moyenne de la face
	 for(j=0;j<nb_dir;j++)
	 { val1m[j]=0; 
	   //val2m[j]=0;
	   //val3m[j]=0;
	 }
	 // moyenne
	 for(j=0;j<nbcont;j++)	
		{
		 fscanf(prose_in,"%d\n",&noc);
		 //printf(" contour %d \n ", noc);

		  for(k=0;k< nb_dir;k++)
			{ 
			  if(nb_val ==1)
				{	fscanf(prose_in,"%d %f\n",&angle,&val1);
					//printf(" %d  %f \n ", angle,val1);
					val1m[k]+=val1;
					val1m_geo[k]+=val1;
				}
			  else if (nb_val ==2)
				{	;
				}
			  else if (nb_val ==3)
				{	;
				}
			}
		 }
	 // calcul la rose moyenne val1m/nbcont et affecte � tous les contours de la face
	 for(j=0;j<nbcont;j++)	
		{ 
			fprintf(prose_out,"%d\n",j+1);
			for(k=0;k< nb_dir;k++)
			{ 
			  if(nb_val ==1)
				{	fprintf(prose_out,"%d %f\n",(int) (ang_delta*k),val1m[k]/nbcont);
				}
			  else if (nb_val ==2)
				{	;
				}
			  else if (nb_val ==3)
				{	;
				}
			}
		}
  }

  // imprime la rose moyenne pour toute la g�om�trie
  printf("ROSE MOYENNE DE LA GEOMETRIE\n");
		for(k=0;k< nb_dir;k++)
			{ 
				printf("%3d %8.4f\n",(int)(ang_delta*k),val1m_geo[k]/nbcont_geo);
			}
}/*____________________________________________________________________*/
void traite_direction(prose_in, prose_out,nbf,nb_dir,nb_val,direction)
FILE *prose_in,*prose_out;
int nbf,nb_dir,nb_val;
int direction;
{
	// ne retient que la valeur pour la direction choisie
  int angle;
  float val1;
  char c;
  int nofac,nbcont,noc;
  int i,j,k;

  for(i=0;i<nbf;i++)
  { // traite face i
	 fscanf(prose_in,"\n%c%d%d\n",&c,&nofac,&nbcont);
	 fprintf(prose_out,"f%d %d\n",nofac,nbcont);

    // traite les contours
	 for(j=0;j<nbcont;j++)	
		{
		 fscanf(prose_in,"%d\n",&noc);
		 //printf(" contour %d \n ", noc);

		  for(k=0;k< nb_dir;k++)
			{ 
			  if(nb_val ==1)
				{	fscanf(prose_in,"%d %f\n",&angle,&val1);
					//printf(" %d  %f \n ", angle,val1);
					if(angle == direction)
					{
			          fprintf(prose_out," %7.2f\n",val1);
					}
				}
			  else if (nb_val ==2)
				{	;
				}
			  else if (nb_val ==3)
				{	;
				}
			}
		}
  }
}


/*____________________________________________________________________*/
void lit_fic_rose(prose)
FILE *prose;
{
	int nbf, nb_dir,nb_val;
	int num_face,nofac,nbcont_face,num_cont;
	int i,angle,noc;
	float val1,val2,val3;
	char c;

	fscanf(prose,"%d %d %d",&nbf,&nb_dir,&nb_val);
	printf("nbf nb_dir, nb_val : %d %d %d\n",nbf,nb_dir,nb_val);

	for(num_face=0;num_face<nbf;num_face++)
	{
	 fscanf(prose,"\n%c%d%d\n",&c,&nofac,&nbcont_face);
	 printf("f%d %d\n",nofac,nbcont_face);

	 for(num_cont=0;num_cont<nbcont_face;num_cont++)	
		{
		 fscanf(prose,"%d\n",&noc);
		 printf(" contour %d \n ", noc);

		  for(i=0;i< nb_dir;i++)
			{ 
			  if(nb_val ==1)
				{	fscanf(prose,"%d %f\n",&angle,&val1);
					printf(" %d  %f \n ", angle,val1);
				}
			  else if (nb_val ==2)
				{	fscanf(prose,"%d %f %f",&angle,&val1,&val2);
					printf("%d  %f  %f\n", angle,val1,val2);
				}
			  else if (nb_val ==3)
				{	fscanf(prose,"%d %f %f %f",&angle,&val1,&val2,&val3);
					printf("%d  %f  %f  %f\n", angle,val1,val2,val3);
				}
		  }
		}
	}
}



/*_________________________________________________________________*/
/* Format de la fonction */
void format_entree()
{
  printf("\n rose_op \n");
	printf("\n       a comme param�tre d'entr�e\n");
  printf("\n IN   fichier_rose (.ros)\n");
    printf("\n       a comme param�tre de sortie\n");
  printf("\n OUT  fichier_rose_moyenne (.ros) \n");  
	printf("\n       a comme param�tre facultatif\n");
  printf("\n IN    direction\n");
  printf("\n OUT   fichier_descripteur_direction(.val)\n");

}

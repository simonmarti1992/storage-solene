/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/*

cc union -o union solutile.o geomutile.o face_op_face.o poly_op_poly.o lib_solene_94.o -lm

*/

#include<solene.h>


/*_________________________________________*/
/* DESCRIPTION
  fait l'union de toutes les faces d'un fichier
  sans s'occuper des normales
  r�sultat : 1 face de plusieurs contours
*/

// Declare functions
int  ecrit_en_tete();
void format_entree();
void traite_l_union_bis();
int  traite_union_nouveau();

// en global 
extern int option_calcul_z; 
extern int option_sup_surf;    /* option SUPPRESSION de SURFACE ds FACE-OP-FACE 1=oui */


FILE *fsource,*fdest;
int nbfac1;
struct modelisation_face *fac1;

extern double coef_discol;

/*________________________________________________________________________*/
main(argc,argv)
char **argv;
int  argc ;
{
char 	buf[512],*s_dir;
double	englob[10];
int nomax1;

  singularite=0; non_singularite=0; nb_etat=0;
   pb_masque=0; colle_max=coef_discol*DISCOL;

 if(argc!=3)
   { format_entree();
     exit(0);
   }
   

printf("union : UNION des faces\n");

 s_dir=(char *)getenv("PWD");

 compose_nom_complet(buf,s_dir,argv[1],"cir");
 if((fsource = fopen(buf, "r"))==NULL)
// if((fsource = fopen("c:\\temp\\Wessai_15_2.cir", "r"))==NULL)
	{ printf("\n impossible ouvrir %s\n",buf);
	  exit(0);
    }
printf("IN  = %s\n",buf);

 compose_nom_complet(buf,s_dir,argv[2],"cir");
 if((fdest = fopen(buf, "w"))==NULL)
// if((fdest = fopen("c:\\temp\\Wessai_UNI.cir", "w"))==NULL)
	{ printf("\n impossible creer %s\n",buf);
	  exit(0);
        }
printf("OUT = %s\n",buf);

   lit_en_tete(fsource,&nbfac1,&nomax1,englob);
   fac1=alloue_face(nbfac1,1000);
   lit_fic_cir3d(fsource,nbfac1,fac1); 
   fclose(fsource);

   ecrit_en_tete(fdest,1,1,englob);

   
  /* traite union pour chaque face */

  printf(" traitement en cours\n");

  traite_l_union_bis();



  desalloue_fface(fac1,nbfac1);
  fclose(fdest);

  printf(" fin union\n");

  creer_OK_Solene();

 }

/*________________________________________________________________________*/
void traite_l_union_bis()
{
 int 	i,nbf_out,noma_out;
 struct modelisation_face *face_resultat_union;
 struct modelisation_face	*face_union;

  face_union=alloue_face(1,1013);
  face_resultat_union=alloue_face(1,1014);

   /*  attention les contours de face ne sont pas ds le meme plan */

   /* avec option_calcul_z=0 union garde les bons Z et les pts alignes */

  option_calcul_z = 0;
  option_sup_surf = 0;
  
  for(i=0;i<nbfac1;i++)
    {
	  copie_face_projete(fac1+i,1,fac1+i,0); 
	}

   //alloue face union r�sultat    	  
     face_resultat_union->nofac_fichier=1;
     face_resultat_union->vnorm[0]=0;
     face_resultat_union->vnorm[1]=0;
     face_resultat_union->vnorm[2]=1;
  
     face_resultat_union->debut_projete=NULL;

	 // unit les nbfac1 faces fac1
	 traite_union_nouveau(fac1,nbfac1,face_resultat_union);

	 // ecrit r�sultat
     output_face_sur_fichier(face_resultat_union,1,1,0,fdest,&nbf_out,&noma_out);

  desalloue_fface(face_resultat_union,1);

}



/*________________________________________________________________________*/
void format_entree()
{
  printf("\n   *union_contour_face*  fichier_in(.cir) fichier_out(.cir) \n\n");
  printf("    fait l'union des contours pour chaque face du fichier_in \n\n");
}






/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/*

cc tas_solene.c  solutile.o geomutile.o lib_solene_94.o

*/
// D. GROLEAU janvier 2005

// construit, a partir d'un fichier.cir  r�cup�r� de tas, 
// contenant des  faces avec, � la fois, des contours TRIANGLES et des contours QUADRANGLES
// 2 fichiers .cir:
//		un fichier PAROI avec les contours TRIANGLES
//		un fichier FENETRE avec les contours QUADRANGLES

#include<solene.h>


// DECLARATIONS FUNCTIONS

int ecrit_en_tete();
void format_entree();



/*_________________________________________________________________*/
main(argc,argv)
 int argc;char **argv;
{
 char 	buf[512],nom[512],*s_dir, c;
 double englob[10];
 int	i,j,k, nbff,nomax;
 int	nofac, nbcir, nbtrou, nbpoint;
 FILE	*fp, *fpP, *fpF;
 int	nbfP,nbfF,nbcP,nbcF; // nb de faces  nb de contours
 long	pointeP, pointeF; // pointeurs d�but de  face
 double x,y,z,xn,yn,zn;

 if(argc!=2)format_entree();

	s_dir=(char *)getenv("PWD");

 printf(" Fonction Solene : tas_solene\n\n");
  
// INPUT
  compose_nom_complet(buf,s_dir,argv[1],"cir");
  if((fp=fopen(buf,"r"))==NULL)
        { printf("\n impossible ouvrir %s\n",buf); exit(0);}
   lit_en_tete(fp,&nbff,&nomax,englob);
  printf("fichier IN � traiter : %s (%d faces)\n",buf,nbff);
        
// OUTPUT : 3 fichiers
  // PAROI
  sprintf(nom,"%s_PAROI",argv[1]);
  printf("fichier OUT  PAROI : %s\n",nom);
  compose_nom_complet(buf,s_dir,nom,"cir");
  fpP=fopen(buf,"w");
    if(fpP==NULL) 
	{ printf("impossible creer %s\n",buf);
	  exit(0);
	}
  ecrit_en_tete(fpP,nbff,nomax,englob);

  // FENETRE
  sprintf(nom,"%s_FENETRE",argv[1]);
  printf("fichier OUT  FENETRE : %s\n",nom);
  compose_nom_complet(buf,s_dir,nom,"cir");
  fpF=fopen(buf,"w");
    if(fpF==NULL) 
	{ printf("impossible creer %s\n",buf);
	  exit(0);
	}
  ecrit_en_tete(fpF,nbff,nomax,englob);

// TRAITEMENT  
    nbfP =nbfF =0;
	
   // Lit FACE par face 
   for (i=0;i<nbff;i++)
   { pointeP = ftell(fpP); pointeF=ftell(fpF);
	 nbcP = nbcF =0;	
		// lit info face
		fscanf(fp,"\n%c%d %d",&c,&nofac,&nbcir);     
							 //printf(" lit face no %d nb contour = %d\n",nofac,nbcir); 
        // lit normale
        fscanf(fp,"%lf %lf %lf",&xn,&yn,&zn);

		// lit chaque contour
        for(j=0;j<nbcir;j++)
		{  
            fscanf(fp,"\n%c%d",&c,&nbtrou);
							//printf(" lit contour  nbtrou = %d\n",nbtrou); 
			if(nbtrou)
			{ printf("PROBLEME: il y a des contours avec trou!!!\n");
			  exit;
			}
	        /* lit le nb de points */
              fscanf(fp,"%d",&nbpoint);
							//printf("  nb de pts %d\n",nbpoint);

			  if(nbpoint==4)
			  { // un TRIANGLE : ecrit sur PAROI
			    if(nbcP==0)
				{ // c'est le 1er contour de la face � cr�er
				  // on �crit l'en-tete de face sur le fichier PAROI
				   fprintf(fpP,"f%d %5d\n",nofac,nbcir);
				   fprintf(fpP," %lf  %lf  %lf\n",xn,yn,zn);
				}
				  
				 fprintf(fpP,"c%d\n",nbtrou);
				 fprintf(fpP,"4\n"); //nb de points
				 // lit et ecrit les points
				 for(k=0;k<nbpoint;k++)
                 { fscanf(fp,"%lf%lf%lf",&x,&y,&z);
				   fprintf(fpP,"%15.5f %15.5f %15.5f\n",x,y,z);
				 }
				nbcP++;
			  }
			  else if(nbpoint==5)
			  {
				// un QUADRANGLE : ecrit sur FENETRE
				if(nbcF==0)
				{ // c'est le 1er contour de la face � cr�er
				  // on �crit l'en-tete de face sur le fichier FENETRE
				   fprintf(fpF,"f%d %5d\n",nofac,nbcir);
				   fprintf(fpF," %lf  %lf  %lf\n",xn,yn,zn);
				}

				 fprintf(fpF,"c%d\n",nbtrou);
				 fprintf(fpF,"5\n"); //nb de points
				 // lit et ecrit les points
				 for(k=0;k<nbpoint;k++)
                 { fscanf(fp,"%lf%lf%lf",&x,&y,&z);
				   fprintf(fpF,"%15.5f %15.5f %15.5f\n",x,y,z);
				 }
				nbcF++;
			  }
			  else
			  { printf("??? PROBLEME la face %d poss�de un contour de plus de 4 points\n",nofac);
			    exit;
			  }
		}
	// test si des contours PAROI
	 fseek(fpP,pointeP,SEEK_SET);
	 if(nbcP)
	 { // r�ecrit le nombre de contour
       fprintf(fpP,"f%d %5d",nofac,nbcP);
	   fseek(fpP,0,SEEK_END);
	   nbfP++;
	 }
 	// test si des contours FENETRE 
	 fseek(fpF,pointeF,SEEK_SET);
	 if(nbcF)
	 { // r�ecrit le nombre de contour
       fprintf(fpF,"f%d %5d",nofac,nbcF);
	   fseek(fpF,0,SEEK_END);
	   nbfF++;
	 }       
   }

 
/* re�crit en-tete avec bonnes valeurs */
   rewind(fpP);
   ecrit_en_tete(fpP,nbfP,nomax,englob);
   rewind(fpF);
   ecrit_en_tete(fpF,nbfF,nomax,englob);

   fclose(fp);
   fclose(fpP);
   fclose(fpF);
   printf("\n");

   printf( "Fichier de PAROI : %d faces\n", nbfP);
   printf( "Fichier de FENETRE : %d faces\n", nbfF);

    printf(" Fin du traitement: tas_solene\n\n");

  		creer_OK_Solene();

}


/*_________________________________________________________________*/
void format_entree()
{
  printf("\ntas_solene  \n\n");
  printf("\n  Param�tres de la fonction:   \n\n");
  printf("\t IN    fichier_geometrie_in(.cir) \n\n");
  printf("NOTA:   2 fichiers sont cr��s: \n");
  printf("\t\t    fichier_geometrie_in_PAROI\n");
  printf("\t\t    fichier_geometrie_in_FENETRE\n");

   exit(0);
}
/*_________________________________________________________________*/




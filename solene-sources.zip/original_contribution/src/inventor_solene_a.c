/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/* inventor_solene_a.c */
/* 
D. GROLEAU 2002
D. GROLEAU fev 2006 // MODIF pour fichier open inventor FR2E

cc -o inventor_solene_a inventor_solene.c solutile.o geomutile.o lib_solene_94.o -lm
 
*/

/* Conversion fichier open Inventor (.iv) en fichier SOLENE (.cir) */
/* version 1: ok pour les fichiers venant de Brest Geo Architecture     */
/* version 2: ok pour les fichiers venant de FR2E        */

// la diff�rence tient dans la pr�sence ou non de blanc s�parateurs et du positionnement attach� ou non de [ et ]

/*  on cherche Coordinate3, puis point                   */
/*        et on lit les coordonnees des points           */
/*  on cherche IndexedFaceSet suivi de coordIndex       */
/*     et on lit les indices (de 0 a ..) des no */
/*     des points constituant le contour des faces;                */
/*     indice -1 indique la fin d'un contour                       */
/*  on peut lire a plusieurs reprises IndexedFaceSet suivi de coordIndex */

/* ATTENTION ICI, l'ordre de indices  restitue le contour de la face */

#include<solene.h>
#include <string.h>
/*---------------------------------------------------------------------------*/
// D�clarations Fonction

void	 calcul_normale();
void	 cherche_ext();
void	 construit_les_faces();
void	 decode_ligne_commande_macro();
int		 ecrit_en_tete();
int		 enregistre_face();
void	 format_entree();
void	 gere_parametre();
void	 lit_coordonnees_version1();
void	 lit_coordonnees_version2();
int		 lit_DEF_version1();
int		 lit_DEF_version2();
int		 lit_faces_version1();
int		 lit_faces_version2();
int		 lit_ligne_commande();
void	 trop_de_point();


// en GLOBAL
FILE *fi,*fo;

#define MAXCORD 36000
#define EPSI    0.00001

int parc;
char ligne_commande[2048],*parv[128],met_param[2048];

char   buf[512],nom_in[512],nom_out[512];
double xmin,ymin,zmin,xmax,ymax,zmax,precision;
double x[MAXCORD],y[MAXCORD],z[MAXCORD];
int    nopt[MAXCORD];
int    nbpoint;
int    nbfac_enr;
double tx,ty,tz,rot1,rot2,rot3,rot4;

/*________________________________________________________*/
main(argc,argv)
int  argc;
char *argv[];    /* ou **argv */

{
 char *s_dir;
 double englob[10];
 int no_version;

	s_dir=(char *)getenv("PWD");

 if(argc!=4)format_entree();

  printf("Fonction Solene : inventor_solene_a\n\n");


 // initialise extremes x,y,z 
 xmin=ymin=zmin=1000000.;
 xmax=ymax=zmax=-xmin;
 zmin=0; zmax=0;

 precision=0.001;

 // lit les param�tres de commande

       sscanf(argv[3],"%d", &no_version);
	   printf("\nno version =%d\n",no_version);
	   if(no_version!=1 && no_version!=2 ) format_entree();


            compose_nom_complet(nom_in,s_dir,argv[1],"iv");
            if((fi=fopen(nom_in,"r"))==NULL) 
               { printf(" impossible ouvrir %s\n",nom_in);
   	         format_entree();
               }
printf("\nConvertit  %s\n",nom_in);

            compose_nom_complet(nom_out,s_dir,argv[2],"cir");
            if((fo=fopen(nom_out,"w"))==NULL) 
               { printf(" impossible ouvrir %s\n",nom_out);
   	         format_entree();
               }
printf("en         %s\n\n",nom_out);
        // no_version


nbfac_enr=1;
englob[0]=zmin; englob[1]=zmax;
englob[2]=xmin; englob[3]=ymin;
englob[4]=xmax; englob[5]=ymin;
englob[6]=xmax; englob[7]=ymax;
englob[8]=xmin; englob[9]=ymax;
  ecrit_en_tete(fo,nbfac_enr,nbfac_enr,englob);

/* cherche   les points puis les faces  et recommence */

        if(no_version==1) lit_DEF_version1(&nbfac_enr);
        else              lit_DEF_version2(&nbfac_enr);
      

englob[0]=zmin; englob[1]=zmax;
englob[2]=xmin; englob[3]=ymin;
englob[4]=xmax; englob[5]=ymin;
englob[6]=xmax; englob[7]=ymax;
englob[8]=xmin; englob[9]=ymax;
rewind(fo);
  ecrit_en_tete(fo,nbfac_enr-1,nbfac_enr-1,englob);

  printf("Nombre de faces g�n�r�es : %d\n",nbfac_enr-1);
  printf("\nAttention: v�rifier si des faces doubles (faire import dans Solene)\n");



 fclose(fi); fclose(fo);

   	creer_OK_Solene();

printf("\nFin de inventor_solene_a\n");
printf("___________________________________________\n\n");

}

/*______________________________________________________*/
int lit_DEF_version1(nbfac)
int *nbfac;
{
 int jailu,ilu;
  
	 /* jailu =0 rienlu
			  =1 Coordinate3
			  =2 point
			  =3 IndexedFaceSet
			  =4 coordIndex
	  */
jailu=0;

while(1)
 {
  ilu = lit_ligne_commande(); 
  if(ilu) break;
  decode_ligne_commande_macro();
  gere_parametre(ligne_commande);
  //printf("Dans litDEF    nb de par %d   parv0= %s\n",parc,parv[0]);
  if( parc > 1 && (strcmp(parv[0],"Coordinate3"))==0)
   {
	  jailu=1;
	  
   }
  
  else if(parc > 1 && (strcmp(parv[0],"point"))==0)
   {
	  if (jailu == 1)
	  {   //printf("lit les coord\n");
		  //printf("point: nb de par %d = %s %s %s \n",parc,parv[0],parv[1],parv[2]);
		    lit_coordonnees_version1();
			jailu=2;
	  }
   }

  else if(parc > 1 && (strcmp(parv[0],"IndexedFaceSet"))==0)
   {
	  if (jailu == 2 || jailu == 4)
	  {
			//printf("jailu=%d\n",jailu);
			jailu=3;
	  }
   }
  else if(parc > 1 && (strcmp(parv[0],"coordIndex"))==0)
  { //printf("a lu coordIndex\n");
	  if (jailu == 3)
	  {   //printf("lit les faces\n");
		  //printf("coord: nb de par %d = %s %s %s \n",parc,parv[0],parv[1],parv[2]);
            lit_faces_version1();
			jailu=4;
	  }
   }
 }
return(1);
}


/*______________________________________________________*/
int lit_DEF_version2(nbfac)
int *nbfac;
{
 int jailu,ilu;
  
	 /* jailu =0 rienlu
			  =1 Coordinate3
			  =2 point
			  =3 IndexedFaceSet
			  =4 coordIndex
	  */
jailu=0;

while(1)
 {
  ilu = lit_ligne_commande(); 
  if(ilu) break;
  decode_ligne_commande_macro();
  gere_parametre(ligne_commande);
  //printf("Dans litDEF    nb de par %d   parv0= %s\n",parc,parv[0]);
  if( parc > 1 && (strcmp(parv[0],"Coordinate3"))==0)
   {
	  jailu=1;
	  
   }
  
  else if(parc > 1 && (strcmp(parv[0],"point"))==0)
   {
	  if (jailu == 1)
	  {   //printf("lit les coord\n");
		  //printf("point: nb de par %d = %s %s %s \n",parc,parv[0],parv[1],parv[2]);
		    lit_coordonnees_version2();
			jailu=2;
	  }
   }

  else if(parc > 1 && (strcmp(parv[0],"IndexedFaceSet"))==0)
   {
	  if (jailu == 2 || jailu == 4)
	  {
			//printf("jailu=%d\n",jailu);
			jailu=3;
			lit_faces_version2();
			jailu=4;
	  }
   }
 }
return(1);
}

/*______________________________________________________*/
void lit_coordonnees_version1()
{
 int i,k;
/*
La forme d'�criture de la version 1 est :
 
 Coordinate3 { 
 point [   20.20516 -3.64886 -0.22805,
51.47171 -3.64886 -0.22805,
51.47171 -3.64886 6.47268,
]

 ou
 
 Coordinate3 { 
 point [   20.20516 -3.64886 -0.22805,
51.47171 -3.64886 -0.22805,
51.47171 -3.64886 6.47268,]

*/

 k=0;

 /* lit les coord de la ligne point si parc >2 */
 if(parc > 2)
 {
  i=2; 

    sscanf(parv[i],  "%lf", x+k);
    sscanf(parv[i+1],"%lf", y+k);
    sscanf(parv[i+2],"%lf", z+k);
	//printf("point %f %f %f\n", x[k],y[k],z[k]);

    k++; /* nb de points */
 }
    nbpoint = k;

 /* lit les coor sur lignes suivantes */
 while(1)
  {
   lit_ligne_commande(); 
   decode_ligne_commande_macro();
   gere_parametre(ligne_commande);
   if(parc > 2)
   {
    for(i=0 ;i<3;i+=3)  /* on s'attend � lire une coordonn�e xyz par ligne */
     { 
       sscanf(parv[i],"%lf", x+k);
       sscanf(parv[i+1],"%lf", y+k);
       sscanf(parv[i+2],"%lf", z+k);
	   //printf("point %f %f %f\n", x[k],y[k],z[k]);

       k++; /* nb de points */
       nbpoint = k;

       if(k>MAXCORD)
	    { printf("\n trop de coordonnees dans vertex - on arrete \n");
	      printf(" nbp = %d > %d \n\n",k,MAXCORD);
	      exit(0);
	    }
     }
     
     /* test si la fin des coord : , ou ]=fin) 
        ou si le 4 paramtre de la commande est ]
     */
    i= i-1;  /*printf("parv = %s\n",parv[i]);*/
    if((strchr(parv[i],']')))
      { //printf("] fin \n");
        break;
      }
	//printf("parc = %d\n",parc);
    if(parc==4)break; /* on a ] en 4eme parametre */
   }
   else break;
  }

 
 for(i=0 ;i<nbpoint;i++)
     {   
       //printf("%f %f %f\n", x[i],y[i],z[i]);
	  
       cherche_ext(x[i],y[i],z[i]);
     }
 //printf("fin des coordonn�es\n");
}
/*______________________________________________________*/
void lit_coordonnees_version2()
{
 int i,k;
 char c;
/*
La forme d'�criture de la version 2 est :
 
 Coordinate3 { 
 point [20.20516 -3.64886 -0.22805,
51.47171 -3.64886 -0.22805,
51.47171 -3.64886 6.47268,
20.20516 -3.64886 6.47268,
20.20516 -3.64886 -0.22805,
]
}
*/

 k=0;

 /* lit les coord de la ligne point si parc >2 */
 if(parc > 2)
 {
    i=1;   
    sscanf(parv[i],"%c%lf",&c, x+k);
    sscanf(parv[i+1],"%lf", y+k);
    sscanf(parv[i+2],"%lf", z+k);
	//printf("point %f %f %f\n", x[k],y[k],z[k]);

    k++; /* nb de points */
 }
    nbpoint = k;

 /* lit les coor sur lignes suivantes */
 while(1)
  {
   lit_ligne_commande(); 
   decode_ligne_commande_macro();
   gere_parametre(ligne_commande);
   if(parc > 2)
   {
    for(i=0 ;i<3;i+=3)  /* on s'attend � lire une coordonn�e xyz par ligne */
     { 
       sscanf(parv[i],"%lf", x+k);
       sscanf(parv[i+1],"%lf", y+k);
       sscanf(parv[i+2],"%lf", z+k);
	   //printf("point %f %f %f\n", x[k],y[k],z[k]);

       k++; /* nb de points */
       nbpoint = k;

       if(k>MAXCORD)
	    { printf("\n trop de coordonnees dans vertex - on arrete \n");
	      printf(" nbp = %d > %d \n\n",k,MAXCORD);
	      exit(0);
	    }
     }
     
     /* test si la fin des coord : , ou ]=fin) 
        ou si le 4 paramtre de la commande est ]
     */
    i= i-1;  /*printf("parv = %s\n",parv[i]);*/
    if((strchr(parv[i],']')))
      { //printf("] fin \n");
        break;
      }
	//printf("parc = %d\n",parc);
    if(parc==4)break; /* on a ] en 4eme parametre */
   }
   else break;
  }

 
 for(i=0 ;i<nbpoint;i++)
     {   
       //printf("%f %f %f\n", x[i],y[i],z[i]);
	  
       cherche_ext(x[i],y[i],z[i]);
     }
 //printf("fin des coordonn�es\n");
}


/*______________________________________________________*/
int lit_faces_version1()
{
 int i,k; 

/* voir FORMAT fichier Geo_architecture
La forme d'�criture de la version 1 est :
 IndexedFaceSet {
 coordIndex  [  0, 1, 6, 5, -1, 
5, 6, 1, 0, -1, 
1, 2, 7, 6, -1, 
6, 7, 2, 1, -1 ]   				
}

ou

 IndexedFaceSet {
 coordIndex   [  0,  1,  6,  5,  -1  ] 

  // on peut avoir plusieurs lignes de no de points � suivre sans -1;
  // le -1 n'est pas forc�ment plac� en bout de ligne
*/
/* lit les points sur la ligne de coordIndex */

k=0;
if (parc > 2)
{
  for(i=2 ;i<parc-1;i++)
     { 
       sscanf(parv[i],"%d", nopt+k);
	   //printf("nopoint %d\n",nopt[k]);
       k++; /* nb de points */
	   trop_de_point(k);
     }

   if((strchr(parv[parc-1],']')))
      { //printf("fin ]\n");
        construit_les_faces(k);
		return(0);
      }
   else  
     {	sscanf(parv[i],"%d", nopt+k);
        k++; /* nb de points */
		trop_de_point(k);
     }
   	  
}

/* lit tous les points des faces sur les lignes suivantes */
while(1)
{  
   lit_ligne_commande(); 
   decode_ligne_commande_macro();
   gere_parametre(ligne_commande);
   if (parc > 2)
   {
     for(i=0 ;i<parc-1;i++)
     { 
       sscanf(parv[i],"%d", nopt+k);
	   //printf("nopoint %d\n",nopt[k]);
       k++; /* nb de points */
	   trop_de_point(k);
     }
     
     /* test si la fin des points : , ou ]=fin) */
    if((strchr(parv[parc-1],']')))
      { //printf("fin ]\n");
        construit_les_faces(k);
		return(0);
      }
	else  
     {	sscanf(parv[i],"%d", nopt+k);
        k++; /* nb de points */
		trop_de_point(k);
     }
   }
   else
   {  if(k)  construit_les_faces(k);
	  break;  
   }
  }
}



/*______________________________________________________*/
int	lit_faces_version2()
{
 int i,k,ilu; 
 char c[3],cbidon;
 char  *s1,*s2;
/*
La forme d'�criture de la version 2 est :
 IndexedFaceSet {
 coordIndex[0,1,6,5,-1, 
5,6,1,0,-1, 
1,2,7,6,-1, 
6,7,2,1,-1, 
2,3,8,7,-1, 
7,8,3,2,-1, 
3,4,9,8,-1, 
8,9,4,3,-1, 
]
}
ou 
 IndexedFaceSet {
 coordIndex[0,1,6,5,-1,] 
*/
// la ligne qu'on vient de lire est IndexedFacet 	 
// lit la ligne qui suit :  coordIndex[0,1,6,5,-1, 
  ilu = lit_ligne_commande(); 
  if(ilu) 
  { printf("PB: coordIndex ne suit pas IndexedFaceSet { (exit) \n");
    exit(0);
  }
  decode_ligne_commande_macro();
  gere_parametre(ligne_commande);
  //printf("Dans litDEF    nb de par %d   parv0= %s\n",parc,parv[0]);

// lit tout dans parv[0], car il n'y a pas de "blanc" s�parateur

// lit les points sur la ligne de coordIndex apr�s ] et ensuite apr�s ,
 i=0;
 k=0;
 c[0]='[';
 c[1]=',';
 c[2]=']';
 s1=parv[0];
 //printf("s1=%s\n",s1);
 while(1)
 { s2= strchr(s1,c[i]);
   //printf("s2=%s\n",s2);
   // lit le no du point 
   sscanf(s2,"%c%d",&cbidon,nopt+k);
   //printf("%d\n",nopt[k]);
   if(nopt[k]==-1)
	{	// test si fin de Contour ]
	    k++; // on stocke nop=-1;
	    s1=s2+1;
		i=2;
		s2= strchr(s1,c[i]);
		if(s2!=NULL)
		{ // on construit les faces
		  construit_les_faces(k);
		  return(0);
		}
	   else
	   { // on lit la ligne suivante : soit des coordonn�es, soit ] (fin des points des faces)
		 ilu = lit_ligne_commande(); 
		 if(ilu) 
			  { printf("PB: on doit trouver une liste de points ou ] (exit) \n");
			    exit(0);
			  }
		  decode_ligne_commande_macro();
		  gere_parametre(ligne_commande);
		  //printf("Dans litDEF    nb de par %d   parv0= %s\n",parc,parv[0]);
		  // on teste si on a lu  ]
		  sscanf(parv[0],"%c",&cbidon);
		  if(cbidon==']')
		  {
			  if(k)	construit_les_faces(k);
			  return(0);
		  }
		  else
		  { // on continue � lire les points d'une nouvelle face
			s2=parv[0];
			//printf("s2=%s\n",s2);
		    sscanf(s2,"%d",nopt+k);
			//printf("%d\n",nopt[k]);
		  }
	   }
	}// fin du if (nopt[k]==-1)
  s1=s2+1;
  i=1;
  k++; /* nb de points */
  trop_de_point(k);
 }
}

/*______________________________________________________*/
void  construit_les_faces(k)
int k;
{
 
 int i,j,kk,istoke,ideb,nbcontour;
 double xnn,ynn,znn,xx[3],yy[3],zz[3];
 
/*
 printf("Construit les faces avec les no des points\n");
 for(i=0; i<k; i++)
    { printf("%d\n",nopt[i]);
    }
*/

  /* stocke les faces */

   nbcontour=0;
   istoke=0; ideb=0;
   for(i=0; i<k; i++)
    { 
     //printf("%d\n",nopt[i]); 
     if(nopt[i]==-1)
        { /* c'est une face */
            nbcontour=1;
          /* calcul sa normale */
            for(j=0; j<3 ;j++)
              { kk=j+ideb;
                xx[j]=x[nopt[kk]];
                yy[j]=y[nopt[kk]];
                zz[j]=z[nopt[kk]];
              }
            calcul_normale(xx,yy,zz,&xnn,&ynn,&znn);
            ideb=i+1;
            /*printf("ideb = %d ;normale = %f %f %f \n",ideb,xnn,ynn,znn);*/
       
          // on stocke un contour par face

          /* en demarrant a istoke */
           enregistre_face(&istoke,1,xnn,ynn,znn);
		}
    }
                     
}


/*______________________________________________________*/
int enregistre_face(istoke,nbcontour,xnn,ynn,znn)
int 	*istoke,nbcontour;
double xnn,ynn,znn;
{
  int i,j,irendu,nbp;

/*   if(sup_pt_proche(x,y,z,&nbp)==0)return(0); */

nbp=0; irendu= *istoke; while(nopt[irendu]!=-1) { nbp++; irendu++; }
//nbcontour= nbp-2;
nbcontour=1;

fprintf(fo,"f%d %d\n",nbfac_enr,nbcontour);
fprintf(fo,"%f %f %f\n",xnn,ynn,znn);

  
  
   //printf("face %d de %d points a partir de %d\n", nbfac_enr,nbp+1,*istoke);

//i=*istoke;
//for (j=0; j<nbcontour; j++) 
 // { /* cree un contour triangle l l+1 l+2*/
	/*fprintf(fo,"c0 \n  4\n");

	fprintf(fo,"%12.3f %12.3f %12.3f\n",x[nopt[i]],y[nopt[i]],z[nopt[i]]);
	fprintf(fo,"%12.3f %12.3f %12.3f\n",x[nopt[i+1]],y[nopt[i+1]],z[nopt[i+1]]);
	fprintf(fo,"%12.3f %12.3f %12.3f\n",x[nopt[i+2]],y[nopt[i+2]],z[nopt[i+2]]);
	fprintf(fo,"%12.3f %12.3f %12.3f\n",x[nopt[i]],y[nopt[i]],z[nopt[i]]);
    i++;
  }
	*/

fprintf(fo,"c0 \n  %d\n",nbp+1);
i=*istoke;
for (j=i; j<i+nbp; j++) 
  { /* cree un contour polygonal*/

	fprintf(fo,"%15.5f %15.5f %15.5f\n",x[nopt[j]],y[nopt[j]],z[nopt[j]]);

  }
	fprintf(fo,"%15.5f %15.5f %15.5f\n",x[nopt[i]],y[nopt[i]],z[nopt[i]]);


*istoke= *istoke + nbp +1;   
nbfac_enr++;
   
return(1);
}

/*________________________________________________________________________*/
void calcul_normale(x,y,z,xnn,ynn,znn)
double *x,*y,*z;
double *xnn,*ynn,*znn;
{
 double x1,y1,z1,x2,y2,z2,norm;
 int i,j,k;

 /* calcul sur les  3 premiers  */
 i=0; j=1; k=2;
 x1=x[j]-x[i]; y1=y[j]-y[i]; z1=z[j]-z[i];
 x2=x[k]-x[j]; y2=y[k]-y[j]; z2=z[k]-z[j];
 *xnn=y1*z2-y2*z1;
 *ynn=-x1*z2+x2*z1;
 *znn=x1*y2-x2*y1;

 norm=sqrt(*xnn*(*xnn)+*ynn*(*ynn)+*znn*(*znn)); 
 *xnn=*xnn/norm; *ynn=*ynn/norm; *znn=*znn/norm;
}

/*________________________________________________________________________*/
void cherche_ext(x,y,z)
double x,y,z;
{ 
	if(x<xmin)xmin=x;
	if(x>xmax)xmax=x;
	if(y<ymin)ymin=y;
	if(y>ymax)ymax=y;
	if(z<zmin)zmin=z;
	if(z>zmax)zmax=z;
}

/*______________________________________________________*/
int cherche_chaine(s)
char *s;
{
 int ilu;

ilu=0;
while(ilu==0)
  {  ligne_commande[0]=0;
     ilu=lit_ligne_commande(); if(ilu){ilu=2; break;}

     
     if(ligne_commande[0]!=0)
       { decode_ligne_commande_macro();
         gere_parametre(ligne_commande);

         /*if( parc > 1)printf(" parv = %s \n",parv[0]); */
         if( parc > 1 && (strcmp(parv[0],s))==0) ilu=1;

       }

   }
 return(ilu);

}

/*_________________________________________________________________*/
int lit_ligne_commande()
{
  int i;   /* lit ligne de commande ds ligne_commande sur console */
  
  i=-1;
  do
    { i++; 
      if((fscanf(fi,"%c",ligne_commande+i))==EOF)
		{   ligne_commande[i]=0;
			return(1);
		}
		
	/*printf("i= %d c=%c\n",i,ligne_commande[i]);*/
    }while(ligne_commande[i]!='\n');

  ligne_commande[i]=0;
  //printf("ligne = %s\n",ligne_commande);
  return(0); 

}


/*_________________________________________________________________*/
void decode_ligne_commande_macro()
{
   /* epure la ligne de commande */
   /* enleve les blancs consecutifs et met fin de chaine des que # */
  int i,j,ignore_car;

  ignore_car=0;
  i=0;   /* ieme caractere de ligne_commande */
  j=0;   /* jeme caracter de ligne epuree  */
  while(1)
    { if(ligne_commande[i]==0) break;
      if(ignore_car) i++;
      else if(ligne_commande[i]==' ' || ligne_commande[i]=='	')
         { if(j!=0 && ligne_commande[j-1]!=' ') 
               { /*ligne_commande[j]=ligne_commande[i]; */
                 ligne_commande[j]=' ';
		         j++;
               }
           i++;
         }
/* ne traite pas (ligne_commande[i]=='#' */
/*       else if(ligne_commande[i]=='#') */

      else
         { ligne_commande[j]=ligne_commande[i]; 
           j++; i++;
         }
    }
  if(ligne_commande[j-1]==' ') j--; 
  ligne_commande[j]=0;
//if(ligne_commande[0]!=0) printf("ligne epuree = %s \n",ligne_commande);
}

/*_________________________________________________________________*/
void gere_parametre(ligne_commande)
char *ligne_commande;
{       
        /* etablit les parametres de ligne_commande ds *parv[] */
        /* construit un parametre jusqu'a un BLANC */
  int i,j,nb;
  
  nb=0;  /* 1er parametre */
  i=0;   /* 1er caractere de ligne_commande */
  j=0;   /* 1er caractere du parametre  */
  parv[nb]=&met_param[j];
  while(1)
    { if(ligne_commande[i]==' ')
         { met_param[i]=0; nb++; parv[nb]=&met_param[i+1];
         }
      else 
         { met_param[i]=ligne_commande[i]; 
           if(ligne_commande[i]==0 || ligne_commande[i]=='\n') break;
         }
      i++;
    }
  nb++; parc=nb;

  //printf("nb param %d\n",parc); 
  //for(i=0;i<nb;i++) printf("%s\n",parv[i]); 
}
/*______________________________________________________*/
int sup_pt_proche(x,y,z,nbp)
double *x,*y,*z;
int *nbp;
{
 int i,k,nbpp;
         /* suppression artificielle des pts proches avec statut <0 */

/* for(i=0;i<MAXCORD;i++)statut[i]=0; */

//printf(" nbp = %d \n",*nbp);
 nbpp=*nbp;
 for(i=0;i<*nbp-1;i++)
   { for(k=i+1;k<*nbp;k++)
          { 
               if(fabs(x[i]-x[k])<precision && fabs(y[i]-y[k])<precision && fabs(z[i]-z[k])<precision)
                  { nbpp--; printf(" --\n");
	/*	    statut[k]=-1;  */
                    i--;
                  }
	   if(nbpp<3)return(0);
          }

   }
 return(1);
}

/*______________________________________________________*/
void   trop_de_point(k)
int		k;
{
       if(k > MAXCORD)
	     { printf("\n trop de points dans une face  - on arrete \n");
	       printf(" nbp = %d > %d \n\n",k,MAXCORD);
	       exit(0);
	     }
}

/*______________________________________________________*/
void format_entree()
{
 printf("\n  inventor_solene_a f_inventor(.iv) f_solene(.cir)  no_version \n");
 printf("\n");   
 printf("   conversion geometrie Inventor (.iv) en fichier Solene (.cir) \n");
 printf("\nNota: version 1: Open Inventor avec s�parateurs espace entre les no de points et [ et ]\n");   
 printf("      version 2: Open Inventor sans s�parateurs espace entre les no de points et [ et ]\n");   
printf("___________________________________________\n\n");
exit(0);
}

/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

//		PROC_OUT_mrt.c											

// J. Vinet 2000,
// D. Groleau janv 2004 
//			dissocie : maillage de scene et maillage support calcul MRT du pi�ton)
//			lit POUR LE MAILLAGE SCENE
//				les temp�ratures de surface
//				les �missivit�s
//			lit POUR LE MAILLAGE PIETON
//				le flux direct
//				le flux diffus
//				les albedos
//				les vitesses d'air (de Fluent)
//				les temp�ratures d'air (de Fluent)
//
// D. Groleau juin 2004  // j'ai enlev� dans "traitement" le test "si dans maille car pas bon toujours"
						 // et donc dans "mrt_moyenneee", on  devrait toujours avoir mrt[contour] != 0.



/*
 procedure complete de calcul des temperatures moyennes radiantes			

 pour un pi�ton (bohomme.cir standard) en n'importe quel point de la scene										
 A partir de l'article de Pickup, J. and de Dear, R. (1999) plus :							
   facteurs de forme pour echanges entre l'individu et son environnement (surfaces et ciel)
   temperatures des surfaces et vitesses de vent deja calculees							
*/


//
#include<solene.h>

// DELARATIONS FUNCTIONS INTERNES
void	usage();
void	lecture();
void	lect_ff_param();


double calcul_fp(double hauteur_soleil); /* calcul du facteur de surface projetee en fonction de la hauteur du soleil */
double calcul_Ia(double vitesse); /* calcul de l'isoation de la couche limite d'air */
double calcul_U(double Ia, double fcl, double Icl); /* calcul de la fraction de rayonnement incident atteignant la peau */
double IR_ciel(double Ta);	/* Modele de ciel dans l'IR */
void	traitement();
double	mrtmoyennee();


// en Global 
FILE *pfacf; /* Lecture du fichier de facteurs de forme */
FILE *pfic_mrt;


/*_________________________________________________________________________________*/
main(argc,argv)           
int argc;
char **argv;
{ 
char *dir_courant;

// Entrees 
char	buf[512];
double hauteur_soleil; // hauteur du soleil en degre 
double *surf_obs;	// valeurs de bonhomme
double *temp_surf;	// valeurs de scene_maille 
double *emissivite; // valeurs de scene_maille
double *dflux_sol_dir;	// valeurs de sol_pieton
double *dflux_sol_dif;	// valeurs de sol_pieton
double *vit_air;		// valeurs de sol_pieton 
double *temp_air;		// valeurs de sol_pieton 
double *albedo;			// valeurs de sol_pieton

// traitement
double *mrt;			// valeurs sur les differents patchs de bonhomme 
double mrt_moy_mail;	// valeurs mrt en une maille
double mrt_moy;			// valeurs mrt en un point pour le bonhomme

float  *facf;			// valeurs de scene_maille (fac forme du bonhomme avec la scene_maillee
double *fac_ciel;		// valeurs du bonhomme


// constantes pour le Bonhomme
const double albedo_indiv=0.3; /* albedo de la surface vetue de l'individu */
const double eps_indiv=1.0; /* coefficient d'�mission de la surface vetue de l'individu */
const double Icl=0.6; /* Isolation des vetements en clo pour un individu en ete */
const double fcl=1.1; /* facteur de surface de vetement */
const double Feff=0.75; /* facteur de surface de rayonnement effective */
const double stefan=5.67e-8; /* Constante de Stefan */
const int option_visee=1; /* pour df_visib: dans le sens de la normale */
const double demi_angle=89.9; /* pour df_visib: demi_angle de vision */
double fp; /* Facteur de surface projetee en fonction de la hauteur du soleil */
double Ia; /* Isolation de la couche limite d'air */
double U;  /* Fraction du rayonnement incident atteignant la peau */

// Autres 
int gnum; /* num�ro du contour o� se situe l'individu */
int k,kk;
int nbfac_ref,nbfac_mail,nbfac_pieton,nomax_ref,nomax_mail,nomax_pieton;
int noface,nb_contour_obs, nb_contour_total, nb_contour_pieton;
double englob[10];
char buf0[1024];

struct modelisation_face *fac_ref,*fac_mail,*fac_pieton;	/* faces */
struct circuit *pcir; /* Pour balayage faces et contours */
struct contour *pcont;		/* id. */

double xgcir, ygcir, zgcir;
int OK_sauvegarde = 0;
int nb_mesure;
double mini,maxi;
FILE *pfic;


/*** Lecture des parametres de la commande ***/

dir_courant=(char *)getenv("PWD");

printf("Fonction solene : proc_mrt_out\n\n");
if (argc!=16)usage();


//________
// Ouverture du fichier HOMME_REF et de ses descripteurs .val
compose_nom_complet(buf,dir_courant,argv[1],"cir");  
if((pfic=fopen(buf,"r"))==NULL)
	{ printf("\n impossible ouvrir %s\n",buf); 
	  exit(0);
	}

lit_en_tete(pfic,&nbfac_ref,&nomax_ref,englob);
fac_ref=alloue_face(nbfac_ref,34);
lit_fic_cir3d(pfic,nbfac_ref,fac_ref);
fclose(pfic);

	// Determination du nombre de contours du fichier hommme_ref 
nb_contour_obs = 0;
for (k=0;k<nbfac_ref;k++)
	{ nb_contour_obs+= nb_contour_face(fac_ref+k,1);
	}
printf("Bonhomme de reference : %s (%d faces, %d contours)\n",buf,nbfac_ref, nb_contour_obs);

desalloue_fface(fac_ref,nbfac_ref); // on en a plus besoin
									// (utiliser seulement dans les commandes externes)


	// Allocations des valeurs relatives au fichier hommme_ref
	surf_obs = alloue_double(nb_contour_obs,1);
	fac_ciel = alloue_double(nb_contour_obs,2);

	// Lecture du fichier des surfaces de l'observateur 
compose_nom_complet(buf,dir_courant,argv[2],"val");
printf("\tFichier des surfaces du bonhomme_ref : %s \n", buf);

lecture(buf,surf_obs);


//________
// Ouverture du fichier SCENE_MAILLEE et de ses descripteurs .val
compose_nom_complet(buf,dir_courant,argv[3],"cir");  
if((pfic=fopen(buf,"r"))==NULL)
	{ printf("\n impossible ouvrir %s\n",buf); 
	  exit(0);
	}

lit_en_tete(pfic,&nbfac_mail,&nomax_mail,englob);
fac_mail=alloue_face(nbfac_mail,35);
lit_fic_cir3d(pfic,nbfac_mail,fac_mail);
fclose(pfic);

	// Determination du nombre de contours du fichier scene_mail 
nb_contour_total = 0;
for (k=0;k<nbfac_mail;k++)
	{ nb_contour_total+=nb_contour_face(fac_mail+k,1);
	}
printf("fichier scene_mail : %s (%d faces, %d contours)\n",buf,nbfac_mail, nb_contour_total);

desalloue_fface(fac_mail,nbfac_mail); // on en a plus besoin
									  // (utiliser seulement dans les commandes externes)

	// Allocations des valeurs relatives au fichier scene_mail 
temp_surf = alloue_double(nb_contour_total,6);
emissivite = alloue_double(nb_contour_total,9);

	// Lecture du fichier des temperature de surfaces de scene_mail
compose_nom_complet(buf,dir_courant,argv[4],"val");
printf("\tFichier temperatures de surface de scene_maillee : %s \n", buf);
lecture(buf,temp_surf); 

	// Lecture du fichier des emissivites de scene_mail
compose_nom_complet(buf,dir_courant,argv[5],"val");
printf("\tFichier emissivite de scene_maillee : %s \n", buf);
lecture(buf,emissivite); 


//________
// Ouverture du fichier SCENE_MASQUE pour voir si existe (utiliser seulement dans les commandes externes)
compose_nom_complet(buf,dir_courant,argv[6],"cir");
if((pfic=fopen(buf,"r"))==NULL)
	{ printf("\n impossible ouvrir %s\n",buf); 
	  exit(0);
	}
fclose(pfic);
printf("scene_masque : %s \n", buf);


//________
// Ouverture du fichier SOL_PIETON_MAILLEE et de ses descripteurs .val
compose_nom_complet(buf,dir_courant,argv[7],"cir");  
if((pfic=fopen(buf,"r"))==NULL)
	{ printf("\n impossible ouvrir %s\n",buf); 
	  exit(0);
	}

lit_en_tete(pfic,&nbfac_pieton,&nomax_pieton,englob);
fac_pieton=alloue_face(nbfac_pieton,35);
lit_fic_cir3d(pfic,nbfac_pieton,fac_pieton);
fclose(pfic);

	// Determination du nombre de contours du fichier sol_pieton 
nb_contour_pieton = 0;
for (k=0;k<nbfac_pieton;k++)
	{ nb_contour_pieton+=nb_contour_face(fac_pieton+k,1);
	}
printf("fichier sol_pieton_maille : %s (%d faces, %d contours)\n",buf,nbfac_pieton, nb_contour_pieton);

	// Allocations des valeurs relatives au fichier sol_pieton 
dflux_sol_dir  = alloue_double(nb_contour_pieton,6);
dflux_sol_dif  = alloue_double(nb_contour_pieton,7);
albedo  = alloue_double(nb_contour_pieton,8);
vit_air  = alloue_double(nb_contour_pieton,9);
temp_air  = alloue_double(nb_contour_pieton,10);


	// Lecture du fichier des direct incident de sol_pieton
compose_nom_complet(buf,dir_courant,argv[8],"val");
printf("\tFichier direct solaire incident de sol_pieton : %s \n", buf);
lecture(buf,dflux_sol_dir); 

	// Lecture du fichier des diffus incident de sol_pieton
compose_nom_complet(buf,dir_courant,argv[9],"val");
printf("\tFichier diffus solaire incident de sol_pieton : %s \n", buf);
lecture(buf,dflux_sol_dif); 

	// Lecture du fichier des albedo de sol_pieton
compose_nom_complet(buf,dir_courant,argv[10],"val");
printf("\tFichier albedo de sol_pieton : %s \n", buf);
lecture(buf,albedo); 

	// Lecture du fichier des vitesses d'air de sol_pieton
compose_nom_complet(buf,dir_courant,argv[11],"val");
printf("\tFichier vitesse d'air de sol_pieton : %s \n", buf);
lecture(buf,vit_air); 

	// Lecture du fichier des temperatures d'air de sol_pieton
compose_nom_complet(buf,dir_courant,argv[12],"val");
printf("\tFichier temperature d'air de sol_pieton : %s \n", buf);
lecture(buf,temp_air); 


//________
// Lecture autres param�tres
sscanf(argv[13],"%lf",&hauteur_soleil);
printf("Hauteur du soleil (degre): %lf\n", hauteur_soleil);

// l'argument ciel.cir  est transmis dans une commande argv[14]
// Ouverture du fichier pour voir si existe (utiliser seulement dans les commandes externes)
compose_nom_complet(buf,dir_courant,argv[14],"cir");
if((pfic=fopen(buf,"r"))==NULL)
	{ printf("\n impossible ouvrir %s\n",buf); 
	  exit(0);
	}
fclose(pfic);
printf("ciel : %s \n", buf);

// ouvre fichier OUT.val et ecrit les resultats en cours de traitement
compose_nom_complet(buf,dir_courant,argv[15],"val");
if((pfic=fopen(buf,"w"))==NULL)
	{ printf("\n impossible ouvrir %s\n",buf); 
	  exit(0);
	}
mini = 100000;maxi = -mini;
fprintf (pfic,"%5d %5d %12.3f %12.3f\n", nbfac_pieton, nomax_pieton, mini, maxi);   


/******************************************************************/
/* Traitement en combinant descripteurs et facteurs de visibilite */
/******************************************************************/

printf("\nDebut du traitement ...\n\n"); 

// en degr� 
fp=calcul_fp(hauteur_soleil); /* calcul du facteur de surface projetee en fonction de la hauteur du soleil */
printf("-->> fp : %lf\n", fp);

gnum =0;
for (noface=0;noface<nbfac_pieton;noface++)
{
  fprintf (pfic,"f%d %d\n",(fac_pieton+noface)->nofac_fichier,nb_contour_face(fac_pieton+noface,1));

  pcont = (fac_pieton+noface)->debut_projete;
  while (pcont)
  {
    pcir = pcont->debut_support;
	
    //  place le bonhomme aux diff�rents points du contour 
		//printf("gnum : %d\n", gnum);
	    mrt_moy_mail=0;
		kk = 0;
//		printf("-->> kk :%d\n", kk);	
		for (k=0; k<pcir->nbp-1;k++)
		{   //printf("-->> k :%d\n", k);
			// position du sommet de la maille etudiee 
			xgcir = pcir->x[k];
			ygcir = pcir->y[k];
			zgcir = pcir->z[k];
			//printf ("xgcir, ygcir, zgcir %lf %lf %lf\n",xgcir,ygcir,zgcir);

			// Translation du bonhomme de reference vers le sommet du contour etudie 
			sprintf(buf0, "translation %s %10.3f %10.3f %10.3f bonhomme_cir",argv[1],xgcir,ygcir,zgcir);
			//printf("%s\n",buf0);		
			system(buf0);

			// ligne de commande pour la procedure df_visib avec surfaces ( visee normale =1)
			sprintf(buf0,"df_visib bonhomme_cir %s %s 89.9 bonhomme_vis 1",argv[3],argv[6]);
			//printf("%s\n",buf0);
			system(buf0);

			// ligne de commande pour la procedure df_visib_facform avec les surfaces	
			sprintf(buf0,"df_visib_facform bonhomme_cir %s bonhomme_vis bonhomme_fac",argv[3]);
			//printf("%s\n",buf0);
			system(buf0);

			system("del bonhomme_vis.vis");

			// lire et affecter les fac de forme pour le bonhomme
			if ((pfacf=fopen("bonhomme_fac.faf","rb"))==NULL)
			{ printf("\n  impossible ouvrir %s\n\n", "bonhomme_fac.faf"); 
			  exit(0);
			}		
			facf = alloue_float(nb_contour_total,10);

			/* ligne de commande pour la procedure facteur de forme avec ciel */  
			sprintf(buf0,"facform_ciel bonhomme_cir %s %s 89.9 bonhomme_fac_ciel",argv[6], argv[14]);
			//printf("%s\n",buf0);
			system(buf0);

			// lire et affecter les fac de ciel pour le bonhomme
		    lecture("bonhomme_fac_ciel.val", fac_ciel);

			// Calculs intermediaires

			Ia=calcul_Ia(vit_air[gnum]); /* calcul de l'isolation de la couche limite d'air */
//			printf("-->> Ia : %lf\n", Ia);
		
			U=calcul_U(Ia,fcl,Icl); /* calcul de la fraction de rayonnement incident atteignant la peau */
//			printf("-->> U : %lf\n", U);
		
			mrt=alloue_double(nb_contour_obs,30);
			// Calcul en ce point pour les diff�rentes faces du bonhomme
			traitement(gnum,temp_air,nb_contour_obs,nb_contour_total,pfacf,facf,fac_ciel,emissivite,temp_surf,mrt);

			// Calcul de la valeur moyenne de la mrt sur la maille (moyenne sur les valeurs obtenues aux sommets)	
			mrt_moy = mrtmoyennee(nb_contour_obs,surf_obs,fp,U,albedo[gnum],dflux_sol_dir[gnum],dflux_sol_dif[gnum],mrt);		
			
			if (mrt_moy == 0)
				{	kk++;
					//printf("-->> kk :%d\n", kk);
				}
			mrt_moy_mail += mrt_moy;

		// delete les tempo
			system("del bonhomme_cir.cir");
			fclose(pfacf);
			system("del bonhomme_fac.faf");
			system("del bonhomme_fac_ciel.val");
			desalloue_double(mrt);

		} // end For fin d'une maille
			
		//printf("-->> k fin de maille :%d\n", k);
		//printf("-->> kk fin de maille :%d\n", kk);


		nb_mesure = pcir->nbp -1 -kk;
		if(nb_mesure) mrt_moy_mail = mrt_moy_mail/nb_mesure;
		else mrt_moy_mail = 0;

		fprintf (pfic," %8.3f\n",mrt_moy_mail);
		//printf("-->> MRT sur la maille : %lf\n", mrt_moy_mail);
	   
		if(mrt_moy_mail < mini) mini = mrt_moy_mail;
	    if(mrt_moy_mail > maxi) maxi = mrt_moy_mail;

	  pcont= pcont->suc;
	  gnum++;
  } // fin While des mailles de la face

}// fin for des faces de sol_pieton

// REecrit l'en-tete de mrt.val
rewind(pfic);
fprintf (pfic,"%5d %5d %12.3f %12.3f\n", nbfac_pieton, nomax_pieton, mini, maxi);   
fclose(pfic);

printf("-->> Fin normale du calcul");

/* desallocation */
// bonhomme
desalloue_double(surf_obs);
desalloue_double(fac_ciel);

// scene_maillee
desalloue_double(emissivite);
desalloue_double(temp_surf);

// sol_pieton
desalloue_double(dflux_sol_dir);
desalloue_double(dflux_sol_dif);
desalloue_double(albedo);
desalloue_double(vit_air);
desalloue_double(temp_air);


//autres
desalloue_fface(fac_pieton,nbfac_pieton); 

	creer_OK_Solene();

}


/*_________________________________________________________________*/
/* Ouverture et lecture fichier au "bon" format (.val) et remplissage tableau 'valeur' */
void lecture(char *nom, double *valeur)
{
	FILE *pfic;

	if ((pfic=fopen(nom,"r"))==NULL)
       {printf("\n  impossible ouvrir %s\n\n", nom); 
		exit(0);}
	
	lect_fic_val(pfic,valeur);

	fclose(pfic);
}

/*_____________________________________________________________________*/
/* Lecture des facteurs de forme dans fichier */

void lect_ff_param(pff, ff, nb_contour, i, j)
FILE *pff;
float *ff;
int nb_contour;
int i; /* Ligne */
int j; /* colonne */
/* Lit une ligne specifiee dans un fichier de facteurs arranges en Fij,i et j variant de 0 a nb_contour-1*/
/* si j positif, donne la seule valeur Fij sinon donne toute la ligne i*/
{
//int f;
//printf("-->> nb_contour : %d\n", nb_contour);
fseek(pff,(i*nb_contour)*sizeof(float),SEEK_SET);
fread(ff, sizeof(float), nb_contour, pff);
/*if (j<0)
	{printf("Ligne %d ", i+1);
	for (f=0;f<nb_contour;f++) printf(" %f ", ligne_ff[f]);
	printf("\n");}
else
	printf("Valeur F de %d vers %d: %f\n", i+1,j+1,ligne_ff[j]); 
	
*/
}

/*_____________________________________________________________________*/
double calcul_fp(double hauteur_soleil)
/* calcul du facteur de surface projettee en fonction de la hauteur du soleil */
{
	double fp;
	double hauteur_soleil_rad;
	double pi;

	pi=4*atan(1.);
	hauteur_soleil_rad=pi*hauteur_soleil/180.;
	fp=(0.42*cos(hauteur_soleil_rad))+(0.043*sin(hauteur_soleil_rad));
	return fp;
}

/*_____________________________________________________________________*/
double calcul_Ia(double vitesse)
/* calcul de l'isolation de la couche limite d'air */

{
	double Ia;

	if (vitesse < 0.1) 
		Ia = 0.7;
	else
		Ia = 0.3767-(0.3225*log10(vitesse)); 

	return Ia;
}

/*_____________________________________________________________________*/
double calcul_U(double Ia, double fcl, double Icl)
/* calcul de la fraction de rayonnement incident atteignant la peau */
{
	double U;

	U= Ia/(fcl*(Icl+(Ia/fcl)));
	return U;
}

/*__________________________________________*/
double IR_ciel(double Ta)
/* Calcul du flux GLO avec le ciel, Ta temperature de l'air ambiant (a la station meteo par exemple) */

{ /* Calcul du flux IR maximum recu en provenance du ciel d'apres modele these J. Noilhan*/
	return (double)(5.5*Ta + 213);
}


/*_____________________________________________________________________*/
void traitement(gnum,temp_air,nb_contour_obs,nb_contour_total,pfacf,facf,fac_ciel,emissivite,temp_surf,mrt)

int gnum;
double *temp_air;
int nb_contour_obs;
int nb_contour_total;
FILE *pfacf;
float *facf;
double *fac_ciel;
double *emissivite;
double *temp_surf;
double *mrt;

{
	// traitement pour un bonhomme (avec ses contours) en un point de la maille

	const double stefan=5.67e-8; /* Constante de Stefan */
	const double eps = 1.; /* Coefficient d'emission du ciel */
	double flux_ciel, Tciel4;
	double sommefacf,sommeff;
	int no_contour_obs, no_contour_test;

	flux_ciel = IR_ciel(temp_air[gnum]);
	//printf("-->> Flux_ciel : %lf\n", flux_ciel);
	Tciel4 = flux_ciel/(stefan*eps);
//	printf("-->> Tciel : %lf\n", pow(Tciel4,0.25)-273);

	for (no_contour_obs=0;no_contour_obs<nb_contour_obs;no_contour_obs++)
		 
	{
		//printf("-->> no_contour_obs : %d\n", no_contour_obs);
		sommefacf=0;

		lect_ff_param(pfacf,facf,nb_contour_total,no_contour_obs,-1);

	 
		for (no_contour_test=0;no_contour_test<nb_contour_total;no_contour_test++)
		{
			mrt[no_contour_obs]+=facf[no_contour_test]*emissivite[no_contour_test]*pow((273.+temp_surf[no_contour_test]), 4.);
//			printf("-->> facf[no_contour_test] : %f\n", facf[no_contour_test]);
			sommefacf+=facf[no_contour_test];
//			printf("-->> temp_surf[no_contour_test] : %lf\n",temp_surf[no_contour_test]);	
//			printf("-->> mrt avec surfaces : %lf\n", pow(mrt[no_contour_obs], 0.25) - 273);
		}
		//printf("-->> Somme des facteurs de forme avec les surfaces : %lf\n",sommefacf);	
		//printf("-->> Facteur de forme avec le ciel : %lf\n", fac_ciel[no_contour_obs]);
		mrt[no_contour_obs] += fac_ciel[no_contour_obs]*eps*Tciel4;

		sommeff =sommefacf+fac_ciel[no_contour_obs]; 
		//printf("-->> Somme des facteurs de forme : %lf\n",sommeff);	
		// Dans le cas du'un scene ouvert la somme des facteurs de formes n'est pas egale a 1
		// il est donc necessaire de diviser le resulat par la somme des facteurs de forme
		// cacules avec les surfaces et avec le ciel pour ne tenir compte que de la scene �tudie
		// de plus il est perferable d'eviter de faire le calcul sur un bord de scene (pieton.val)
// ATTENTION j'ai enlev� : if (sommeff<0.6) mrt[no_contour_obs] = 0.; // pour eviter le cas ou le bonhomme est dans un mur !
//		if (sommeff<0.6) mrt[no_contour_obs] = emissivite[gnum]*pow((273.+temp_surf[gnum]), 4.); // pour eviter le cas ou le bonhomme est dans un mur !
// ATTENTION j'ai enlev� : else mrt[no_contour_obs] = mrt[no_contour_obs]/sommeff;
// ATTENTION ajout
		mrt[no_contour_obs] = mrt[no_contour_obs]/sommeff;
		//printf("-->> mrt : %lf\n\n", pow(mrt[no_contour_obs],0.25)-273.);
	
	}
}

/*_____________________________________________________________________*/
double mrtmoyennee(nb_contour_obs,surf_obs,fp,U,albedo,dflux_sol_dir,dflux_sol_dif,mrt)

int nb_contour_obs;
double *surf_obs;
double *mrt;
double albedo;
double dflux_sol_dir;
double dflux_sol_dif;
double fp, U;

{
	int contour;
	double resul;
	double somme_surf;
	const double stefan=5.67e-8; /* Constante de Stefan */
	const double albedo_indiv=0.3;	
	const double Feff=0.75;


	resul = 0.;
	somme_surf = 0.;

	for(contour=0;contour<nb_contour_obs;contour++)
	{
		if (mrt[contour] != 0.) 
		{
			resul += surf_obs[contour]*mrt[contour];
			somme_surf += surf_obs[contour];
		}
		else
		{		
		// si un contour de l'observateur est dans le mur 
		//le point de la maille n'est pas pris en compte pour le calcul de la mrt sur la maille
		resul =0;
		return resul;
		}

	}
	
		resul = resul/somme_surf;
		//printf("-->> mrt sans soleil: %lf\n", pow(resul,0.25)-273);
//		printf("-->> dflux_sol_dir: %lf\n", dflux_sol_dir);
 		resul += (fp*(1-albedo_indiv)*U*dflux_sol_dir)/(Feff*stefan);
		//printf("-->> mrt avec soleil dir: %lf\n", pow(resul,0.25)-273);
//		printf("-->> dflux_sol_dif: %lf\n", dflux_sol_dif);
		resul += ((1-albedo_indiv)*U*(dflux_sol_dif+(albedo*(dflux_sol_dir+dflux_sol_dif))))/stefan;
//		printf("-->> mrt avec soleil dir+dif: %lf\n", pow(resul,0.25)-273);

		resul = (pow(resul, 0.25) - 273);

		return  resul;

}

/*_____________________________________________________________________*/
void usage()
{	
	printf(" proc_out_mrt \n\n");
		printf("\tIN    bonhomme_ref(.cir)\n");
		printf("\tIN		surfaces_bonhomme(.val) \n");
		printf("\tIN    scene_maillee(.cir)\n");
		printf("\tIN		temperature_de_surface(.val)\n");
		printf("\tIN		emissivite(.val)\n");
		printf("\tIN    scene_masque(.cir)\n");
		printf("\tIN    sol_pieton_maille(.cir)\n"); 
		printf("\tIN		flux_direct_incident(.val)\n");
		printf("\tIN		flux_diffus_incident(.val)\n");
		printf("\tIN		albedo(.val)\n");
		printf("\tIN		vitesse_air(.val)\n");
		printf("\tIN		temperature_air(.val)\n");
		printf("\tIN    hauteur_soleil\n"); 
		printf("\tIN    ciel(.cir)\n"); 
	    printf("\tOUT   mrt_sol_pieton(.val)\n");

 exit(0);
}

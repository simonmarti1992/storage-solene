/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/*____________________________________________________________________________________*/
/*  transitoire_h_options2.c */

// D.GROLEAU juillet 2005

// sur le modele de transitoire_h_options2

// J.Vinet 1999
// modifi� D.Groleau sep 2000 (�paisseurs)
// modifi� D.Groleau nov 2001 (courcircuite le calcul des flux solaires nets, en option)
// modifi� D.Groleau nov 2002 (introduit fichier de paroi,
//							   d�finit pas de temps,
//					    	   mur � une ou 2 couches, ne distingue plus mur et sol)
//                             ATTENTION TEST D'ARRET sur ecart de temperature max obtenu sur une maille
// modifi� D.Groleau mars 2003 (lecture du flux atmosph�rique en entr�e, en option)
// modifi� D.Groleau 4 juin 2003 (supprime le stockage  de Tperm et delta et les remplace par GLOsurf et GLOciel)
// modifi� D.Groleau 6 juin 2003 (supprime le stockage  de Teq  et le remplace par Tsi2)
// modifi� D.Groleau 12 f�vrier 2005 (modifie le calcul du flux net GLO �chang� avec la sc�ne,
//									  en prenant en compte les 2 �missivit�s des faces qui s'�changent)
// modifi� D.Groleau J.Bouyer 11 janvier 2007
//											prise en compte des r�flexions Atmosph�riques et GLO scene
//											et correction calc_GLO

//__________________________________________________________________________________
/*  Calcul des temperatures des murs (interieures et des surfaces) en regime transitoire	       */
/*	Les transferts thermo a�rauliques sont decouples, le coef de convection h est fonction du vent */
/*	Algorithme iteratif: 
																					*/
/*    (&) - lectures des apports solaires (directs + diffus + reflechis) :CLO		*/
/*		  - calcul d'une temperature equivalente au soleil							*/
/*		  - evaluation des echanges de grandes longueurs d'onde : GLO				*/
/* 		  - application du bilan thermique 
                et calcul en regime variable  des nouvelles temperatures		    */
/*			Retour a (&)																					*/
/*				- estimation des flux convectifs															*/
/*----------------------------------------------------------------------*/
/* 	Possibilite de fixer les temperatures de surface 					*/
/* 	pour certaines facettes (Pelouse ou autres ... 						*/
/*----------------------------------------------------------------------*/
/*	Pour le traitement de la conduction il est necessaire de preciser	*/
/*dans un fichier si la surface correspond a un mur (0) ou a un sol (1) */
/*l'�paisseur de chaque couche ainsi que les coefficients thermiques	*/
/*sont d�finis en interne pour le moment (sinon beaucoup de parametres)	*/
/*----------------------------------------------------------------------*/
/*     Les donnees d'entree sont des valeurs, des fichiers .val ou .fac */
/*______________________________________________________________________*/


/*   Rappel ligne de compilation
cc transitoire_h_option.c ./UTILS/solutile.o ./UTILS/lib_solene_94.o ./UTILS/geomutile.o -o transitoire_h_option -lm      */


/* Fichiers inclus */
#include<solene.h>

/* Pointeur global de fichier pour facteurs de forme */
FILE *fp;

// PAROIS
// structure des parois
struct paroi { 
			   int nb_couches;
			   struct materiau *materiau_couches;
				}*pparoi;

struct materiau {
				 double *epaisseur;	            
				 double *lambda;
				 double *cp;
				 double *rho;
		 };

// declarations FUNCTION de PAROIS

void caracteristiques_materiau();
void desalloue_paroi();
void format_entree();
int lit_fic_paroi();
struct paroi *alloue_paroi();
struct materiau *alloue_materiau();
int nb_couches_materiau ();

/* Procedures auxiliaires */
void usage();
void lect_fichier();
void lecture_ff();
void lecture();
void lecture_int();
void	lit_fic_options();
int sauve_tableau();
void test_zeros();
void met_a_zero();

/* Procedure pour radiosite "generalisee" (incluant temperatures) */
int radiog(); 

/* calcul iteratif des temperatures par application de bilans thermiques en regime variable*/
/* avec temperatures fixees pour certaines facettes */

void calc_temp_mur_1_couche( double temp_surf_ext_ini,
				    double temp_surf1_ini,
                    double temp_ref,
					double hint,
					int    no_paroi,
					double Sol_Net,
					double GLO_Total_Net,
					double h,
					double temp_meteo,
					double *Tse,
					double *Tn1,
					double *Tsi1,
					double *temp_perm,
					double Dt);


void calc_temp_mur_2_couches_hint(double temp_surf_ext_ini,
				   double temp_surf1_ini,
				   double temp_surf2_ini,
				   double temp_ref,
				   double hint,
				   int	  no_paroi,
				   double Sol_Net,
				   double GLO_Total_Net,
				   double h,
				   double temp_meteo,
				   double *Tse,
				   double *Tn1,
				   double *Tn2,
				   double *Tsi1,
				   double *Tsi2,
				   double *temp_perm,
				   double Dt);

double calc_temp_eq_mur(double h,
						double temp_meteo,
						double temp_surf1_ini,
						int no_paroi,
						double Sol_Net);
		/* Temperatures au soleil equivalentes utilis�es pour les flux GLO  paroi 1 ou 2 couches*/

double IR_ciel(double Ta);	/* Modele de ciel dans l'IR */

double calc_GLO(double temp_meteo,
				double fciel,
			//janvier 2007
				//double *temp_eq,
				double *tse,
			//Fin 
				float *fform,
				double *emissivite,   // modif 12 fevrier 2005
				int numero_contour_ref,
				int numero_contour_total,
				double flux_atmosphere,
				double *GLO_Ciel_Emis,
				double *GLO_Ciel_Recu,
				double *GLO_Ciel_Net,
				double *GLO_Scene_Emis,
				double *GLO_Scene_Recu,
				double *GLO_Scene_Net,
				double *GLO_Total_Emis,
				double *GLO_Total_Recu);

void tridiag (double *a,
			  double *b,
			  double *c,
			  double *r,
			  double *u,
			  int n);



//_____________________________________________________________________________
main(argc,argv)           
int argc;
char **argv;

{
/********** DECLARATIONS DE VARIABLES **********/
// 

#define NBLIGNES_OPTION_RESULTAT 19  // � mettre � jour

/* En entree */
double	temp_meteo;
char	nom_temp_surf_ext_ini[256]; /* fichier des temperatures initiales a l'exterieur du mur, en Celsius */
double	*temp_surf_ext_ini; /* valeurs Tse(t-1)*/
char	nom_temp_surf1_ini[256]; /* fichier des temperatures initiales a l'interieur du mur et a l'interieur de la 1ere couche de sol, en Celsius */
double *temp_surf1_ini; /* valeurs Tn1(t-1)*/
char nom_temp_surf2_ini[256]; /* fichier des temperatures initiales a l'interieur de la 2eme couche de sol, en Celsius */
double *temp_surf2_ini; /* valeurs Tn2(t-1)*/
char nom_temp_ref[256]; /* fichier des temperatures de reference (a 1 m dans le sol T=Tair_moy sur 1 jour, Tint = constante (clim), valeurs en Celsius */
double *temp_ref; /* valeurs */
char nom_temp_fix[256]; /* fichier (lu) pour temperatures fixees */
double *temp_fix; /* temperatures fixees (1 temp fix�e =Tair, sinon calcul�e) */

char nom_CLO[256]; /* fichier des densites de flux CLO */
double *CLO; /* valeurs */
char nom_albedo[256]; /* fichier (lu) pour albedo dans le "solaire" (visible + PIR) */
double *albedo; /* valeurs */
char nom_emissivite[256]; /* fichier (lu) pour coefficient d'emission infrarouge */
double *emissivite; /* valeurs */
double *reflexivite; //janvier 2007  pour calcul r�flexion Atmospherique dans la sc�ne

char nom_paroi[256]; /* fichier (lu) pour les no de parois */
double *no_paroi; /* valeurs */
char nom_h[256]; /* fichier (lu) des coefficients d'�change convectif */
double *h; /* valeurs */
char nom_hint[256]; /* fichier (lu) des coefficients d'�change inter�rieur (convectif+radiatif) */
double *hint; /* valeurs */
char nom_surf[256]; /* fichier (lu) pour surfaces des facettes */
double *surf; /* valeurs */
char nom_fform[256]; /* fichier (lu) pour facteurs de forme */
float *fform; /* valeurs */
char nom_fciel[256]; /* fichier (lu) pour fractions de ciel vu (entre 0 et 1) */
double *fciel; /* valeurs */

char nom_fic_paroi[256]; /* fichier (lu) contenant les parois */

/* En sortie */
char nom_Tse[256]; /* fichier (cree) des temperatures des surfaces exterieures calculees, en regime variable, en Celsius */
double *Tse; /* valeurs */
char nom_Tn1[256]; /* fichier (cree) des temperatures a l'interieur du mur, en regime variable, en Celsius */
double *Tn1; /* valeurs */
char nom_Tn2[256]; /* fichier (cree) des temperatures a l'interieur du sol au milieu de la 2eme couche, en regime variable, en Celsius */
double *Tn2; /* valeurs */

/* En options */
char nom_tsi1[256]; /* fichier (cree) des temperatures des surfaces interieures calculees, en regime variable, en Celsius */
double *Tsi1; /* valeurs */
char nom_tsi2[256]; /* fichier (cree) des temperatures des surfaces interieures de la 2 eme couche */
double *Tsi2; /* valeurs */

//char nom_temp_eq[256]; /* temperature equivalente au soleil */
double *temp_eq; /* valeurs */
//char nom_temp_perm[256]; /* temperature equivalente au soleil */
double *temp_perm; /* valeurs */
//char nom_delta[256]; /* temperature equivalente au soleil */
double *delta; /* valeurs */

char	nom_GLO_Ciel_Emis[256]; /* fichier des densites de flux GLO �mis le ciel */
double *GLO_Ciel_Emis;			/* valeurs */
char	nom_GLO_Ciel_Recu[256]; /* fichier des densites de flux GLO recu du ciel */
double *GLO_Ciel_Recu;			/* valeurs */
char	nom_GLO_Ciel_Net[256];	/* fichier des densites de flux GLO Net �chang� avec le ciel */
double *GLO_Ciel_Net;			/* valeurs */


char	nom_GLO_Scene_Emis[256]; /* fichier des densites de flux GLO �mis vers les surfaces */
double *GLO_Scene_Emis;			 /* valeurs */
char	nom_GLO_Scene_Recu[256]; /* fichier des densites de flux GLO re�u des surfaces */
double *GLO_Scene_Recu;			 /* valeurs */
char	nom_GLO_Scene_Net[256]; /* fichier des densites de flux GLO �chang� avec les surfaces */
double *GLO_Scene_Net;			/* valeurs */

char nom_GLO_Total_Emis[256];	/* fichier des densites de flux GLO TOTAL �mis */
double *GLO_Total_Emis;			/* valeurs */
char nom_GLO_Total_Recu[256];	/* fichier des densites de flux GLO TOTAL re�u */
double *GLO_Total_Recu;			/* valeurs */
char nom_GLO_Total_Net[256];	/* fichier des densites de flux GLO TOTAL net*/
double *GLO_Total_Net;			/* valeurs */

char nom_CONV[256];				/* fichier des densites de flux CONv, chaleur sensible */
double *CONV;					/* valeurs */

char nom_Sol_Ciel_Reflechi[256]; /* fichier (cree) des densites de flux solaires r�fl�chis vers le ciel*/
double *Sol_Ciel_Reflechi;		// valeurs = fciel * alb�do * Incident apr�s r�flexion
char nom_Sol_Scene_Apport[256]; /* fichier (cree) des densites de flux solaires absorb�s en provenance de la sc�ne*/
double *Sol_Scene_Apport;		// valeurs = (1-alb�do) * (Incident apr�s r�flexion - Incident avant r�flexion)
char nom_Sol_Net[256];			/* fichier (cree) des densites de flux nettes (absorbees)solaires */
double *Sol_Net;				/* valeurs */



double Dt; // pas de temps en secondes defini en parametre

double flux_atmosphere; // possiblement fourni en entr�e (ou alors calcul� par formule de Monteith


/* Coefficients et constantes d�finis en interne  */

const double stefan = 5.67e-8;
const double TINY = 1.0e-20; // valeur petite
const double temp_fixe = 1.; // convention: 
//si la valeur de temp_fixe est egale a 0, alors la temperature doit etre calculee -
//sinon 1, elle est fixee a la valeur de la temp�rature de l'air meteo

/* Criteres d'arret pour procedure iterative de calcul des temperatures */
double *temp_surf_ext_iter;
double *temp_surf_perm_iter;
const double delta_T_lim = 0.1; 
double delta_temp_surf_var;
double delta_temp_surf_perm;
double delta_max;

/* Variables auxiliaires */
char *s_dir, c;
int gi, gnum, gk, nofac, nbcont;
double val_min, val_max;
double *auxiliaire;
int test_erreur = 0;
int OK_sauvegarde = 0;
int nbfac;		/* Nombre de faces dans modele geometrique */
int nb_contour_total; 	/* Nombre de contours total */
int *nb_cont_face;	/* Nombre de contours par face */
int *numero_face;	/* Numeros affectes aux faces */
int im = 1;		/* impression=oui */
double *exit_init;	/* Exitances (ou radiosites) initiales */
double *exit;		/* Exitances (ou radiosites) calculees */
int flag_arret = 2;	/* Arret quand moins de x% de l'energie initiale */
int epsilon = 100;		/* Si flag_arret = 1 */
double pourc = 0.1;		/* Si flag_arret = 2 */
double seuil = 1;		/* Si flag_arret = 3 */
int nb_iter_max =100;	/* Si flag_arret = 4 */
int no_iter;

int calcule, calcul_flux_net;
int nb_paroi;     // nb de parois d�finies dans le fichier des parois

/* Pointeur de fichier pour lecture descripteurs */
FILE *pfic;

// Nouvelles Declarations de Variable
//int i;
char	buf[256], nom_GEN[64];
int option_resultats[NBLIGNES_OPTION_RESULTAT];

char *ext_periode_heure;


// DEBUT PROG **********/

///____________________________________________

s_dir=(char *)getenv("PWD");

if (argc !=25) usage();

printf("Transitoire_h_option2\n\n",argc);
printf("nb arguments = %d\n",argc);


/// *** Lecture du fichier OPTION DE CALCUL : 

compose_nom_complet(buf,s_dir,argv[23],"txt");
printf("Fichier_Options de Calcul dans : %s \n", buf);
// � lire et interpr�ter


/// *** Lecture du fichier OPTION DE RESULTATS : NBLIGNES_OPTION_RESULTAT lignes � lire (� mettre � jour)

compose_nom_complet(buf,s_dir,argv[24],"txt");
printf("Fichier_Options de Resultats dans : %s \n", buf);
if ((pfic=fopen(buf,"r"))==NULL)
	{printf("\n  impossible ouvrir %s\n\n", buf); 
	 goto fin;
	}
lit_fic_options(pfic,NBLIGNES_OPTION_RESULTAT,option_resultats,nom_GEN);
fclose(pfic);

//printf("nom gen : %s\n",nom_GEN);
//for (i=1;i<NBLIGNES_OPTION_RESULTAT;i++) printf("%d\n",option_resultats[i]);


// *** initialisation ***
calcul_flux_net =1;			// calcule le flux net



// *** lecture parametres commande ***

// en INPUT
sscanf(argv[1], "%lf", &temp_meteo);
printf("Temperature meteo (C) : %lf\n", temp_meteo);

//calcul de le t de ciel utilis�e p140 th�se vinet pour Info utilisateur
//A VOIR

compose_nom_complet(nom_temp_surf_ext_ini,s_dir,argv[2],"val");
printf("Temperatures exterieures initiales : %s \n", nom_temp_surf_ext_ini);

compose_nom_complet(nom_temp_surf1_ini,s_dir,argv[3],"val");
printf("Temperatures initiales dans les murs et dans la 1 ere couche de sol : %s \n", nom_temp_surf1_ini);

compose_nom_complet(nom_temp_surf2_ini,s_dir,argv[4],"val");
printf("Temperatures initiales dans la deuxieme couche de sol : %s \n", nom_temp_surf2_ini);

compose_nom_complet(nom_temp_ref,s_dir,argv[5],"val");
printf("Temperatures de reference (dans les batiments et le sol): %s \n", nom_temp_ref);

compose_nom_complet(nom_temp_fix,s_dir,argv[6],"val");
printf("Temperatures fixees : %s \n", nom_temp_fix);

compose_nom_complet(nom_CLO,s_dir,argv[7],"val");
printf("Apports CLO : %s \n", nom_CLO);

compose_nom_complet(nom_albedo,s_dir,argv[8],"val");
printf("Coefficients d albedo : %s \n", nom_albedo);

compose_nom_complet(nom_emissivite,s_dir,argv[9],"val");
printf("Coefficients d emissivite : %s \n", nom_emissivite);

compose_nom_complet(nom_paroi,s_dir,argv[10],"val");
printf("no de paroi : %s \n", nom_paroi);

compose_nom_complet(nom_h, s_dir, argv[11], "val");
printf("Coefficients d echange convectif ext�rieur: %s\n", nom_h);

compose_nom_complet(nom_hint, s_dir, argv[12], "val");
printf("Coefficients d echange int�rieur: %s\n", nom_hint);

compose_nom_complet(nom_surf,s_dir,argv[13],"val");
printf("Surfaces facettes: %s \n", nom_surf);

compose_nom_complet(nom_fform,s_dir,argv[14],"fac");
printf("Facteurs de forme: %s \n", nom_fform);

compose_nom_complet(nom_fciel,s_dir,argv[15],"val");
printf("Facteurs de forme avec le ciel: %s \n", nom_fciel);

sscanf(argv[16], "%lf", &Dt);
printf("pas de temps en secondes : %f\n", Dt);

compose_nom_complet(nom_fic_paroi,s_dir,argv[17],"txt");
printf("Fichier des parois: %s \n", nom_fic_paroi);

 
printf("  ---------------------------------\n");


// en OUTPUT obligatoires  Tse (surf ext) Tn1 (noeud paroi couche 1) Tn2 (noeud paroi couche 2)

compose_nom_complet(nom_Tse,s_dir,argv[18],"val");
printf("Temperatures des surfaces exterieures calculees (C): %s \n", nom_Tse);

// extraction de l'heure dans "ext_periode_heure" dans le nom de Tse fourni en argument 18

ext_periode_heure= argv[18] + (strlen(argv[18]) -8);  // extrait les 8 derniers caract�res de la chaine argv[18]
printf("Periode_Heure de la simulation : %s\n", ext_periode_heure);

compose_nom_complet(nom_Tn1,s_dir,argv[19],"val");
printf("Temperatures internes des murs calculees (C): %s \n", nom_Tn1);

compose_nom_complet(nom_Tn2,s_dir,argv[20],"val");
printf("Temperatures internes dans la 2eme couche de sol calculees (C): %s \n",nom_Tn2);


// en OUTPUT facultatif suivant OPTIONS_RESULTATS

	if(option_resultats[4]==1)
	{ sprintf(buf,"%sTsi1_%s",nom_GEN,ext_periode_heure);
	  compose_nom_complet(nom_tsi1,s_dir,buf,"val");
	  printf("Stocke Tsi1: %s \n", nom_tsi1);
	}
	
	if(option_resultats[5]==1)
	{ sprintf(buf,"%sTsi2_%s",nom_GEN,ext_periode_heure);
	  compose_nom_complet(nom_tsi2,s_dir,buf,"val");
	  printf("Stocke Tsi2: %s\n", nom_tsi2);
	}

	if(option_resultats[6]==1)
	{ sprintf(buf,"%sGLO_Ciel_Emis_%s",nom_GEN,ext_periode_heure);
	  compose_nom_complet(nom_GLO_Ciel_Emis,s_dir,buf,"val");
	  printf("Stocke GLO_Ciel_Emis: %s\n", nom_GLO_Ciel_Emis);
	}

	if(option_resultats[7]==1)
	{ sprintf(buf,"%sGLO_Ciel_Recu_%s",nom_GEN,ext_periode_heure);
	  compose_nom_complet(nom_GLO_Ciel_Recu,s_dir,buf,"val");
	  printf("Stocke GLO_Ciel_Recu: %s \n", nom_GLO_Ciel_Recu);
	}
																
	if(option_resultats[8]==1)
	{ sprintf(buf,"%sGLO_Ciel_Net_%s",nom_GEN,ext_periode_heure);
	  compose_nom_complet(nom_GLO_Ciel_Net,s_dir,buf,"val");
	  printf("Stocke GLO_Ciel_Net: %s \n", nom_GLO_Ciel_Net);
	}
																

	if(option_resultats[9]==1)
	{ sprintf(buf,"%sGLO_Scene_Emis_%s",nom_GEN,ext_periode_heure);
	  compose_nom_complet(nom_GLO_Scene_Emis,s_dir,buf,"val");
	  printf("Stocke GLO_Scene_Emis: %s \n", nom_GLO_Scene_Emis);
	}
								

	if(option_resultats[10]==1)
	{ sprintf(buf,"%sGLO_Scene_Recu_%s",nom_GEN,ext_periode_heure);
	  compose_nom_complet(nom_GLO_Scene_Recu,s_dir,buf,"val");
	  printf("Stocke GLO_Scene_Recu: %s \n", nom_GLO_Scene_Recu);
	}
																
	if(option_resultats[11]==1)
	{ sprintf(buf,"%sGLO_Scene_Net_%s",nom_GEN,ext_periode_heure);
	  compose_nom_complet(nom_GLO_Scene_Net,s_dir,buf,"val");
	  printf("Stocke GLO_Scene_Net: %s\n", nom_GLO_Scene_Net);
	}

	if(option_resultats[12]==1)
	{ sprintf(buf,"%sGLO_Total_Emis_%s",nom_GEN,ext_periode_heure);
	  compose_nom_complet(nom_GLO_Total_Emis,s_dir,buf,"val");
	  printf("Stocke GLO_Total_Emis: %s \n", nom_GLO_Total_Emis);
	}
															
	if(option_resultats[13]==1)
	{ sprintf(buf,"%sGLO_Total_Recu_%s",nom_GEN,ext_periode_heure);
	  compose_nom_complet(nom_GLO_Total_Recu,s_dir,buf,"val");
	  printf("Stocke GLO_Total_Recu: %s \n", nom_GLO_Total_Recu);
	}
																
	if(option_resultats[14]==1)
	{ sprintf(buf,"%sGLO_Total_Net_%s",nom_GEN,ext_periode_heure);
	  compose_nom_complet(nom_GLO_Total_Net,s_dir,buf,"val");
	  printf("Stocke GLO_Total_Net: %s\n", nom_GLO_Total_Net);
	}

	if(option_resultats[15]==1)
	{ sprintf(buf,"%sConv_%s",nom_GEN,ext_periode_heure);
	  compose_nom_complet(nom_CONV,s_dir,buf,"val");
	  printf("Stocke Conv: %s\n", nom_CONV);
	}

	if(option_resultats[16]==1)
	{ sprintf(buf,"%sSol_Ciel_Reflechi_%s",nom_GEN,ext_periode_heure);
	  compose_nom_complet(nom_Sol_Ciel_Reflechi,s_dir,buf,"val");
	  printf("Stocke Sol_Ciel_Reflechi: %s \n", nom_Sol_Ciel_Reflechi);
	}																

	if(option_resultats[17]==1)
	{ sprintf(buf,"%sSol_Net_%s",nom_GEN,ext_periode_heure);
	  compose_nom_complet(nom_Sol_Net,s_dir,buf,"val");
	  printf("Stocke Sol_Net: %s \n", nom_Sol_Net);
	}

	if(option_resultats[18]==1)
	{ sprintf(buf,"%sSol_Scene_Apport_%s",nom_GEN,ext_periode_heure);
	  compose_nom_complet(nom_Sol_Scene_Apport,s_dir,buf,"val");
	  printf("Stocke Sol_Scene_Apport: %s \n", nom_Sol_Scene_Apport);
	}


   // INPUT 

  printf("  ---------------------------------\n");
  sscanf(argv[21], "%d", &calcul_flux_net); // evalue (1) ou non (0) les flux nets
  if(calcul_flux_net)   printf("le flux solaire net est � calculer\n");
  else printf("le flux solaire net est donn� en entr�e\n");


   // INPUT  du FLUX en provenance de l'ATMOSPHERE // fevrier 2005
  sscanf(argv[22], "%lf", &flux_atmosphere); // le flux en provenance de l'atmosph�re est connu
  printf("le flux atmosph�rique est donn� en entr�e\n");

/* si NON
{  printf("le flux atmosph�rique est calcul� par la formule de Montheit\n");
   // Calcul du flux GLO echange avec le ciel si pas donn� en entr�e 
   flux_atmosphere = IR_ciel(temp_meteo);
}
*/

printf("Flux en provenace de l'atmosph�re : %f\n",flux_atmosphere);


printf("  ---------------------------------\n");


/* LECTURE D'UN FICHIER .val POUR �valuer le NBRE DE CONTOURS TOTAL */
// et le nombre de contours par face
/* Lecture du fichier des densites de flux incident CLO  */
nb_contour_total= 0;
if ((pfic=fopen(nom_CLO,"r"))==NULL)
	{printf("\n  impossible ouvrir %s\n\n", nom_CLO); 
	 goto fin;}
fscanf(pfic,"%d %d %lf %lf",&nbfac,&nomax,&val_min,&val_max);	
numero_face=(int *)malloc(nbfac*sizeof(int));
nb_cont_face=(int *)malloc(nbfac*sizeof(int));
for(gi=0;gi<nbfac;gi++)
	{fscanf(pfic,"\n%c%d%d\n",&c,&nofac,&nbcont);
	 numero_face[gi]=nofac;
	 nb_cont_face[gi]=nbcont;
	 nb_contour_total+=nbcont;
	 auxiliaire=(double *)malloc(nbcont*sizeof(double));
	 for(gk=0;gk<nbcont;gk++) fscanf(pfic,"%lf\n",auxiliaire+gk);
	 free(auxiliaire);}
fclose(pfic);
printf("  ---------------------------------\n");
printf("nombre total de contours: %d\n", nb_contour_total);	

/* allocations memoire */
temp_surf_ext_ini = alloue_double(nb_contour_total,1);
temp_surf1_ini = alloue_double(nb_contour_total,2);
temp_surf2_ini = alloue_double(nb_contour_total,3);
temp_ref = alloue_double(nb_contour_total,4);
temp_fix = alloue_double(nb_contour_total,5);

CLO = alloue_double(nb_contour_total,7);
albedo = alloue_double(nb_contour_total,8);
emissivite = alloue_double(nb_contour_total,9);
reflexivite = alloue_double(nb_contour_total,19); //janvier 2007
no_paroi = alloue_double(nb_contour_total,29);
h = alloue_double(nb_contour_total,13);
hint = alloue_double(nb_contour_total,13);
surf = alloue_double(nb_contour_total,14);
fform = alloue_float(nb_contour_total,15);
fciel =alloue_double(nb_contour_total,16);
temp_eq = alloue_double(nb_contour_total,22);
temp_perm = alloue_double(nb_contour_total,23);
delta = alloue_double(nb_contour_total,24);
exit_init =alloue_double(nb_contour_total,27);
exit =alloue_double(nb_contour_total,28);

// alloue les resultats choisis quelque soit l'option

	 Tse= alloue_double(nb_contour_total,30);
	 Tn1= alloue_double(nb_contour_total,30);
	 Tn2= alloue_double(nb_contour_total,30);
	 Tsi1= alloue_double(nb_contour_total,30);
	 Tsi2= alloue_double(nb_contour_total,30);

     GLO_Ciel_Emis= alloue_double(nb_contour_total,30);
     GLO_Ciel_Recu= alloue_double(nb_contour_total,30);
     GLO_Ciel_Net= alloue_double(nb_contour_total,30);
     GLO_Scene_Emis= alloue_double(nb_contour_total,30);
     GLO_Scene_Recu= alloue_double(nb_contour_total,30);
     GLO_Scene_Net= alloue_double(nb_contour_total,30);
     GLO_Total_Emis= alloue_double(nb_contour_total,30);
     GLO_Total_Recu= alloue_double(nb_contour_total,30);
     GLO_Total_Net= alloue_double(nb_contour_total,30);
	 CONV = alloue_double(nb_contour_total,25);
     Sol_Ciel_Reflechi= alloue_double(nb_contour_total,30);
     Sol_Net= alloue_double(nb_contour_total,30);
     Sol_Scene_Apport= alloue_double(nb_contour_total,30);


printf("OK toutes allocations\n");


/*** LECTURE DES FICHIERS POUR DONNEES ***/

/*** Lecture des fichiers .val ***/
lecture(nom_temp_surf_ext_ini,temp_surf_ext_ini);	/* Lecture des temperatures de surface initiales */
lecture(nom_temp_surf1_ini,temp_surf1_ini);			/* Lecture des temperatures 1 initiales */
lecture(nom_temp_surf2_ini,temp_surf2_ini);			/* Lecture des temperatures 2 initiales */
lecture(nom_temp_ref,temp_ref);						/* Lecture des temperatures de reference */
lecture(nom_temp_fix,temp_fix);						/* Lecture des temperatures fixees */
lecture(nom_CLO,CLO);								/* Lecture du fichier des densites de flux solaire direct  */
if(calcul_flux_net==0)				// les flux nets sont connus et donnes en entree
for (gnum=0;gnum<nb_contour_total;gnum++)
{ Sol_Net[gnum]=CLO[gnum];
}
lecture(nom_albedo,albedo); /* Lecture des albedos */
lecture(nom_emissivite,emissivite); /* Lecture des emissivites */
lecture(nom_paroi,no_paroi); /* Lecture des no de parois */
lecture(nom_h,h); /* Lecture des h */
lecture(nom_hint,hint); /* Lecture des h globaux int�rieurs */
lecture(nom_surf,surf); /* Lecture du fichier des surfaces */
if ((fp=fopen(nom_fform,"rb"))==NULL) /* Lecture des facteurs de forme */
{printf("\n  impossible ouvrir %s\n\n", nom_fform); goto fin;}
lecture(nom_fciel,fciel); /* Lecture de facteurs de formes avec le ciel */

// lecture du fichier des parois
printf("  ---------------------------------\n");
nb_paroi = lit_fic_paroi(nom_fic_paroi);
printf("nb de parois dans fichier parois = %d\n", nb_paroi);
printf("OK lecture\n");


// ETAPE 1
//--------
/*** CALCUL ET STOCKAGE DES FLUX NETS DANS LA BANDE SOLAIRE (VISIBLE + PIR) ***/

/* RADIOSITE : METHODE A RAFFINEMENT PROGRESSIF */
printf("  ---------------------------------\n");
printf("\nDebut du calcul ...\n");

if(calcul_flux_net)
{
 printf("Calcul du flux solaire absorbe net\n");
 printf("(bande visible+proche IR)\n");
 /* Initialisation densite de flux partant */
 calcule=0;
 for (gnum = 0; gnum < nb_contour_total; gnum++)
 {  
	exit_init[gnum] = CLO[gnum]*albedo[gnum];
	if(	exit_init[gnum]) calcule=1;
	exit[gnum] = 0.0;
 }
 /* Lancement iterations */
 if(calcule)
 {
  im = 0;

  test_erreur = radiog(im, nb_cont_face, numero_face, nbfac, nb_contour_total, exit_init, surf, albedo, fform, flag_arret, pourc, exit);
  /* A ce stade: exitance = radiosite = densite de flux partant de chaque facette, dans la bande visible + PIR */
  //printf("ok\n");

  for (gnum = 0;gnum<nb_contour_total;gnum++)
	{//janvier 2007
	  if(albedo[gnum])
	  {Sol_Net[gnum] = ((1/albedo[gnum]) - 1.0)*exit[gnum];}
	  else
	  {printf("PB : l'alb�do ne doit pas �tre �gale � 0\n");
	   goto pb;;
	  }
     // Fin janvier 2007

     //	 printf("\nSol_Net[gnum]:%lf",Sol_Net[gnum]);
	 
	 Sol_Ciel_Reflechi[gnum] = fciel[gnum]*exit[gnum];									//rajout aout 2005
	 Sol_Scene_Apport[gnum] = (1.0-albedo[gnum])*((exit[gnum]/albedo[gnum])-CLO[gnum]); //rajout aout 2005
	} 
 }
 //janvier 2007
 else //pas de flux reflechi
 {
  for (gnum = 0;gnum<nb_contour_total;gnum++)
	{Sol_Net[gnum] = CLO[gnum]*(1-albedo[gnum]);
     //	 printf("\nSol_Net[gnum]:%lf",Sol_Net[gnum]);
	 Sol_Ciel_Reflechi[gnum] = 0;									
	 Sol_Scene_Apport[gnum] = 0; 
	}
 }
// Fin janvier 2007
}
/* ecriture directe du fichier resultat: densite de flux solaire absorbe */
	if(option_resultats[17]==1)
	{ printf("\n>>> Sauvegarde de Sol_Net (flux solaires absorbes)  ... \n");
	  OK_sauvegarde = sauve_tableau(nom_Sol_Net, nbfac, nomax, nb_contour_total, numero_face, nb_cont_face,Sol_Net);
	  if (!OK_sauvegarde)
	  {printf("*** Attention, probleme de sauvegarde pour les flux solaires nets. ***\n");
	   goto fin;
	  }
	} 

// ecriture directe du fichier resultat: densite de flux solaire reflechi vers ciel (aout 2005)
	if(option_resultats[16]==1)
	{ printf("\n>>> Sauvegarde de Sol_Ciel_Reflechi (flux solaires reflechis vers le ciel)  ... \n");
	  OK_sauvegarde = sauve_tableau(nom_Sol_Ciel_Reflechi, nbfac, nomax, nb_contour_total, numero_face, nb_cont_face,Sol_Ciel_Reflechi);
	  if (!OK_sauvegarde)
	  {printf("*** Attention, probleme de sauvegarde pour les flux solaires reflechis vers le ciel. ***\n");
	   goto fin;
	  }
	}

// ecriture directe du fichier resultat: densite de flux solaire absorbes provenant des intereflexions dans la scene (aout 2005)
	if(option_resultats[18]==1)
	{ printf("\n>>> Sauvegarde de Sol_Scene_Apport (flux solaires absorbes provenant des intereflexions dans la scene)  ... \n");
	  OK_sauvegarde = sauve_tableau(nom_Sol_Scene_Apport, nbfac, nomax, nb_contour_total, numero_face, nb_cont_face,Sol_Scene_Apport);
	  if (!OK_sauvegarde)
	  {printf("*** Attention, probleme de sauvegarde pour les flux solaires provenant des intereflexions dans la scene. ***\n");
	   goto fin;
	  }
	}

// Janvier 2007

/*** CALCUL DES FLUX ATMOSPHERIQUE RECU apr�s Reflexion ***/

/* RADIOSITE : METHODE A RAFFINEMENT PROGRESSIF */
printf("  ---------------------------------\n");

 printf("Calcul du flux atmosph�rique absorbe net (apr�s reflexion)\n");
 /* Initialisation densite de flux partant */
 calcule=0;
 for (gnum = 0; gnum < nb_contour_total; gnum++)
 {  
	 reflexivite[gnum]= 1-emissivite[gnum];
	 exit_init[gnum] = reflexivite[gnum] * fciel[gnum] *flux_atmosphere ;
	if(	exit_init[gnum]) calcule=1;
	exit[gnum] = 0.0;
 }
 /* Lancement iterations */
 if(calcule)
 {
  im = 0;

  test_erreur = radiog(im, nb_cont_face, numero_face, nbfac, nb_contour_total, exit_init, surf, reflexivite, fform, flag_arret, pourc, exit);
  /* A ce stade: exitance = radiosite = densite de flux partant de chaque facette */
  //printf("ok\n");

  for (gnum = 0;gnum<nb_contour_total;gnum++)
  { if(reflexivite[gnum])
	{GLO_Ciel_Recu[gnum] = ((1/reflexivite[gnum]) - 1.0)*exit[gnum];}
	else
	{printf("PB : l'�missivit� ne doit pas �tre �gale � 1\n");
	 goto pb;
	}
     //	 printf("\nGLO_Ciel_Recu[gnum]:%lf",GLO_Ciel_Recu[gnum]);
  } 
 }

 else // alors, les emissivit�s de toutes les parois sont � 1
  {
	for (gnum = 0;gnum<nb_contour_total;gnum++)
	{ GLO_Ciel_Recu[gnum] = emissivite[gnum] * fciel[gnum] *flux_atmosphere ;
     //	 printf("\nGLO_Ciel_Recu[gnum]:%lf",GLO_Ciel_Recu[gnum]);
	} 
  }
// Fin Janvier 2007

met_a_zero(nb_contour_total, exit_init);
met_a_zero(nb_contour_total, exit);



// ETAPE 2
//--------
/*** CALCUL DES DIFFERENTES TEMPERATURES	***/
printf("  ---------------------------------\n");
printf("\nTraitement en cours ...\n\n");

/*** Calcul des temperatures equivalentes au soleil pour initialisation des flux GLO_Total_Net ***/
printf("\nCalcul des temperatures equivalentes ...");

// Test sur les surfaces: temperatures fixees, sinon mur ou paroi
for (gnum = 0;gnum<nb_contour_total;gnum++)
{
	if (temp_fix[gnum] == temp_fixe) 
	{ // la temperature est fixee 
	  	temp_eq[gnum]=temp_meteo;  // prend la valeur de l'air exterieur
		//temp_eq[gnum]=temp_fix[gnum];  // prend valeur du fichier tfix
	}
	else 
	{ // calcul Teq
		gi = (int)no_paroi[gnum];
		if (gi>nb_paroi)
		{ printf("pb de numero de paroi : %d> nb de parois du fichier parois (%d)\n",gi,nb_paroi);
		  goto fin;
		}
		temp_eq[gnum]=calc_temp_eq_mur(h[gnum],temp_meteo,temp_surf1_ini[gnum],gi,Sol_Net[gnum]);
	}
}

// allocation temporaire des vecteurs des temperatures de surface subissant les iterations

temp_surf_ext_iter = alloue_double(nb_contour_total,30);
temp_surf_perm_iter = alloue_double(nb_contour_total,31);

// initialisation des temperatures iteratives de surfaces a la valeur la temperature equivalente au soleil
for (gnum = 0;gnum<nb_contour_total;gnum++)
{temp_surf_ext_iter[gnum]=temp_eq[gnum];
 temp_surf_perm_iter[gnum]=temp_eq[gnum];}
		
// initialisation du critere d'arret sur les temperatures de surface
delta_temp_surf_var = 0.0;
delta_temp_surf_perm = 0.0;
delta_max=1;
no_iter=0;


// ITERATIONS

//while (delta_temp_surf_var < TINY || delta_temp_surf_var > delta_T_lim || delta_temp_surf_perm < TINY || delta_temp_surf_perm > delta_T_lim || delta_max > 0.1) // Critere d'arret
while (delta_max >0.1)
{ printf("\nCalcul des flux GLO_Total_Net  _ iteration %d",no_iter++);

  delta_temp_surf_var = 0.0;
  delta_temp_surf_perm = 0.0;
  delta_max =0;

	for (gnum = 0;gnum<nb_contour_total;gnum++)
	{
	 /*** CALCUL DES FLUX GLO_Total_Net (avec ciel et avec les autres surfaces) ***/

	   // modif 12/02/2005
		GLO_Total_Net[gnum] = calc_GLO(temp_meteo,fciel[gnum],temp_surf_ext_iter,fform,emissivite,gnum,nb_contour_total,flux_atmosphere,GLO_Ciel_Emis,GLO_Ciel_Recu,GLO_Ciel_Net,GLO_Scene_Emis,GLO_Scene_Recu,GLO_Scene_Net,GLO_Total_Emis,GLO_Total_Recu);
	}	

	 /*** CALCUL DES TEMPERATURES DE SURFACE ***/

	printf("\nCalcul des temperatures de surface");
	for (gnum = 0;gnum<nb_contour_total;gnum++)
	{
		// Test sur les surfaces: temperatures fixees sinon mur ou paroi

		if (temp_fix[gnum] == temp_fixe) // la temperature est fixee � t air (tmeteo)
		{ 
								//printf(" temp fixe gnum %d\n",gnum);
			Tse[gnum] = temp_meteo;
			Tn1[gnum]= temp_meteo;
			Tn2[gnum]= temp_meteo;
			Tsi1[gnum] = temp_meteo;
			Tsi2[gnum] = temp_meteo;
			temp_perm[gnum] = temp_meteo;
		}
		else 
		{ gi= (int)no_paroi[gnum];
		  if (nb_couches_materiau(gi) == 1) // cas des parois 1 couche
			{
				calc_temp_mur_1_couche(temp_surf_ext_ini[gnum],temp_surf1_ini[gnum],temp_ref[gnum],hint[gnum],gi,Sol_Net[gnum],GLO_Total_Net[gnum],h[gnum],temp_meteo,Tse+gnum,Tn1+gnum,Tsi1+gnum,temp_perm+gnum,Dt);
				Tn2[gnum]=0.0;
			}
			else				    // cas des parois 2 couches
			{
								
				calc_temp_mur_2_couches_hint(temp_surf_ext_ini[gnum],temp_surf1_ini[gnum],temp_surf2_ini[gnum],temp_ref[gnum],hint[gnum],gi,Sol_Net[gnum],GLO_Total_Net[gnum],h[gnum],temp_meteo,Tse+gnum,Tn1+gnum,Tn2+gnum,Tsi1+gnum,Tsi2+gnum,temp_perm+gnum,Dt);
			}
			
		}
	}

	/*** CONVERGENCE DES TEMPERATURES DE SURFACE ***/
	//	printf("Etude de la convergence des temperatures de surface \n");

	for (gnum = 0;gnum<nb_contour_total;gnum++)
	{		
		if(fabs(Tse[gnum] - temp_surf_ext_iter[gnum]) > delta_max)
		{ delta_max = fabs(Tse[gnum] - temp_surf_ext_iter[gnum]);
		}
		delta_temp_surf_var += (Tse[gnum] - temp_surf_ext_iter[gnum]);
		delta_temp_surf_perm += (temp_perm[gnum] - temp_surf_perm_iter[gnum]);
	}
	delta_temp_surf_var = fabs(delta_temp_surf_var/nb_contour_total);
	delta_temp_surf_perm = fabs(delta_temp_surf_perm/nb_contour_total);
	
	printf("\ndelta_temp_surf_var:%lf",delta_temp_surf_var);
	printf("\ndelta_temp_surf_perm:%lf",delta_temp_surf_perm);
    printf("\necart de temperature max en surface : %f\n", delta_max);

	for (gnum = 0;gnum<nb_contour_total;gnum++)
	{
		temp_surf_ext_iter[gnum]=Tse[gnum];
		temp_surf_perm_iter[gnum]=temp_perm[gnum];
	}
							
} // fin de WHILE

printf("\necart de temperature max en surface : %f\n", delta_max);
desalloue_double(temp_surf_ext_iter);
desalloue_double(temp_surf_perm_iter);

// ETAPE 3
//--------
// RESULTATS
	/*** ESTIMATION DES FLUX CONVECTIFS ***/

for (gnum = 0;gnum<nb_contour_total;gnum++)
	CONV[gnum]=h[gnum]*(Tse[gnum]-temp_meteo);

	/*** ESTIMATION DES ECARTS ENTRE VARIABLE ET PERMANENT***/

for (gnum = 0;gnum<nb_contour_total;gnum++)
	delta[gnum]=Tse[gnum]-temp_perm[gnum];

	/*** SAUVEGARDE DES RESULTATS ***/

	/* ecriture resultats des temperatures dans le mur et dans le sol */

printf("  ---------------------------------\n");
printf("\n>>> Sauvegarde finale des temperatures des murs en Celsius ... \n");

// Sauvegarde obligatoire de Tse Tn1 Tn2
OK_sauvegarde = sauve_tableau(nom_Tse,nbfac,nomax,nb_contour_total,numero_face,nb_cont_face,Tse);
if (!OK_sauvegarde)
	{printf("*** Attention, probleme de sauvegarde pour les temperatures des surfaces exterieures. ***\n");
	 goto fin;}
	
OK_sauvegarde = sauve_tableau(nom_Tn1,nbfac,nomax,nb_contour_total,numero_face,nb_cont_face,Tn1);
if (!OK_sauvegarde)
	{printf("*** Attention, probleme de sauvegarde pour les temperatures du mur calculees au noeud 1. ***\n");
	 goto fin;}

OK_sauvegarde = sauve_tableau(nom_Tn2,nbfac,nomax,nb_contour_total,numero_face,nb_cont_face,Tn2);
if (!OK_sauvegarde)
	{printf("*** Attention, probleme de sauvegarde pour les temperatures du mur calculees au noeud 2. ***\n");
	 goto fin;}

// Sauvegarde suivant option Resultats

if(option_resultats[4]==1)
{
	OK_sauvegarde = sauve_tableau(nom_tsi1,nbfac,nomax,nb_contour_total,numero_face,nb_cont_face,Tsi1);
	if (!OK_sauvegarde)
	{printf("*** Attention, probleme de sauvegarde de Tsi1. ***\n");
	 goto fin;}
}
if(option_resultats[5]==1)
{   OK_sauvegarde = sauve_tableau(nom_tsi2,nbfac,nomax,nb_contour_total,numero_face,nb_cont_face,Tsi2);
	if (!OK_sauvegarde)
	{printf("*** Attention, probleme de sauvegarde de Tsi2 ***\n");
	 goto fin;}
}
if(option_resultats[6]==1)
{
	OK_sauvegarde = sauve_tableau(nom_GLO_Ciel_Emis, nbfac, nomax, nb_contour_total, numero_face, nb_cont_face, GLO_Ciel_Emis);
	if (!OK_sauvegarde)
	{printf("*** Attention, probleme de sauvegarde de GLO_Ciel_Emis. ***\n");
	 goto fin;}
}
if(option_resultats[7]==1)
{
	OK_sauvegarde = sauve_tableau(nom_GLO_Ciel_Recu, nbfac, nomax, nb_contour_total, numero_face, nb_cont_face, GLO_Ciel_Recu);
	if (!OK_sauvegarde)
	{printf("*** Attention, probleme de sauvegarde de GLO_Ciel_Recu. ***\n");
	 goto fin;}
}
if(option_resultats[8]==1)
{
	OK_sauvegarde = sauve_tableau(nom_GLO_Ciel_Net, nbfac, nomax, nb_contour_total, numero_face, nb_cont_face, GLO_Ciel_Net);
	if (!OK_sauvegarde)
	{printf("*** Attention, probleme de sauvegarde de GLO_Ciel_Net. ***\n");
	 goto fin;}
}
if(option_resultats[9]==1)
{
	OK_sauvegarde = sauve_tableau(nom_GLO_Scene_Emis, nbfac, nomax, nb_contour_total, numero_face, nb_cont_face, GLO_Scene_Emis);
	if (!OK_sauvegarde)
	{printf("*** Attention, probleme de sauvegarde de GLO_Scene_Emis. ***\n");
	 goto fin;}
}
if(option_resultats[10]==1)
{
	OK_sauvegarde = sauve_tableau(nom_GLO_Scene_Recu, nbfac, nomax, nb_contour_total, numero_face, nb_cont_face, GLO_Scene_Recu);
	if (!OK_sauvegarde)
	{printf("*** Attention, probleme de sauvegarde de GLO_Scene_Recu. ***\n");
	 goto fin;}
}
if(option_resultats[11]==1)
{
	OK_sauvegarde = sauve_tableau(nom_GLO_Scene_Net, nbfac, nomax, nb_contour_total, numero_face, nb_cont_face, GLO_Scene_Net);
	if (!OK_sauvegarde)
	{printf("*** Attention, probleme de sauvegarde de GLO_Scene_Net. ***\n");
	 goto fin;}
}
if(option_resultats[12]==1)
{
	OK_sauvegarde = sauve_tableau(nom_GLO_Total_Emis, nbfac, nomax, nb_contour_total, numero_face, nb_cont_face, GLO_Total_Emis);
	if (!OK_sauvegarde)
	{printf("*** Attention, probleme de sauvegarde de GLO_Total_Emis. ***\n");
	 goto fin;}
}
if(option_resultats[13]==1)
{
	OK_sauvegarde = sauve_tableau(nom_GLO_Total_Recu, nbfac, nomax, nb_contour_total, numero_face, nb_cont_face, GLO_Total_Recu);
	if (!OK_sauvegarde)
	{printf("*** Attention, probleme de sauvegarde de GLO_Total_Recu. ***\n");
	 goto fin;}
}
if(option_resultats[14]==1)
{
	OK_sauvegarde = sauve_tableau(nom_GLO_Total_Net, nbfac, nomax, nb_contour_total, numero_face, nb_cont_face, GLO_Total_Net);
	if (!OK_sauvegarde)
	{printf("*** Attention, probleme de sauvegarde de GLO_Total_Net. ***\n");
	 goto fin;}
}
if(option_resultats[15]==1)
{
	OK_sauvegarde = sauve_tableau(nom_CONV, nbfac, nomax, nb_contour_total, numero_face, nb_cont_face, CONV);
	if (!OK_sauvegarde)
	{printf("*** Attention, probleme de sauvegarde pour les flux CONV. ***\n");
	 goto fin;}
}
if(option_resultats[16]==1)
{
	OK_sauvegarde = sauve_tableau(nom_Sol_Ciel_Reflechi, nbfac, nomax, nb_contour_total, numero_face, nb_cont_face, Sol_Ciel_Reflechi);
	if (!OK_sauvegarde)
	{printf("*** Attention, probleme de sauvegarde pour les flux Sol_Ciel_Reflechi. ***\n");
	 goto fin;}
}
if(option_resultats[17]==1)
{
	OK_sauvegarde = sauve_tableau(nom_Sol_Net, nbfac, nomax, nb_contour_total, numero_face, nb_cont_face, Sol_Net);
	if (!OK_sauvegarde)
	{printf("*** Attention, probleme de sauvegarde pour les flux Sol_Net. ***\n");
	 goto fin;}
}
if(option_resultats[18]==1)
{
	OK_sauvegarde = sauve_tableau(nom_Sol_Scene_Apport, nbfac, nomax, nb_contour_total, numero_face, nb_cont_face, Sol_Scene_Apport);
	if (!OK_sauvegarde)
	{printf("*** Attention, probleme de sauvegarde pour les flux Sol_Scene_Apport. ***\n");
	 goto fin;}
}


// on ne le fait plus
	/* ecriture resultats des temperatures equivalentes au soleil*/
/*
	printf("\n>>> Sauvegarde finale des temperatures equivalentes en Celsius ... \n");

	OK_sauvegarde = sauve_tableau(nom_temp_eq,nbfac,nomax,nb_contour_total,numero_face,nb_cont_face,temp_eq);
	if (!OK_sauvegarde)
	{printf("*** Attention, probleme de sauvegarde pour les temperatures equivalentes. ***\n");
	goto fin;}
*/
// on ne le fait plus
	/* ecriture resultats des temperatures en r�gime permanent*/
/*	printf("\n>>> Sauvegarde finale des temperatures en r�gime permanent en Celsius ... \n");

	OK_sauvegarde = sauve_tableau(nom_temp_perm,nbfac,nomax,nb_contour_total,numero_face,nb_cont_face,temp_perm);
	if (!OK_sauvegarde)
	{printf("*** Attention, probleme de sauvegarde pour les temperatures en r�gime permanent. ***\n");
	goto fin;}

*/
	/* ecriture resultats des �carts entre r�gime variable et permanent */
/*
	printf("\n>>> Sauvegarde finale des �carts entre r�gime variable et permanent ... \n");

	OK_sauvegarde = sauve_tableau(nom_delta, nbfac, nomax, nb_contour_total, numero_face, nb_cont_face, delta);
	if (!OK_sauvegarde)
	{printf("*** Attention, probleme de sauvegarde pour les �carts entre r�gime variable et permanent. ***\n");
	 goto fin;}
*/
	/* ecriture resultats des flux CONV */

	//printf("\n>>> Sauvegarde finale des flux CONV ... \n");



fclose(fp);

desalloue_double(exit_init);
desalloue_double(exit);
	
desalloue_double(temp_surf_ext_ini);
desalloue_double(temp_surf1_ini);
desalloue_double(temp_surf2_ini);
desalloue_double(temp_ref);
desalloue_double(CLO);
desalloue_double(albedo);
desalloue_double(emissivite);
desalloue_double(no_paroi);
desalloue_double(temp_fix);
desalloue_double(h);
desalloue_double(hint);
desalloue_double(surf);
free(fform);
desalloue_double(fciel);
desalloue_double(temp_eq);
desalloue_double(temp_perm);
desalloue_double(delta);

// desalloue les resultats choisis quelque soit l'option

	 desalloue_double(Tse);
	 desalloue_double(Tn1);
	 desalloue_double(Tn2);
	 desalloue_double(Tsi1);
	 desalloue_double(Tsi2);

     desalloue_double(GLO_Ciel_Emis);
     desalloue_double(GLO_Ciel_Recu);
     desalloue_double(GLO_Ciel_Net);
     desalloue_double(GLO_Scene_Emis);
     desalloue_double(GLO_Scene_Recu);
     desalloue_double(GLO_Scene_Net);
     desalloue_double(GLO_Total_Emis);
     desalloue_double(GLO_Total_Recu);
     desalloue_double(GLO_Total_Net);
	 desalloue_double(CONV);
     desalloue_double(Sol_Ciel_Reflechi);
     desalloue_double(Sol_Net);
     desalloue_double(Sol_Scene_Apport);


desalloue_paroi(pparoi,nb_paroi);


creer_OK_Solene();

fin:;
printf("\nFin\n");
pb:;
printf("\nLes coefficiients albedo doivent �tre non nuls\n");
printf("\nLes coefficiients emissivit� doivent �tre diff�rent de 1\n");

		
}


/********************** PROCEDURES ***************************/




/*_________________________________________________________________*/
/* Ouverture et lecture fichier au "bon" format (.val) et remplissage tableau 'valeur' */
void lecture(char *nom, double *valeur)
{
	FILE *pfic;

	if ((pfic=fopen(nom,"r"))==NULL)
       {printf("\n  impossible ouvrir %s\n\n", nom); 
		exit(0);}
	
	lect_fic_val(pfic,valeur);

	fclose(pfic);

}

/*_____________________________*/
/* Teste si zeros dans tableau */
void test_zeros(nb_valeurs, tab)
int nb_valeurs;
double *tab;
{
int compt;

for (compt=0;compt<nb_valeurs;compt++)
	{if (tab[compt] < 1e-3) 
		{ printf("Erreur, reflectivite nulle rencontree ...\n");
		  printf("Contour no %d\n", compt);
		   exit(0); }		
	}
}

/*____________________________________________*/
/* Met toutes les valeurs d'un tableau a zero */
void met_a_zero(nb_valeurs, tab)
int nb_valeurs;
double *tab;
{int compt;

for (compt=0;compt<nb_valeurs;compt++)
	tab[compt] = 0.0;
}

/*____________________________________________*/
/* Lecture des facteurs de forme dans fichier */
/*____________________________________________*/

void lecture_ff(factf,ii,nb_contour_total)
float *factf;
int ii, nb_contour_total;
   {
   fseek(fp,(ii*nb_contour_total)*sizeof(float),SEEK_SET);
   fread(factf, sizeof(float), nb_contour_total, fp);
   }

/*_______________________________________________________________________________________________*/
/* Sauvegarde d'un tableau de valeurs (descripteurs) associees a un fichier de faces et contours */
/*_______________________________________________________________________________________________*/

int sauve_tableau(nom_fichier,nbfac,nomax,nb_contour_total,numero_face,nb_cont_face,tab)

char *nom_fichier;
int nbfac;
int nomax;
int *numero_face;
int *nb_cont_face;
double *tab;
{ 
FILE *pf;
double mini, maxi;
int i, k, num;
int sauvOK = 1;

if ((pf= fopen(nom_fichier,"w"))==NULL)
	sauvOK = 0;
else
	{mini=maxi=tab[0];
	for(i=0;i<nb_contour_total;i++)
		{
		if(tab[i]<mini) mini=tab[i];
		if(tab[i]>maxi) maxi=tab[i];
		} 

	fprintf (pf,"%5d %5d %8.3lf %8.3lf\n", nbfac, nomax, mini, maxi);   

	num=0;
	for(i=0;i<nbfac;i++)
		{
		fprintf (pf,"f%d %d\n",numero_face[i],nb_cont_face[i]);
		for(k=0;k<nb_cont_face[i];k++)
			{
			fprintf (pf,"    %8.3f\n",tab[num]);
			num++;
			}
		}
	fclose(pf);
	}
return sauvOK;
}

/*______________________________________________________________________*/
/*    Radiosite "generalisee"    					*/
/* Tableau d'entree: `exit_init', tableau de sortie: 'exit' 		*/
/* Dans la bande solaire: mettre en entree la 1ere reflexion 		*/
/* du flux solaire incident 						*/
/* Dans l'IR: mettre en entree l'emission propre de chaque surface 	*/
/* On recupere en sortie l'exitance (ou la radiosite) de chaque surface */
/* pour la bande du spectre consideree 					*/

int radiog(im, nb_cont_face, numero_face, nbfac, nb_contour_total, exit_init,
surf, reflex, fform, flag_arret, pourc, exit)

int im;
int *nb_cont_face;
int *numero_face;
int nbfac;
int nb_contour_total;
double *exit_init;
double *surf;
double *reflex;
float *fform;
int flag_arret; 
double pourc;
double *exit;


{ 	int face;    
	int num_cont, contour; 
	int iteration; 
	int icont_liste_max;
	int iface_max;
	int icont_max;	
	double energie_totale; 
	double a_distribuer;
	double a_distribuer_preced;
	double a_distribuer_max;
	double *delta_exit;
	double fform_recip;
	double d_exit;
	static int nb_iter_max_abs = 50000;
	int erreur = 0;
  	

	/* Allocations dynamiques */
       	delta_exit =(double *)malloc(nb_contour_total*sizeof(double));
	if (delta_exit==NULL)
		{printf("*** Probleme allocation radiosite residuelle.\n");
		 erreur=1;
		 return erreur;}

	/* initialisations */
	for(contour=0;contour<nb_contour_total;contour++)
	  	exit[contour]=delta_exit[contour]=exit_init[contour];	


	energie_totale=0.0;
   	for(contour=0;contour<nb_contour_total;contour++) 
      		energie_totale+=delta_exit[contour]*surf[contour];
   	printf("\nEnergie totale a distribuer (W): %.2lf\n",energie_totale);
	a_distribuer_preced=energie_totale;
	a_distribuer = energie_totale;


	/* iterations */
	
	iteration=1;
	while(iteration < nb_iter_max_abs) 
   		{
// 		printf("...iteration %d...\r",iteration); 
		/* Recherche de l'element de flux maximal */
   		a_distribuer_max=0.0;
   		num_cont=0;
		for(face=0;face<nbfac;face++)
		  {
		  for(contour=0;contour<nb_cont_face[face];contour++)
		
			{if(delta_exit[num_cont]*surf[num_cont]>a_distribuer_max)
         			{
				a_distribuer_max=delta_exit[num_cont]*surf[num_cont];
				iface_max=face;     
				icont_max=contour+1;   
         			icont_liste_max=num_cont;	  
         			}		 		    
			num_cont++;
			}
		  }

   		if(im) printf("\nFlux maxi (W) en provenance de la face %d, contour %d (no %d) : %5.2f\n",numero_face[iface_max],icont_max,icont_liste_max+1,a_distribuer_max); 
 
		/* lecture des ff[ii] */
	
   		lecture_ff(fform,icont_liste_max, nb_contour_total);
 

		/* contribution de l'element de flux maximal, a tous les autres */
   		for(num_cont=0;num_cont<nb_contour_total;num_cont++) 
      			{
		
			fform_recip=fform[num_cont]*surf[icont_liste_max]/surf[num_cont];
			//if(fform_recip>1.) fform_recip=1.; reprend modif r�alis�e dans radiosit�
			if(fform_recip>1.) 
			{ // recipro=1.; VOIR note algo eclairement, et note Fernand 24 avril 2002 
			  printf("recipro = %f\n",fform_recip);
			}
		
			d_exit=reflex[num_cont]*delta_exit[icont_liste_max]*fform_recip;    
      			delta_exit[num_cont]+=d_exit;
      			exit[num_cont]+=d_exit;  
      			}
   		delta_exit[icont_liste_max]=0.0;

		a_distribuer=0.0;
   		for(num_cont=0;num_cont<nb_contour_total;num_cont++) 
      			a_distribuer+=delta_exit[num_cont]*surf[num_cont]; 
  
   		if(im) printf("energie non distribuee (W): %.2lf\n\n",a_distribuer);


		/* Sortie de boucle  */
		/* Pas genial mais dependant des conventions adoptees dans
versions precedentes 
		*/
		// flag_arret =2 impos� en entr�e

		if ((flag_arret == 2) && (a_distribuer < (pourc*energie_totale/100)))
			break;

		a_distribuer_preced=a_distribuer;
	   	iteration++;
   		}
	free(delta_exit);
	/* Les resultats a exploiter dans le corps du prog sont dans 'exit' */
	printf("energie non distribuee (W): %.2lf\n\n",a_distribuer);
	return erreur;
}

/*___________________________________________________________*/
/*	temperature equivalente au soleil (paroi 1 ou 2 couches) */
/*___________________________________________________________*/

double calc_temp_eq_mur(double h,
						double temp_meteo,
						double temp_surf1_ini,
						int no_paroi,
						double Sol_Net)

	
{	
	double epaisseur,lambda,cp,rho;
	double K;	// conductance
	double temp_eq;
	double Dx; // pas d'espace

	// cherche caract�ristiques de &ere couche de paroi
	caracteristiques_materiau (no_paroi, 1, &epaisseur,&lambda,&cp,&rho);

	Dx=epaisseur/2;
	K = lambda/Dx;
	temp_eq = ((h*temp_meteo) + (K*temp_surf1_ini) + Sol_Net)/(h+K);
	//printf("\ntemperature de surface equivalente:%lf",temp_eq);

	return (double)temp_eq;
}


/*__________________________________________*/
/* Calcul du flux IR envoye par le ciel		*/
/*__________________________________________*/

double IR_ciel(double Ta)

/* Ta temperature de l'air ambiant ( a la station meteo par exemple) */

{ /* Calcul du flux IR maximum recu en provenance du ciel d'apres modele these J. Noilhan*/
	return (double)(5.5*Ta + 213);
}

/*______________________________________________*/
/*					GLO							*/
/*______________________________________________*/

double calc_GLO(double temp_meteo,
				double fciel,
				//double *temp_eq,
				double *tse, //janvier 2007
				float *fform,
				double *emissivite,  // modif 12/02/2005
				int numero_contour_ref,
				int numero_contour_total,
				double flux_atmosphere,
				double *GLO_Ciel_Emis,
				double *GLO_Ciel_Recu,
				double *GLO_Ciel_Net,
				double *GLO_Scene_Emis,
				double *GLO_Scene_Recu,
				double *GLO_Scene_Net,
				double *GLO_Total_Emis,
				double *GLO_Total_Recu)
	// modif 12/02/2005 on change emissivite en emissivite[numero_contour_ref]
{
	const double stefan = 5.67e-8; // constante de stefan
	int num_contour; // pour boucler sur tous les contours
	double GLO_Total_Net;
	float sommeFF;

	tse[numero_contour_ref] += 273.0; /* conversion en Kelvin */
//	printf("\nNumero de contour: %d\n", numero_contour_ref);
	
	// GLO CIEL
	//janvier 2007 calcul� en Etape 1 avec r�flexion
	//GLO_Ciel_Recu[numero_contour_ref]= fciel * flux_atmosphere; 
	// FIN janvier 2007 
    GLO_Ciel_Emis[numero_contour_ref] =fciel * stefan * emissivite[numero_contour_ref] * pow(tse[numero_contour_ref],4);
	GLO_Ciel_Net[numero_contour_ref]= GLO_Ciel_Emis[numero_contour_ref] - GLO_Ciel_Recu[numero_contour_ref];
	
    //	printf("facteur de forme avec le ciel : %f\n", fciel);
	//  printf("\nDensite de flux GLO �mis vers le ciel: %lf\n", GLO_Ciel_Net[numero_contour_ref]);

	tse[numero_contour_ref] -= 273.0; /* conversion en Celsius */

	// GLO_SCENE
	/* Calcul des flux GLO echanges avec les autres surfaces */	
	GLO_Scene_Net[numero_contour_ref]  = 0.0; //initialisation
	lecture_ff(fform,numero_contour_ref, numero_contour_total);
	fform[numero_contour_ref]=0.0;
	sommeFF=0;// janvier 2007
	for (num_contour = 0;num_contour<numero_contour_total;num_contour++)
	{
		
	  GLO_Scene_Net[numero_contour_ref]  += stefan*fform[num_contour]*(emissivite[numero_contour_ref]*pow((tse[numero_contour_ref]+273),4) - emissivite[num_contour]*pow((tse[num_contour]+273),4));

	  //		printf("facteur de forme avec la surface : %f\n", fform[num_contour]);
	  sommeFF+= fform[num_contour]; // janvier 2007
	}
	//printf("Densite de flux GLO net echangee avec les surfaces : %lf\n", GLO_Scene_Net[numero_contour_ref]);
	GLO_Scene_Emis[numero_contour_ref]= sommeFF* stefan * emissivite[numero_contour_ref]*pow((tse[numero_contour_ref]+273),4);// janvier 2007
	GLO_Scene_Recu[numero_contour_ref]= GLO_Scene_Emis[numero_contour_ref] - GLO_Scene_Net[numero_contour_ref]; // janvier 2007


	// GLO_TOTAL
	GLO_Total_Emis[numero_contour_ref]= GLO_Ciel_Emis[numero_contour_ref] + GLO_Scene_Emis[numero_contour_ref];
	GLO_Total_Recu[numero_contour_ref]= GLO_Ciel_Recu[numero_contour_ref] + GLO_Scene_Recu[numero_contour_ref];
	GLO_Total_Net = GLO_Ciel_Net[numero_contour_ref] + GLO_Scene_Net[numero_contour_ref];
	//printf("\nDensite de flux GLO total Net: %lf\n", GLO_Total_Net);
	
	return GLO_Total_Net;
}


/*_________________________________________________________________*/
/*	Resolution systeme tridiagonale (d'apres numerical recipes)	   */
/* Attention, dans NR les vecteurs sont definies de 1 a n		   */
/* Il faut modifier les incermentations car nous allons de 0 a n-1!*/
/*_________________________________________________________________*/

void tridiag (double *a,
			  double *b,
			  double *c,
			  double *r,
			  double *u,
			  int n)

// les vecteurs a,b,c et r sont en entree et ne sont pas modifies
// n est la dimension des vecteur (entree)

{
	int j;
	double bet, *gam;
	
//	printf("Dimension de la matrice:%d\n",n);

	// Alloctaion du vecteur gam pour le traitement
	gam = (double*)malloc(n*sizeof(double));
	if (gam==NULL)
	{printf("\nProbleme d'allocation du vecteur gam.\n"); 
	exit(0);}

	if (b[0]==0.0)
	{
		printf("\n erreur 1 dans tridiag.\n"); 
		exit(0);
	}
	bet = b[0];
	u[0] = r[0]/bet;
//	printf("u[0]:%lf\n",u[0]);
	for (j=1;j<n;j++)
	{
		// decomposition et substitution avant
		gam[j]=c[j-1]/bet;
//		printf("gam[j]:%lf\n",gam[j]);
		bet=b[j]-a[j]*gam[j];
//		printf("bet:%lf\n",bet);
		if (bet==0.0)
		{
		printf("\n erreur 2 dans tridiag.\n"); 
		exit(0);
		}
		u[j]=(r[j]-(a[j]*u[j-1]))/bet;
//		printf("j:%d\n",j);
//		printf("u[j]:%lf\n",u[j]);

	}
	for (j=(n-2);j>=0;j--)
	{
		u[j]-=gam[j+1]*u[j+1]; // substitution arriere
//		printf("j:%d\n",j);
//		printf("u[j]:%lf\n",u[j]);
	}

	free(gam);
}


/*_________________________________________________________________*/
/*	temperatures du mur (a l'interieur et aux surfaces)			   */
/*_________________________________________________________________*/

void calc_temp_mur_1_couche( double temp_surf_ext_ini,
					double temp_surf1_ini,
					double temp_ref,
					double hint,
					int    no_paroi,
					double Sol_Net,
					double GLO_Total_Net,
					double h,
					double temp_meteo,
					double *Tse,
					double *Tn1,
					double *Tsi1,
					double *temp_perm,
					double Dt)

{
	double epaisseur_mur, lambda, Cp, rho;

	int n = 3; // dimension de la matrice
	double a[3],b[3],c[3]; // vecteurs diagonaux de la matrice A
	double r[3]; // vecteur des termes de droite dans l'equation A.X = B
	double u[3]; // vecteur des inconnues

	double K,K1,K2,Cm; // conductances et capacite dans le mur
	double Dx; // pas d'espace

	// ecriture des equations sous une forme matricielle A.X = B
	// cherche caract�ristiques de paroi
	caracteristiques_materiau (no_paroi, 1, &epaisseur_mur,&lambda,&Cp,&rho);
	
	// Calcul de certaines valeurs 
	Dx=epaisseur_mur/2;
	K1=lambda/Dx;
	K2=lambda/Dx;
	Cm=rho*Cp*epaisseur_mur;

//	printf("Conductances1 et 2 :%lf, %lf\n",K1,K2);
//	printf("Capacite du mur:%lf\n",Cm);
//	printf("pas de temps:%lf\n",Dt);
	
	// Initialisation de la matrice A (dont on ne retient que 3 vecteurs a, b et c) et du vecteur B (un vecteur r)

a[1]=c[0]=-K1;
a[2]=c[1]=-K2;

b[0]=K1+hint;
b[1]=K1+K2+((9*Cm/(10*Dt)));
b[2]=K2+((Cm/(10*Dt)))+h;

r[0]=hint*temp_ref;
r[1]=((9*Cm)/(10*Dt))*temp_surf1_ini;
r[2]=Sol_Net +(temp_surf_ext_ini*(Cm/(10*Dt)))- GLO_Total_Net +(h*temp_meteo);

	// Resolution
	tridiag(a,b,c,r,u,n);

	*Tsi1 = u[0];
//printf("\nTemperature de surface int du mur:%lf",*Tsi1);
	*Tn1 = u[1];
//printf("\nTemperature a l'int du mur:%lf",*Tn1);
	*Tse = u[2];
//printf("\nTemperature de surface ext du mur:%lf",*Tse);

	K =1/((1/hint)+(1/K1)+(1/K2));
// printf("\nK:%lf",K);

	*temp_perm = (Sol_Net - GLO_Total_Net +(h*temp_meteo)+(K*temp_ref))/(K+h);
//printf("\nTemperature de surface regime permanent:%lf",*temp_perm);

}


/*_____________________________________________________________________*/
/*	temperatures du mur � 2 couches (a l'interieur et aux surfaces)	   */
/* avec imposition de h int�rieur
// rajoute noeud int�rieur Tsi2
// simule un hint fort pour imposer temp de sol
/*_____________________________________________________________________*/

void calc_temp_mur_2_couches_hint(double temp_surf_ext_ini,
				   double temp_surf1_ini,
				   double temp_surf2_ini,
				   double temp_ref,
				   double hint,
				   int no_paroi,
				   double Sol_Net,
				   double GLO_Total_Net,
				   double h,
				   double temp_meteo,
				   double *Tse,
				   double *Tn1,
				   double *Tn2,
				   double *Tsi1,
				   double *Tsi2,
				   double *temp_perm,
				   double Dt)
{
	// A VOIR A TRANSFORMER EN UNE PAROI 2 COUCHES AVEC un hint
	// hint serait grand dans le cas d'un sol pour imposer la temperature du sol temp_ref
	double epaisseur_mur, lambda, cp, rho; // 1ere couche
	double epaisseur_terre, lambda_terre, cp_terre, rho_terre; // 2eme couche

	int n = 5; // dimension de la matrice
	double a[5],b[5],c[5]; // vecteurs diagonaux de la matrice A
	double r[5]; // vecteur des termes de droite dans l'equation A.X = B
	double u[5]; // vecteur des inconnues

	double K,K1,K2,K3,K4,Csol1,Csol2; // conductances et capacites dans le sol
	double Dx1,Dx2; // pas d'espace


	// ecriture des equations sous une forme matricielle A.X = B

	// cherche caract�ristiques de paroi : 1ere couche
	caracteristiques_materiau (no_paroi, 1, &epaisseur_mur,&lambda,&cp,&rho);
	// cherche caract�ristiques de paroi : 2eme couche
	caracteristiques_materiau (no_paroi, 2, &epaisseur_terre,&lambda_terre,&cp_terre,&rho_terre);

	// Calcul de certaines valeurs 
	Dx1=epaisseur_mur/2;

	Dx2=epaisseur_terre/2;
	K1=lambda/Dx1;
	K2=lambda/Dx1;
	K3=lambda_terre/Dx2;
	K4=lambda_terre/Dx2;
	Csol1=rho*cp*epaisseur_mur;
	Csol2=rho_terre*cp_terre*epaisseur_terre;
//printf("Conductances1,2,3 et  :%lf, %lf, %lf, %lf\n",K1,K2,K3,K4);
//printf("Capacite du sol:%lf, %lf\n",Csol1,Csol2);

	// Initialisation de la matrice A (dont on ne retiens que 3 vecteurs a, b et c) et du vecteur B (un vecteur r)

a[1]=c[0]=-K1;
a[2]=c[1]=-K2;
a[3]=c[2]=-K3;
a[4]=c[3]=-K4;

b[0]=K1+((Csol1/(10*Dt)))+h;
b[1]=K1+K2+((9*Csol1/(10*Dt)));
b[2]=K2+K3;
b[3]=K3+K4+(Csol2/Dt);
b[4]=K4+hint;

r[0]=Sol_Net+(temp_surf_ext_ini*(Csol1/(10*Dt)))- GLO_Total_Net +(h*temp_meteo);
r[1]=temp_surf1_ini*((9*Csol1)/(10*Dt));
r[2]=0.0;
r[3]=((Csol2/Dt)*temp_surf2_ini);
r[4]=hint*temp_ref;

	// Resolution
	tridiag(a,b,c,r,u,n);	
	
	*Tse = u[0];
//printf("\nTemperature de surface ext du sol:%lf",*Tse);
	*Tn1 = u[1];
//printf("\nTemperature a l'int du sol1:%lf",*Tn1);
	*Tsi1 = u[2];
//printf("\nTemperature de surface int du mur:%lf",*Tsi1);
	*Tn2 = u[3];
//printf("\nTemperature a l'int du sol2:%lf",*Tn2);

	// A VOIR SI STOCKE
	*Tsi2 = u[4];
//printf("\nTemperature 2 de surface int du mur:%lf",*Tsi2);

	K =1/((1/K1)+(1/K2)+(1/K3)+(1/K4));
//printf("\nK:%lf",K);

	*temp_perm = (Sol_Net - GLO_Total_Net +(h*temp_meteo)+(K*temp_ref))/(K+h);
//printf("\nTemperature de surface regime permanent:%lf",*temp_perm);

}
/*_______________________________________________________________*/
/* lit fichier des parois et stocke info                         */
/*_______________________________________________________________*/
int lit_fic_paroi(nom)
char *nom;
{
 int i,j;
 int nb_paroi;
 FILE *fi;
 char nom_paroi[32];
 int nb_couches;
 double epaisseur,lambda, cp, rho;
 struct materiau *pmateriau;   

	if((fi=fopen(nom,"r"))==NULL) 
		{ printf(" impossible ouvrir %s\n",nom);
   	      exit(0);
        }
    fscanf(fi,"%d", &nb_paroi);
	//printf("%d\n",nb_paroi);
	pparoi= alloue_paroi(nb_paroi,1234);

	for(i=0;i<nb_paroi;i++)
	{
		fscanf(fi,"%s",nom_paroi);
			//printf("%s\n",nom_paroi);
		fscanf(fi,"%d",&nb_couches);
			//printf("%d\n",nb_couches);

		(pparoi+i)->nb_couches=nb_couches;
		pmateriau= alloue_materiau(nb_couches,4567);
		(pparoi+i)->materiau_couches=pmateriau;

		for(j=0;j<nb_couches;j++)
				{ fscanf(fi,"%lf",&epaisseur);
					//printf("%f\n",epaisseur);
				  fscanf(fi,"%lf",&lambda);
					//printf("%f\n",lambda);
				  fscanf(fi,"%lf",&cp);
					//printf("%f\n",cp);
				  fscanf(fi,"%lf",&rho);
					//printf("%f\n",rho);

					pmateriau->epaisseur[j] = epaisseur;
					pmateriau->lambda[j] = lambda;
					pmateriau->cp[j] = cp;
					pmateriau->rho[j] = rho;
				}					
	}
	fclose (fi);

	// test stockage
	for(i=0;i<nb_paroi;i++)
	{ 
	  printf("paroi no %d\nn",i+1);
	  pmateriau= (pparoi+i)-> materiau_couches;
	  nb_couches = (pparoi+i)-> nb_couches;
	  printf("epaisseur, lammbda, cp, rho\n");

	  for (j=0;j<nb_couches;j++)
	  { 
		  printf("%f ", pmateriau->epaisseur[j]);
		  printf("%f ", pmateriau->lambda[j]);
		  printf("%f ", pmateriau->cp[j]);
		  printf("%f\n", pmateriau->rho[j]);
	  }
	}


	return(nb_paroi);
}

/*-----------------------------------------------------------------------------*/

struct paroi *alloue_paroi(nbf,err)
int nbf,err;
{    /* alloue et initialise nbf parois */
  struct paroi *pparoi;
  int i;
     pparoi=(struct paroi *)malloc(nbf*sizeof(*pparoi));
     if(pparoi==NULL) pb_allocation(err); 
     for(i=0;i<nbf;i++)
        {
		 pparoi[i].nb_couches=0;
		 pparoi[i].materiau_couches=NULL; 
		} 

     return(pparoi);
}
/*-----------------------------------------------------------------------------*/

struct materiau *alloue_materiau(nbf,err)
int nbf,err;
{    /* alloue les materiaux d'une paroi de nbf couches */
  struct materiau *pmateriau;
     pmateriau=(struct materiau *)malloc(nbf*sizeof(*pmateriau));
     if(pmateriau==NULL) pb_allocation(err);
	 pmateriau->epaisseur = alloue_double (nbf,12345);
	 pmateriau->lambda = alloue_double (nbf,12345);
	 pmateriau->cp  = alloue_double (nbf,12345);
	 pmateriau->rho = alloue_double (nbf,12345);
     

     return(pmateriau);
}

/*-----------------------------------------------------------------------------*/
void desalloue_paroi(pparoi,nbf)
  struct paroi *pparoi;
  int nbf;
{
int i;
struct materiau *pmateriau;

   if(pparoi)
    { for(i=0;i<nbf;i++)
		{ pmateriau = (pparoi+i)->materiau_couches;
			free(pmateriau->epaisseur);
			free(pmateriau->lambda);
			free(pmateriau->cp);
			free(pmateriau->rho);
			free(pmateriau);
      }
    free(pparoi);
    }

}

/*-----------------------------------------------------------------------------*/
int nb_couches_materiau (no_liste)
int no_liste;
{
	no_liste = no_liste-1;
	return((pparoi+no_liste)->nb_couches);
}
/*-----------------------------------------------------------------------------*/
void caracteristiques_materiau (no_liste, no_couche, epaisseur,lambda,cp,rho)
int no_liste,no_couche;
double *epaisseur,*lambda,*cp,*rho;
{
	struct materiau *pmateriau;
	no_liste = no_liste-1;
	no_couche = no_couche-1;
	pmateriau=(pparoi+no_liste)->materiau_couches;
	*epaisseur = pmateriau->epaisseur[no_couche];
	*lambda = pmateriau->lambda[no_couche];
	*cp = pmateriau->cp[no_couche];
	*rho = pmateriau->rho[no_couche];
}

/*------------------------------------------------------------*/
void lit_fic_options(fp,nblignes_lire,option_resultats,nom_GEN)
FILE	*fp;
int nblignes_lire;
int *option_resultats;
char *nom_GEN;
{
int i,id;
char buf[36];
// nb de ligne du fichier OPTIONS

	  id=fscanf(fp,"%s %s ", buf,nom_GEN);
	  if(id==EOF) 
	  {printf("Erreur: nombre de lignes du fichier 0 au lieu de %d\n",nblignes_lire);
	   exit(0);
	  }
	printf("%s : %s \n",buf,nom_GEN);
	printf("Variables sauvegardees si valeur 1\n");
	for(i=1;i<nblignes_lire;i++)
	{
	  id=fscanf(fp,"%s %d ", buf,option_resultats+i);
	  if(id==EOF) 
	  {printf("Erreur: nombre de lignes du fichiers %d au lieu de %d\n",i,nblignes_lire);
	   exit(0);
	  }
	  printf("%s %d \n", buf,option_resultats[i]);
	}
	printf("\n");
}
/*_______________________*/
/* Format de la fonction */
/*_______________________*/

void usage()
	{
  	printf("\n   format d'entree des parametres:\n\n");
  	printf("*transitoire_h_option*:\n");
  	printf(" en INPUT\n");
	printf("\t Tmeteo Tse(.val) Tn1(.val) Tn2(.val)\n");
	printf("\t Tint(.val) Tfix(.val)  flux_solaire_incident(.val)\n"); 
	printf("\t albedo(.val) emissivite(.val) no_paroi(.val)\n");
	printf("\t hc(.val) hint(.val) surfaces(.val) fac_forme(.fac) fac_forme_ciel(.val)\n");
	printf("\t pas_de_temps nom_fichier_paroi(.txt)\n");
	printf(" en OUTPUT\n");
	printf("\t Tse_t(.val) Tn1_t(.val) Tn2_t(.val) \n");
	printf(" en INPUT \n");
	printf("\t calcul_flux_net\n");
	printf("\t flux_atmosphere\n");
	printf("\t nom_fichier_Options_Calcul\n");
	printf("\t nom_fichier_Options_Resultats\n\n");
	printf(" QUELQUES INDICATIONS\n");
	printf("\t - Les temperatures sont en Celsius, certaines sont fixees (Tfix)\n"); 
	printf("\t		(convention:0=libre, 1= valeur fix� � Tmeteo)\n");
	printf("\t	calcul_flux_net = 1 (d�faut) on calcule le flux solaire net � partir des flux solaires incidents\n");
	printf("\t	           calcul_flux_net = 0  le flux solaire net est donn� en entree\n\n");
	printf("NOTA : plus d'info dans fonction_solene_plus.doc\n");
  	printf("\n\n");
	exit(0);
	}

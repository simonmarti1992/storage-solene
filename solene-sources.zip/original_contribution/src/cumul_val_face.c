/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */
 
/*
cumul_val_face

solutile.o geomutile.o lib_solene_94.o -lm
*/

// Dominique GROLEAU   10 janvier 2004


// Calcule par face; 
//		valeur moyenne pond�r�e par la surface
//		valeur cumul�e multipli�e la surface
//		valeur cumul�e
//		valeur moyenne 
// sur une g�om�trie triangul�e de faces
// et construit le descripteur associ� pour la g�om�trie des m�mes faces non triangul�es



#include <solene.h>


// DECLARATION des fonctions 
void format_entree();
void traite_cir_val_face();

// declaration application 





/************************************************/
main(argc,argv)
int argc;char **argv;
{
 char buf[512],*s_dir;
 int 	i;

 FILE	 *fp;
 int	 nbfacg,nomaxg,nbfacgt,nomaxgt;
 struct	 modelisation_face *facg,*facgt;
 double	 englob[10];
 int	 nbc;

 double  *surf_cont,*valeura;

 float	 minv,maxv;

 int	op;

  if(argc!=7){ format_entree(); exit(0);}

	s_dir=(char *)getenv("PWD");
	

 nb_etat=0;      /* nb de valeurs entieres allouees par contour */

 printf("Fonction Solene: cumul_val_face\n\n");

 // LIT les faces : geometrie_face
 compose_nom_complet(buf,s_dir,argv[1],"cir");
 if((fp=fopen(buf,"r"))==NULL)
	{ printf("impossible ouvrir %s\n",buf);
	  exit(0);
	}

   lit_en_tete(fp,&nbfacg,&nomaxg,englob);
   facg=alloue_face(nbfacg,1000);
   lit_fic_cir3d(fp,nbfacg,facg); 
   fclose(fp);

   printf(" Geom�trie_face   : %s (%d faces)\n",buf,nbfacg);	


 // LIT les faces triangul�e : geometrie_face_triangule
 compose_nom_complet(buf,s_dir,argv[2],"cir");
 if((fp=fopen(buf,"r"))==NULL)
	{ printf("impossible ouvrir %s\n",buf);
	  exit(0);
	}

   lit_en_tete(fp,&nbfacgt,&nomaxgt,englob);
   	   // test coherence
	   if(nbfacg != nbfacgt) 
	   { printf("incompatibilit� entre geometrie face et geometrie triangul�e\n");
	     exit(0);
	   }
   facgt=alloue_face(nbfacgt,1000);
   lit_fic_cir3d(fp,nbfacgt,facgt); 
   fclose(fp);


	// calcule le nombre de contour de geometrie_face_triangule
	nbc = nbcontours_total(facgt, nbfacgt);

	printf(" Geom�trie_face_triangul�   : %s (%d faces, %d contours)\n",buf,nbfacgt,nbc);	

    // LIT les valeurs de Surface associ�es : surface_geometrie_face_triangul�e
    compose_nom_complet(buf,s_dir,argv[3],"val");
	if((fp=fopen(buf,"r"))==NULL)
	{ printf("impossible ouvrir %s\n",buf);
	  exit(0);
	}
    printf(" Surface_geometrie_face_triangulee : %s\n",buf);

	//lit seulement  pour val min et max  */	
    fscanf(fp,"%d %d %f %f\n",&i,&i,&minv,&maxv);
    rewind(fp);
	

    // Allocation du tableau des valeurs associ�es aux contours*/
	surf_cont = alloue_double(nbc,456);
	lect_fic_val(fp, surf_cont);
	fclose(fp);

	// LIT les VALEURS  : valeur_geometrie_face_triangul�e
    compose_nom_complet(buf,s_dir,argv[4],"val");
	if((fp=fopen(buf,"r"))==NULL)
	{ printf("impossible ouvrir %s\n",buf);
	  exit(0);
	}
    printf(" Valeur_geometrie_face_triangulee : %s\n",buf);

	//lit seulement  pour val min et max  */	
    fscanf(fp,"%d %d %f %f\n",&i,&i,&minv,&maxv);
    rewind(fp);
	
    // Allocation du tableau des valeurs associ�es aux contours*/
	valeura = alloue_double(nbc,456);
	lect_fic_val(fp, valeura);
	fclose(fp);

	/*for (i=0;i<nbc;i++)
	{ printf("%f %f\n",surf_cont[i],valeura[i]);
	}*/

  // TYPE de CALCUL
  sscanf(argv[5],"%d",&op);
  if(op<0 || op>4)
  { printf(" il faut 1< code d'operation <4 \n");
	exit(0);
  }
  printf("\n Type de calcul effectu�:\n");
  if(op==1)      printf("    Somme(v*s)/S (moyenne pond�r�e des valeurs)\n");
  else if(op==2) printf("    Somme(v*s)	(cumul surfacique des valeurs)\n");
  else if(op==3 )printf("    Somme(v)	    (cumul simple des valeurs)\n");
  else if(op==4 )printf("    Somme(v)/n	(moyenne des valeurs)\n\n");
  else 
  { printf(" il faut 1< code d'operation <4 \n");
	exit(0);
  }


  // OUVRE le fichier resultat : resultat_geometrie_face
 compose_nom_complet(buf,s_dir,argv[6],"val");
 if((fp=fopen(buf,"w"))==NULL)
	{ printf("impossible ouvrir %s\n",buf);
	  exit(0);
	}
 printf(" \n Resultat_geometrie_face   : %s\n",buf);	

   // FAIT le calcul par face
 printf(" \n Traitement en cours ...\n\n");	
 traite_cir_val_face(facg,facgt,nbfacg,surf_cont,valeura,fp,op);

  fclose(fp);

   // fin
   desalloue_fface(facg,nbfacg);
   desalloue_fface(facgt,nbfacgt);
   desalloue_double(valeura);
   desalloue_double(surf_cont);

   creer_OK_Solene();
   printf("\n Fin cumul_val_face\n");

}

/*------------------------------------------------------------*/
void traite_cir_val_face(facg,facgt,nbfacg,surf_cont,valeur_cont,fp,op)
struct	modelisation_face *facg,*facgt;
int		nbfacg;
double	*surf_cont,*valeur_cont;
int		op;
FILE *fp; // fichier de resultat
{
 int 	i,j, noc,nop;
 struct contour *pcont;
 struct circuit *pcir;
 
 int	nbc;
 double valr; // valeur pour la face non triangul�e
 double vmin,vmax;
 double surf;

 // ECRIT en TETE FICHIER VAL RESULTAT
  vmin= 10000000.; vmax=-vmin;
  fprintf(fp,"%d %d %15.3f %15.3f\n",nbfacg,nbfacg,vmin,vmax);

	
	noc=0;
	// TRAITEMENT PAR FACE
	for(i=0;i<nbfacg;i++)
	 { //printf(" FACE %d   \n",(facgt+i)->nofac_fichier);

	   nop =0;
	   surf=0;
	   valr=0;
	   // CALCULE la valeur � partir  de Geometrie_face_triangule
	   pcont=(facgt+i)->debut_projete;
	   while(pcont)	   
         { pcir=pcont->debut_support;
		   surf+= surf_cont[noc];
           //printf("     Contour %d      Val %10.2f Surf %10.2f\n",nop,valeur_cont[noc],surf_cont[noc]);

           pcont=pcont->suc;
		   if(op==1 || op==2) valr+= valeur_cont[noc]*surf_cont[noc];
		   else  valr += valeur_cont[noc];

		   noc++; nop++; 
         } 

	   // Evalue le r�sultat
	   //printf(" valeur %f  surf face %f \n",valr,surf);
	   if(op==1) valr = valr / surf;
	   else if(op==4) valr= valr / nop;
	   if(valr < vmin) vmin=valr;
	   if(valr > vmax) vmax=valr;

	   // ECRIT LE RESULTAT POUR LA FACE i de Geometrie_face
	   nbc= nb_contour_face(facg+i,1);	
	   fprintf(fp,"f%d %d\n",(facg+i)->nofac_fichier,nbc);
	   for (j=0;j<nbc;j++)
	   { fprintf(fp,"%10.3f\n",valr);
	   }

	}

 // REECRIT en TETE FICHIER VAL RESULTAT
	rewind(fp);
	fprintf(fp,"%d %d %15.3f %15.3f\n",nbfacg,nbfacg,vmin,vmax);
}


/*------------------------------------------------------------*/
void format_entree()
{
  printf("\nFormat de la commande: \n");
  printf("\n   cumul_val_face \n");
  printf("\tIN   geometrie_face(.cir) \n");
  printf("\tIN   geometrie_face_triangul�e(.cir) \n");
  printf("\tIN   surface_geometrie_face_triangul�e(.val) \n");
  printf("\tIN   valeur_geometrie_face_triangul�e(.val) \n");
  printf("\tIN   type_de_resultat_a_calculer \n");
  printf("\tOUT  resultat_geometrie_face(.val) \n");
  printf("\nNOTA  type_de_resultat\n");
  printf("\t  1    Somme(v*s)/S (moyenne pond�r�e des valeurs)\n");
  printf("\t  2    Somme(v*s)	(cumul surfacique des valeurs)\n");
  printf("\t  3    Somme(v)	    (cumul simple des valeurs)\n");
  printf("\t  4    Somme(v)/n	(moyenne des valeurs)\n\n");


}



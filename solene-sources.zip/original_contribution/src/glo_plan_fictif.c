/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/* glo_plan_fictif.c 

EVALUE le GLO en provenance des �l�ments d'une sc�ne  SUR PLAN FICTIF TRIANGULE HORIZONTAL

D. GROLEAU dec 2003
D. GROLEAU modiifcation mars 2004 appel � coplanaire
D. GROLEAU modification Janvier 2007 ; prend aussi en compte dans le calcul du GLO la partie r�fl�chie
D. GROLEAU modification Mars 2007 ; supprime correction Janvier 2007
*/
/*_____________________________________________________________________________*/

/*
modele ecl_plan_fictif
cc ecl_plan_fictif.c  pers_util.o solutile.o face_op_face.o lib_solene_94.o geomutile.o poly_op_poly.o traite.o solaire.o -o ecl_plan_fictif -lm
*/

/*__________________________________________________________________________*/
/* POUR UN FICHIER .cir contenant un plan fictif maill�	(nbfac fac) horizontal */
/* determine pour chaque contour                                            */
/* une vue cach�e pour le fichier .cir MASQUE non triangul� (nbfac1 fac1 )  */
/* et calcule le facteur de forme et le GLO 	            */

/* avec les contours du fichier .cir MASQUE maill�  (nbfac2 fac2)           */
/*  GLO = Somme(p) ( Fp * Emissivite(p) * T4 (p) * constants de stefan )    */
/* Modele : ecl_plan_fictif.c                                               */    
/*__________________________________________________________________________*/
// ATTENTION  modif de mars 2004:

// Ne tient pas compte des faces situ�es dans le m�me plan que celui du contour de la face en traitement


#include<solene.h>


// DECLARE FUUNCTION
void evalue_ff();
void fait_pers_fac1();
void format_glo() ;
int GLO_des_patch_ds_face();
double  traite_nusselt();
double 	fform_yamanouti();
double longueur_arete_poly();
double divise_triangle();


// EN GLOBAL
struct modelisation_face *fac,*fac1,*fac2,*fac3;

struct vertex { double x, y, z; };
struct triangle { struct vertex a, b, c; };

int 	nbfac,nbfac1,nbfac2,nbfac3;

extern int option_calcul_z;   /* option CALCUL du Z ds FACE-OP-FACE 1=oui */
                              /* utilise ds singul.c epure_polygone */
			      /* et dans face_op_face.c             */
extern 	double coef_discol;
extern 	int z_axono_pers;


double 	ang,angvis,pi,tgvis,covis,sinvis, x[3], y[3], z[3], valg;
//double  pi, tgvis;
double  valg;
double 	normal_x,normal_y,normal_z,vnf[3];
double  long_max_arete,distance_patch_patch,xgg,ygg,zgg;
struct  circuit *cir_traite;

FILE *pval;

double somme_fac_form, valeur_ecl;

double *emis ;
double *temperature;

#define STEFAN 5.67e-8

 double	 epsiloneN;  // parametre de coplanaire
 int	 facteurD;   // parametre de coplanaire


/*_________________________________________________________________*/
main(argc,argv)           
int argc;char **argv;
	{
	int i,k,noc,nomax,nbf,nbcont,nb_cont,nofac;
 	char nom_in[256],nom_masc[256],nom_masc_tr[256],nom_emis[256],nom_temperature[256],nom_glo_out[256],c;
 	FILE *pfic;
 	struct contour *pcont;
 	struct circuit *pcir;
	char *s_dir;

    double englob[10];
	double ddd;


  int nof_max_somme,noc_max_somme,num;
  double max_somme_fac,val_min,val_max;

printf("Fonction Solene : glo_plan_fictif\n\n");
// Mars 2007
 printf("\nGLO = Somme(p) ( Fp * Emissivite(p) * T4 (p) * constante de stefan ) \n\n");
// printf("\nGLO = Somme(p) ( Fp * T4 (p) * constante de stefan ) \n\n");
// Fin  mars 2007

/* initialisation */

   	singularite=0; non_singularite=0; nb_etat=0;
   	pb_masque=0; colle_max=coef_discol*DISCOL;
   	pi=4*atan(1.);

// initialisation pour coplan�rit�
   epsiloneN = 0.0001;
   facteurD= 1000;


	s_dir = (char *)getenv("PWD");  

   	if(argc!=7 && argc!=8) format_glo();


/* champ de vision : 1/2 angle au sommet */
   	ang=89.9;
	if (argc==8)
	{  sscanf(argv[7],"%lf",&ang);
	}
 printf("1/2 angle de vision : %f\n",ang);

   	angvis=pi*ang/180.;
   	tgvis=tan(angvis); covis=cos(angvis); sinvis=sin(angvis);

 
/* lecture parametres commande */
    compose_nom_complet(nom_in,s_dir,argv[1],"cir");  
    printf("\n\nplan fictif triangul�       : %s \n",nom_in);

    compose_nom_complet(nom_masc,s_dir,argv[2],"cir");  
    printf("geometrie masque            : %s \n",nom_masc);

    compose_nom_complet(nom_masc_tr,s_dir,argv[3],"cir");  
    printf("geometrie masque triangulee : %s \n",nom_masc_tr);

    compose_nom_complet(nom_emis,s_dir,argv[4],"val");  
    printf("emissivit� du masque_triangule : %s \n",nom_emis);

    compose_nom_complet(nom_temperature,s_dir,argv[5],"val");  
    printf("emissivit� du masque_triangule : %s \n",nom_temperature);

    compose_nom_complet(nom_glo_out,s_dir,argv[6],"val");  
    printf("GLO sur plan fictif    : %s \n",nom_glo_out);


/* open les fichiers a traiter  */
/* lecture  pfic  ; alloue fac nbfac  */

   if((pfic=fopen(nom_in,"r"))==NULL)
	{ printf("\n impossible ouvrir %s\n",nom_in); 
	  exit(0);
	}
   lit_en_tete(pfic,&nbfac,&nomax,englob);
   printf("\nplan fictif triangul� %d faces\n",nbfac);
   fac=alloue_face(nbfac,34);
   lit_fic_cir3d(pfic,nbfac,fac);
   fclose(pfic);

/* lecture  pfic masque ;  alloue fac1 nbfac1 pour traitement*/
/* et             met original ds fac3 nbfac3 */

   if((pfic=fopen(nom_masc,"r"))==NULL)
	{ printf("\n impossible ouvrir %s\n",nom_masc); 
	  exit(0);
	}
   lit_en_tete(pfic,&nbfac1,&i,englob);
   printf("geometrie masque %d faces\n",nbfac1);

   fac1=alloue_face(nbfac1,34);
   fac3=alloue_face(nbfac1,34);
   nbfac3=nbfac1;
   lit_fic_cir3d(pfic,nbfac3,fac3);
   fclose(pfic);


/* lecture  pfic masque triangule;  alloue fac2 nbfac2 */

   if((pfic=fopen(nom_masc_tr,"r"))==NULL)
	{ printf("\n impossible ouvrir %s\n",nom_masc_tr); 
	  exit(0);
	}

   lit_en_tete(pfic,&nbfac2,&i,englob);
   printf("geometrie masque triangul�e %d faces\n",nbfac2);

   fac2=alloue_face(nbfac2,34);
   lit_fic_cir3d(pfic,nbfac2,fac2);
   fclose(pfic);

	// �value le nb de contours de masc_tr
	nb_cont=0;
	for(i=0;i<nbfac2;i++)
	  { nb_cont+= nb_contour_face(fac2+i,1);
	  }
	printf("nb de contours de masque_tr : %d\n",nb_cont);


 /* lecture  pval des emissivites du masque triangule */
 /* et stockage des valeurs */

	if ((pval = fopen(nom_emis,"r")) == NULL)
		{ printf("\n  impossible d'ouvrir %s\n", nom_emis);
		  exit(0);
		}
	fscanf(pval,"%d %d %lf %lf",&nbf,&nomax,&val_min,&val_max);
	if(nbf != nbfac2)
	{ printf("pb : nb de faces des emissivite.val # nb de faces de masque triangule\n");
	  exit(0);
	}

	emis =alloue_double(nb_cont,1234);

	num=0;
	for(i=0;i<nbfac2;i++)
	 {
		fscanf(pfic,"\n%c%d%d\n",&c,&nofac,&nbcont);
		for(k=0;k<nbcont;k++)	
		 {	
		  fscanf(pfic,"%lf\n",emis+num);
		  //printf("%f\n",emis[num]);
		  num++;
		 }
	 }
    fclose(pval);

	//for(i=0;i<nb_cont;i++) printf("%f\n",*(emis+i));

/* lecture  pval des temperatures du masque triangule */
 /* et stockage des valeurs */

	if ((pval = fopen(nom_temperature,"r")) == NULL)
		{ printf("\n  impossible d'ouvrir %s\n", nom_temperature);
		  exit(0);
		}
	fscanf(pval,"%d %d %lf %lf",&nbf,&nomax,&val_min,&val_max);
	if(nbf != nbfac2)
	{ printf("pb : nb de faces des temperature.val # nb de faces de masque triangule\n");
	  exit(0);
	}

	temperature =alloue_double(nb_cont,1234);

	num=0;
	for(i=0;i<nbfac2;i++)
	 {
		fscanf(pfic,"\n%c%d%d\n",&c,&nofac,&nbcont);
		for(k=0;k<nbcont;k++)	
		 {	
		  fscanf(pfic,"%lf\n", temperature+num);
		  //printf("%f\n", temperature[num]);
		  num++;
		 }
	 }
    fclose(pval);

	//for(i=0;i<nb_cont;i++) printf("%f\n",*( temperature +i));



/** ECRITURE DU FICHIER GLO.val **/

	if ((pval = fopen(nom_glo_out,"w")) == NULL)
		{ printf("\n  impossible de creer %s !!\n\n", nom_glo_out);
		  exit(0);
		}

	val_min=1000000; val_max = -val_min;
	fprintf (pval,"%d %d %15.5f %15.5f\n", nbfac, nomax, val_min, val_max);   

	
	/* EVALUE Eclairement sur Plan Fictif horizontal : fac */

	printf("\nTraitement en cours ...\n");
	printf("\n");

  max_somme_fac=0;  /* somme maxi trouve pour un contour (<1 normalement) */
  nof_max_somme=0;
  noc_max_somme=0;

/* traitement pour chaque chaque face de nom_in */

 for(i=0;i<nbfac;i++) 
  { 
	//printf("\nTraite contours de Face %d \n",(fac+i)->nofac_fichier);

    fprintf (pval,"f%d %d\n",(fac+i)->nofac_fichier,nb_contour_face(fac+i,1));

	normal_x=(fac+i)->vnorm[0];
	normal_y=(fac+i)->vnorm[1];
	normal_z=(fac+i)->vnorm[2];
    vnf[0]=normal_x; vnf[1]=normal_y; vnf[2]=normal_z;

    /* observateur regarde dans le sens de la normale a la face */
    obs.x=-normal_x;
    obs.y=-normal_y;
    obs.z=-normal_z;
    /* transformation a appliquer a chaque contour de la face */
    tranfo();


	noc=0;
    pcont=(fac+i)->debut_projete;


	while(pcont) 	   
      { 
        obs.xo=0; obs.yo=0; obs.zo=0; 
	    long_max_arete=0;
		pcir=pcont->debut_support;
		cir_traite=pcir;
        for(k=0;k<pcir->nbp-1;k++) 
           { 
	         obs.xo+=pcir->x[k];
             obs.yo+=pcir->y[k];
             obs.zo+=pcir->z[k];

			 ddd=longueur_arete_poly(pcir->x[k],pcir->y[k],pcir->z[k],pcir->x[k+1],pcir->y[k+1],pcir->z[k+1]);
			 if(ddd>long_max_arete)long_max_arete=ddd;
            }
        obs.xo=obs.xo/(pcir->nbp-1);
        obs.yo=obs.yo/(pcir->nbp-1);
        obs.zo=obs.zo/(pcir->nbp-1);
		xgg=obs.xo; ygg=obs.yo; zgg=obs.zo;
 		noc++;
// ????? activer le print sinon Mauvais, pourquoi?????
//printf("\nDans Plan_Fictif, Face %d contour %d\n",(fac+i)->nofac_fichier,noc);
		//printf("      pt de calcul %lf %lf %lf\n",obs.xo,obs.yo,obs.zo);   
		//printf("normale %lf %lf %lf\n",normal_x,normal_y,normal_z);  

		/* TRAITEMENT pour ce CONTOUR : 

		pers de fac1, 

		facform avec patch visibles de fac2 

		et calcul eclairement reflechi sur le contour

		*/
	
        fait_pers_fac1(i);
        somme_fac_form=0;

		valeur_ecl=0;


		evalue_ff((fac+i)->nofac_fichier); 


        /*printf("somme fac forme %f \n",somme_fac_form);*/
      	if( somme_fac_form > max_somme_fac )
           { max_somme_fac = somme_fac_form;
  	   	     nof_max_somme=(fac+i)->nofac_fichier;
 		     noc_max_somme=noc;
           }

		if(valeur_ecl < val_min) val_min = valeur_ecl;

		if(valeur_ecl > val_max) val_max = valeur_ecl;


        fprintf (pval,"%15.5f\n",valeur_ecl);

        pcont=pcont->suc;
      }
  }

 printf("somme fac forme MAXI calcule : %f pour face %d contour %d\n",max_somme_fac,nof_max_somme,noc_max_somme);

 desalloue_fface(fac,nbfac);
 desalloue_fface(fac1,nbfac1);
 desalloue_fface(fac2,nbfac2);

 desalloue_fface(fac3,nbfac3);

 desalloue_double(emis);
 desalloue_double(temperature);



 rewind(pval);
 fprintf (pval,"%d %d %15.5f %15.5f\n", nbfac, nomax, val_min, val_max);   
 fclose(pval);


 creer_OK_Solene();
 printf("\n\nFin du Traitement GLO sur Plan Fictif Horizontal\n");

 exit(0);
}


/*_________________________________________________________________*/
void fait_pers_fac1(noface)
int noface;
{  
	int i;

/* met en perspective le fichier Masque non triangul� fac1 */
/* COPIE ORIGINAL fac3 ds fac1 pour travail */
    for(i=0;i<nbfac1;i++) 
	{ //printf("copie face indice %d\n",i);
		copie_face(fac3+i,fac1+i);
	}


/* TRANSFORMATION fichier "masque" et COUPE PYRAMIDE , si vu */
    for(i=0;i<nbfac1;i++)
	{ 
	  if(coplanaire(fac+noface,1,fac1+i,1,epsiloneN,0,facteurD)!=1)
        { 
		  if(visible_pers(fac1+i,1))
           { 
	        tran_face(fac1+i,1,fac1+i,0);
            tran_normale((fac1+i)->vnorm);
            if((fac1+i)->debut_dessin) 
                { 
				calcul_d_du_plan(fac1+i,0);
                face_dans_vision(fac1+i,0);
                }
            }
        }
      }

/* PERSPECTIVE */
   init_fenetre_affichage();
   for(i=0;i<nbfac1;i++)
	{ 
	  //liste_face(fac1+i,0);
	  if((fac1+i)->debut_dessin)
        { //printf("   avant pers face %d\n",(fac1+i)->nofac_fichier);
		  pers_conic_face(fac1+i,0);
	    }
	}
/* reajuste la fenetre a angle de vision */
   fen_aff[0]=-tgvis; fen_aff[1]=-tgvis; 
   fen_aff[3]=tgvis; fen_aff[4]=tgvis; 
   cal_fen_aff();
          /* attention si angvis proche de 90 */
          /* on evite fen_aff[6]=0 */
   if(fen_aff[6]<0.008) fen_aff[6]=0.008;

/* NORMALISATION */
   z_axono_pers=1;  
   option_calcul_z=0;

   for(i=0;i<nbfac1;i++)
     { if((fac1+i)->debut_dessin)
           { //printf("   ok pers face %d\n",(fac1+i)->nofac_fichier); 
		     normalise_face(fac1+i,0);
             sens_face(fac1+i,0,1);		 
           }

	   copie_face_projete(fac1+i,0,fac1+i,1);
     }

  /* TRAITE VU/CACHE ; resultat dans ->dessin */

   traite_moins(fac1,nbfac1);

	   /*
       for(i=0;i<nbfac1;i++)
	   {if((fac1+i)->debut_dessin)
					  {
					  printf("\n   apres vu cach� face %d\n",(fac1+i)->nofac_fichier);
					  printf("\n   liste face %d apres pers\n",(fac1+i)->nofac_fichier);
					  liste_face(fac1+i,0);
					  }
	   }
       */
   z_axono_pers=0;
   option_calcul_z=1;
}


/*_________________________________________________________________*/
void evalue_ff(noface)
int noface;
{
  /* evalue l'�clairement sur le contour en traitement
  /* pour chaque face de fac2 (nbfac2)  masque triangul� porteur d'�clairement */
  /* cherche si vue ds la perspective fac1 (nbfac1) */
  /* si vu, test pour chaque centre de gravite des contours de fac2 */
  /*        si est dans le polygone image perspective fac1 de la face */
  /*             si oui, evalue facteur de forme et eclairement avec contour en traitement */
 int i,j;
 int noc;

 noc=0;
 for(i=0;i<nbfac2;i++)
  { //printf(" Examine dans Masque_TR  Face  %d\n",(fac2+i)->nofac_fichier);
	 /* cherche si fac2+i vue ds pers : 
        elle est vue si on trouve une face coplanaire fac1+j vue  meme sens normale*/
    for(j=0;j<nbfac1;j++)
     { 
	  if((fac1+j)->debut_dessin)
        { //printf("  dans Masque  Face vue %d\n",(fac1+j)->nofac_fichier);
	      // on utilise fac3 pour avoir la vraie normale de fac1

	      if(coplanaire(fac2+i,1,fac3+j,1,epsiloneN,1,facteurD)) // anciennement 0.00001
			{ 
			  //printf("   Coplanaires Face Masque_TR %d et Face Masque %d\n",(fac2+i)->nofac_fichier,(fac1+j)->nofac_fichier);
			  /* elle est vue au moins en partie ;
			     calcule les fac de forme se ses contours avec le contour en traitement 
			     et l'eclairement qui en r�sulte */
		   	  if(GLO_des_patch_ds_face(i,j,noc)) 
			    { //un facteur de forme non nul
				  //evalue eclairement r�fl�chi vers le contur en traitement
				  break;
				}
			 }
		}
	 }//fin de for j
	noc=noc+nb_contour_face(fac2+i,1);
  }// fin du for i

}

/*_________________________________________________________________*/
int GLO_des_patch_ds_face(i,j,ind_contour)
int i,j;

int ind_contour;

{ 

	/* cherche contours de fac2+i contenu dans face fac1+j */

	/* et calcule facform et �clairement GLO pour le contour en traitement de fac */
 int k;
 struct contour *pcont;
 struct circuit *pcir;
 double xg,yg,zg;
 double xp, yp, zp;
 double xyz[3];
 double ang_inc,fac_de_form;
 int noc, dans_face;

 double tempK ;

 noc=0; dans_face=0;
 pcont=(fac2+i)->debut_projete;
 while(pcont)
     { pcir=pcont->debut_support;
       /* cherche centre de gravite */
	   xg=yg=zg=0;
       for(k=0;k<pcir->nbp-1;k++) 
         { xg+=pcir->x[k];
           yg+=pcir->y[k];
           zg+=pcir->z[k];
         }
       /* et vecteur centre de gravite - point observation */
           
       xg=xg/(pcir->nbp-1) -obs.xo;
       yg=yg/(pcir->nbp-1) -obs.yo;
       zg=zg/(pcir->nbp-1) -obs.zo;
	   distance_patch_patch=longueur_arete_poly(xg,yg,zg,0.,0.,0.);


	   //printf("xg %f  yg %f  zg %f\n",xg,yg,zg);


	   /* test si ds le champ de la face */
       xyz[0]=xg; xyz[1]=yg; xyz[2]=zg;

       if((vincid(vnf,xyz,&ang_inc)) > 0)
         {

           /* transforme en perspective */
           tranp(xg,yg,zg,xyz,xyz+1,xyz+2);
   
           /* coupe par pyramide : retient ou non le point */
       	   if(xyz[2]<0 && fabs(xyz[0]/xyz[2])<tgvis && fabs(xyz[1]/xyz[2])<tgvis) 
          	{ 
			  /* met en pers et normalise  */
			  xp=-xyz[0]/xyz[2];
			  yp=-xyz[1]/xyz[2];
			  zp=0;
              //printf("xa %f  ya %f  za %f\n",xp,yp,zp);

              z_axono_pers=1;
              normalise_point(xp,yp,zp,&xp,&yp,&zp);
              z_axono_pers=0;
              //printf("xp %f  yp %f  zp %f\n",xp,yp,zp);


              /* test si ds face j en pers */
              if(point_dans_face(xp,yp,(fac1+j),0))
               {

				// donc parmi les faces coplanaires , c'est la bonne

				dans_face=1;
			    fac_de_form=traite_nusselt(pcir); //de fac2
                somme_fac_form+=fac_de_form;

                // calcule eclairement

				//printf("   calcule GLO avec face %d contour %d (indice contour %d)\n",(fac2+i)->nofac_fichier,noc,ind_contour);
				//printf("   facform = %f emis = %f  temperature = %f\n",fac_de_form, *(emis+ind_contour), *(temperature+ind_contour));

				// voir note  : densit� ecl emis de j vers i = Fij * Rj
				tempK = temperature[ind_contour] + 273;
// Mars 2007
				valeur_ecl = valeur_ecl + fac_de_form * emis[ind_contour]* pow(tempK,4) * STEFAN;
				// valeur_ecl = valeur_ecl + fac_de_form * pow(tempK,4) * STEFAN;
// Fin Mars 2007
				//printf("ff %f emis %f T %f glopartiel %f\n", fac_de_form,emis[ind_contour], temperature[ind_contour], valeur_ecl);

               }
         }
     }

   ind_contour++;

   noc++;
   pcont=pcont->suc;
  }

 return(dans_face);
}


/*_________________________________________________________________*/
double traite_nusselt(pcir)
struct circuit *pcir;
{ 
  int i,recurs,nbdivise=1;
  struct triangle t;

  /* YAMANOUTI */
  /*printf("yamanouti\n");*/


/* triangle parent */
/* ne fonctionne que pour patch triangulaire */
   t.a.x=cir_traite->x[0],t.a.y=cir_traite->y[0], t.a.z=cir_traite->z[0];
   t.b.x=cir_traite->x[1],t.b.y=cir_traite->y[1], t.b.z=cir_traite->z[1];
   t.c.x=cir_traite->x[2],t.c.y=cir_traite->y[2], t.c.z=cir_traite->z[2];

  if(distance_patch_patch > 5*long_max_arete) 
	{
	valg=fform_yamanouti(pcir,xgg,ygg,zgg);
	recurs=0;
	}
  else if(distance_patch_patch > 5*long_max_arete/2) recurs=1;
  else if(distance_patch_patch > 5*long_max_arete/4) recurs=2;
  else recurs=3;

/*  printf("d=%5.3f l=%5.3f  %d\n",distance_patch_patch,long_max_arete,recurs);*/

  if(recurs)
   	{ 
	valg=0;

	/* divise le triangle parent en 4, 16 ou 64 elements */
	divise_triangle(&t,recurs,pcir);

	for (i=0;i<recurs;i++)
		nbdivise *= 4;
	valg=valg/nbdivise;

/*	printf("kkkk=%f  %d\n",valg,nbdivise);*/
   	}

return(valg);
}


/*-----------------------------------------------------------*/
double fform_yamanouti(pcir,xppp,yppp,zppp)
struct circuit *pcir;
double xppp,yppp,zppp;
{
  int i;
  double aire,ga,gb;
  double poab[4],xt[3],yt[3],zt[3];

  aire=0;
/*  xt[2]=obs.xo;  yt[2]=obs.yo; zt[2]=obs.zo; */ /* pt O */

 xt[2]=xppp;  yt[2]=yppp; zt[2]=zppp;

  for(i=0;i<pcir->nbp-1;i++)
    { /* traite une arete ab (i,i+1) */
       xt[0]=pcir->x[i]; yt[0]=pcir->y[i]; zt[0]=pcir->z[i];  
       xt[1]=pcir->x[i+1]; yt[1]=pcir->y[i+1]; zt[1]=pcir->z[i+1]; 
 
      /* normale du plan oab */       
       normale_avec_3pts(xt,yt,zt,poab);
	
      /* calcul alpha  : cos entre 2 vecteurs poab et normale normale_x y z */
       ga=cos_angle_vec_3D(poab[0],poab[1],poab[2],normal_x,normal_y,normal_z);

      /* calcul du facteur de forme */

gb=cos_angle_vec_3D(xt[0]-xt[2],yt[0]-yt[2],zt[0]-zt[2],xt[1]-xt[2],yt[1]-yt[2],zt[1]-zt[2]);

       aire+=ga*acos(gb);  
    }

  return(fabs(aire/2)/pi);
}





/*________________________________________________________________________*/
double longueur_arete_poly(x1,y1,z1,x2,y2,z2)
double x1,y1,z1,x2,y2,z2;
{
 double longueur;
 longueur=(sqrt((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1)+(z2-z1)*(z2-z1)));
/*printf("longueur arete %f\n",longueur);*/
 return(longueur);
 
}



/*________________________________________________________________________*/
/* milieu de 2 points */
struct vertex average(v1, v2)
struct vertex *v1;
struct vertex *v2;
	{
	struct vertex m;

	m.x = (v1->x + v2->x) / 2;
	m.y = (v1->y + v2->y) / 2;
	m.z = (v1->z + v2->z) / 2;

	return m;
	}


/*________________________________________________________________________*/
/* divise un triangle en 4 triangles plus petits */
double divise_triangle(t,profond,pcir)
struct triangle *t;
struct circuit *pcir;
int profond;
	{
	int subt; 
	double cdgx,cdgy,cdgz,val;
	struct triangle new_t[4];
	val=0;

	new_t[0].a = t->a;
	new_t[1].b = t->b;
	new_t[2].c = t->c;

	new_t[0].c = new_t[2].a = new_t[3].b = average(&t->a, &t->c);
	new_t[0].b = new_t[1].a = new_t[3].c = average(&t->a, &t->b);
	new_t[1].c = new_t[2].b = new_t[3].a = average(&t->c, &t->b);
	
	/* recommence si profond n'est pas atteint */
	if (--profond != 0)
		for(subt = 0; subt < 4; subt++)
			divise_triangle(&new_t[subt],profond,pcir);
	else            
	    {
	    for(subt = 0; subt < 4; subt++)
		{
	        x[0]=new_t[subt].b.x, x[1]=new_t[subt].a.x, x[2]=new_t[subt].c.x;
	        y[0]=new_t[subt].b.y, y[1]=new_t[subt].a.y, y[2]=new_t[subt].c.y;
	        z[0]=new_t[subt].b.z, z[1]=new_t[subt].a.z, z[2]=new_t[subt].c.z;
	/* centre de gravite */
		cdgx=(x[0]+x[1]+x[2])/3,cdgy=(y[0]+y[1]+y[2])/3,cdgz=(z[0]+z[1]+z[2])/3;
	/* facteur de forme */
		val+=fform_yamanouti(pcir,cdgx,cdgy,cdgz);

	/*	ff=fform_yamanouti(pcir,cdgx,cdgy,cdgz);
		printf("%10.5f %10.5f %10.5f\n",x[1], y[1], z[1]); 
		printf("%10.5f %10.5f %10.5f\n",x[0], y[0], z[0]); 
		printf("%10.5f %10.5f %10.5f\n",x[2], y[2], z[2]);
		printf("cdg %10.5f %10.5f %10.5f ff=%f\n",cdgx,cdgy,cdgz,ff);*/

		}
	    valg+=val;
      /*    printf("kkk=%f\n",valg);*/

	    }
	return(valg);
	}





/*_________________________________________________________________*/
void format_glo()
{
  	printf("\n   format d'entree des parametres \n\n");

  	printf("\n  glo_plan_fictif  \n\n");

 printf("\n      la fonction a comme parametre ENTREE :\n\n");
 printf("\t geometrie_plan_fictif_in(.cir)\n"); 
 printf("\t geometrie_masque_in(.cir)\n");
 printf("\t geometrie_masque_triangule_in (.cir)\n");
 printf("\t emissivite_geometrie_masque_triangule (.val)\n");
 printf("\t temperature_surface_geometrie_masque_triangule (.val)\n");


 printf("\n                comme parametres en SORTIE :\n\n");
 printf("\t glo_plan_fictif (.val)\n\n");

 printf("\n                comme parametres FACULTATIF en ENTREE :\n\n");
 printf("\t angle_de_vue\n\n");


  exit(0);
	
}


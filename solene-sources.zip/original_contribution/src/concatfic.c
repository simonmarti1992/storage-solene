/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */
 
/* 
cc -o concatfic concatfic.c solutile.o geomutile.o lib_solene_94.o -lm
*/

// D.GROLEAU juillet 2002
/*
	Concatene deux ou plusieurs fichiers de faces .cir

*/
#include<solene.h>

// declare FUNCTIONS
void actualise_englob();
void actualise_fenext();
int ecrit_en_tete();
void ecrit_fic();
void format_entree_concatfic();
void init_fenext();
void traite();



FILE *fp1,*fpc;
int change_nofac;

///_____________________________________________________________
main(argc,argv)
int argc;char **argv;
{char buf[512],c[2],*s_dir;
 int i,nbfac,rendu;
 double englob[10],fenext[6];

	/* fenext[4]=zmin; [5]=zmax; 
	   fenext[0]=xmin; [1]=ymin; [2]=xmax; [3]=ymax; 
        */

printf("\n\n CONCATENATION DE FICHIERS \n\n");

  if(argc<5){format_entree_concatfic(); exit(0);}

	s_dir=(char *)getenv("PWD");

       rendu=0; nbfac=0; 

	for(i=0;i<10;i++)englob[i]=0;

  sscanf(argv[1],"%c%c",c,c+1);
  if(c[0]!='-'){format_entree_concatfic(); exit(0);}
  else if(c[1]=='i')change_nofac=0;
  else if(c[1]=='m')change_nofac=1;
  else {format_entree_concatfic();exit(0);}


    compose_nom_complet(buf,s_dir,argv[argc-1],"cir");
    fpc=fopen(buf,"w");
    if(fpc==NULL) 
	{ printf("impossible creer %s\n",buf);
	  exit(0);
	}	
    ecrit_en_tete(fpc,nbfac,rendu,englob);
    printf("\n fichier de sortie = %s \n",buf);
  

  /* traite tous les fichiers a concatener */
    for(i=2;i<argc-1;i++)
     {compose_nom_complet(buf,s_dir,argv[i],"cir");
      if((fp1=fopen(buf,"r"))==NULL)
          {printf("\n impossible ouvrir %s\n",buf); exit(0);}
printf(" traite fichier %s \n",buf);
      traite(&rendu,&nbfac,englob);
      if(i==2)init_fenext(englob,fenext);
      actualise_fenext(englob,fenext);
      fclose(fp1);
     }
    actualise_englob(englob,fenext);
    rewind(fpc);
    ecrit_en_tete(fpc,nbfac,rendu,englob);
	printf(" Fin du traitement Concatfic\n");
	creer_OK_Solene();
}
/*------------------------------------------------------------*/
void init_fenext(englob,fenext)
double * englob,*fenext;
{
	
	fenext[4]=englob[0];  fenext[5]=englob[1];
	fenext[0]=englob[2];  fenext[1]=englob[3];
	fenext[2]=englob[2];  fenext[3]=englob[3];

}
/*------------------------------------------------------------*/
void actualise_englob(englob,fenext)
double * englob,*fenext;
{
	englob[0]=fenext[4];	 englob[1]=fenext[5];
	englob[2]=fenext[0]; 	 englob[3]=fenext[1];
	englob[4]=fenext[0];	 englob[5]=fenext[3];
	englob[6]=fenext[2];	 englob[7]=fenext[3];
	englob[8]=fenext[2];	 englob[9]=fenext[1];
}
/*------------------------------------------------------------*/
void actualise_fenext(englob,fenext)
double *englob,*fenext;
{ 
 int i;

	if(englob[0]<fenext[4])fenext[4]=englob[0];
	if(englob[1]>fenext[5])fenext[5]=englob[1];

	for(i=2;i<10;i+=2)
		{if(englob[i]<fenext[0])fenext[0]=englob[i];
		 else if(englob[i]>fenext[2])fenext[2]=englob[i];
		 if(englob[i+1]<fenext[1])fenext[1]=englob[i+1];
		 else if(englob[i+1]>fenext[3])fenext[3]=englob[i+1];
		}

}

/*------------------------------------------------------------*/

void traite(rendu,nbfac,englob)
int *rendu,*nbfac;
double *englob;
{int nbfac1,nomax1;
       /* lit les entetes */
       lit_en_tete(fp1,&nbfac1,&nomax1,englob);
       *nbfac=*nbfac+nbfac1;
       
       ecrit_fic(fp1,rendu,nbfac1);
}
/*------------------------------------------------------------*/
void ecrit_fic(fp,rendu,nbfac)
FILE *fp;
int *rendu,nbfac;
{int i,j,k,kk,nofac,nbcont,nbtrou,nbp,nofacmax;
 double x,y,z; 
 char c;
   nofacmax=0;
   printf(" Concatene %5d Faces\n",nbfac);
  for(i=0;i<nbfac;i++)
	{fscanf(fp,"\n%c%d%d",&c,&nofac,&nbcont);
         /* printf("\n lit face no %d ",nofac); */
	 if(nofac>nofacmax)nofacmax=nofac;
         if(change_nofac)fprintf(fpc,"f%d  %d\n",nofac+*rendu,nbcont);
         else fprintf(fpc,"f%d  %d\n",nofac,nbcont);
         fscanf(fp,"\n %lf %lf %lf ",&x,&y,&z);
	 fprintf(fpc,"    %lf  %lf  %lf \n",x,y,z);
         for(j=0;j<nbcont;j++)
            {fscanf(fp,"\n%c%d",&c,&nbtrou);
	     fprintf(fpc,"    c%d\n",nbtrou);
             fscanf(fp,"\n%d",&nbp); fprintf(fpc,"  %d \n",nbp);
             for(k=0;k<nbp;k++)
		{fscanf(fp,"\n%lf%lf%lf",&x,&y,&z);
		 fprintf(fpc,"      %lf   %lf    %lf\n",x,y,z);
		}
             for(k=0;k<nbtrou;k++)
		{fscanf(fp,"\n%c",&c); fprintf(fpc,"   t\n");
                 fscanf(fp,"\n%d",&nbp); fprintf(fpc,"  %d \n",nbp);
                 for(kk=0;kk<nbp;kk++)
		   {fscanf(fp,"\n%lf%lf%lf",&x,&y,&z);
		    fprintf(fpc,"      %lf   %lf    %lf\n",x,y,z);
		   }
		}
            }
	}

   if(change_nofac)*rendu=nofacmax+*rendu;
   else if(*rendu<nofacmax)*rendu=nofacmax;
}
/*------------------------------------------------------------*/
void format_entree_concatfic()
{
  printf("\n   *concatfic* -m|-i fichier1(.cir)  fichier2(.cir) ----  fichier_out(.cir) \n");
  printf("\n     -m : change les numeros des faces \n");
  printf("     -i : ne change pas les numeros des faces \n\n");

}

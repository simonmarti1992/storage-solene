/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */
 
/* 
cc -o contour_face contour_face.c solutile.o lib_solene_94.o geomutile.o -lm  
*/

/*
 TRANSFORME LES CONTOURS EN FACES 
*/

#include<ctype.h>

#include<solene.h>
#include<ctype.h>


FILE *fp,*fpc;

/*_________________________________________________________________*/
main(argc,argv)
int argc;char **argv;
{char buf[50];
 int i,rendu,nbff,nomax,nofac,nbcont;
 double englob[10];
 struct modelisation_face *ff;
 char c[2],*s_dir;
  if(argc!=3)format_entree_contour_face(); 

	s_dir=(char *)getenv("PWD");

      compose_nom_complet(buf,s_dir,argv[1],"cir");
      if((fp=fopen(buf,"r"))==NULL)
          {printf("\n impossible ouvrir %s\n",buf); exit(0);}

   lit_en_tete(fp,&nbff,&nomax,englob);
    printf(" nbff = %d nomax = %d \n",nbff,nomax);

   compose_nom_complet(buf,s_dir,argv[2],"cir");
   fpc=fopen(buf,"w");

    ecrit_en_tete(fpc,nbff,nomax,englob);
    printf("\n fichier de sortie = %s \n",buf);
  

  /* traite toutes les faces */
     rendu=0;
     traite_face(fp,nbff,ff,&rendu);
    rewind(fpc);
    ecrit_en_tete(fpc,rendu,rendu,englob);
    fclose(fpc);

 	
  creer_OK_Solene();
  printf("\n");

}
/*------------------------------------------------------------*/
int traite_face(fp,nbff,ff,rendu)
FILE *fp;
int *rendu,nbff;
struct modelisation_face *ff;
{int i,j,k,kk,nofac,nbcont,nbtrou,nbp;
 double x,y,z,xn,yn,zn; 
 char c[2];

  for(i=0;i<nbff;i++)
	{fscanf(fp,"\n%c%d %d",c,&nofac,&nbcont);
         fscanf(fp," %lf %lf %lf ",&xn,&yn,&zn);
         for(j=0;j<nbcont;j++)
            {*rendu=*rendu+1;
	     fprintf(fpc,"f%d 1\n",*rendu);
	     fprintf(fpc,"    %lf  %lf  %lf \n",xn,yn,zn);
	     fscanf(fp,"\n%c%d",c,&nbtrou);
	     fprintf(fpc,"    c%d\n",nbtrou);
             fscanf(fp,"\n%d",&nbp); fprintf(fpc,"  %d \n",nbp);
             for(k=0;k<nbp;k++)
		{fscanf(fp,"\n%lf%lf%lf",&x,&y,&z);
		 fprintf(fpc,"      %lf   %lf    %lf\n",x,y,z);
		}
             for(k=0;k<nbtrou;k++)
		{fscanf(fp,"\n%c",c); fprintf(fpc,"   t\n");
                 fscanf(fp,"\n%d",&nbp); fprintf(fpc,"  %d \n",nbp);
                 for(kk=0;kk<nbp;kk++)
		   {fscanf(fp,"\n%lf%lf%lf",&x,&y,&z);
		    fprintf(fpc,"      %lf   %lf    %lf\n",x,y,z);
		   }
		}
            }
	}

}
/*------------------------------------------------------------*/
int format_entree_contour_face()
{
  printf("\n   *contour_face*  fichier_in(.cir)  fichier_out(.cir) \n");
  printf("\n    tous les contours sont transformes en faces\n\n");
  exit(0);
}

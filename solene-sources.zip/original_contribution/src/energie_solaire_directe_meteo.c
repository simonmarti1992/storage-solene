/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/*
cc energie_solaire_directe_meteo  ~marenne/newsolene/solutile.o  ~marenne/newsolene/geomutile.o ~marenne/newsolene/lib_solene_94.o  ~marenne/newsolene/solaire.o -o energie_solaire_directe -lm

*/
/* construit sur le mod�le de angle_incidence_solaire et �nergie_solaire_directe */

// D.GROLEAU juillet 2002
// D.GROLEAU  modifi� nov 2002  (fichier meteo.txt et non .dat)
// D.GROLEAU  modifi� juin 2003 (si fichier meteo.txt vide, calcul avec valeurs SOLENE)

// evalue energie solaire directe incidente
// les valeurs de r�f�rence sont donn�es dans fichier m�teo :
//			 heure minute flux_direct_au sol
//			 heure minute flux_direct_au sol
//			 ....
// une analyse pr�alable de l'ensoleillement des contours est obligatoire (h�liodon ou masque) .mas


#include<solene.h>

// DECLARE FUNCTIONS

void energie_directe();
void format_entree();
int lit_fic_meteo();
float lit_val_meteo();
void met_extension();
int test_ensoleille();
void test_min_max();

// en GLOBAL
#define HMAX 4096  // donnees meteo entrees par pas de 5 minutes au maximum
int nb_contour;

/*_________________________________________________________________*/
main(argc,argv) 
int argc;char **argv;

{
FILE *fpcir,*fpmas1,*fpmeteo, *fpval;
char buf[256],*s_dir,c;
int nojour,nomois,jo,mo,indice_date;
int hh1,hh2,pas,minute;
int nbfac,nomax,nofac,nb_pas,nb_date;
double englob[10],*nx_face,*ny_face,*nz_face;
int *nbc_face,*no_face;
int i,j,k,ind_valeur,temps,nbcontour,indice,no_contour;
float x,vmin_gen,vmax_gen;
double latitude,vnorm[3];
float *valeur;

int noc,iok;
char extension[32];

int		nb_val_meteo;
int		meteo_temps[HMAX];
float	meteo_flux_hor[HMAX];
int		h_trans;



struct modelisation_face *fac;

 if(argc != 10 && argc != 11) { format_entree(); exit(0); }

	s_dir=(char *)getenv("PWD");

printf("Commande : energie_solaire_directe_meteo (�nergie_incidente)\n\n");


/* ouverture des fichiers */

         compose_nom_complet(buf,s_dir,argv[1],"cir");
         if((fpcir=fopen(buf,"r"))==NULL)
            { printf("\n impossible ouvrir %s\n",buf); exit(0);
            }

		 printf("fichier geometrie :  %s \n",buf);

         compose_nom_complet(buf,s_dir,argv[2],"mas");
         if((fpmas1=fopen(buf,"r"))==NULL)
            { printf("\n impossible ouvrir %s\n",buf); exit(0);
            }

		 printf("fichier ensoleillement :  %s \n",buf);
		
	// jour mois heure pas
  	     sscanf(argv[3],"%d%c%d",&nojour,&c,&nomois);
         //printf("jour mois %d %d\n",nojour,nomois);
         sscanf(argv[4],"%d%c%d",&hh1,&c,&minute);
         hh1=hh1*60+minute;
         sscanf(argv[5],"%d%c%d",&hh2,&c,&minute); 
         hh2=hh2*60+minute;
         sscanf(argv[6],"%d%c%d",&pas,&c,&minute);
         pas=pas*60+minute;
         //printf("hh1 hh2 pas %d %d %d\n",hh1,hh2,pas);

      /* fichier de donn�es meteo : heure minute flux_direct_au_sol*/
         compose_nom_complet(buf,s_dir,argv[7],"txt");
		 		 printf("fichier meteo :  %s \n",buf);

         if((fpmeteo=fopen(buf,"r"))==NULL)
            { printf("\n impossible ouvrir %s\n",buf); exit(0);
            }
		 nb_val_meteo = lit_fic_meteo(fpmeteo,meteo_temps,meteo_flux_hor);
		 fclose(fpmeteo);

		 if(nb_val_meteo ==0)
		 { printf("fichier meteo vide : ne prend pas en compte le fichier meteo\n");
		 }


	   /* lit  latitude en degres */
  		 sscanf(argv[8],"%lf",&latitude);

		// translation en heure en sortie
		 h_trans=0;
		 if(argc ==11)
		 {  sscanf(argv[10],"%d",&h_trans);

		 }
 /* calcul du nombre de pas */
   nb_pas=1;
   i=hh1;
   while(i<hh2)
    { nb_pas++;
      i=i+pas;
    }
//printf("nb de pas %d\n",nb_pas);

   /* lecture de geom.cir  */
   lit_en_tete(fpcir,&nbfac,&nomax,englob);

   fac=alloue_face(nbfac,34);
   lit_fic_cir3d(fpcir,nbfac,fac);
   fclose(fpcir);

       printf(" Traite %d faces\n",nbfac);
   nbc_face =alloue_int(nbfac,1023);
   no_face = alloue_int(nbfac,1023);
   nx_face = alloue_double(nbfac,1023);
   ny_face = alloue_double(nbfac,1023);
   nz_face = alloue_double(nbfac,1023);
   

   nb_contour=0;

   for(i=0;i<nbfac;i++)
     { 
       no_face[i]=(fac+i)->nofac_fichier;
       nbc_face[i]=nb_contour_face(fac+i,1);
       nx_face[i]=(fac+i)->vnorm[0];
       ny_face[i]=(fac+i)->vnorm[1];
       nz_face[i]=(fac+i)->vnorm[2];
       nb_contour+=nbc_face[i];
     }
   printf("     soit  %d contours\n\n",nb_contour);

   desalloue_fface(fac,nbfac);
   fclose(fpcir);

 /* allouer nb_contour*nb_de_pas valeurs  */
   // et initialise � 0 (pas ensoleille)

   valeur=alloue_float(nb_contour*nb_pas,1023);
   for(j=0;j<nb_contour*nb_pas;j++) valeur[j]= 0;

 /* lit en tete des .mas  et determine indice de la bonne date */
     
    fscanf(fpmas1,"%d",&nb_date);
	iok=0;
	for(j=0;j<nb_date;j++)
         { fscanf(fpmas1,"%d %d",&jo,&mo);			  
           if(mo == nomois && jo == nojour)
		   { indice_date=j;
		     iok=1;
		   }
         }
        fscanf(fpmas1,"%d %d",&i,&i);
		if(iok==0)
		{printf("on ne connait pas l'ensoleillment pour la date sp�cifi�e (%d/%d)\n\n",nojour,nomois);
		 exit(0);
		}

/* printf("indice de la bonne date %d\n", indice_date);*/

 
/* examine les contours et determine les valeurs */
/* stocke les valeurs dans valeur contour  apres contour */
/* soit nb_contour*nb_pas valeurs */

     ind_valeur=0;
     noc=0;
     for(j=0;j<nbfac;j++)
       { fscanf(fpmas1,"\n%c%d %d",&c,&nofac,&nbcontour);
         //printf("FACE %d\n",nofac);
		vnorm[0]=nx_face[j];
		vnorm[1]=ny_face[j];
		vnorm[2]=nz_face[j];

         for(k=0;k<nbcontour;k++)  
           { //printf("test contour %d\n",k+1);
			noc++;

             /* evalue valeurs en fonction du temps pour chaque contour */

energie_directe(nb_pas,pas,nb_date,indice_date,hh1,&ind_valeur,valeur,fpmas1,latitude,vnorm,nojour,nomois,nb_val_meteo,meteo_temps,meteo_flux_hor);
		  }

       }
   fclose(fpmas1);

/* constitue le fichier .val correspondant */
/* avec les valeurs en fonction du temps */

 printf(" Cree les fichiers de Descripteur resultat  : \n");

  temps=hh1 + h_trans*60;
   for(i=0;i<nb_pas;i++)
     { 
		
		//construit extension pour fichier val : _hhHmm

		met_extension (temps,extension);

		//printf("extension %s\n",extension);
	/* calcule min_max pour le pas i AVEC MASQUE */
        vmin_gen=10000000.; vmax_gen=-vmin_gen;

        indice=i;
        for(j=0;j<nbfac;j++)
           { for(k=0;k<nbc_face[j];k++)
               { x=valeur[indice];
				//printf("face %d pas %d indice %d x %f \n", j,i,indice,x);

                 test_min_max(x,&vmin_gen,&vmax_gen);

                 indice+=nb_pas;
               }
           }    
		//printf("pas %d min %f max %f\n", i,vmin_gen,vmax_gen);
		
       /* open fichier .val pour le pas i */
       /* compose le nom avec l'extension heure */
		sprintf(buf,"%s%s.val",argv[9],extension);   
        printf("   %s\n",buf);

        fpval=fopen(buf,"w");
        fprintf(fpval,"%5d %5d %15.3f %15.3f\n",nbfac,nomax,vmin_gen,vmax_gen);
 
       /* stocke les valeurs pour le pas i */
         no_contour=0;
         indice=i;
         for(j=0;j<nbfac;j++)
           {
             /* printf("Face %d\n",no_face[j]);*/
             fprintf(fpval,"f%d %d\n",no_face[j],nbc_face[j]);

             for(k=0;k<nbc_face[j];k++)
               { 
                 /* printf("Contour %d indice %d\n",k+1,indice);*/

                 fprintf(fpval,"%10.3f\n",valeur[indice]);
		         no_contour++;
                 indice+=nb_pas;

               }
           }    
          fclose(fpval);
          temps+=pas;
     }

 desalloue_float(valeur); 
 desalloue_int(nbc_face); 
 desalloue_int(no_face);
 desalloue_double(nx_face);
 desalloue_double(ny_face);
 desalloue_double(nz_face);


creer_OK_Solene();
printf("\nFin energie_solaire_directe_meteo\n\n");

}

/*_________________________________________________________________*/

void energie_directe(nb_pas,pas,nb_date,ind_date,hh1,ind_valeur,valeur,pf_mas,latitude,vnorm,nojour,nomois,nb_val_meteo,meteo_temps,meteo_flux_hor)
int nb_pas,pas,nb_date,ind_date,hh1,*ind_valeur;
float *valeur;
FILE *pf_mas;
double latitude,*vnorm;
int nojour,nomois;
int nb_val_meteo;
int *meteo_temps;
float *meteo_flux_hor;
{
  int nb_per,dh[50],dm[50],fh[50],fm[50];
  float val[50],val_meteo,flux_normal_rii;
  int i,k,kk,temps,h_deb,m_deb;
  double x,y,z,oui,ang,a,h,xyzsol[3];
  char c;

/*
printf("nb_pas pas nb_date ind_date %d %d %d %d\n",nb_pas,pas,nb_date,ind_date);
printf("hh1 ind_valeur %d %d\n",hh1,*ind_valeur);
*/
             fscanf(pf_mas,"\n%c",&c);

  for(i=0;i<nb_date;i++)
     { fscanf(pf_mas,"%d",&nb_per);
       for(k=0;k<nb_per;k++)
          { fscanf(pf_mas,"%d %d %d %d %f",dh+k,dm+k,fh+k,fm+k,val+k);
      /*printf("%d %d %d %d %f\n",dh[k],dm[k],fh[k],fm[k],val[k]);*/ 
          }


       /* test ensoleillement sur ce jour */
       if(i==ind_date)  
          {  temps=hh1;
             for(kk=0;kk<nb_pas;kk++)
              { x=temps/60.;
                h_deb=(int)x;
                m_deb=(int)(temps-h_deb*60.);
				//printf("Heure %d minute %d\n",h_deb,m_deb);
                heure_et_minute_EN_heure_double(h_deb,m_deb,&z); 
	        	oui=0;
                for(k=0;k<nb_per;k++)
                  { heure_et_minute_EN_heure_double(dh[k],dm[k],&x);
 		            heure_et_minute_EN_heure_double(fh[k],fm[k],&y);
		            if(x<=z && y>=z) oui=1;
                  }
		if(oui)
                  { /*evalue energie solaire directe */
                   info_solaire(latitude,nojour,nomois,h_deb,m_deb,xyzsol,&a,&h);

				   if(nb_val_meteo ==0) // calcul Solene
				   {
				    valeur[*ind_valeur]=rii(h,2)*vincid(xyzsol,vnorm,&ang)*1.;

				   //printf("flux_normal %f\n",rii(h,2));
				   }
				   else
				   {
				   // cherche valeur du flux horizontal dans fichier meteo 
				   val_meteo = lit_val_meteo(h_deb*60+m_deb,nb_val_meteo,meteo_temps,meteo_flux_hor);
				   // et retrouve le flux normal (flux_au_sol = flux_normal*sin(h) )
				   flux_normal_rii= (float) (val_meteo/ sin(h));
				   valeur[*ind_valeur]=(float) (flux_normal_rii*vincid(xyzsol,vnorm,&ang)*1.);
				   }

				   if(valeur[*ind_valeur] < 0. ) valeur[*ind_valeur] = 0;
                  }

         temps+=pas;
         /*printf(" valeur oui %f %f\n",oui,valeur[*ind_valeur]);*/
		 (*ind_valeur)++;
        }

      }
    }
}

/*_________________________________________________________________*/
void test_min_max(x,vmin_gen,vmax_gen)
float x;
float *vmin_gen,*vmax_gen;
{
		 if(x < *vmin_gen) *vmin_gen = (float) x;
         if(x > *vmax_gen) *vmax_gen = (float) x;
}




/*------------------------------------------------------------*/
float lit_val_meteo(temps,nb_val_meteo,meteo_temps,meteo_val)
int		temps, nb_val_meteo;
int		*meteo_temps;
float	*meteo_val;
{
int i, ecart_t, delta_t;
float ecart_v, valeur;
// soit trouve la valeur au temps (en minutes) exact, soit interpole entre 2 valeurs encadrant le temps choisi

//printf("lit_val pour %d H %d\n",heure,minute);

	for (i=0;i<nb_val_meteo;i++)
	{
	  
	  if(temps == meteo_temps[i]) return(meteo_val[i]);
	  if(temps < meteo_temps[i])
	  { if (i ==0) return(meteo_val[0]);
	    else
		{ ecart_t = meteo_temps[i] - meteo_temps[i-1];
		  delta_t = temps - meteo_temps[i-1];
		  ecart_v = meteo_val[i] - meteo_val[i-1];
		  valeur = meteo_val[i-1] + (ecart_v * delta_t)/ecart_t;
		  return(valeur);
		}
	  }
	}
	return(meteo_val[nb_val_meteo-1]);
}


/*------------------------------------------------------------*/
int lit_fic_meteo(fp,meteo_temps,meteo_valeur)
FILE	*fp;
int		*meteo_temps;
float	*meteo_valeur;
{
int i,id, hh, mm;
	i=0;
	while(1)
	{ if (i > HMAX)
		{ printf("trop de lignes dans le fichier meteo (max %d)\n\n",HMAX);
		  exit(0);
		}
	  id= fscanf(fp,"%d %d %f", &hh,&mm,meteo_valeur+i);
	  //printf("i =%d %d %d \n",i,hh,mm);
	  if(id==EOF) break;
	  meteo_temps[i]= 60*hh + mm;
	  i++;
	}
	printf("	nombre de lignes lues dans le fichier de meteo : %d\n",i);
	return(i);

}


//_____________________________________________________
void met_extension (temps,extension)
int temps;
char *extension;
{  // modele energie diffuse meteo
	float xh_heure;
	int h_heure, m_minute;

		xh_heure= (float)temps/60;
		h_heure= (int) xh_heure;
		m_minute= temps-h_heure*60;
		//printf(" heure_minute %d H %d\n",h_heure,m_minute);
		//construit extension pour fichier val heure
		if(h_heure>=10 && m_minute >=10)
		{
		 sprintf(extension,"_%dH%d",h_heure,m_minute);
		}
		else if(h_heure>=10 && m_minute <10)
		{
		 sprintf(extension,"_%dH0%d",h_heure,m_minute);
		} 
		else if(h_heure<10 && m_minute >=10)
		{
		 sprintf(extension,"_0%dH%d",h_heure,m_minute);
		} 
		else if(h_heure <10 && m_minute <10)
		{
		 sprintf(extension,"_0%dH0%d",h_heure,m_minute);
		} 
		//printf("extension %s\n",extension);
}


/*_________________________________________________________________*/

void format_entree()
{
 printf("\n la fonction energie_solaire_directe_meteo\n a comme parametre ENTREE :\n\n");
 printf("\t fichier_in(.cir)\n"); 
 printf("\t fichier_in(.mas)\n");
 printf("\t jour/mois\n");
 printf("\t hh1:mn1\n");
 printf("\t hh2:mn2\n");
 printf("\t pas(hh:mn)\n");

 printf("\t fichier_donnees_meteo(.txt)\n");
 printf("\t latitude\n");
 
 printf("\n           comme parametres en SORTIE:\n\n");
   
 printf("\t energie_directe_incidente(.val)\n");
 printf("\n           comme parametres FACULTATIF:\n\n");
 printf("\t translation_en_heure\n");

 printf("\nNOTA: le programme ajoute une extension _hhHmm au nom de fichier correspondant � l'heure du calcul\n");
 printf("\nNOTA: en tenant compte d'une translation en heures si souhait�\n");

 printf("\nNOTA: fichier meteo sous la forme d'une liste de lignes \n");
 printf("				heure minute direct_au_sol\n");
 printf("				heure minute direct_au_sol\n");
 printf("				.......\n\n");
  
}

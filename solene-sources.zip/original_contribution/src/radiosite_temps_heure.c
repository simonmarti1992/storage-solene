/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/* radiosite_temps_heure.c : APPEL RADIOSITE pour une s�quence de temps	*/
/*______________________________________________________________________*/
// D.GROLEAU mars 2006


// modele radiosite_temps
/*
cc radiosite_temps_heure.c  geomutile.o solutile.o lib_solene_94.o -o radiosite_temps -lm
*/

#include<solene.h>

void met_extension_heure();
int test_si_nom_existe();
void usage_rad_temps();

/*_________________________________________________________________*/
main(argc,argv)           
int argc;
char **argv;
{
 int 	i,nb_pas;
 char   buf[2048], c;
 int hh1,hh2,pas,minute,temps;
 char extension_heure[16];


   	if(argc<13) usage_rad_temps();

	printf("Fonction Solene : radiosite_temps_heure\n\n");

    //  heure debut et fin ; pas
    sscanf(argv[2],"%d%c%d",&hh1,&c,&minute);
    printf("evalue de  %dH%d",hh1,minute);
    hh1=hh1*60+minute;
    sscanf(argv[3],"%d%c%d",&hh2,&c,&minute); 
    printf(" a  %dH%d",hh2,minute);
    hh2=hh2*60+minute;
    sscanf(argv[4],"%d%c%d",&pas,&c,&minute);
    printf(" par pas de  %dH%d\n",pas,minute);
    pas=pas*60+minute;

    // calcul du nbre de pas
    nb_pas=1;
    i=hh1;
    while(i<hh2)
    { nb_pas++;
      i=i+pas;
    }
    printf("nb de pas %d\n",nb_pas);

 /* APPEL RADIOSITE */
  temps = hh1;
  for(i=0;i<nb_pas;i++)
   {
		  met_extension_heure(temps,extension_heure);
      
      /* compose ligne de commande */
       sprintf(buf,"radiosite %s%s %s %s %s %s%s  %s%s %s%s %s %s",argv[1],extension_heure,argv[5],argv[6],argv[7],argv[8],extension_heure,argv[9],extension_heure,argv[10],extension_heure,argv[11],argv[12]);

       printf("%s\n",buf);

      /* appel de radiosite */

       system(buf);

      /* test si OK  (rm OK_SOLENE) */
	   //modif SII DFA 24-4-2006
	   if (!existOkSolene()) {
			printf("\n PB execution de radiosite au Pas %d (temps = %d)\n\n",i,temps);
			exit(0);
		}
		cleanOkSolene();


	temps+=pas;
  }

creer_OK_Solene();

printf("\nFin radiosite_temps_heure\n");
printf("______________________________\n\n");

}

/*_________________________________________________________________*/
/* Format de la fonction radiosite_temps_heure */
void usage_rad_temps()
	{
  	printf("\nFormat d'entree des parametres de la commande\n\n");
  	printf("   radiosite_temps_heure  \n\n");
 printf("\n      la fonction a comme parametres en ENTREE :\n\n");
 printf("\t NOM generique des fichiers_exitances_initiales (_--H--.val)\n");
 printf("\t hh1:mn1\n");
 printf("\t hh2:mn2\n");
 printf("\t pas(hh:mn)\n");

 printf("\t coef_reflexion(.val) des contours de la geometrie\n"); 
 printf("\t le fichier des facteurs de forme (.ff) de la geometrie\n"); 
 printf("\t les surfaces (.val) des contours de la geometrie\n"); 

  printf("\n           comme parametres en SORTIE, les descripteurs .val :\n\n");
   
 printf("\t eclairement (ou rayonnement) incident apres reflexion (.val)\n"); 
 printf("\t eclairement (ou rayonnement) reflechi apres reflexion (.val)\n"); 
 printf("\t eclairement (ou rayonnement) absorbe apres reflexion (.val)\n"); 

  printf("\n           comme parametres d'arret, soit :\n\n");
	printf("\ti suivi du nombre d'iterations maxi\n");
	printf("\te suivi de valeur d'energie restant a distribuer\n");
	printf("\tp suivi de valeur en %% d'energie restant a distribuer/premiere iteration\n");
	printf("\ts suivi de valeur de la difference maxi entre 2 iterations\n\n");


 	exit(0);
	}

/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */
 
/* 
cc -o concatval concatval.c solutile.o geomutile.o lib_solene_94.o -lm
*/
// D.GROLEAU juillet 2002
/*
	Concatene deux ou plusieurs fichiers de valeur .val

*/
#include<solene.h>

// declare FUNCTIONS
void traite();
void format_entree_concatval();
void ecrit_fic();

FILE *fp1,*fpc;
int change_nofac;
double min,max;

///______________________________________________
main(argc,argv)
int argc;char **argv;
{char buf[512],c[2],*s_dir;
 int i,nbfac,rendu;




  if(argc<5){format_entree_concatval(); exit(0);}

	s_dir=(char *)getenv("PWD");

       rendu=0; nbfac=0; 

  sscanf(argv[1],"%c%c",c,c+1);
  if(c[0]!='-'){format_entree_concatval(); exit(0);}
  else if(c[1]=='i')change_nofac=0;
  else if(c[1]=='m')change_nofac=1;
  else {format_entree_concatval();exit(0);}


    compose_nom_complet(buf,s_dir,argv[argc-1],"val");
    fpc=fopen(buf,"w");
    if(fpc==NULL) 
	{ printf("impossible creer %s\n",buf);
	  exit(0);
	}	
    printf("\n fichier de sortie = %s \n",buf);
  

  /* traite tous les fichiers a concatener */
    for(i=2;i<argc-1;i++)
     {compose_nom_complet(buf,s_dir,argv[i],"val");
      if((fp1=fopen(buf,"r"))==NULL)
          {printf("\n impossible ouvrir %s\n",buf); exit(0);}
printf(" traite fichier %s \n",buf);
      traite(&rendu,&nbfac,i);
      fclose(fp1);
     }
    rewind(fpc);
   
    fprintf(fpc,"%7d %7d %12.5f %12.5f",nbfac,rendu,min,max);
	
	printf(" Fin du traitement Concatval\n");
}

/*------------------------------------------------------------*/

void traite(rendu,nbfac,nofic)
int *rendu,*nbfac,nofic;
{int nbfac1,nomax1;
 float val_min,val_max;
       /* lit les entetes */
fscanf(fp1,"%d %d %f %f",&nbfac1,&nomax1,&val_min,&val_max);
if(nofic==2) 
 {  fprintf(fpc,"%7d %7d %12.5f %12.5f\n",nbfac1,nomax1,val_min,val_max);
    min=val_min; max=val_max;
 }
else
  { if(min > val_min) min=val_min;
    if(max < val_max) max=val_max;
  }

       *nbfac=*nbfac+nbfac1;
       
       ecrit_fic(fp1,rendu,nbfac1);
}
/*------------------------------------------------------------*/
void ecrit_fic(fp,rendu,nbfac)
FILE *fp;
int *rendu,nbfac;
{int i,j,nofac,nbcont,nofacmax;

 char c;
 float val;

   nofacmax=0;
   printf(" Concatene VAL sur %5d Faces\n",nbfac);

  for(i=0;i<nbfac;i++)
	{fscanf(fp,"\n%c%d%d\n",&c,&nofac,&nbcont);
	 if(nofac>nofacmax)nofacmax=nofac;
         if(change_nofac)fprintf(fpc,"f%d  %d\n",nofac+*rendu,nbcont);
         else fprintf(fpc,"f%d  %d\n",nofac,nbcont);
         for(j=0;j<nbcont;j++)
            {fscanf(fp,"%f",&val);
	     fprintf(fpc,"  %12.5f\n",val);
            }
	}

   if(change_nofac)*rendu=nofacmax+*rendu;
   else if(*rendu<nofacmax)*rendu=nofacmax;

}
/*------------------------------------------------------------*/
void format_entree_concatval()
{
  printf("\n   *contcatval* -m|-i fichier1(.val)  fichier2(.val) ----  fichier_out(.val) \n");
  printf("\n     -m : change les numeros des faces \n");
  printf("     -i : ne change pas les numeros des faces \n\n");

}

/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

// luminance_ciel.h
// Protype des fonctions

void affiche_soleil(double latit,	//latitude en degr�
					double longit,	//longitude en degr�
					int jour,		//no du jour
					int mois,		//no du mois
					int jd,			//no du jour dans l'ann�e
					int h_deb,		//heure entiere
					int m_deb,		//minute
					double h,		//hauteur du soleil
					double sd,		// 
					double st,		// 
					double epsilon,	//epsilon du ciel
					double delta,	//delta du ciel
					double lzenit,	//luminance au zenith
					double De,		//
					double Se,		//
					double Dv,		//
					double Sv);		//
double airmass (double h );// hauteur du soleil en radian
double alt ( double sd, double st,  double latit);         
double azim (double sd, double st,  double latit);        
double declin (int jd);
double effic_lum_diffus(double delta , double Z , double w , int interval);
double effic_lum_normal(double delta , double Z , double w , int interval);
double exentr (int jd );
int jdate (int mois ,int jour );
void lect_coef_per(char *filename , double * per_ );
void luminance (double xg , double yg , double h , double az ,double *lumin, double *integr );
void usage_ciel();







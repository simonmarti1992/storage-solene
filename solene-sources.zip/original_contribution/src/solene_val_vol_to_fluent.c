/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/*__________________________  solene_val_vol_to_fluent   __________________________ */

// D.Groleau, d�cembre 2003

/*______________________________________________________________________    */
/* Pour couplage Solene - Fluent   r�cup�ration des flux des arbres de solene 
  Utilitaire : a partir d'un fichier de geometrie.cir triangul�		 
 et d'un fichier de descripteur .val, sauve un fichier ASCII 		      
 exploitable par FLUENT.
 
*/
/*______________________________________________________________________  */


#include<solene.h>


// declare functions
int applique_val_element();
int cherche_ap_element();
void format();
void lit_fic_ap();
int stocke_element();

// GLOBAL

 double *xge,*yge,*zge;  // correspondance gf face / ge element 
 double *xgf,*ygf,*zgf;
 double *xgel,*ygel,*zgel; // les gravites des elements a envoyer a Fluent
 double *flux;			   //  les flux associ�s � ces elements
 int nb_face,nb_elem;

#define EPSI    0.001

/*_________________________________________________________________*/
main(argc,argv)           
int argc;char **argv;
	{

/*--------------*/
/* Declarations */
/*--------------*/

	char nom_geometrie[256];				/* fichier de geometrie lu */
	char nom_valeur[256];					/* fichier de valeur lu (descripteur) */ 
	char nom_app[256];					    /* fichier txt centre gravit� face / centre gravite element */
	char nom_resultat[256];					/* fichier resultat (centres de gravite + valeurs) */
	
	int nbfac;			    /* nombre de faces d'apres le fichier de geometrie */
	int nbfac_val;			/* nombre de faces d'apres le fichier de valeurs */
	double englob[10];
	int nb_contour_total;		/* nombre total de contours */
	double *valeur;				/* valeurs lues */
	struct modelisation_face *fac;	/* faces */
 	FILE *pficg, *pficv, *pficr ;	/* pointeurs pour manips fichiers */
	int nomax;			/* numero maxi des faces */
	int nomax_val;
	double maxi, mini;		/* valeurs mini et maxi lues */
	char *rep_courant;		/* repertoire courant */
	int nf;					/* Pour balayage faces et contours */
	struct contour *pcont;		/* id. */
	struct circuit *pcir;		/* id. */
	int		 noc;
	double xg, yg, zg, xgt, ygt, zgt;
	int i;

/*-----------------------------*/
/* lecture parametres commande */
/*-----------------------------*/

	rep_courant = (char *)getenv("PWD");  

   	if(argc<5) format(); 
 
	printf("\n\nFonction : Solene_val_vol_to_fluent\n");

    compose_nom_complet(nom_geometrie,rep_courant,argv[1],"cir");  
        printf("\n\nFichier de geometrie : %s \n",nom_geometrie); 

	compose_nom_complet(nom_valeur,rep_courant,argv[2],"val");  
        printf("Fichier de valeur a transmettre   : %s \n",nom_valeur);

	compose_nom_complet(nom_app,rep_courant,argv[3],"txt");  
        printf("Fichier de correspondance face - element    : %s \n",nom_app);

	compose_nom_complet(nom_resultat,rep_courant,argv[4],"dat");  
        printf("Fichier des valeurs pour fluent     : %s \n",nom_resultat);


/* fichiers en input */

       if((pficg=fopen(nom_geometrie,"r"))==NULL)
		{
        	printf("\n impossible ouvrir %s\n",nom_geometrie); 
			exit(0);
		}

	   /* lecture fichier geometrie a traiter */
       lit_en_tete(pficg,&nbfac,&nomax,englob);      
       fac=alloue_face(nbfac,34);
       lit_fic_cir3d(pficg,nbfac,fac);
       fclose(pficg);
	   
	   // nb de contours du fichier
	   nb_contour_total = nbcontours_total(fac, nbfac);
      
	// Lecture du fichier des valeurs
       if((pficv=fopen(nom_valeur,"r"))==NULL)
		{
            printf("\n impossible ouvrir %s\n",nom_valeur); 
			exit(0);
  		}
          
	fscanf(pficv,"%d %d %lf %lf",&nbfac_val,&nomax_val,&mini,&maxi);
	if ((nbfac_val != nbfac) || (nomax_val != nomax))
	{ printf("--- Incoherence entre fichiers .cir et .val, verifiez vos donnees ... ---\n");
	 exit(0);
	}
	rewind(pficv);

		// Allocation du tableau des valeurs 
	valeur = alloue_double(nb_contour_total,456);
	lect_fic_val(pficv, valeur);
	fclose(pficv);



	// Lecture du fichier appartenance des faces aux elements : x y z (gravite face) x y z (gravite element)
       if((pficv=fopen(nom_app,"r"))==NULL)
		{
            printf("\n impossible ouvrir %s\n",nom_app); 
			exit(0);
  		}
	lit_fic_ap(pficv);
	fclose(pficv);

	// TEST IMPRESSION
/*
	for(i=0;i<nb_elem;i++)
	{
      printf(" %15.4f %15.4f %15.4f \n", xgel[i],ygel[i],zgel[i]);
	}
	printf("    nombre de faces %d\n",nb_face);
	for(i=0;i<nb_face;i++)
	{
      printf(" %15.4f %15.4f %15.4f %15.4f %15.4f %15.4f \n", xgf[i],ygf[i],zgf[i],xge[i],yge[i],zge[i]);
	}
*/

/*------------------------------------------------------------------------------*/
/* �criture du fichier des flux au centre de gravit� des elements pour FLUENT */
/*------------------------------------------------------------------------------*/
  if((pficr=fopen(nom_resultat,"w"))==NULL)
		{
        	printf("\n impossible ouvrir %s\n",nom_resultat); 
			exit(0);
		}
  fprintf (pficr," %6d\n",nb_elem);

  // prend chaque contour
  // evalue son centre de gravite
  // cherche son correspondant dans la correspondance face element
  // place la valeur dans l'element

  noc =0;
  for(nf=0;nf<nbfac;nf++) 
  {
	  pcont=(fac+nf)->debut_projete;
      while(pcont) 	
      { pcir=pcont->debut_support;   	
		centre_de_gravite(pcir,&xg,&yg,&zg);

        // cherche son correspondant dans la correspondance face element
		// renvoie les coordonnees du centre de gravite de l'�l�ment
		if(cherche_ap_element(xg,yg,zg,&xgt,&ygt,&zgt))
		{ // a trouv� un correspondant
		  //additionne la valeur � cet �lement
		  applique_val_element(valeur[noc],xgt,ygt,zgt);
		}
		noc++;
 		pcont=pcont->suc; 
       } 
  }
 // ecrit les flux pour Fluent
  	for(i=0;i<nb_elem;i++)
	{
      fprintf(pficr,"  %15.4f %15.4f %15.4f %15.4f\n", xgel[i],ygel[i],zgel[i],flux[i]);
	}
  fclose(pficr);


/* Desallocations */
    desalloue_fface(fac,nbfac);
	desalloue_double(valeur);

	desalloue_double(xgf);
	desalloue_double(ygf);
	desalloue_double(zgf);

	desalloue_double(xge);
	desalloue_double(yge);
	desalloue_double(zge);

	desalloue_double(xgel);
	desalloue_double(ygel);
	desalloue_double(zgel);

	desalloue_double(flux);

       	
	printf(" fin du traitement\n\n");
}


/*------------------------------------------------------------*/
void lit_fic_ap(fp)
FILE	*fp;
{
int i,id;
float bidon;

// compte le nombre de faces
	nb_face =0;
	while(1)
	{ 
	  id= fscanf(fp," %lf %lf %lf %lf %lf %lf", &bidon,&bidon,&bidon,&bidon,&bidon,&bidon);

	  if(id==EOF) break;
	  nb_face++;
	}
	printf(" nombre de faces dans le fichier d'appartenance : %d\n",nb_face);

// alloue
	// allocation des centres de gravit�s des elements (il y en plusieurs en double
	// car ce fichier etablit correspondance Gravite Face - Gravite element

	xge=alloue_double(nb_face,14);
    yge=alloue_double(nb_face,14);
	zge=alloue_double(nb_face,14);

   // allocation des centres de gravit�s des faces

	xgf=alloue_double(4*nb_face,14);
    ygf=alloue_double(4*nb_face,14);
	zgf=alloue_double(4*nb_face,14);

	// allocation des centres de gravit�s des elements � retenir (sans doublon)

	xgel=alloue_double(nb_face,14);
    ygel=alloue_double(nb_face,14);
	zgel=alloue_double(nb_face,14);

	// allocation des flux a associer aux elements � retenir (sans doublon)

	flux=alloue_double(nb_face,14);

// lit et stocke
	rewind(fp);

	nb_elem=0;
	for(i=0;i<nb_face;i++)
	{
      fscanf(fp," %lf %lf %lf %lf %lf %lf", xgf+i,ygf+i,zgf+i,xge+i,yge+i,zge+i);
	  //stocke l'element si pas d�j� fait
		  stocke_element(xge[i],yge[i],zge[i]);
	}
	printf(" nombre d elements %d\n",nb_elem);

}


/*_________________________________________________________________*/
int stocke_element(xg,yg,zg)
double xg,yg,zg;
{
 int j;
	 for(j=0;j<nb_elem;j++)
	 { 
	   if(fabs(xg-xgel[j]) < EPSI && fabs(yg-ygel[j]) < EPSI && fabs(zg-zgel[j]) < EPSI)
			{ // l'element est deja la
		     return(0);
			}
	 }
	 // retient l'element
	xgel[nb_elem]= xg;
	ygel[nb_elem]= yg;
	zgel[nb_elem]= zg;
	nb_elem++;
	return(1);
}

/*_________________________________________________________________*/
int cherche_ap_element(xg,yg,zg,xgt,ygt,zgt)
double xg,yg,zg;
double *xgt,*ygt,*zgt;
{
  int j;
  for(j=0;j<nb_face;j++)
	 { 
	   if(fabs(xg-xgf[j]) < EPSI && fabs(yg-ygf[j]) < EPSI && fabs(zg-zgf[j]) < EPSI)
			{ // c'est une bonne  face ; prend le centre de gravite de son element
		      *xgt= xge[j];
		      *ygt= yge[j];
		      *zgt= zge[j];
			  return(1);
			}
	 }
  //printf("pas trouver Face\n");
  return(0);
 
}
/*_________________________________________________________________*/
int applique_val_element(val,xg,yg,zg)
double val,xg,yg,zg;
{
  int j;
  for(j=0;j<nb_elem;j++)
	 { 
	   if(fabs(xg-xgel[j]) < EPSI && fabs(yg-ygel[j]) < EPSI && fabs(zg-zgel[j]) < EPSI)
			{ // c'est le bon  element
		      flux[j] = flux[j] + val;
			  return(1);
			}
	 }
  printf("pas trouver Element\n");
  return(0);

}


/*_________________________________________________________________*/
void format()
	{
  	printf("\n   format d'entree des parametres \n\n");
  	printf("solene_val_vol_to_fluent  fichier_a_traiter(.cir)  fichier_valeur(.val) f_ap_face_element(.txt) fichier_resultat_fluent(.dat) \n\n");	
  	exit(0);
	}

/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

//  info_ff_un_contour



// //
// imprime dans un fichier les facteurs de forme d'un contour avec une g�om�trie donn�e 

// D.GROLEAU novembre 2006
// D.GROLEAU janvier 2007
//				imprime la somme des FF pour le contour retenu
#include<solene.h>

// DECLARE FUNCTIONS

void format_entree();
void lecture_ff();
struct modelisation_face *alloue_face();

FILE *fp; // facteur de forme

/*_________________________________________________________________*/
main(argc,argv) 
int argc;char **argv;

{
char buf[256],*s_dir;
int i,k,ii,num,nbcontour,nb_contour_total;

FILE *fp_out;
struct modelisation_face *fs;
int nbff,noma;
double englob[10];
int no_de_face,no_de_contour;
float *fform;
int liste_tous_les_ff;
double sommeFF; // janvier 2007

 if(argc != 6 && argc != 7) { format_entree(); exit(0); }

	s_dir=(char *)getenv("PWD");

printf("Fonction Solene: info_ff_un_contour\n\n");

// Open et Lit geom.cir
	compose_nom_complet(buf,s_dir,argv[1],"cir");
	if((fp=fopen(buf,"r"))==NULL)
		{ printf("\n   le fichier %s n'existe pas\n",buf );
		  exit(0);
        }

   lit_en_tete(fp,&nbff,&noma,englob);
   printf("\nG�om�trie: %s (%d faces)\n",buf,nbff);
   fs=alloue_face(nbff,1000);
   lit_fic_cir3d(fp,nbff,fs);
   fclose(fp);

// Lit 	no_de_face et no_de_contour
   sscanf(argv[2],"%d",&no_de_face);
   sscanf(argv[3],"%d",&no_de_contour);
   printf("IMPRESSION des valeurs de facteur de forme pour:\n");
   printf("Face %d Contour %d\n",no_de_face,no_de_contour);

// Open fichier des facteurs de forme
   compose_nom_complet(buf,s_dir,argv[4],"fac");
   if ((fp=fopen(buf,"rb"))==NULL)
    { printf("\n  impossible ouvrir %s\n\n", buf); 
	  exit(0);
    }
   printf("\nFacteur de Forme : %s \n",buf);

  // OPen fichier Impression
   compose_nom_complet(buf,s_dir,argv[5],"txt");
   if ((fp_out=fopen(buf,"w"))==NULL)
    { printf("\n  impossible ouvrir %s\n\n", buf); 
	  exit(0);
    }
   printf("\nFichier Impression : %s \n",buf);

  // Param�tre Facultatif en entr�e
   liste_tous_les_ff=0;
   if(argc==7)
   {    sscanf(argv[6],"%d",&liste_tous_les_ff);
   }

   // TRAITEMENT
   // Lecture des facteurs de forme pour face id_FACE et id_CONTOUR
   nb_contour_total=0;
   num=0;
	for(i=0;i<nbff;i++)
	{ nbcontour=nb_contour_face(fs+i,1);
	  printf("face indice %d (no %d) de nb de contours %d\n",i,(fs+i)->nofac_fichier,nbcontour);
	  nb_contour_total += nbcontour;
	  for(k=0;k<nbcontour;k++)
	  { if((fs+i)->nofac_fichier == no_de_face && (k+1) == no_de_contour)
			{
         	  ii=num;	     // indice de contour dans la liste globale des contours
			  printf("Num�ro (dans la liste des contours de la g�om�trie) du contour retenu %d\n",ii+1);
         	}
		num++;
	  }
	}

	fform =alloue_float(nb_contour_total,12);  

	// Lecture et impression des ff[ii] : valeurs de facteur de forme pour id_FACE et id_CONTOUR
		fprintf(fp_out,"Liste des facteurs de forme de:\n");
		fprintf(fp_out,"face %d contour %d no_contour_dans_liste = %d  nb_contour_total = %d\n",no_de_face,no_de_contour,ii+1,nb_contour_total); 
   		

		lecture_ff(fform,ii,nb_contour_total); 
		sommeFF=0; // janvier 2007
		for(i=0;i<nb_contour_total;i++)
		{ fprintf(fp_out,"%15.6f\n",fform[i]);
		  sommeFF+=fform[i]; // janvier 2007
		}
        fprintf(fp_out,"Somme des Facteurs de Forme = %f\n", sommeFF); // janvier 2007

	// POUR INFO, imprime le fichier total de ff
	if(liste_tous_les_ff)
	{ printf("\nLISTE des Facteurs de Forme des Contours:\n",k+1);
		for(k=0;k<nb_contour_total;k++)
		{
			lecture_ff(fform,k,nb_contour_total); 
			printf("Contour %d\n",k+1);
			for(i=0;i<nb_contour_total;i++)
			{ printf("%15.6f\n",fform[i]);
			}
		}	
    }

		desalloue_float(fform);
		desalloue_face(fs);

		fclose(fp);
		fclose(fp_out);
 
creer_OK_Solene();
printf("\nFin info_ff_un_contour\n\n");

}


/*____________________________________________*/
/* Lecture des facteurs de forme dans fichier */
void lecture_ff(factf, ii, nb_contour_total)
float *factf;
int ii, nb_contour_total;
   {
   fseek(fp,(ii*nb_contour_total)*sizeof(float),SEEK_SET);
   fread(factf, sizeof(float), nb_contour_total, fp);
   }

/*_________________________________________________________________*/

void format_entree()
{
 printf("\n la fonction info_inf_un_contour\n a comme parametre ENTREE :\n\n");
 printf("\t fichier_geometrie(.cir)\n");
 printf("\t no_de_face \n");
 printf("\t no_de_contour \n");
 printf("\t fichier_fac_forme(.fac)\n");
 

 printf("\n comme parametres en SORTIE:\n\n");
 printf("\t fichier_impression(.txt)\n");

 printf("\n comme parametres FACULTATIF:\n\n");
 printf("\t liste_tous_les_ff\n");

 printf("\nNOTA: La fonction imprime les facteurs de forme d'un contour dans fichier_impression(.txt)\n");
 printf("\nNOTA: liste_tous_les_ff =1 (DEFAUT 0, non) dans le listing\n");
 printf("\n");
 exit(0);
  
}

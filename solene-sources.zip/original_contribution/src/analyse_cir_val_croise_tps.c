/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */
 
/* 
   analyse_cir_val_croise_tps

   solutile.o geomutile.o lib_solene_94.o 
*/
// sur modele analyse_cir_val_croise et val_contour_tps

// Dominique GROLEAU   25 avril 2003

// analyse crois�e:
// calcule ; valeur moyenne, valeur pond�r�e par la surface, valeur cumul�e
// calcule   variance et ecart type
// d'un descripteur
// en les croisant  par un second descripteur entier
// EN FONCTION DU TEMPS pour pouvoir etre trac� sur un graphe


// ne retient que les contours satisfaisant une valeur de gravit� de Z  et une valeur V


#include <solene.h>


// DECLARATION des fonctions 
float cal_surf_contour();
void met_extension();
void format_entree();
void surface_des_contours();
void traite_cir_val();
void traite_cir_val_classe();

// declaration application 

FILE *fpcir1,*fpval1, *fptxt;

int	 nbfac1,nomax1;
int	 codev;
float 	valeur,val_min,val_max;
float	zmin,zmax, minv,maxv;
float	*surf_cont;
double  *valeura,*valeurc;
int		*retenu;
double  surf_total_fic;
struct modelisation_face *fac1;


/************************************************/
main(argc,argv)
int argc;char **argv;
{
 char buf[512], nom_graph[256], nom_val1[256],*s_dir, c;
 int hh1,hh2,pas,minute,temps;
 float xh_heure;
 int h_heure,m_minute ,nb_pas;
 char extension[32];

 int 	i, j, ip, nbc;
 float cminv,cmaxv;
 int i_cminv,i_cmaxv;
 double englob[10];


  if(argc!=14){ format_entree(); exit(0);}
  nb_etat=0;      /* nb de valeurs entieres allouees par contour */

  s_dir=(char *)getenv("PWD");
	
  printf("Fonction Solene: analyse_cir_val_croise_tps\n\n");
  printf("Analyse croisee des valeurs d'un descripteur d'une g�om�trie en fonction du temps \n");

  sscanf(argv[3],"%f",&zmin);
  sscanf(argv[4],"%f",&zmax);

  sscanf(argv[5],"%f",&val_min);
  sscanf(argv[6],"%f",&val_max);

 //  heures debut et fin , pas
         sscanf(argv[8],"%d%c%d",&hh1,&c,&minute);
         hh1=hh1*60+minute;
         sscanf(argv[9],"%d%c%d",&hh2,&c,&minute); 
         hh2=hh2*60+minute;
         sscanf(argv[10],"%d%c%d",&pas,&c,&minute);
         pas=pas*60+minute;
         printf(" de hh1 %d a hh2 %d par pas de %d\n",hh1,hh2,pas);
 
 /* calcul du nombre de pas */
   nb_pas=1;
   i=hh1;
   while(i<hh2)
    { nb_pas++;
      i=i+pas;
    }
 printf("Nb de pas %d\n",nb_pas);

 // code de la valeur � stocker
  sscanf(argv[11],"%d",&codev);

 // Lit les faces
 //_________________
 compose_nom_complet(buf,s_dir,argv[1],"cir");
 if((fpcir1=fopen(buf,"r"))==NULL)
	{ printf("impossible ouvrir %s\n",buf);
	  exit(0);
	}
   printf(" Geom�trie   : %s\n",buf);	

   lit_en_tete(fpcir1,&nbfac1,&nomax1,englob);
   fac1=alloue_face(nbfac1,1000);
   lit_fic_cir3d(fpcir1,nbfac1,fac1); 
   fclose(fpcir1);

   // calcule les surfaces de chaque contour
  nbc = nbcontours_total(fac1, nbfac1);
  surf_cont = alloue_float(nbc, 1234);
  surface_des_contours();
  // calcule de la surface totale cumul�e des contours du fichier
  surf_total_fic=0;
  for (i=0;i<nbc; i++)
  {	    surf_total_fic += surf_cont[i];
  }

 // Lit les valeurs associ�es du descripteur � croiser
 //___________________________________________________
  compose_nom_complet(buf,s_dir,argv[7],"val");
  if((fpval1=fopen(buf,"r"))==NULL)
	{ printf("impossible ouvrir %s\n",buf);
	  exit(0);
	}
   printf(" Descripteur � croiser: %s\n",buf);

   /* lit seulement  pour val min et max  */	
   fscanf(fpval1,"%d %d %f %f\n",&i,&i,&cminv,&cmaxv);
   rewind(fpval1);
	
  // Allocation du tableau des valeurs associ�es aux contours*/
  valeurc = alloue_double(nbc,456);
  lect_fic_val(fpval1, valeurc);
  fclose(fpval1);

  // Allocation du tableau des valeurs du descripteur � traiter associ�es aux contours */
  valeura = alloue_double(nbc,456);

  // alloue pour traitement
  retenu=alloue_int(nbc,456);  // 1 contour retenu, 0 non retenu



 // Ouvre le fichier en �criture pour contenir le tableau de valeurs f(tps) � tracer
 //___________________________________________________
  compose_nom_complet(buf,s_dir,argv[13],"txt");
  if((fptxt=fopen(buf,"w"))==NULL)
	{ printf("impossible ouvrir %s\n",buf);
	  exit(0);
	}
   printf(" Ecrit le tableau de valeurs dans: %s\n",buf);

 // REALISE LE TRAITEMENT STATISTIQUE A CHAQUE PAS DE TEMPS
 //_______________________________________________________
   temps=hh1;
   for(ip=0;ip<nb_pas;ip++)
     { 
		xh_heure= (float)temps/60;
		h_heure= (int) xh_heure;
		m_minute= temps-h_heure*60;
		printf("___________________________________________\n");
		printf("Heure_minute %d H %d\n",h_heure,m_minute);
		printf("___________________________________________\n");
		fprintf(fptxt,"%.2f ",(float)(xh_heure + m_minute*100./60.));

		// appel extension 
		  met_extension(temps,extension);

		// Ouvre descripteur � traite  en Input pour cette heure
		  sprintf(buf,"%s%s",argv[2],extension);
          compose_nom_complet(nom_val1,s_dir,buf,"val");
          printf(" Descripteur � traiter : %s \n", nom_val1);
	      if ((fpval1=fopen(nom_val1,"r"))==NULL)
            { printf("\n  impossible ouvrir %s\n\n", nom_val1); 
			  exit(0);
            }
		// Lit les valeurs associ�es du descripteur � traiter
			/* lit seulement  pour val min et max  */	
			fscanf(fpval1,"%d %d %f %f\n",&i,&i,&minv,&maxv);
			rewind(fpval1);
			lect_fic_val(fpval1, valeura);
			fclose(fpval1);

		// Nom du fichier graphe de fr�quence cumul�e pour tracer avec DPLOT pour cette heure
		   sprintf(buf,"%s%s",argv[12],extension);
		   compose_nom_complet(nom_graph,s_dir,buf,"grf");

		// Fait les stats pour l'ensemble du fichier
		//___________________________________________
		  
		  traite_cir_val(nbc,nom_graph);

		// Fait les stats en croisant
		//___________________________________________
		  i_cminv= (int) cminv;
		  i_cmaxv= (int) cmaxv;
 
		  printf("\n VALEURS CALCULEES SUIVANT DESCRIPTEUR CROISE\n");
		  printf(" ___________________________________________\n");

		  for (i=i_cminv;i<=i_cmaxv;i++)
		  {
			  for(j=0;j<nbc;j++) { retenu[j]=0;}
			  // traite pour la valeur crois�e = i
			   printf(" VALEURS CALCULEES POUR DESCRIPTEUR = %d\n",i);
			   printf(" ___________________________________________\n");

			  traite_cir_val_classe(nbc, i);
		  }
	temps+=pas;
	fprintf(fptxt,"\n");
   } // fin d'un pas de temps

   // fin
   fclose(fptxt);
   desalloue_fface(fac1,nbfac1);
   desalloue_double(valeura);
   desalloue_double(valeurc);
   desalloue_float(surf_cont);
   desalloue_int(retenu);

   creer_OK_Solene();
   printf("\n Fin analyse_cir_val_croise_tps \n");
  
}

/*------------------------------------------------------------*/
void traite_cir_val(nbc, nom_graph)
int nbc; // nb total de contours
char *nom_graph;
{
 int 	i,j, k,nb_contour_r,noc,nop, nopi,nopj;
 int nb_val_differentes;
 double zmoyen,surf,surf_total,val_total, val_cumul;
 double moyenne_p;
 double variance; // (somme [Si *(Vi-my)2]) /somme Si
 double ecart_type, mediane;
 struct contour *pcont;
 struct circuit *pcir;
 double *r_surf,*r_val,*r_F,*r_FP;
 double surf_cumul, ecart, ecart50, ecart_val, valini;
 FILE *pg;

	surf_total=0;  val_total=0; val_cumul=0;
	nb_contour_r=0; noc=0;

	for(i=0;i<nbfac1;i++)
	 { nop =0;

	   pcont=(fac1+i)->debut_projete;
	   while(pcont)	   
         { pcir=pcont->debut_support;
		   surf= surf_cont[noc];
           zmoyen=0;
           for(k=0;k<pcir->nbp-1;k++) 
             { zmoyen+=pcir->z[k];
               /*printf("%d : %lf %lf %lf\n",k+1,pcir->x[k],pcir->y[k],pcir->z[k]);*/
             }
           zmoyen=zmoyen/(pcir->nbp-1);

           //printf(" FACE %d  Contour %d Zgravite  %f Val %f \n",(fac1+i)->nofac_fichier,nop,zmoyen,valeura[noc]);
		   //printf("surf= %f\n",surf_cont[noc]); 



			if(zmoyen>=zmin && zmoyen<=zmax && valeura[noc]>=val_min && valeura[noc]<= val_max)
			{ 
				/* RETIENT LE CONTOUR */
			 retenu[nb_contour_r] = noc;  // stocke indice du contour retenu
			 nb_contour_r++;
				// calcule des valeurs
		     surf_total += surf_cont[noc];
			 val_cumul  += valeura[noc];
			 val_total  += valeura[noc] * surf_cont[noc];

		     //printf("   contour retenu : surf = %lf\n",surf_cont[noc]);
           }

		   noc++; nop++; 
           pcont=pcont->suc;
         } 
	}

  printf("\n Contour retenu si:\n  %f <= z centre gravite <= %f\n",zmin,zmax);
  printf("\n  %f <= valeur descripteur <= %f\n\n",val_min,val_max);
  printf("\n Valeurs extr�mes du fichier� traiter\n");
  printf("\n  %f <= descripteur <= %f\n\n",minv,maxv);
  printf(" Surface totale des contours de la g�om�trie : %f\n\n",surf_total_fic);
  printf(" N = nb de contours retenus = %d (sur un total de %d dans %d faces)\n",nb_contour_r,noc,nbfac1);

  printf(" S = surface totale retenue   = %lf (soit %4.2f%%)\n\n",surf_total, surf_total*100/surf_total_fic);

  printf(" V   = somme des valeurs des contours = %lf\n",val_cumul);
  printf(" V/N = valeur moyenne = %lf\n\n",val_cumul/nb_contour_r);

  printf(" V pond�r�e = somme des (valeur * surf) des contours = %lf\n",val_total);

  moyenne_p= val_total/surf_total;
  printf(" V/S moyenne pond�r�e = %lf\n\n",moyenne_p);

    // Ecrit dans le fichier TxT pour graph Dplot
  if(codev==1) fprintf(fptxt,"%f ",val_cumul);
  else if(codev==2) fprintf(fptxt,"%f ",val_cumul/nb_contour_r);
  else if(codev==3) fprintf(fptxt,"%f ",val_total);
  else if(codev==4) fprintf(fptxt,"%f ",moyenne_p);


  // VARIANCE : Traite les contours retenus 

  variance =0;
 for(i=0; i<nb_contour_r; i++)
 { //printf("retenu %d\n",retenu[i]);
   nop= retenu[i];
   variance += surf_cont[nop] * (valeura[nop] - moyenne_p) * (valeura[nop] - moyenne_p);
 }
 variance = variance / surf_total;

 ecart_type = sqrt (variance);

 printf(" VARIANCE = %f \n", variance);
 printf(" ECART_TYPE = %f \n", ecart_type);

  // MEDIANE : Traite les contours retenus 

		// tri les retenus suivant leurs valeurs par ordre croissant
		// modifie leur indice

 for(i=0; i<nb_contour_r-1; i++)
 { 
   nopi= retenu[i];
   for(j=i+1;j<nb_contour_r; j++)
   {
	   nopj= retenu[j];
	   if(valeura[nopj] < valeura[nopi])
	   {
		   // on inverse les indices des contours
		   retenu[i] = nopj;
		   retenu[j] = nopi;
		   nopi = nopj;
	   }
   }
 }

  // Constitue liste tri�e avec valeurs associ�es
  //   en REUNISSANT LES VALEURS EGALES

 r_surf=alloue_double(nb_contour_r,678);
 r_val =alloue_double(nb_contour_r,679);
 r_F   =alloue_double(nb_contour_r,680);
 r_FP   =alloue_double(nb_contour_r,680);
 surf_cumul=0;
 k=0;
 	// probabilit� pour avoir V<Vi; cumul les surfaces dans vecteurs des retenus
  nb_val_differentes = k;
  for(i=0; i<nb_contour_r; i++)
  { 
	nopi= retenu[i];
	if(k!=0 && valeura[nopi] == r_val[k-1])
	{ // valeurs �gales
	 r_surf[k-1] += surf_cont[nopi];
	 surf_cumul += surf_cont[nopi];
	 r_F[k-1] = surf_cumul;
	}
	else
	{
	 r_val[k] = valeura[nopi];
	 r_surf[k] = surf_cont[nopi];
	 surf_cumul += surf_cont[nopi];
	 r_F[k] = surf_cumul;

	 k++;
	}
  }
  nb_val_differentes = k;
  //printf("nb_val_differentes  %d\n",nb_val_differentes);

    for(i=0; i<nb_val_differentes; i++)
	{ 
     r_FP[i] = r_F[i]*100/surf_total;
     //printf("  valeur %f surface %f F %f FProba %f\n",r_val[i],r_surf[i],r_F[i],r_FP[i]);
	}

	// recherche 50%
    for(i=0; i<nb_val_differentes; i++)
	{ if(r_FP[i]>=50)
	  // on a atteint ou d�pass� 50% des valeurs; c'est la m�diane
		{ 
	      // attention si i=0;
		  if(i!=0) 
		  {
			  ecart50 = 50 - r_FP[i-1];
			  ecart = r_FP[i] - r_FP[i-1];
			  ecart_val= r_val[i]-r_val[i-1];
			  valini = r_val[i-1];
		  }
		  else
		  {   ecart50 = 50;
		      ecart = r_FP[i];
			  ecart_val= r_val[i];
			  valini= 0;
		  }
	// attention ecart =0 0
          if(ecart)
		  {
		    mediane = valini+ (ecart_val*ecart50/ecart);
		  }
		  else
		  {
			mediane = r_val[i];
		  }
		//printf(" ecartF %f  ecart50 %f ecartval %f val1 %f \n", ecart,ecart50,ecart_val,valini);

		  printf(" MEDIANE = %f\n", mediane);
		  break;
		}
	}

	// STOCKAGE des valeurs pour affichage avec Dplot (.grf)
	// distribution de la probabilite cumul�e d'avoir v < Valeur)
    if((pg=fopen(nom_graph,"w"))==NULL)
	{ printf("impossible ouvrir %s\n",nom_graph);
	  exit(0);
	}
	printf(" \n Ecriture du graphe : %s\n",nom_graph);

	fprintf(pg,"DPLOT/W v1.2\ndata\n1\n");
	fprintf(pg,"%d\n",nb_val_differentes);

    for(i=0; i<nb_val_differentes; i++)
	{ fprintf(pg,"%f,%f\n",r_val[i],r_FP[i]);
	}

	fprintf(pg," 1    0\n\n\n");
	fprintf(pg," Distribution fr�quence cumul�e (V<Vi) : %s\n\n",nom_graph);
	fprintf(pg," Valeurs (m�diane = %.2f)\n",mediane);
	fprintf(pg," Fr�quence (%%)\n");
	fprintf(pg,"     1\n");
	fprintf(pg,"0,0\n");
	fprintf(pg,"Grid Type\n");
	fprintf(pg,"01\n");
	fprintf(pg,"LineWidths\n");
	fprintf(pg," 30\n");
	fprintf(pg,"Manual Scale\n");
	fprintf(pg,"%f   0.0\n",r_val[0]);
	fprintf(pg,"%f   100.0\n",r_val[nb_val_differentes-1]);
	fprintf(pg,"PointSizes\n");
	fprintf(pg," 7\n");
	fprintf(pg," 10 18 14 14 14 14 10\n");
	fprintf(pg,"SymbolSizes\n");
	fprintf(pg," 125\n");
	fprintf(pg,"Stop\n");
	fclose(pg);


desalloue_double(r_surf);
desalloue_double(r_val);
desalloue_double(r_F);
desalloue_double(r_FP);
}

/*------------------------------------------------------------*/
void traite_cir_val_classe(nbc, i_valc)
int nbc; // nb total de contours
int i_valc;
{
 int 	i, k,nb_contour_r,noc,nop;
 double zmoyen,surf,surf_total,val_total, val_cumul;
 double moyenne_p;
 struct contour *pcont;
 struct circuit *pcir;

	surf_total=0;  val_total=0; val_cumul=0;
	nb_contour_r=0; noc=0;

	for(i=0;i<nbfac1;i++)
	 { nop =0;

	   pcont=(fac1+i)->debut_projete;
	   while(pcont)	   
         { pcir=pcont->debut_support;
		   surf= surf_cont[noc];
           zmoyen=0;
           for(k=0;k<pcir->nbp-1;k++) 
             { zmoyen+=pcir->z[k];
               /*printf("%d : %lf %lf %lf\n",k+1,pcir->x[k],pcir->y[k],pcir->z[k]);*/
             }
           zmoyen=zmoyen/(pcir->nbp-1);

           //printf(" FACE %d  Contour %d Zgravite  %f Val %f \n",(fac1+i)->nofac_fichier,nop,zmoyen,valeura[noc]);
		   //printf("surf= %f\n",surf_cont[noc]); 

			if(zmoyen>=zmin && zmoyen<=zmax && valeura[noc]>=val_min && valeura[noc]<= val_max && valeurc[noc]==(double) i_valc)
			{ 
				/* RETIENT LE CONTOUR */
			 retenu[nb_contour_r] = noc;  // stocke indice du contour retenu
			 nb_contour_r++;
				// calcule des valeurs
		     surf_total += surf_cont[noc];
			 val_cumul  += valeura[noc];
			 val_total  += valeura[noc] * surf_cont[noc];

		     //printf("   contour retenu : surf = %lf\n",surf_cont[noc]);
           }

		   noc++; nop++; 
           pcont=pcont->suc;
         } 
	}

  printf(" N = nb de contours retenus = %d (sur un total de %d dans %d faces)\n",nb_contour_r,noc,nbfac1);

  printf(" S = surface totale retenue   = %lf (soit %4.2f%%)\n\n",surf_total, surf_total*100/surf_total_fic);

  printf(" V   = somme des valeurs des contours = %lf\n",val_cumul);
  printf(" V/N = valeur moyenne = %lf\n\n",val_cumul/nb_contour_r);

  printf(" V pond�r�e = somme des (valeur * surf) des contours = %lf\n",val_total);

  moyenne_p= val_total/surf_total;
  printf(" V/S moyenne pond�r�e = %lf\n\n",moyenne_p);

  // Ecrit dans le fichier TxT pour graph Dplot
  if(codev==1) fprintf(fptxt,"%f ",val_cumul);
  else if(codev==2) fprintf(fptxt,"%f ",val_cumul/nb_contour_r);
  else if(codev==3) fprintf(fptxt,"%f ",val_total);
  else if(codev==4) fprintf(fptxt,"%f ",moyenne_p);

}

/*_____________________________________________________*/
void surface_des_contours()
{
 int i,nop;
 struct contour *pcont;
 struct circuit *pcir;
   nop=0;
	for(i=0;i<nbfac1;i++)
	{
		// pour calcule de la surface de chaque contour - celle des trous
                      obs.xo=0; obs.yo=0; obs.zo=0;
                      obs.x=(fac1+i)->vnorm[0];
                      obs.y=(fac1+i)->vnorm[1];
                      obs.z=(fac1+i)->vnorm[2];
                      tranfo();
					  tran_face(fac1+i,1,fac1+i,0); 

	   pcont=(fac1+i)->debut_dessin;
	   while(pcont)
	   {
		   pcir=pcont->debut_support;
		   surf_cont[nop] = cal_surf_contour(pcont);
		   nop++;
		   pcont=pcont->suc;
	   }
	 }
}

/*-----------------------------------------------------------------------------*/
float cal_surf_contour(pcont)
struct contour *pcont;
{ 
 float surf;
 struct circuit *pcir;

 surf=0;
	 pcir=pcont->debut_support;
	 surf+=(float)fabs(surface(pcir->nbp,pcir->x,pcir->y));
	 pcir=pcont->debut_interieur;
	 while(pcir)
	    {surf-=(float)fabs(surface(pcir->nbp,pcir->x,pcir->y));
	     pcir=pcir->suc;
	    }
  return(surf);
}

//_____________________________________________________
void met_extension (temps,extension)
int temps;
char *extension;
{  // modele energie diffuse meteo
	float xh_heure;
	int h_heure, m_minute;

		xh_heure= (float)temps/60;
		h_heure= (int) xh_heure;
		m_minute= temps-h_heure*60;
		//printf(" heure_minute %d H %d\n",h_heure,m_minute);
		//construit extension pour fichier val heure
		if(h_heure>=10 && m_minute >=10)
		{
		 sprintf(extension,"_%dH%d",h_heure,m_minute);
		}
		else if(h_heure>=10 && m_minute <10)
		{
		 sprintf(extension,"_%dH0%d",h_heure,m_minute);
		} 
		else if(h_heure<10 && m_minute >=10)
		{
		 sprintf(extension,"_0%dH%d",h_heure,m_minute);
		} 
		else if(h_heure <10 && m_minute <10)
		{
		 sprintf(extension,"_0%dH0%d",h_heure,m_minute);
		} 
		//printf("extension %s\n",extension);
}

/*------------------------------------------------------------*/
void format_entree()
{
 printf("\n analyse_cir_val  fichier_in(.cir) nom_generique_fichier_val(.val)\n");
 printf("\tIN	fichier_in(.cir) \n");
 printf("\tIN	nom_generique_fichier_val(.val) \n");
 printf("\tIN	zmin_g\n");
 printf("\tIN	zmax_g\n");
 printf("\tIN	val_min\n");
 printf("\tIN	val_max\n");
 printf("\tIN	fichier_descripteur_croise(.val)\n");
 printf("\tIN	hh1:mm1\n");
 printf("\tIN	hh2:mm2\n");
 printf("\tIN	pas(hh:mn)\n");
 printf("\tIN	code_de_valeur_a_stocker\n");
 printf("\tOUT  nom_gen_fic_dplot(.grf)\n");
 printf("\tOUT  fichier_texte pour Dplot(.txt)\n\n");

  printf("NOTA: ne retient que contour dont zmin_g < centre gravite < zmax_g\n");
  printf(" et que contour dont val_min < valeur_descripteur < val_max\n\n");
  printf("NOTA: le descripteur crois� doit contenir des valeurs enti�res \n\n");
  printf("NOTA	code_de_valeur_a_stocker:\n");
  printf("		1 (valeur cumul�e) 2 (valeur my) 3 (valeur cumul�e pond�r�e) 4 (valeur my pond�r�e)\n\n");

  printf("NOTA: le fichier Texte pour Dplot contient les valeurs fonction du temps \n");
  printf(" pour l'ensemble du fichier_in et pour chaque valeur du descripteur � croiser\n\n");
  printf("NOTA: Le programme ajoute une extension _hhHmm au nom de fichier correspondant � l'heure du calcul\n");

}


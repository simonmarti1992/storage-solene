/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */
 
/***** surf_ensol.c *************/
/**** pour these L.Tiraoui ****/
/*** M.J. Antoine, CERMA, 1999 ***/


/*** Calcul du taux de surf ensoleillee pour une scene ou partie de scene
***/

/*   Rappel ligne de compilation */

/* cc surf_ensol.c  ./UTILS/solutile.o ./UTILS/geomutile.o   ./UTILS/lib_solene_94.o -o surf_ensol -lm */
   
 
/* Fichiers inclus */
#include<solene.h>
#include<ctype.h>
//#include<unistd.h>


void usage();
int info_faces_contours();
void lect_fichier();


main(argc,argv)           
int argc;
char **argv;
{ 
char *dir_courant;

char nom_surf[256];
/* fichier (lu) pour descripteur du fichier test (surf) */
double *surf;
/* valeurs */
char nom_sol[256];
/* fichier (lu) pour descripteur du fichier test (flux solaires incidents) */
double *sol;
/* valeurs */

int no_face_debut, no_face_fin;
int nb_contour;
int nbfac, nomax;
int *nb_cont_face, *numero_face;
int no_face, no_contour;
int compt_contour;
double surf_totale;
double surf_ensoleillee;
double taux;


FILE *pfic_descr;

double seuil_sol;
/* seuil sur flux incident pour considerer qu'une surf est ensoleillee */

/* Autres */
double min, max; char c;
int ind_fac, ind_cont, compteur;
int OK_sauv=0;
double *auxiliaire;

/*** Lecture des parametres de la commande ***/

dir_courant=(char *)getenv("PWD");

if (argc<3)usage();

compose_nom_complet(nom_surf,dir_courant,argv[1],"val");
printf("Surfaces du fichier : %s \n", nom_surf);

compose_nom_complet(nom_sol,dir_courant,argv[2],"val");
printf("Flux solaires incidents du fichier : %s \n", nom_sol);

if (argc==4)
	{sscanf(argv[3], "%d", &no_face_debut);
	 no_face_fin = no_face_debut;
	 printf("Traitement pour les faces comprises entre no %d et no %d\n", no_face_debut, no_face_fin);}

if (argc==5)
	{sscanf(argv[3], "%d", &no_face_debut);
	 sscanf(argv[4], "%d", &no_face_fin);
	 printf("Traitement pour les faces comprises entre no %d et no %d\n", no_face_debut, no_face_fin);}

/*** Ouverture des fichiers ***/

	/* Lecture d'un fichier .val pour infos fichier observateur*/
	

if ((pfic_descr=fopen(nom_surf,"r"))==NULL)
            	{ 
		printf("\n  *** impossible ouvrir %s ***\n\n", nom_surf); 
		goto fin;
            	}
fscanf(pfic_descr,"%d %d %lf %lf",&nbfac,&nomax,&min,&max);

if (argc==3)
	{no_face_debut=1;
	 no_face_fin=nomax;
	 printf("Traitement pour les faces comprises entre no %d et no %d\n", no_face_debut, no_face_fin);}

numero_face=(int *)malloc(nbfac*sizeof(int));
if (numero_face==NULL)
	{printf("Probleme d'allocation numero face, arret.\n\n");
	 exit(0);}
nb_cont_face=(int *)malloc(nbfac*sizeof(int));
if (nb_cont_face==NULL)
	{printf("Probleme d'allocation nombre contours par face, arret.\n\n");
	 exit(0);}
fclose(pfic_descr);

nb_contour = info_faces_contours(pfic_descr, nom_surf, nbfac, numero_face, nb_cont_face);


surf = (double*)malloc(nb_contour*sizeof(double));
if (surf==NULL)
	{printf("Probleme allocation surfaces du fichier, abandon.\n");
	 exit(0);}

	
pfic_descr=fopen(nom_surf, "r");	
lect_fichier(pfic_descr, nbfac, nomax, surf);
fclose(pfic_descr);

sol = (double*)malloc(nb_contour*sizeof(double));
if (sol==NULL)
	{printf("Probleme allocation (flux solaires incidents), abandon.\n");
	 exit(0);}

if ((pfic_descr=fopen(nom_sol,"r"))==NULL)
            	{ 
		printf("\n  *** impossible ouvrir %s ***\n\n", nom_sol); 
		goto fin;
            	}

lect_fichier(pfic_descr, nbfac, nomax, sol);
fclose(pfic_descr);





/******************************************************************/
/* Traitement : calcul du taux de surf ensoleillees           */
/******************************************************************/

seuil_sol = 0.0; /* Seuil strict pour considerer qu'une surf est ensoleillee */
		/* ici, bon pour flux solaire incident direct */

compt_contour = 0;
surf_totale = 0.0;
surf_ensoleillee = 0.0;


printf("Prise en compte face(s) ");

for (no_face = 0; no_face<nbfac; no_face++)
	{ if ((numero_face[no_face] >= no_face_debut) && (numero_face[no_face] <= no_face_fin))
		{ printf("%d, ", numero_face[no_face]);
		 for (no_contour = 0;no_contour<nb_cont_face[no_face];no_contour++)
			{surf_totale += surf[compt_contour];
			 if (sol[compt_contour] > seuil_sol)
			 	surf_ensoleillee += surf[compt_contour];
			 compt_contour++;
			}
		}
	}

taux = surf_ensoleillee/surf_totale;

printf("arret\n");
printf("--------------------------------------------------------------------------\n");
printf("RESULTAT : taux de surface ensoleillee = %lf (%3.1lf/100)\n", taux, 100*taux);
printf("--------------------------------------------------------------------------\n");

free(numero_face);
free(nb_cont_face);
free(surf);
free(sol);

fin:;
}

/*_____________________________________________________________________*/
void usage()
{printf(" *surface_ensol* surfaces(.val) flux_solaires_incidents(.val) [no_face_debut] [no_face_fin] \n\n");
 
 exit(0);
}

/*_____________________________________________________________________*/
int info_faces_contours(pfic, nom, nbfac, numero_face, nb_cont_face)
FILE *pfic;
char nom[256];
int nbfac;
int *numero_face;
int *nb_cont_face;
{
/* LECTURE D'UN FICHIER nom.val POUR DETERMINER NBRE DE CONTOURS TOTAL */
/* - remplit les tableaux de numeros de faces et nombre de contours par face */
/* Remarque: le nombre de faces doit deja avoir ete lu dans le fichier, */
/* on doit proceder en deux temps */
	
int nb_contour_total=0;
int nbf, nomx;
int numero, nb_contours;
int f, ct;
double val_min, val_max;
char c;
double *auxiliaire;

nbf=0;
nomx=0;
val_min=0.0;
val_max=0.0;

if ((pfic=fopen(nom,"r"))==NULL)
            	{ 
		printf("\n  compte contours: impossible ouvrir %s\n\n", nom); 
		exit(0);
            	}
fscanf(pfic,"%d %d %lf %lf",&nbf,&nomx,&val_min,&val_max);

for(f=0;f<nbfac;f++)
		{
		fscanf(pfic,"\n%c%d%d\n",&c,&numero,&nb_contours);
		numero_face[f] = numero;
		nb_cont_face[f] = nb_contours;
		nb_contour_total+=nb_cont_face[f];
		auxiliaire=(double *)malloc(nb_cont_face[f]*sizeof(double));
		for(ct=0;ct<nb_cont_face[f];ct++)
			fscanf(pfic,"%lf\n",auxiliaire+ct);
		free(auxiliaire);
		}
fclose(pfic);

return nb_contour_total;

}


/*_________________________________________________________________*/
/* Lecture fichier au "bon" format (.val) et remplissage tableau 'valeur' */
void lect_fichier(pfic, nbfac, nomax, valeur)
FILE *pfic;
int nbfac;
int nomax;
double *valeur;
{ double val_min;
  double val_max;
  int num_cont, num_face, num_cont_liste;
  int nofac, nbcont_face;
  char c;

  fscanf(pfic,"%d %d %lf %lf",&nbfac,&nomax,&val_min,&val_max);
  num_cont_liste = 0;
  for(num_face=0;num_face<nbfac;num_face++)
	{
	fscanf(pfic,"\n%c%d%d\n",&c,&nofac,&nbcont_face);
	for(num_cont=0;num_cont<nbcont_face;num_cont++)	
		{	
		fscanf(pfic,"%lf\n",valeur+num_cont_liste);
		num_cont_liste++;
		}
	}
}




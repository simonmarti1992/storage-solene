/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/*

cc projette_suivant_normale.c  solutile.o geomutile.o lib_solene_94.o 

D.GROLEAU 28 septembre 2005
D. GROLEAU fevrier 2006 
		ajoute Option I : projette suivant Inverse de la normale
		ajouter une option : transformation inverse au sens de la normale

Projette les faces suivant leurs normales
La normale n'est pas transform�e

*/


#include<solene.h>

// FUNCTIONS
int ecrit_en_tete();
void format_entree();
void output_ff();
void projette_face_suivant_normale();
void tran_face_mod();


// GLOBAL
struct modelisation_face *alloue_face();
struct modelisation_face *ff;
int nbff;

FILE *fp;

/*_________________________________________________________________*/
main(argc,argv)
 int argc;char **argv;
{char 	buf[512],*s_dir;
 double englob[10];
 int nb;
 int sens_normale;
 
 if(argc!=3 && argc!=4)format_entree();
 printf("Fonction Solene : projette_suivant_normale\n");

 if(argc==4)
 { printf("\n Projette Suivant le sens Inverse de la normale\n");
   sens_normale=-1;
 }
 else
 { printf("\n Projette Suivant le sens de la normale\n");
   sens_normale=1;
 }

	s_dir=(char *)getenv("PWD");

     init_verif_pteur_solene();
     obs.xo=0; obs.yo=0; obs.zo=0;
     nb_etat=0;
     pi=4*atan(1.); 

 
  //INPUT
  compose_nom_complet(buf,s_dir,argv[1],"cir");
  if((fp=fopen(buf,"r"))==NULL)
        { printf("\n impossible ouvrir %s\n",buf); exit(0);}
   lit_en_tete(fp,&nbff,&nomax,englob);
   ff=alloue_face(nbff,35);
   lit_fic_cir3d(fp,nbff,ff);
   fclose(fp);
   printf("g�om�trie � projeter : %s (%d faces)\n",buf,nbff);
        
  /* projette chaque face suivant sa normale */ 
     
   
	  projette_face_suivant_normale(sens_normale); // dans dessin 0
   

/* OUTPUT :stocke le fichier */

   compose_nom_complet(buf,s_dir,argv[2],"cir");
   fp=fopen(buf,"w");
    if(fp==NULL) 
	{ printf("impossible creer %s\n",buf);
	  exit(0);
	}
   ecrit_en_tete(fp,nbff,nomax,englob);
   output_ff(ff,nbff,0,0,fp,&nb,&nomax); //la face est dans dessin
// ATTENTION MODIF TEMPO
//   output_ff(ff,nbff,1,0,fp,&nb,&nomax); //la face est dans projet

   output_ff(ff,nbff,0,0,fp,&nb,&nomax); //la face est dans dessin
   fclose(fp);

      printf("g�om�trie r�sultat : %s (%d faces)\n\n",buf,nbff);
	  printf("NOTA: la normale n'est pas transform�e\n");


   printf("\n");
  		creer_OK_Solene();

	desalloue_fface(ff,nbff);
	printf("Fin projette_suivant_normale\n");

}

/*_____________________________________________________*/
void projette_face_suivant_normale(sens_normale)
int sens_normale;
{
 int i;
	for(i=0;i<nbff;i++)
	{
		// projette suivant la normale (ou inverse de la normale) de chaque face
                      obs.xo=0; obs.yo=0; obs.zo=0;
                      obs.x=(ff+i)->vnorm[0] * sens_normale;
                      obs.y=(ff+i)->vnorm[1] * sens_normale;
                      obs.z=(ff+i)->vnorm[2] * sens_normale;
					  
                      tranfo();
					  tran_face(ff+i,1,ff+i,0);

					  // ATTENTION MODIF TEMPO
					 //tran_face_inverse(ff+i,1);
	 }
}



/*-----------------------------------------------------------*/
void output_ff(face,nb,projete,itranf,pf,nbf,nomax)
struct modelisation_face *face;
int nb,projete,itranf,*nbf,*nomax;
FILE *pf;
{
              /* ecrit sur fichier pf,les nb faces; contour projete si projete=1; */
              /*                                    contour dessin  si projete=1; */
              /* en appliquant Tranfo inverse_Normalise  si itranf */
              /* et en mettant a jour nb de faces du fichier, nb contour, nomax */
  struct contour *pcont;
  struct circuit *pcir;
  int i,nbcont,nbtrou;



  for(i=0;i<nb;i++) 
    { 
     if(projete) pcont=face[i].debut_projete; else pcont=face[i].debut_dessin;
     if(pcont)
       {*nbf=*nbf+1; if(face[i].nofac_fichier>*nomax) *nomax=face[i].nofac_fichier;
        nbcont=nb_contour_face(face+i,projete);
        fprintf(pf,"f%d %d\n",face[i].nofac_fichier,nbcont);
        fprintf(pf," %lf  %lf  %lf\n",face[i].vnorm[0],face[i].vnorm[1],face[i].vnorm[2]);
 
        while(pcont)
         { nbtrou=nb_trou_contour(pcont);
           pcir=pcont->debut_support;
                       /* support ; en principe 1 seul */
           fprintf(pf,"c%d\n",nbtrou);
           output_circuit_sur_fichier(pcir,pf,itranf);
           pcir=pcont->debut_interieur;
                      /* les trous */
           while(pcir)
              { fprintf(pf,"t%\n");
                output_circuit_sur_fichier(pcir,pf,itranf);
                pcir=pcir->suc;
              }
           pcont=pcont->suc;
        }
     }
   }
}
/*_________________________________________________________________*/
void format_entree()
{
  printf("\n    projette_suivant_normale   fichier_in(.cir) fichier_out(.cir)   [I]  \n\n");
  printf("NOTA: la normale n'est pas transform�e\n");
  exit(0);
}



/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */
 
/*__________________________  df_visib_parcours.c   __________________ _  */
/*                           Construit a partir de :   	 		          */
/* facformn.c : DETERMINATION DES FACTEURS DE FORME DE CONTOUR A CONTOUR  */
/* Pour triangles et quadrangles 					                      */
/* MJ Antoine Dec.98 st Groleau 99
  et de df_visib.c	

/* D. GROLEAU modification mars 2004 appel � coplanaire	 				  */
	 					                             
/*______________________________________________________________________  */
/* Pour traitement pbs visibilite D. Follut 				  */
/* Ce programme determine si les contours d'un fichier "test" sont visibles */
/* a partir des  points observateur-visee d'un fichier de reference,  */
/* avec des obstructions dues a un fichier "masque"                       */
/* Le resultat est un fichier de type .vis contenant des valeurs 0 ou 1   */
/* a la ligne l, colonne c: visibilite du patch numero c du fichier test  */
/* depuis le patch numero l du fichier reference                          */
/* ce fichier de valeurs peut ensuite etre exploite en conjonction avec   */
/* un certain nombre de fichiers de descripteurs                          */
/*                                                                        */
/*L'axe de vue est donn� par le point suivant l'observateur               */
/*______________________________________________________________________  */

/* Rappel ligne de compilation */
/*
cc visib.c  pers_util.o solutile.o face_op_face.o 
            lib_solene_94.o .geomutile.o poly_op_poly.o traite.o
            solaire.o
   -o visib -lm
*/


//si recompile, v�rifier nb de param�tres de coplanaire (sens de la normale)

#include<solene.h>


/* Fonctions */
extern int option_calcul_z;   /* option CALCUL du Z ds FACE-OP-FACE 1=coincidence_faces */
                              /* utilise ds singul.c epure_polygone */
			      /* et dans face_op_face.c             */
extern 	double coef_discol;
extern 	int z_axono_pers;


/*** Ajoutees par M.J.A. 02-98 ***/
/*** et 03/99 */

int nbcontours_total();
void traitement_faces();
/*** ***/
void fait_pers_fac_visib();
void preevalue_visib_contours();
void evalue_visib_contours();
void format_visib();

/* Variables globales */
/* n'ayant pu etre supprimees: */

double 	ang,angvis,pi,tgvis,covis,sinvis;
double vnf[3]; // utilis� dans evalue_visib_contour

FILE *pfacvis;		/* fichier binaire de visibilit� (exploitable par d'autres utilitaires) */

 double	 epsiloneN;  // parametre de coplanaire
 int	 facteurD;   // parametre de coplanaire


/*_________________________________________________________________*/
main(argc,argv)           
int argc;char **argv;
	{

/* Fichiers et structures de donnees */
	char nom_in[256];	/* plan d'observation */
	char nom_masc[256];	/* fichier masque (non maille) */ 
	char nom_test[256];	/* fichier regarde (maille) */
	char nom_fvis[256];	/* fichier-resultat de facteurs de visibilite */

	int nbfac,nbfac_masque,nbfac_test; /* Nombres de faces */

	struct modelisation_face *fac,*fac_visib,*fac_masque,*fac_test;
 	FILE *pfic,*pficm, *pfict;
	int nomax, nomaxm, nomaxt;
	double englob[10];

/* Autres */
	int im = 0;
 	double ang;
	char *s_dir;

/* initialisation */

   	singularite=0; non_singularite=0; nb_etat=0;
   	pb_masque=0; colle_max=coef_discol*DISCOL;
   	pi=4*atan(1.);

	// initialisation pour coplan�rit�
   epsiloneN = 0.0001;
   facteurD= 1000;


/* lecture parametres commande */
	s_dir = (char *)getenv("PWD");  

   	if(argc<6) format_visib();
 
        compose_nom_complet(nom_in,s_dir,argv[1],"cir");  
        printf("\n\nVisibilite a partir du fichier a traiter : %s \n",nom_in);

	    compose_nom_complet(nom_test,s_dir,argv[2],"cir");  
        printf("vers fichier test: %s \n",nom_test);

        compose_nom_complet(nom_masc,s_dir,argv[3],"cir");  
        printf("avec fichier masque: %s \n",nom_masc);

	    sscanf(argv[4],"%lf", &ang);
        printf("demi-angle de vision: %lf \n",ang);


	if ((ang<5)||(ang>89.9))
		{printf("Erreur angle de vision, doit etre compris entre 5 et 89.9 degres.\n");
		 exit(0);
		}

	compose_nom_complet(nom_fvis,s_dir,argv[5],"vis");  
        printf("fichier de facteurs de visibilite (resultat): %s \n",nom_fvis);




/*****************************************/
/* champ de vision : 1/2 angle au sommet */
   	
   	angvis=pi*ang/180.;
   	tgvis=tan(angvis); covis=cos(angvis); sinvis=sin(angvis);

/* ouvre les fichiers a traiter et  fichier resultat */

       if((pfic=fopen(nom_in,"r"))==NULL)
		{
        	printf("\n impossible ouvrir %s\n",nom_in); 
		    exit(0);
		}
            
       if((pficm=fopen(nom_masc,"r"))==NULL)
		{
            printf("\n impossible ouvrir %s\n",nom_masc); 
			exit(0);
  		}
          
       if((pfict=fopen(nom_test,"r"))==NULL)
		{
           	printf("\n impossible ouvrir %s\n",nom_test); 
			exit(0);
		}

	   if((pfacvis=fopen(nom_fvis,"wb"))==NULL)
		{
           	printf("\n impossible ouvrir %s\n",nom_fvis); 
			exit(0);
		}

/* lecture fichier a traiter  LES OBSERVATEURS */
       lit_en_tete(pfic,&nbfac,&nomax,englob);
      
       fac=alloue_face(nbfac,34);
       lit_fic_cir3d(pfic,nbfac,fac);

       fclose(pfic);

/* lecture  fichier LE MASQUE */
       lit_en_tete(pficm,&nbfac_masque,&nomaxm,englob);
       
       fac_visib=alloue_face(nbfac_masque,34);
       fac_masque=alloue_face(nbfac_masque,34);
       lit_fic_cir3d(pficm,nbfac_masque,fac_masque);

       fclose(pficm);

/* lecture  fichier LA SCENE 3D TRIAGULEE */
       lit_en_tete(pfict,&nbfac_test,&nomaxt,englob);
       
       fac_test=alloue_face(nbfac_test,34);
       lit_fic_cir3d(pfict,nbfac_test,fac_test);
       fclose(pfict);

/* lancement du calcul */

    printf("Pour chaque contour, Vise horizontalement du 1er point vers le point suivant\n\n");  	
    traitement_faces(nbfac, fac, nbfac_masque, fac_masque, fac_visib, nbfac_test, fac_test, pfacvis);
  
/* on termine */
	
		fclose(pfacvis);
       	desalloue_fface(fac,nbfac);
       	desalloue_fface(fac_visib,nbfac_masque);
       	desalloue_fface(fac_masque,nbfac_masque);
       	desalloue_fface(fac_test,nbfac_test);

	printf("Fin du traitement\n");
	exit(0);
}


/*___________________________________________________________________________________*/
void traitement_faces(nbfac, fac, nbfac_masque, fac_masque, fac_visib, nbfac_test, fac_test, pfvis)
int nbfac;
struct modelisation_face *fac;
int nbfac_masque;
struct modelisation_face *fac_masque;
struct modelisation_face *fac_visib;
int nbfac_test;
struct modelisation_face *fac_test;
FILE *pfvis;

{ 
int nf;
int noc;
int comptc = 0;
double xv,yv,zv;
struct contour *pcont;
struct circuit *cir_emetteur;

for(nf=0;nf<nbfac;nf++) // pour geometrie � traiter
  {	
	
	//
	noc=0;
        	
	pcont=(fac+nf)->debut_projete;
	while(pcont) 	/* Balayage des contours de la face courante */   
      { 
		cir_emetteur=pcont->debut_support;   /* Pointeur sur le contour courant */
        // l'observateur est le premier point du contour
		obs.xo = cir_emetteur->x[0];
		obs.yo = cir_emetteur->y[0];
		obs.zo = cir_emetteur->z[0]; 
		// la vis�e est le second point du contour
		xv = cir_emetteur->x[1];
		yv = cir_emetteur->y[1];
		zv = cir_emetteur->z[1];
		// vecteur de vue
        obs.x=obs.xo-xv;
		obs.y=obs.yo-yv;
		obs.z=obs.zo-zv;
		//printf("obs.xo yo zo %f %f %f\n",obs.xo,obs.yo,obs.zo);
		//printf("obs.x y z %f %f %f\n",obs.x,obs.y,obs.z);
		// la normale au champ de vision de l'observateur
		vnf[0] = - obs.x;
		vnf[1] = - obs.y; 
		vnf[2] = - obs.z; 
        // on modifie aussi la normale de la face pour ce contour � la direction de vis�e
		(fac+nf)->vnorm[0] = vnf[0];
		(fac+nf)->vnorm[1] = vnf[1];
		(fac+nf)->vnorm[2] = vnf[2];
	    // transformation a appliquer a chaque contour de la face 
        tranfo();

		noc++; 
		comptc++;
		//printf("Observateur Face numero %d, contour numero %d >>>> indice contour interne %d\n", (fac+nf)->nofac_fichier, noc, comptc); 

		/* Visibilite en tenant compte des masques */
		/* et calcul des facteurs de visibilite du contour courant emetteur */
		/* vers les contours des autres faces du fichier */

		fait_pers_fac_visib(fac+nf,nbfac_masque, fac_masque, fac_visib);

		preevalue_visib_contours(nbfac_masque, fac_masque,fac_visib, nbfac_test, fac_test, pfvis); 

		pcont=pcont->suc; /* Passage au contour suivant de la face courante */
	  }	
   }
}
/*_________________________________________________________________*/
void fait_pers_fac_visib(fac,nbfac_masque, fac_masque, fac_visib)
int nbfac_masque;
struct modelisation_face *fac;
struct modelisation_face *fac_masque;
struct modelisation_face *fac_visib;
{  
	int i;
	
/* COPIE ORIGINAL fac_masque ds fac_visib pour travail */
for(i=0;i<nbfac_masque;i++) 
copie_face(fac_masque+i,fac_visib+i);

/* TRANSFORMATION fichier "masque" et COUPE PYRAMIDE , si vu */
for(i=0;i<nbfac_masque;i++)
 { 
   //if(coplanaire(fac,1,fac_masque+i,1,0.0007) != 1)
     if(coplanaire(fac,1,fac_masque+i,1,epsiloneN,0,facteurD) != 1)

    { // on ne retient que les faces non coplanaires avec la face en traitement
	 if(visible_pers(fac_visib+i,1))
      { 
		 tran_face(fac_visib+i,1,fac_visib+i,0);
		 tran_normale((fac_visib+i)->vnorm);
		 if((fac_visib+i)->debut_dessin) 
           { 
			calcul_d_du_plan(fac_visib+i,0);
            face_dans_vision(fac_visib+i,0); 
           }
       }
     }
 }

/* PERSPECTIVE */
       init_fenetre_affichage();
       for(i=0;i<nbfac_masque;i++)
		{if((fac_visib+i)->debut_dessin)
               		{pers_conic_face(fac_visib+i,0);}
		}
               	
/* reajuste la fenetre a angle de vision */
       fen_aff[0]=-tgvis; fen_aff[1]=-tgvis; 
       fen_aff[3]=tgvis; fen_aff[4]=tgvis; 
       cal_fen_aff();
              /* attention si angvis proche de 90 */
              /* on evite fen_aff[6]=0 */
       if(fen_aff[6]<0.008) fen_aff[6]=0.008;


/* NORMALISATION */
       z_axono_pers=1;  
       option_calcul_z=0;

       for(i=0;i<nbfac_masque;i++)
	    { if((fac_visib+i)->debut_dessin)
           { normalise_face(fac_visib+i,0);
             sens_face(fac_visib+i,0,1);		 
           }

	      copie_face_projete(fac_visib+i,0,fac_visib+i,1);
        }

/* TRAITE VU/CACHE ; resultat dans (fac_visib+numero)->debut_dessin */
/* si ce pointeur est nul, la face 'numero' n'est pas visible	*/
/* depuis le point d'observetion courant, avec la direction de visee courante */

       traite_moins(fac_visib,nbfac_masque);
       z_axono_pers=0;
       option_calcul_z=1;

	   //printf("fin fait_pers\n");

}


/*_________________________________________________________________*/
void preevalue_visib_contours( nbfac_masque, fac_masque, fac_visib, nbfac_test, fac_test, pfvis) 
int nbfac_masque;
struct modelisation_face *fac_masque;
struct modelisation_face *fac_visib;
int nbfac_test;
struct modelisation_face *fac_test;
FILE *pfvis;

{
  /* pour chaque face de fac_test (nbfac_test) 			*/
  /* cherche si vue ds la perspective fac_visib (nbfac_masque) 	*/
  /* si vu, lance la procedure 'evalue_visib_contours' 		*/
  /* qui teste pour chaque centre de gravite des contours de fac_test */
  /* si est dans le polygone image perspective fac_visib de la face */
 

int i, noface_observee, noface_masque, nbcont;
float *valeur; 

for(noface_observee=0;noface_observee<nbfac_test;noface_observee++)
 {
   // pour chaque face_test
   // initialise nb_contour_face valeurs (correspondant � non visible)
   //printf("Pour face scene3D %d\n",(fac_test+noface_observee)->nofac_fichier);

   nbcont = nb_contour_face(fac_test+noface_observee,1);
   valeur = alloue_float(nbcont,1256);
   for(i=0;i<nbcont;i++) { valeur[i] = 0.; }
      
   for(noface_masque=0;noface_masque<nbfac_masque;noface_masque++)
     {
	   // pour chaque face_masque visible
	   if((fac_visib+noface_masque)->debut_dessin)
		{ 
		   // et coplanaire avec face_test
	     //printf("avec masque visible face %d\n",(fac_visib+noface_masque)->nofac_fichier);
		 //printf("les 2 normales : \n");
	     //printf("%f %f %f\n",(fac_test+noface_observee)->vnorm[0],(fac_test+noface_observee)->vnorm[1],(fac_test+noface_observee)->vnorm[2]);
	     //printf("%f %f %f\n",(fac_masque+noface_masque)->vnorm[0],(fac_masque+noface_masque)->vnorm[1],(fac_masque+noface_masque)->vnorm[2]);
		  //if(coplanaire(fac_test+noface_observee,1,fac_masque+noface_masque,1,0.0007) == 1)
		    if(coplanaire(fac_test+noface_observee,1,fac_masque+noface_masque,1,epsiloneN,1,facteurD) == 1)

		   {
			 //printf("et coplanaire\n");
			 //test visibilit� de chaque contour de face_test dans face_visible
			 evalue_visib_contours(fac_test, fac_visib, noface_observee,noface_masque, valeur);
			 
		   }
        }
     }

    // ecrit les nb_contour_face valeurs de face_test
    fwrite(valeur,sizeof(float),nbcont,pfvis);
	/*
    for(i=0;i<nbcont;i++)
     {  printf("%f ",valeur[i]);
     }
	printf("\n");
	*/
	
    desalloue_float(valeur);
  }
}

/*_________________________________________________________________*/
void evalue_visib_contours(fac_test, fac_visib, noface_observee, noface_masque, valeur)
struct modelisation_face *fac_test;
struct modelisation_face *fac_visib;
int noface_observee, noface_masque;
float *valeur;
{ /* Evaluation de la visibilite des differents contours de la face fac_test+noface_observee */
  /* par rapport au contour de reference */
  /* noface_masque = numero de la face du fichier-masque avec laquelle 'fac_test+noface_observee' coincide */
  /* cette face a subi un traitement de visibilite au prealable */
 
 int k, noc;
 struct contour *pcont;
 struct circuit *pcir;
 double xg,yg,zg;
 double xp, yp, zp;
 double xyz[3];
 double ang_inc;
 float fvis_nul=0.0;
 float fvis_ok=1.0;
 int test_nul = 0;

// on donne une valeur seulement quand effectivement on trouve un contour dans la face visible
   noc=0;
   pcont=(fac_test+noface_observee)->debut_projete;
   while(pcont)
     {  pcir=pcont->debut_support;
	
	    noc++;
        /* printf("... avec face %d contour %i\n",(fac_test+noface_observee)->nofac_fichier, noc); */

        /* cherche centre de gravite du contour courant */
	    xg=yg=zg=0;
        for(k=0;k<pcir->nbp-1;k++) 
           { 
		    xg+=pcir->x[k];
            yg+=pcir->y[k];
            zg+=pcir->z[k];
           }
	    xg=xg/(pcir->nbp-1);
        yg=yg/(pcir->nbp-1);
        zg=zg/(pcir->nbp-1);
        /* et vecteur centre de gravite - point observation */
           
        xg=xg-obs.xo;
        yg=yg-obs.yo;
        zg=zg-obs.zo;

       /* test si ds le champ de vision de l'observateur dont l'axe de visee est ds vnf */
        xyz[0]=xg; xyz[1]=yg; xyz[2]=zg;

     if((vincid(vnf,xyz,&ang_inc)) > 0)
      {

       /* transforme en perspective */
       tranp(xg,yg,zg,xyz,xyz+1,xyz+2);

       /* coupe par pyramide : retient ou non le point */
       if(xyz[2]<0 && fabs(xyz[0]/xyz[2])<tgvis && fabs(xyz[1]/xyz[2])<tgvis) 
        { 
		   /* met en pers et normalise  */
			xp=-xyz[0]/xyz[2];
			yp=-xyz[1]/xyz[2];
			zp=0;
			/*printf("xa %f  ya %f  za %f\n",xp,yp,zp);*/

			z_axono_pers=1;
			normalise_point(xp,yp,zp,&xp,&yp,&zp);
			z_axono_pers=0;
			/*printf("xp %f  yp %f  zp %f\n",xp,yp,zp);*/

			test_nul=0;

			/* test si ds face 'noface_masque' en perspective */

			if(point_dans_face(xp,yp,(fac_visib+noface_masque),0))
			  {/* le patch correspondant au contour pcir est considere comme visible */
		       /* car son centre de gravite l'est (il est contenu par la partie visible de la face) */

		       //printf("Contour %d de la face %d visible\n", noc, (fac+noface_observee)->nofac_fichier); 
					
		       /* Le facteur de visibilite est egal a 1 et est sauve */
			   valeur[noc-1]=1;
		       //fwrite(&fvis_ok,sizeof(float),1,pfvis);

			  }
			else
			  {  
		       /* facteur nul */
		       //test_nul=1;
		       //fwrite(&fvis_nul,sizeof(float),1,pfvis);			
			  }
         }
       	else
         {
           	/* facteur nul */
		   //test_nul = 1;
		   //fwrite(&fvis_nul,sizeof(float),1,pfvis);				
         }
     }

   else
     { //test_nul=1;
       //fwrite(&fvis_nul,sizeof(float),1,pfvis);
     }

   pcont=pcont->suc;
  }

}


/*_________________________________________________________________*/
void format_visib()
	{
  	printf("\n   format d'entree des parametres \n\n");
  	printf("df_visib  fichier_a_traiter(.cir)  fichier_test(.cir) fichier masque(.cir)\n"); 
	printf(" demi-angle de vision (deg) fichier_facteurs_visibilite(.vis)\n\n");
	
  	exit(0);
	}

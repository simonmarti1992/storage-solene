/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */
 
/*

cc compare_surface.c  solutile.o geomutile.o  solaire.o  poly_op_poly.o face_op_face.o lib_solene_94.o -o compare_surface  -lm

*/

/**************************************************************************/
/*   on emploi le + et le - parceque le > ne peut etre employe, il        */
/*   provoque une redirection de fichier et cree un fihier egal a         */
/*   pourcentage							  */
/**************************************************************************/

#include<solene.h>
#include<ctype.h>

extern double coef_discol;
char buf[512];
FILE *pf1,*pf2,*pf3;
int nbf2,nbf1,nbf3;
struct modelisation_face *f2,*f1,*f3;
int numax;


/*_________________________________________________________________*/
main(argc,argv) 
 int argc;char **argv;
{
   singularite=0; non_singularite=0; nb_etat=0;
   normale_orientee=1; traitement_faces_cachees=1;
   pb_masque=0; colle_max=coef_discol*DISCOL;
  
 if(argc!=6)format_entree_compare_surface();
 else traite_compare_surface(argv);


	creer_OK_Solene();
	printf("\n");

}
/*_________________________________________________________________*/
int traite_compare_surface(argv) 
char **argv;
{char op,*s_dir;
 int operation;
 int nbfacori,nbf;
 double pourcen,englob[10];

	s_dir=(char *)getenv("PWD");

printf("\n COMPARAISON DES SURFACES ENTRE DEUX FICHIERS \n");
     /* lit arguments de commande : commande f_in1 op f_in2 f_out */

 compose_nom_complet(buf,s_dir,argv[1],"cir");
 if((pf1=fopen(buf,"r"))==NULL)
      { printf("\n impossible ouvrir %s\n",buf); return(0);
      }
  printf(" %s ",buf);

 sprintf(buf,"%s",argv[2]);
  sscanf(buf,"%c",&op);
  if(op=='+') operation=0;
  else if(op=='=') operation=1;
  else if(op=='-') operation=2;
  else  { printf("\n impossible op %s\n",buf); return(0); }
  printf("%s ",buf);
 
   sscanf(argv[3],"%lf",&pourcen); pourcen=pourcen/100;

  compose_nom_complet(buf,s_dir,argv[4],"cir");
  if((pf2=fopen(buf,"r"))==NULL)
      { printf("\n impossible ouvrir %s\n",buf); return(0);
      }
  printf("%s ",buf);

  compose_nom_complet(buf,s_dir,argv[5],"cir");
  if((pf3=fopen(buf,"w"))==NULL)
      { printf("\n impossible ouvrir %s\n",buf); return(0);
      }
  printf("%s\n",buf);

   /* realise traitement */
  lit_en_tete(pf1,&nbf1,&numax,englob);
  lit_en_tete(pf2,&nbf2,&nbfacori,englob);
  numax=imax(numax,nbfacori); 

  f1=alloue_face(numax,35);
  lit_fic_cir3d(pf1,nbf1,f1);
  fclose(pf1);
  f2=alloue_face(numax,34);
  lit_fic_cir3d(pf2,nbf2,f2);
  fclose(pf2);

       if(operation==0)compare_surface_superieur(f2,nbf2,f1,nbf1,pourcen);
       else if(operation==1)compare_surface_egal(f2,nbf2,f1,nbf1,pourcen);
       else if(operation==2)compare_surface_inferieur(f2,nbf2,f1,nbf1,pourcen);
 
     /* stocke resultat */
   nbf=0; nbfacori=0;    
   ecrit_en_tete(pf3,nbf,nbfacori,englob);
   output_face_sur_fichier(f1,numax,1,0,pf3,&nbf,&nbfacori);
   rewind(pf3);
   ecrit_en_tete(pf3,nbf,nbfacori,englob);
     fclose(pf3);
   desalloue_fface(f1,numax);  desalloue_fface(f2,numax);
}
/*-----------------------------------------------------------------------------*/
int compare_surface_superieur(f2,nbf2,f1,nbf1,pourcen)
int nbf2,nbf1;
struct modelisation_face *f2,*f1;
double pourcen;
{int i,j;
 double surf1,surfo;
 for(i=0;i<nbf1;i++)
    {for(j=0;j<nbf2;j++)
      {if(f2[j].nofac_fichier==f1[i].nofac_fichier)break;} 
     if(j<nbf2)
         {surf1=surface_face(f1+i);
          surfo=surface_face(f2+j);
          if(surf1<=pourcen*surfo)
             {printf(" nofac = %d s = %lf %lf\n",f1[i].nofac_fichier,surf1,surfo);
              desalloue_contour_face(f1+i);
             }
         }
     else {desalloue_contour_face(f1+i);}
    }
}
/*-----------------------------------------------------------------------------*/
int compare_surface_egal(f2,nbf2,f1,nbf1,pourcen)
int nbf2,nbf1;
struct modelisation_face *f2,*f1;
double pourcen;
{int i,j;
 double surf1,surfo;
  for(i=0;i<nbf1;i++)
    {for(j=0;j<nbf2;j++)
      {if(f2[j].nofac_fichier==f1[i].nofac_fichier)break;} 
       if(j<nbf2)
         {surf1=surface_face(f1+i);
          surfo=surface_face(f2+j);
          if(surf1!=pourcen*surfo)desalloue_contour_face(f1+i);
         }
     else desalloue_contour_face(f1+i);
    }
}
/*-----------------------------------------------------------------------------*/
int compare_surface_inferieur(f2,nbf2,f1,nbf1,pourcen)
int nbf2,nbf1;
struct modelisation_face *f2,*f1;
double pourcen;
{int i,j;
 double surf1,surfo;
  for(i=0;i<nbf1;i++)
    {for(j=0;j<nbf2;j++)
      {if(f2[j].nofac_fichier==f1[i].nofac_fichier)break;} 
       if(j<nbf2)
         {surf1=surface_face(f1+i);
          surfo=surface_face(f2+j);
          if(surf1>=pourcen*surfo)desalloue_contour_face(f1+i);
         }
     else desalloue_contour_face(f1+i);

    }

}
/*_________________________________________________________________*/
int format_entree_compare_surface()
{
  printf("\n   *compare_surface*  fichier1_in(.cir)  operation valeur fichier2_in(.cir)  fichier_out(.cir) \n\n");
}

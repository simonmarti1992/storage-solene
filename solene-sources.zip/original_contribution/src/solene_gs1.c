/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/*

cc solen_g.c  solutile.o geomutile.o lib_solene_94.o -o rotz -lm

*/
/* transforme un contour solene en une face arc+ gs1 */
// ne traite pas les trous

#include<solene.h>


struct modelisation_face *alloue_face();

 struct modelisation_face *ff;
 int nbff, numero;
 char  axe;

FILE *fp;
/*_________________________________________________________________*/
main(argc,argv)
 int argc;char **argv;
{char 	buf[512],*s_dir;
 double pi,englob[10];
 int j,nbcont;
 
 if(argc<2)format_entree();

	s_dir=(char *)getenv("PWD");

     init_verif_pteur_solene();
     nb_etat=0;
     pi=4*atan(1.); 

	numero=0;

  // in fichier
  compose_nom_complet(buf,s_dir,argv[1],"cir");
  if((fp=fopen(buf,"r"))==NULL)
        { printf("\n impossible ouvrir %s\n",buf); exit(0);}
   lit_en_tete(fp,&nbff,&nomax,englob);
   ff=alloue_face(nbff,35);
   lit_fic_cir3d(fp,nbff,ff);
   fclose(fp);
        
   printf("solene_gs1\n\n");
   printf(" Transforme %s en .gs1\n\n",buf);

   /* out stocke le fichier */

   compose_nom_complet(buf,s_dir,argv[1],"gs1");
   fp=fopen(buf,"w");
    if(fp==NULL) 
	{ printf("impossible creer %s\n",buf);
	  exit(0);
	}
  // calcul le nb de contours car chaque contour devient une face
	nbcont= nbcontours_total(ff, nbff);
	fprintf(fp,"%10d\n",nbcont);

  /* solene_gs1 */ 
     
   for(j=0;j<nbff;j++) 
    {
	 gs1_face(ff+j,1);  
    }
   

   fclose(fp);
   printf("Fin de la conversion\n");
  		creer_OK_Solene();

	desalloue_fface(ff,nbff);
}

/*_________________________________________________________________*/
format_entree()
{
  printf("\n    *solene_gs1*  fichier_in_out(.cir  en gs1)   \n\n");
 printf(" transforme un contour solene en une face arc+ gs1 (ne traite pas les trous)\n");
  exit(0);
}
/*_________________________________________________________________*/
/*____________________________________________________________________*/
int gs1_face(face,projete)
struct modelisation_face *face;
int projete;
{int i;
 struct contour *pcont;
 struct circuit *pcir;

     
   if(projete)pcont=face->debut_projete; else pcont=face->debut_dessin;

      while(pcont)	   
       { pcir=pcont->debut_support; 
	      numero++;
		  fprintf(fp," 1 1 %d %d\n",numero,pcir->nbp);

         for(i=0;i<pcir->nbp;i++)
           {
            if (i==0) fprintf(fp,"0 %f %f %f\n",pcir->x[i],pcir->y[i], pcir->z[i]);
			else fprintf(fp,"3 %f %f %f\n",pcir->x[i],pcir->y[i], pcir->z[i]);
			}

		 // on ne traite pas les trous
	     pcir=pcont->debut_interieur;
		 //
         while(pcir)
		 {for(i=0;i<pcir->nbp;i++)
	       {
			 //
	       }
	     pcir=pcir->suc;
	    }
         pcont=pcont->suc; 
       } 
}



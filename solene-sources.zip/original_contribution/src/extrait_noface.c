/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/*

cc extrait_noface.c -o extrait_noface ~marenne/newsolene/solutile.o ~marenne/newsolene/geomutile.o ~marenne/newsolene/face_op_face.o ~marenne/newsolene/poly_op_poly.o ~marenne/newsolene/lib_solene_94.o -lm

*/

#include<solene.h>
#include<string.h>


/*_________________________________________*/
/* DESCRIPTION
  res�quence les no de faces   d'un fichier .cir � partir d'une valeur de no
*/

int ecrit_en_tete();
void format_entree();

/*________________________________________________________________________*/
main(argc,argv)
char **argv;
int  argc ;
{
char 	buf[512],*s_dir,c,mode;
double	englob[10];
int nbfac1,nomax1;

FILE *fsource,*fdest;
struct modelisation_face *fac1;

int i,j,k;
int nb, nomax;
int nodeb[100],nofin[100];
int nb_extract;
int dans;
//int icar;


 if(argc<5)
   { format_entree();
     exit(0);
   }

//icar= '/';

printf("Fonction Solene : extrait_noface\n");

 s_dir=(char *)getenv("PWD");

// Lit fichier.cir � traiter
 compose_nom_complet(buf,s_dir,argv[1],"cir");
 if((fsource = fopen(buf, "r"))==NULL)
	{ printf("\n impossible ouvrir %s\n",buf);
	  exit(0);
    }
printf("geometrie IN  = %s\n",buf);

// Lit Si extrait par s�lection ou suppression
 sscanf(argv[2],"%c",&mode);
 if(mode=='+')printf("extrait par s�lection\n");
 else if(mode=='-')printf("extrait par supression\n");
 else format_entree(); 

// Ouvre fichier.cir r�sultat
 compose_nom_complet(buf,s_dir,argv[3],"cir");
 if((fdest = fopen(buf, "w"))==NULL)
	{ printf("\n impossible creer %s\n",buf);
	  exit(0);
    }
printf("geometrie OUT = %s\n",buf);

// Lit No des faces � extraire
   nb_extract= argc-4;
   printf("nb de choix d'extraction: %d\n",nb_extract);
   j=0;
       for(i=4;i<argc;i++)
		{  	 
	      // cherche si Un no de face
		  // ou si De no de face A no de face
		   // cherche dans ch�ine si /
		   if(strchr(argv[i],'/'))
		   { sscanf(argv[i],"%d%c%d",nodeb+j,&c,nofin+j);
			 printf("faces de %6d � %6d\n",nodeb[j],nofin[j]);
		   }
		   else
		   {
		     sscanf(argv[i],"%d",nodeb+j);
			 printf("face     %6d\n",nodeb[j]);
			 nofin[j]=nodeb[j];
		   }
		   j++;
		}

	//for(j=0;j<nb_extract;j++) printf("de %d � %d\n",nodeb[j],nofin[j]);

// Initialisation

   lit_en_tete(fsource,&nbfac1,&nomax1,englob);
   // alloue une face
   fac1=alloue_face(1,1000);
   nb=0; nomax=0;
   ecrit_en_tete(fdest,nb,nomax,englob);

// Traite l'extraction des faces  
 nb=0;

 for(i=0;i<nbfac1;i++)
  {
    lit_fic_cir3d(fsource,1,fac1); 
    //printf("   face %d \n",fac1->nofac_fichier);
    // test si no de face dans liste d'extraction
	dans=0;
    for(k=0;k<nb_extract;k++)
    { if(fac1->nofac_fichier >= nodeb[k] && fac1->nofac_fichier <= nofin[k]) //face dans la s�lection
		{ dans=1;
		  if(mode=='+') // �crit la face s�lectionn�e
			{	printf("     �crit face selectionn�e %d\n",fac1->nofac_fichier);
				output_face_sur_fichier(fac1,1,1,0,fdest,&nb,&nomax);
			}
		  break;
		}
    }
	// face pas dans la s�lection
	if(dans==0 && mode=='-') // �crit la face car elle n'est pas � supprimer
			{	printf("     �crit face non supprim�e %d\n",fac1->nofac_fichier);
				output_face_sur_fichier(fac1,1,1,0,fdest,&nb,&nomax);
			}
   
    desalloue_contour_face(fac1);
  }

 // Termine
  desalloue_fface(fac1,1);
  fclose(fsource);

  rewind(fdest);
  ecrit_en_tete(fdest,nb,nomax,englob);
  printf("nombre de faces retenues : %d\n",nb);
  fclose(fdest);

  printf("Fin : extrait_noface\n");
  creer_OK_Solene();

 }


/*________________________________________________________________________*/
void format_entree()
{
  printf("\n extrait_noface  \n\n");
  printf("\t   param�tres de la fonction \n\n");
  printf("\t IN		fichier_in(.cir) \n");
  printf("\t IN		+ ou - (par selection, par suprression) \n");
  printf("\t OUT		fichier_out(.cir) \n");
  printf("\t IN		de_no-de-face-�-extraire[/�_no-de-face-�-extraire] \n");
  printf("\t[IN]		[de_no-de-face-�-extraire[/�_no-de-face-�-extraire]]   // optionnel \n");
  printf("\t[IN]		[de_no-de-face-�-extraire[/�_no-de-face-�-extraire]]   // optionnel \n");
  printf("\t[IN]		...												       // optionnel \n");

  exit(0);
}






/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */
 
/***** surface_ensol_vue.c *************/
/**** pour these D. Follut ****/
/*** M.J. Antoine, CERMA, 1999 ***/

/*   Rappel ligne de compilation */

/* cc surface_ensol_vue.c  ./UTILS/solutile.o ./UTILS/geomutile.o ./UTILS/lib_solene_94.o -o surface_ensol_vue -lm */
   
 
/* Fichiers inclus */
#include<solene.h>
#include<ctype.h>
//#include<unistd.h>


void usage();
int info_faces_contours();
int sauve_tableau();
void lect_fichier();
void lect_ff_param();
void traitement_surfaces_ensol();

FILE *pfacvis;

main(argc,argv)           
int argc;
char **argv;
{ 
char *dir_courant;

char nom_descr_obs_in[256];
/* fichier de descripteurs lu pour observateurs */
double *descr_obs_in;
int nb_contour_obs;
int nbfac_obs, nomax_obs;
int no_contour_obs;
int *nb_cont_face_obs, *numero_face_obs;
double min_obs, max_obs;


char nom_fvis[256];
/* fichier (lu) pour facteurs de visibilite */
float *ligne_fvis;
/* valeurs */


char nom_surfaces_test[256];
/* fichier (lu) pour descripteur du fichier test (surfaces) */
double *surfaces_test;
/* valeurs */
char nom_sol_test[256];
/* fichier (lu) pour descripteur du fichier test (flux solaires incidents) */
double *sol_test;
/* valeurs */
int nb_contour_test;
int nbfac_test, nomax_test;
int no_contour_test;
int *nb_cont_face_test, *numero_face_test;
double min_test, max_test;

FILE *pfic_descr;

char nom_surfaces_ensol_vues[256];
/* fichier (cree) pour descripteur fichier observateur */
double *surfaces_ensol_vues;
/* valeurs */
double seuil_sol;
/* seuil sur flux incident pour considerer qu'une surface est ensoleillee */

/* Autres */
double mini, maxi; char c;
int ind_fac, ind_cont, compteur;
int OK_sauv=0;
double *auxiliaire;

/*** Lecture des parametres de la commande ***/

dir_courant=(char *)getenv("PWD");

if (argc<6)usage();

compose_nom_complet(nom_descr_obs_in,dir_courant,argv[1],"val");
printf("Fichier de descripteur observateur (entree): %s \n", nom_descr_obs_in);

compose_nom_complet(nom_fvis,dir_courant,argv[2],"vis");
printf("Facteurs de visibilite : %s \n", nom_fvis);

compose_nom_complet(nom_surfaces_test,dir_courant,argv[3],"val");
printf("Surfaces du fichier test: %s \n", nom_surfaces_test);

compose_nom_complet(nom_sol_test,dir_courant,argv[4],"val");
printf("Flux solaires incidents du fichier test: %s \n", nom_sol_test);

compose_nom_complet(nom_surfaces_ensol_vues,dir_courant,argv[5],"val");
printf("Surfaces vues par fichier observateur (resultat): %s \n", nom_surfaces_ensol_vues);

/*** Ouverture des fichiers ***/

	/* Lecture d'un fichier .val pour infos fichier observateur*/
	

if ((pfic_descr=fopen(nom_descr_obs_in,"r"))==NULL)
            	{ 
		printf("\n  *** impossible ouvrir %s ***\n\n", nom_descr_obs_in); 
		goto fin;
            	}
fscanf(pfic_descr,"%d %d %lf %lf",&nbfac_obs,&nomax_obs,&min_obs,&max_obs);

numero_face_obs=(int *)malloc(nbfac_obs*sizeof(int));
if (numero_face_obs==NULL)
	{printf("Probleme d'allocation numero face (descripteur observateur), arret.\n\n");
	 exit(0);}
nb_cont_face_obs=(int *)malloc(nbfac_obs*sizeof(int));
if (nb_cont_face_obs==NULL)
	{printf("Probleme d'allocation nombre contours par face (descripteur observateur), arret.\n\n");
	 exit(0);}
fclose(pfic_descr);

nb_contour_obs = info_faces_contours(pfic_descr, nom_descr_obs_in, nbfac_obs, numero_face_obs, nb_cont_face_obs);
printf("Nombre de contours du fichier observateur: %d\n", nb_contour_obs);


surfaces_ensol_vues = (double*)malloc(nb_contour_obs*sizeof(double));
if (surfaces_ensol_vues==NULL)
	{printf("Probleme allocation descripteurs fichier observateur, abandon.\n");
	 exit(0);}

	/* Ouverture fichier de facteurs de visibilite */

if((pfacvis=fopen(nom_fvis,"rb"))==NULL)
		{
           	printf("\n impossible ouvrir %s\n",nom_fvis); 
		exit(0);
		}

	/* Ouverture descripteurs du fichier test */

nb_contour_test=0;
if ((pfic_descr=fopen(nom_surfaces_test,"r"))==NULL)
            	{ 
		printf("\n  *** impossible ouvrir %s ***\n\n", nom_surfaces_test); 
		goto fin;
            	}
fscanf(pfic_descr,"%d %d %lf %lf",&nbfac_test,&nomax_test,&min_test,&max_test);	
numero_face_test=(int *)malloc(nbfac_test*sizeof(int));
if (numero_face_test==NULL)
	{printf("Probleme d'allocation numero face (descripteur test), arret.\n\n");
	 exit(0);}
nb_cont_face_test=(int *)malloc(nbfac_test*sizeof(int));
if (nb_cont_face_test==NULL)
	{printf("Probleme d'allocation nombre contours par face (descripteur test), arret.\n\n");
	 exit(0);}

nb_contour_test = info_faces_contours(pfic_descr, nom_surfaces_test, nbfac_test, numero_face_test, nb_cont_face_test);
printf("Nombre de contours du fichier test: %d\n", nb_contour_test);

surfaces_test = (double*)malloc(nb_contour_test*sizeof(double));
if (surfaces_test==NULL)
	{printf("Probleme allocation descripteurs fichier-test (surfaces), abandon.\n");
	 exit(0);}

pfic_descr=fopen(nom_surfaces_test, "r");	
lect_fichier(pfic_descr, nbfac_test, nomax_test, surfaces_test);
fclose(pfic_descr);

sol_test = (double*)malloc(nb_contour_test*sizeof(double));
if (sol_test==NULL)
	{printf("Probleme allocation descripteurs fichier-test (flux solaires incidents), abandon.\n");
	 exit(0);}

if ((pfic_descr=fopen(nom_sol_test,"r"))==NULL)
            	{ 
		printf("\n  *** impossible ouvrir %s ***\n\n", nom_sol_test); 
		goto fin;
            	}

lect_fichier(pfic_descr, nbfac_test, nomax_test, sol_test);
fclose(pfic_descr);


/* Allocation 1 ligne de facteurs de visibilite */
ligne_fvis =(float *) malloc(nb_contour_test*sizeof(float));
if (ligne_fvis == NULL)
	{printf("\n*** Probleme d'allocation facteurs de visibilite.\n");
	exit(0);}


/******************************************************************/
/* Traitement en combinant descripteurs et facteurs de visibilite */
/******************************************************************/

seuil_sol = 0.0; /* Seuil strict pour considerer qu'une surface est ensoleillee */
		/* ici, bon pour flux solaire incident direct */
traitement_surfaces_ensol(nb_contour_obs, pfacvis, ligne_fvis, nb_contour_test, surfaces_test, seuil_sol, sol_test, surfaces_ensol_vues);	


/*** Sauvegarde fichier descripteurs resultat ***/

OK_sauv = sauve_tableau(pfic_descr, nom_surfaces_ensol_vues, nbfac_obs, nomax_obs, nb_contour_obs, numero_face_obs, nb_cont_face_obs,
0.0, surfaces_ensol_vues);


free(numero_face_obs);
free(nb_cont_face_obs);
free(numero_face_test);
free(nb_cont_face_test);
free(ligne_fvis);
free(surfaces_ensol_vues);
free(surfaces_test);
free(sol_test);
fclose(pfacvis);

fin:;
}

/*_____________________________________________________________________*/
void usage()
{printf(" *surface_ensol_vue* descripteur-observateur(.val) fichier_visibilite(.vis) \n");
 printf("  surfaces-test(.val) flux_solaire_incident-test(.val) surfaces-ensoleillees-vues-par-observateur(.val) \n\n");
 
 exit(0);
}

/*_____________________________________________________________________*/
int info_faces_contours(pfic, nom, nbfac, numero_face, nb_cont_face)
FILE *pfic;
char nom[256];
int nbfac;
int *numero_face;
int *nb_cont_face;
{
/* LECTURE D'UN FICHIER nom.val POUR DETERMINER NBRE DE CONTOURS TOTAL */
/* - remplit les tableaux de numeros de faces et nombre de contours par face */
/* Remarque: le nombre de faces doit deja avoir ete lu dans le fichier, */
/* on doit proceder en deux temps */
	
int nb_contour_total=0;
int nbf, nomx;
int numero, nb_contours;
int f, ct;
double val_min, val_max;
char c;
double *auxiliaire;

nbf=0;
nomx=0;
val_min=0.0;
val_max=0.0;

if ((pfic=fopen(nom,"r"))==NULL)
            	{ 
		printf("\n  compte contours: impossible ouvrir %s\n\n", nom); 
		exit(0);
            	}
fscanf(pfic,"%d %d %lf %lf",&nbf,&nomx,&val_min,&val_max);

for(f=0;f<nbfac;f++)
		{
		fscanf(pfic,"\n%c%d%d\n",&c,&numero,&nb_contours);
		numero_face[f] = numero;
		nb_cont_face[f] = nb_contours;
		nb_contour_total+=nb_cont_face[f];
		auxiliaire=(double *)malloc(nb_cont_face[f]*sizeof(double));
		for(ct=0;ct<nb_cont_face[f];ct++)
			fscanf(pfic,"%lf\n",auxiliaire+ct);
		free(auxiliaire);
		}
fclose(pfic);

return nb_contour_total;

}


/*______________________________________________________________________________________*/
int sauve_tableau(pf, nom_fichier, nbfac, nomax, nb_contour_total, numero_face, nb_cont_face, decalage, tab)
/* Sauvegarde d'un tableau de valeurs (descripteurs) associees a un fichier de faces et contours */
/* avec eventuellement un decalage (utile pour conversion Kelvin->Celsius) */
FILE *pf;
char *nom_fichier;
int nbfac;
int nomax;
int *numero_face;
int *nb_cont_face;
double decalage;
double *tab;
{ 
double mini, maxi;
int i, k, num;
int sauvOK = 1;

if ((pf= fopen(nom_fichier,"w"))==NULL)
	sauvOK = 0;
else
	{mini=maxi=tab[0]-decalage;
	for(i=0;i<nb_contour_total;i++)
		{
		if(tab[i]-decalage<mini) mini=tab[i]-decalage;
		if(tab[i]-decalage>maxi) maxi=tab[i]-decalage;
		} 

	fprintf (pf,"%5d %5d %8.3lf %8.3lf\n", nbfac, nomax, mini, maxi);   

	num=0;
	for(i=0;i<nbfac;i++)
		{
		fprintf (pf,"f%d %d\n",numero_face[i],nb_cont_face[i]);
		for(k=0;k<nb_cont_face[i];k++)
			{
			fprintf (pf,"    %8.3f\n",tab[num]-decalage);
			num++;
			}
		}
	fclose(pf);
	}
return sauvOK;

}	


/*_____________________________________________________________________*/
void traitement_surfaces_ensol(nb_contour_obs, pfacvis, ligne_fvis, nb_contour_test, surfaces_test, seuil_sol, sol_test, surfaces_ensol_vues)
int nb_contour_obs;
FILE *pfacvis;
float *ligne_fvis;
int nb_contour_test;
double *surfaces_test;
double seuil_sol;
double *sol_test;
double *surfaces_ensol_vues;
{/*** Exploite les fichiers de facteur de visibilite (represente par le pointeur pfacvis) */
/* et de descripteur du fichier-test (tableau surfaces_test) pour fournir un descripteur sur */
/* fichier observateur (tableau surfaces_ensol_vues) ***/

int no_contour_obs, no_contour_test;
double test_ensol;

for (no_contour_obs=0;no_contour_obs<nb_contour_obs;no_contour_obs++)

	{/* printf("Traitement contour %d\n", no_contour_obs); */
	 lect_ff_param(pfacvis, ligne_fvis, nb_contour_test, no_contour_obs, -1); 
	 surfaces_ensol_vues[no_contour_obs] = 0.0;
	 
	 for (no_contour_test=0;no_contour_test<nb_contour_test;no_contour_test++)
		{test_ensol = 0.0;
	 	if (sol_test[no_contour_test] > seuil_sol)
	 		test_ensol = 1.0;
		surfaces_ensol_vues[no_contour_obs]+=ligne_fvis[no_contour_test]*test_ensol*surfaces_test[no_contour_test];
		}

	 /* printf("Resultat traitement: %lf\n\n", surfaces_ensol_vues[no_contour_obs]); */
	}
}



/*_________________________________________________________________*/
/* Lecture fichier au "bon" format (.val) et remplissage tableau 'valeur' */
void lect_fichier(pfic, nbfac, nomax, valeur)
FILE *pfic;
int nbfac;
int nomax;
double *valeur;
{ double val_min;
  double val_max;
  int num_cont, num_face, num_cont_liste;
  int nofac, nbcont_face;
  char c;

  fscanf(pfic,"%d %d %lf %lf",&nbfac,&nomax,&val_min,&val_max);
  num_cont_liste = 0;
  for(num_face=0;num_face<nbfac;num_face++)
	{
	fscanf(pfic,"\n%c%d%d\n",&c,&nofac,&nbcont_face);
	for(num_cont=0;num_cont<nbcont_face;num_cont++)	
		{	
		fscanf(pfic,"%lf\n",valeur+num_cont_liste);
		num_cont_liste++;
		}
	}
}



/*_____________________________________________________________________*/
/* Lecture des facteurs de visibilite dans fichier */

void lect_ff_param(pff, ligne_ff, nb_contour, i, j)
FILE *pff;
float *ligne_ff;
int nb_contour;
int i; /* Ligne */
int j; /* colonne */
/* Lit une ligne specifiee dans un fichier de facteurs */
/* arranges en Fij , i et j variant de 0 a nb_contour-1 */
/* si j positif, donne la seule valeur Fij */
/* sinon donne toute la ligne i */
{int f;
fseek(pff,(i*nb_contour)*sizeof(float),SEEK_SET);
fread(ligne_ff, sizeof(float), nb_contour, pff);

/* if (j<0)
	{printf("Ligne %d ", i+1);
	for (f=0;f<nb_contour;f++)
		printf(" %f ", ligne_ff[f]);
	printf("\n"); 
	}
else
	{printf("Valeur F de %d vers %d: %f\n", i+1,j+1,ligne_ff[j]); 
	}
*/

}


/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */
 
/*

cc axono.c solutile.o geomutile.o lib_solene_94.o traite.o poly_op_poly.o face_op_face.o -o axono -lm

*/

/*
Realise une axono des faces et ne retient que les parties visibles dans la vue

*/
#include<solene.h>
#include<ctype.h>
#include<time.h>


extern double coef_discol;

/*_________________________________________________________________*/
main(argc,argv)                         /* AXONO */
int argc;char **argv;
{int i;
 char c[2];
 char buf[512],nom_out[512],*s_dir;
double x,y,z;

   singularite=0; non_singularite=0; nb_etat=0;
   normale_orientee=1; traitement_faces_cachees=1;
   pb_masque=0; colle_max=coef_discol*DISCOL;

         obs.xo=0; obs.yo=0; obs.zo=0;

	s_dir="";//(char *)getenv("PWD");

         if(argc<6)format_entree_axono();
         printf("\n CALCUL D'UNE VUE AXONOMETRIQUE  \n");

		 sprintf(buf,"%s.cir",argv[1]);
//         compose_nom_complet(buf,s_dir,argv[1],"cir");
         if((fp=fopen(buf,"r"))==NULL)
            { printf("\n impossible ouvrir %s\n",buf); exit(0);}

  	 sscanf(argv[2],"%lf",&(obs.x));
         sscanf(argv[3],"%lf",&(obs.y));
         sscanf(argv[4],"%lf",&(obs.z));

	 sprintf(nom_out,"%s.cir",argv[5]);
       //  compose_nom_complet(nom_out,s_dir,argv[5],"cir");

         printf(" fichier a traiter %s \n",buf);
         printf(" observateur %lf %lf %lf \n",obs.x,obs.y,obs.z);
         /*printf(" nom du fichier de sortie %s \n",argv[5]);*/
         for(i=6;i<argc;i++)
            { sscanf(argv[i],"%c%c",c,c+1);
              if(*c!='-')format_entree_axono();
              if(*(c+1)=='n') normale_orientee=0;
	      else if(*(c+1)=='t') traitement_faces_cachees=0;
              else format_entree_axono();
            }

	 tranfo();
	 traite_heliodon_axono(nom_out);

	creer_OK_Solene();
	printf("\n\nFin du Traitement AXONO\n");

/* liste_des_pointeurs(); */
}	
/*_________________________________________________________________*/
format_entree_axono()
{
  printf("\n   *axono* fichier_in(.cir) xobs yobs zobs fichier_out(.cir) [-n] [-t]\n\n");
  exit(0);
}
/*____________________________________________________________________*/
/*____________________________________________________________________*/
/*      TRAITE_HELIODON_AXONO                   		      */
/*____________________________________________________________________*/
/*____________________________________________________________________*/

/*_________________________________________________________________*/
int traite_heliodon_axono(nom_out)
char *nom_out;
{FILE *fcop;
 int i,nbf,nbfac1,numax,nomax,vu;
 struct modelisation_face *fac1;
 double englob[10];

 clock_t t1,t2;
 double t;

       lit_en_tete(fp,&nbfac1,&numax,englob);
       fac1=alloue_face(nbfac1,34);
       lit_fic_cir3d(fp,nbfac1,fac1);
       init_fenetre_affichage();

       if(normale_orientee) printf(" VISIBILITE par normale\n");
//t1=clock();
       for(i=0;i<nbfac1;i++)
           {  if(normale_orientee==0) vu=1;
              else vu=visible_axono(fac1+i);
              if(vu && traitement_faces_cachees==0)
                { copie_face_projete(fac1+i,1,fac1+i,0);
                }
              else if(vu)
	        { tran_face(fac1+i,1,fac1+i,0);
	          tran_normale((fac1+i)->vnorm);
                }
	   }
//t2=clock();
//t=(t2-t1)/CLOCKS_PER_SEC;
//printf("temps = %lf\n",t);

       if(traitement_faces_cachees)
         { cal_fen_aff();
           printf(" NORMALISE\n");
           for(i=0;i<nbfac1;i++)
	      { normalise_face(fac1+i,0);
	      }
           printf(" COPIE\n");
           for(i=0;i<nbfac1;i++)
	      {	copie_face_projete(fac1+i,0,fac1+i,1);
              }
           printf(" TRAITE VU/CACHE ... \n");
           traite_moins(fac1,nbfac1);
           printf(" fin\n");
           for(i=0;i<nbfac1;i++)
	      {denormalise_face(fac1+i,0);
	       tran_face_inverse(fac1+i,0);
               tran_normale_inverse(fac1[i].vnorm);
	      }
	 }
     
         /* stocke resultat */
      printf(" STOCKE RESULTAT dans %s\n\n",nom_out);
      fcop=fopen(nom_out,"w");
      nbf=0;  nomax=0;
      ecrit_en_tete(fcop,nbf,nomax,englob);
      output_face_sur_fichier(fac1,nbfac1,0,0,fcop,&nbf,&nomax);
      rewind(fcop);
       ecrit_en_tete(fcop,nbf,nomax,englob);
       fclose(fcop); fclose(fp);
       desalloue_fface(fac1,nbfac1);
}

/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */
 
/* 
cc -o attribue_val_appartenance  attribue_val_appartenance.c solutile.o geomutile.o lib_solene_94.o -lm
*/

// D.GROLEAU juin 2002

/*transmet les valeurs du fichier val1 aux fichier val2 
en fonction d'un descripteur d'appartenance */

#include <solene.h>



// DECLARE FUNCTIONS

void fac_val();
void format_entree();
void lit_et_transmet();

/*_______________________________________*/
/*declaration application */

FILE *fpval1,*fpval2;


double 	valeur1,valeur2;
#define LIMIT 100000
double val[LIMIT];

/************************************************/
main(argc,argv)
int argc;char **argv;
{
 char buf[512],*s_dir;

  if(argc!=4){ format_entree(); exit(0);}


	s_dir=(char *)getenv("PWD");

 printf("\n\nCommande:  attribue_val_appartenance\n\n");

 compose_nom_complet(buf,s_dir,argv[1],"val");
  if((fpval1=fopen(buf,"r"))==NULL)
	{ printf("impossible ouvrir %s\n",buf);
	  exit(0);
	}
	
	 fac_val();
	 fclose(fpval1);
	 printf(" valeurs � transmettre : %s\n",buf);

 compose_nom_complet(buf,s_dir,argv[2],"val");
  if((fpval1=fopen(buf,"r"))==NULL)
	{ printf("impossible ouvrir %s\n",buf);
	  exit(0);
	}
	 printf(" valeurs d'appartenance : %s\n",buf);

 compose_nom_complet(buf,s_dir,argv[3 ],"val");
  if((fpval2=fopen(buf,"w"))==NULL)
	{ printf("impossible ouvrir %s\n",buf);
	  exit(0);
	}
	
	 printf(" valeurs transmises dans : %s\n",buf);


	lit_et_transmet();
 

 creer_OK_Solene();

 printf("\n\nFin du Traitement attribue_val_appartenance\n");

}

/*------------------------------------------------------------*/
void fac_val()
{
 int 	i,j,nbfac1,nomax1,nofac,nbcontour;
 double valor;
 char c;

   fscanf(fpval1,"%d %d %lf %lf",&nbfac1,&nomax1,&valeur1,&valeur2);

   if(nomax1>LIMIT) { printf (" PB de dimension \n"); exit(0); }
   for(i=0;i<=nomax1;i++) val[i]=-999999.999;

	for(i=0;i<nbfac1;i++)
	 { 
	   fscanf(fpval1,"\n%c %d %d ",&c,&nofac,&nbcontour); 

	   for(j=0;j<nbcontour;j++)
             {  fscanf(fpval1,"%lf",&valor);
                if(j==0)  val[nofac]=valor;
             }

         }
}

/*------------------------------------------------------------*/
void lit_et_transmet()
{
 int 	i,j,nbcontour,nbfac,nomax,nofac,no;
 double  valor;
 char c;

   fscanf(fpval1,"%d %d %f %f",&nbfac,&nomax,&valor,&valor);
   fprintf(fpval2,"%7d %7d %15.3f %15.3f\n",nbfac,nomax,valeur1,valeur2);

	for(i=0;i<nbfac;i++)
	 { 
	   fscanf(fpval1,"\n%c %d %d ",&c,&nofac,&nbcontour); 
	   fprintf(fpval2,"f%d %d\n",nofac,nbcontour);


	   for(j=0;j<nbcontour;j++) 
             { fscanf(fpval1,"%lf",&valor);
               no=(int) valor;
               if(val[no]==-999999.999)
                 { printf("  contour %d de face %d (de val2) n'a pas d'appartenance dans val1 (met val= 0)\n",j+1,nofac);
	           fprintf(fpval2,"   0.0\n");
                 }

               else fprintf(fpval2,"%15.6f\n",val[no]);
             }
         }
}

/*------------------------------------------------------------*/
void format_entree()
{
  printf("\n   attribue_val_appartenance  fichier_in1(.val)  fichier_in2(.val) fichier_out(.val)  \n\n");
  printf("\n Transmet les valeurs du 1er contour de fichier_in1.val dans fichier out.val\n");
  printf(" suivant les valeurs d'appartenance et la structure de fichier_in2.val \n\n");

}

/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

// FONCTION : "transitoire_h_option2_c"

// D. Groleau  juillet 2005
// modif de transitoire_option_1_c pour J. Bouyer 2005

// date et latitude pour �valuer heure de lever et de coucher 
// du soleil et g�n�rer des noms de flus_solaires_nuls la nuit)
						
// constitue un fichier .bat contenant des appels successifs � transitoire_h_option2

// on precise le nb de periodes, l'heure de d�but et l'heure de fin,
// les noms reels et gen�riques (pour ceux fonction du temps) des fichiers
// n�cessaire a l'execution de la commande transitoire_h_option 

// ATTENTION : en dur dans le code Tint: constant 
//			   � modifier si Tint fonction du temps



// PREAMBULE -------------------------------------------------------------------------------

// Fichiers inclus
#include<solene.h>


// Procedures auxiliaires
int lit_fic_meteo();
float lit_val_meteo();
void met_extension_heure();
void met_extension_per();
void usage();


// en GLOBAL
#define HMAX 4096	// donnees meteo entrees par pas de 5 minutes au maximum


// PROGRAMME PRINCIPAL ------------------------------------------------------------

main(argc,argv)           
int argc;
char **argv;

{

// DECLARATIONS DES VARIABLES --------------------------------------------------------------

int		nb_periode, temps;
char	*s_dir, c, nom_meteo[256], nom_com[256], s_per[12], s_heure[12], s_i[12], s_i_1[12],buf[256];
float	tmeteo, tflux_atm, ttoto;

int		nb_val_meteo;		// pour lecture et gestion donnees f(tps)
int		meteo_temps[HMAX];
float	meteo_temp[HMAX];

int		nb_val_flux_atm;
int		flux_atm_temps[HMAX];
float	flux_atm[HMAX];

int		nb_val_toto;
int		toto_temps[HMAX];
float	toto[HMAX];

int		i, hh1, hh2, minute, pas;


// modif juin 2005
int		nojour,nomois;
double	lati;
double	xyzsol[3],a,h;
float	xh_heure;
int		h_heure, m_minute;
int id;
/* Pointeur de fichier pour lecture descripteurs */
FILE *pfic,*pfbat;
char nom_GEN[32];


/* LES PARAMATRES EN ARGUMENT "argv"

1	Nombre_de_periodes � simuler (au moins 1)
2	Heure:Minute du d�but 
3	Heure :Minute de fin
4	Tmeteo(.txt) � chaque pas de temps (sinon interpole entre les valeurs pr�sentes)
5       #	nom_Tint
6       	nom_Tfix
7      #nom_flux_solaire_incident 
8	nom_albedo
9	nom_emissivite
10	nom_noparoi 
11	nom_hc
12	nom_hint
13	nom_surfaces
14	nom_fac_forme 
15	nom_fac_forme_ciel
16	pas_de_temps (en secondes)
17	nom_fic_paroi
18     **	nom_info_resultat (OUT)
19	nom_du_fichier_de_commande_a_cr�er (OUT)

20  calcul_flux_net (d�faut=1 oui; sinon =0 signifie que les flux solaires incidents en input sont les flux solaires nets absorb�s)
21	flux_atmosphere(.txt) (si present ; lit les valeurs du flux atmospherique � chaque pas de temps)
22	jour/mois
23	latitude

24	nom_fichier_option_calcul
25	nom_fichier_option_resultats
									
26 (et plus) autres param�tres � ajouter si n�cessaire

*/



// DEBUT PROGRAMME PRINCIPAL --------------------------------------------------------------------------------


printf("Fonction :  transitoire_h_option2_c\n\n");

s_dir=(char *)getenv("PWD");
 
printf("nb arg = %d\n", argc);

if (argc !=26) usage(); 
//if (argc !=29) usage();  // avec ajout de param�tres suppl�mantaires


// ***** Lecture conditions de simulation *****

sscanf(argv[1], "%d", &nb_periode);
printf("nb_periode : %d\n", nb_periode);

	//  heures debut et fin 
         sscanf(argv[2],"%d%c%d",&hh1,&c,&minute);
         hh1=hh1*60+minute;
         sscanf(argv[3],"%d%c%d",&hh2,&c,&minute); 
         hh2=hh2*60+minute;
	// lit pas de temps en secondes
         sscanf(argv[16],"%d",&pas); 
		 pas = pas/60;
		 printf("debut %d fin %d pas (minutes) %d\n",hh1,hh2,pas);

// OPEN fichier OPTION RESULTATS pour lire nom CAS GENERIQUE en Prefixe de TSE TN1 et TN2
compose_nom_complet(buf,s_dir,argv[25],"txt");
printf("Fichier_Options de Resultats dans : %s \n", buf);
if ((pfic=fopen(buf,"r"))==NULL)
	{printf("\n  impossible ouvrir %s\n\n", buf); 
	 exit(0);
	}
id=fscanf(pfic,"%s %s ", buf,nom_GEN);
	  if(id==EOF) 
	  {printf("Erreur: nombre de lignes du fichier 0 \n");
	   exit(0);
	  }

fclose(pfic);
// Open et lit fichier meteo Tair
compose_nom_complet(nom_meteo,s_dir,argv[4],"txt");
printf("Fichier Meteo Tair : %s \n", nom_meteo);
if ((pfic=fopen(nom_meteo,"r"))==NULL)
	{printf("\n  impossible ouvrir %s\n\n", nom_meteo); 
	 exit(0);
	}
nb_val_meteo = lit_fic_meteo(pfic,meteo_temps, meteo_temp);
fclose(pfic);

// Open et lit fichier meteo Flux Atmospherique
 compose_nom_complet(nom_meteo,s_dir,argv[21],"txt");
 printf("Fichier Meteo Flux_Atmospherique : %s \n", nom_meteo);
 if ((pfic=fopen(nom_meteo,"r"))==NULL)
	{printf("\n  impossible ouvrir %s\n\n", nom_meteo); 
	 exit(0);
	}
 nb_val_flux_atm = lit_fic_meteo(pfic,flux_atm_temps, flux_atm);
 fclose(pfic);

 /*
// Open et lit fichier TOTO
 compose_nom_complet(nom_meteo,s_dir,argv[28],"txt");
 printf("Fichier TOTO : %s \n", nom_meteo);
 if ((pfic=fopen(nom_meteo,"r"))==NULL)
	{printf("\n  impossible ouvrir %s\n\n", nom_meteo); 
	 exit;
	}
 nb_val_toto = lit_fic_meteo(pfic,toto_temps, toto);
 fclose(pfic);
*/


// INFO SOLAIRE: jour latitude
 		 sscanf(argv[22],"%d%c%d",&nojour,&c,&nomois);
         if(c!='/')usage();
         printf("\n jour = %d mois = %d ",nojour,nomois);

         sscanf(argv[23],"%lf",&(lati));
         printf("\n latitude = %5.2lf\n",lati);

// open fichier de commande .bat
compose_nom_complet(nom_com,s_dir,argv[19],"bat");
printf("nom_du_fichier_de_commande_a_creer : %s \n", nom_com);
if ((pfbat=fopen(nom_com,"w"))==NULL)
	{printf("\n  impossible ouvrir %s\n\n", nom_com); 
	 exit(0);
	}

// boucle sur la periode et le nombre d'heures
// raisonne en minutes
if(hh1 == hh2) nb_periode = 1;

for (i =1; i <= nb_periode ; i++)
{ 
  printf("periode %d\n",i);
  temps= hh1;
  rewind(pfic);
	while (temps >= hh1 && temps <= hh2)
	{
      printf(" temps %10d",temps);

         // cherche info soleil
		if(temps<0) temps = 24*60+temps;
		xh_heure= (float)temps/60;
		h_heure= (int) xh_heure;
		m_minute= temps-h_heure*60;
		printf(" heure_minute %2d H %2d",h_heure,m_minute);
		h_heure= h_heure%24;
		printf(" ( %2d H %2d)",h_heure,m_minute);

		info_solaire(lati,nojour,nomois,h_heure,m_minute,xyzsol,&a,&h);
        if( angdeg(h)<3) printf(" nuit\n"); 
		else printf(" soleil : azimut=%5.2lf hauteur=%5.2lf\n",angdeg(a),angdeg(h));

		// constitue l'indexation des fichiers f(tps)
				// au temps t = heure
		met_extension_per(i,s_per);
		met_extension_heure(temps,s_heure);
		sprintf(s_i,"%s%s",s_per,s_heure);

				// au temps t-1 
		if(temps == hh1 && i>1)
		{ // on recommence une p�riode : t-1 = tfin de periode
			met_extension_per(i-1,s_per);
		    met_extension_heure(hh2,s_heure);
			sprintf(s_i_1,"%s%s",s_per,s_heure);
		}
		else  
		{ //  c'est initialisation du calcul des temp�ratures; on fait heure-1;
			met_extension_per(i,s_per);
		    met_extension_heure(temps-pas,s_heure);
			sprintf(s_i_1,"%s%s",s_per,s_heure);
		}
		// pour les fichiers qui ne varient qu'avec l'heure
		met_extension_heure(temps,s_heure);


		// Lit la temperature et le flux atmospherique � ce temps
		tmeteo = lit_val_meteo(temps,nb_val_meteo,meteo_temps,meteo_temp);
		tflux_atm = lit_val_meteo(temps,nb_val_flux_atm,flux_atm_temps,flux_atm);
		/*
		ttoto = lit_val_meteo(temps,nb_val_toto,toto_temps,toto);
		*/
		// Construction de la commande f(tps)

// Ti constant
		  if(temps==hh1)
		  { fprintf(pfbat,"transitoire_h_option2 %6.2f t_init t_init t_init %s",tmeteo,argv[5]);
		  }
		  else fprintf(pfbat,"transitoire_h_option2 %6.2f %sTse%s %sTn1%s %sTn2%s %s",tmeteo,nom_GEN,s_i_1,nom_GEN,s_i_1,nom_GEN,s_i_1,argv[5]);
//
		  if(angdeg(h)<3) fprintf(pfbat," %s fs_nul %s %s %s",argv[6],argv[8],argv[9],argv[10]);
		  else fprintf(pfbat," %s %s%s %s %s %s",argv[6],argv[7],s_heure,argv[8],argv[9],argv[10]);
		
		  fprintf(pfbat," %s %s %s %s %s %s %s",argv[11],argv[12],argv[13],argv[14],argv[15],argv[16],argv[17]);
		  fprintf(pfbat," %sTse%s %sTn1%s %sTn2%s",nom_GEN,s_i,nom_GEN,s_i,nom_GEN,s_i);			

          fprintf(pfbat," %s",argv[20]);

		  fprintf(pfbat," %5.2f",tflux_atm);
		  // nom fichier options calcul et resultats
		  fprintf(pfbat," %s",argv[24]);
		  fprintf(pfbat," %s",argv[25]);

		  
/*	  
		  // Ajout de nouveaux param�tres � partir de argv[26] ; modifier test nb arguments argc
		  // Julien Bouyer
		  //vitesse d'air cte en m argv[26]
		  fprintf(pfbat," %s",argv[26]);
		  // nom_geometrie  argv[27]
		  fprintf(pfbat," %s",argv[27]);
		  // valeur fonction du temps donn�e dans un fichier f (tps) (analogue � meteo_temp.txt) argv[28]
		  fprintf(pfbat," %5.2f",ttoto);
*/




		  fprintf(pfbat," >%s%s%s.txt\n",nom_GEN,argv[18],s_i);

		  
		temps+=pas;
	}

}

fclose(pfic);
fclose(pfbat);
printf("Fin transitoire_h_option2_c\n");   // Fin

creer_OK_Solene();
		
}


// PROCEDURES --------------------------------------------------------------------------------

void met_extension_heure1 (temps,extension)
int temps;
char *extension;
{  // modele energie diffuse meteo
	float xh_heure;
	int h_heure, m_minute;

	if(temps<0) temps = 24*60+temps;
		xh_heure= (float)temps/60;
		h_heure= (int) xh_heure;
		m_minute= temps-h_heure*60;
		//printf(" heure_minute %d H %d\n",h_heure,m_minute);
		//construit extension pour fichier val heure
		if(h_heure>=10 && m_minute >=10)
		{
		 sprintf(extension,"_%dH%d",h_heure,m_minute);
		}
		else if(h_heure>=10 && m_minute <10)
		{
		 sprintf(extension,"_%dH0%d",h_heure,m_minute);
		} 
		else if(h_heure<10 && m_minute >=10)
		{
		 sprintf(extension,"_0%dH%d",h_heure,m_minute);
		} 
		else if(h_heure <10 && m_minute <10)
		{
		 sprintf(extension,"_0%dH0%d",h_heure,m_minute);
		} 
		//printf("extension %s\n",extension);
}
//_____________________________________________________
void met_extension_per (per,extension)
int per;
char *extension;
{  
		//construit extension pour fichier val periode
		if(per<10)
		{
		 sprintf(extension,"_0%d",per);
		}
		else 
		{
		 sprintf(extension,"_%d",per);
		}

		//printf("extension %s\n",extension);
}

/*------------------------------------------------------------*/
float lit_val_meteo(temps,nb_val_meteo,meteo_temps,meteo_val)

int		temps, nb_val_meteo;
int		*meteo_temps;
float	*meteo_val;
{
int i, ecart_t, delta_t;
float ecart_v, valeur;
// soit trouve la valeur au temps (en minutes) exact, soit interpole entre 2 valeurs encadrant le temps choisi

//printf("lit_val pour %d H %d\n",heure,minute);

	for (i=0;i<nb_val_meteo;i++)
	{
	  
	  if(temps == meteo_temps[i]) return(meteo_val[i]);
	  if(temps < meteo_temps[i])
	  { if (i ==0) return(meteo_val[0]);
	    else
		{ ecart_t = meteo_temps[i] - meteo_temps[i-1];
		  delta_t = temps - meteo_temps[i-1];
		  ecart_v = meteo_val[i] - meteo_val[i-1];
		  valeur = meteo_val[i-1] + (ecart_v * delta_t)/ecart_t;
		  return(valeur);
		}
	  }
	}
	return(meteo_val[nb_val_meteo-1]);
}

/*------------------------------------------------------------*/
int lit_fic_meteo(fp,meteo_temps,meteo_valeur)

FILE	*fp;
int		*meteo_temps;
float	*meteo_valeur;
{
int i,id, hh, mm;
	i=0;
	while(1)
	{ if (i > HMAX)
		{ printf("trop de lignes dans le fichier meteo (max %d)\n\n",HMAX);
		  exit(0);
		}
	  id= fscanf(fp,"%d %d %f", &hh,&mm,meteo_valeur+i);
	  //printf("i =%d %d %d \n",i,hh,mm);
	  if(id==EOF) break;
	  meteo_temps[i]= 60*hh + mm;
	  i++;
	}
	printf("	nombre de lignes lues dans le fichier de meteo : %d\n",i);
	return(i);
}


// -----------------------------------------------------------------------------------------------------------
// la fonction "usage" donne le format de la fonction transitoire_h_option2_c (si erreur utilisateur)

void usage()
	{
  	printf("\n   format d'entree des parametres:\n\n");
  	printf("*transitoire_h_option_c*:\n");
  	printf(" construit un fichier .bat � executer avec des appels successifs � transitoire_h_option\n");
	printf("\t Nombre_de_periodes Heure_de_Debut Heure_de_Fin\n");
	printf("\t Tmeteo(.txt) \n");
	printf("\t **nom_Tsurfext **nom_Tmur/sol1 **nom_Tsol2\n");
	printf("\t #nom_Tref #nom_Tfix nom_sol_mur #nom_flux_solaire_incident\n"); 
	printf("\t nom_albedo nom_emissivite nom_lambda nom_rho nom_cp nom_ep\n");
	printf("\t nom_coef_convectif nom_surfaces nom_fac_forme nom_fac_forme_ciel\n");
	printf("\t **nom_info_resultat\n");
	printf("\t nom_du_fichier_de_commande_a_creer(.bat)\n");
	printf("\t calcul_flux_net\n");
	printf("\t flux_atmosphere(.txt)\n");
	printf("\t jour/mois\n");
	printf("\t latitude\n");
	printf("\t nom_fichier_options_calcul\n");
	printf("\t nom_fichier_options_resultat\n\n");
	printf("\t nom_fichier_options_resultat\n\n");
	printf("\t vitesse_air\n\n");
	printf("\t nom_fichier_geometrie\n\n");
	printf("\t nom_fichier_meteo_toto\n\n");


    printf(" PRECISIONS\n");
	printf("\t Les fichiers fonction du temps sont ceux pr�c�d�s de **\n"); 
	printf("\t Les fichiers fonction du temps seront index�s par le num�ro p�riode et l'heure\n"); 
	printf("\t (ainsi,si fichier a pour nom:  temperature  )\n");
	printf("\t		 (si periode = 2 et heure = 16\n");
	printf("\t		 (le fichier, � ce temps t, aura comme nom : temperature_02_16\n");
 	printf("\t Les fichiers contenant les info de resultats (nom_info_resultat) � chaque pas de temps\n");
	printf("\t seront aussi index�s par le num�ro p�riode et l'heure\n"); 
 	printf("\t Les fichiers pr�c�des de # ne vareint qu'en fonction de l'heure, \n");
	printf("\t ils sont seulement index�s par l'heure  : \n"); 
	printf("\t		 (si periode = 2 et heure = 16\n");
	printf("\t		 (le fichier, � ce temps t, aura comme nom : fluxsolaire_16\n");
 	printf(" Attention, calcul_flux_net =1 flux nets � calculer; si 0 alors les flux incidents donn�s en entr�e sont les flux nets\n");
 	printf(" Attention, si le fichier flux_atmosphere est donn� en entr�e, alors il contient les flux atmospheriques en f(tps)\n");
	exit(0);
	}


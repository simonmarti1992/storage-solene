/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/*

cc fenetre_fic_m.c -o fenetre_fic_m solutile.o geomutile.o face_op_face.o poly_op_poly.o lib_solene_94.o -lm

*/

/*_________________________________________*/
/* DESCRIPTION
 Clip un fichier de faces par un autre.

Les faces du fichier_in sont decoupees par les faces du fichier_fenetre
Le cas des faces vericales est traite a part: la face n'est retenu  que si l'ensemble des points estcontenu dans le contour clip.
*/
//#include</home/ultra5/marenne/newsolene/solene_94.h>
#include<solene.h>
extern int option_calcul_z; 


/*_________________________________________*/
/* declarations */

FILE *fsource,*fdest,*fclip;
int nbfac1,nbfac2;
struct modelisation_face *fac1,*fac2,*fac3,*fac4;
double	englob[10];
#define VERTICAL  0.0001

/*________________________________________________________________________*/
main(argc,argv)
char **argv;
int  argc ;
{
char 	buf[512],*s_dir;
int i,nomax1,nomax2;

 if(argc!=4)
   { format_entree();
     exit(0);
   }

 s_dir=(char *)getenv("PWD");

 compose_nom_complet(buf,s_dir,argv[1],"cir");
 if((fsource = fopen(buf, "r"))==NULL)
	{ printf("\n impossible ouvrir %s\n",buf);
	  exit(0);
        }
 compose_nom_complet(buf,s_dir,argv[2],"cir");
 if((fclip = fopen(buf, "r"))==NULL)
	{ printf("\n impossible ouvrir %s\n",buf);
	  exit(0);
        }

 compose_nom_complet(buf,s_dir,argv[3],"cir");
 if((fdest = fopen(buf, "w"))==NULL)
	{ printf("\n impossible creer %s\n",buf);
	  exit(0);
        }

   lit_en_tete(fclip,&nbfac2,&nomax2,englob);
   fac2=alloue_face(nbfac2,1000);
   lit_fic_cir3d(fclip,nbfac2,fac2); 
   fclose(fclip);

/* fait une copie de l'original pour traitement faces verticales */
   fac4=alloue_face(nbfac2,1000);
   for(i=0;i<nbfac2;i++)
    {
     copie_face(fac2+i,fac4+i);
    }


   lit_en_tete(fsource,&nbfac1,&nomax1,englob);
   fac1=alloue_face(nbfac1,1000);
   lit_fic_cir3d(fsource,nbfac1,fac1); 
   fclose(fsource);

/* fait une copie de l'original pour traitement faces verticales */
   fac3=alloue_face(nbfac1,1000);
   for(i=0;i<nbfac1;i++)
    {
     copie_face(fac1+i,fac3+i);
    }
   init_fenetre_affichage();
   ajuste_face(nbfac1,fac1);
   ajuste_face(nbfac2,fac2);

   // la normalisation calcule aussi le d du plan de la face
   cal_fen_aff();
   for(i=0;i<nbfac1;i++) normalise_face(fac1+i,1);
   for(i=0;i<nbfac2;i++) normalise_face(fac2+i,1);

   ecrit_en_tete(fdest,1,1,englob);



  /* traite union pour chaque face */

  printf(" traitement en cours\n");

  traite_fen_fic();


  desalloue_fface(fac1,nbfac1);
  desalloue_fface(fac2,nbfac2);
  fclose(fdest);


 creer_OK_Solene();
 printf("Fin du traitement fenetre_fic\n");
 }

/*________________________________________________________________________*/
int traite_fen_fic()
{
 int 	i,j,resul,nbf_out,noma_out,in;
 struct modelisation_face 	*face_resultat;
 struct contour *pc;
 struct circuit *pcir;

 face_resultat=alloue_face(1,1010);

 printf("\n traite les faces inclin�es ou horizontales ...\n");
 
  for(i=0;i<nbfac2;i++)
    { /*printf("i=%d\n",i); */

     for(j=0;j<nbfac1;j++)
	  {
		 if(fabs((fac1+j)->vnorm[2]) >= VERTICAL)
		 {
          option_calcul_z=1;
          resul=face1_inter_face2(fac1+j,1,fac2+i,1,face_resultat,0);
	      concatene_fface(face_resultat,0,fac1+j,0);
		 }
	  }

    }

  for(i=0;i<nbfac1;i++)
        denormalise_face(fac1+i,0);

/****************************/
/* traite les faces verticales */

   printf("\n traite les faces verticales ...\n");

   for(j=0;j<nbfac1;j++)
	{ if(fabs((fac3+j)->vnorm[2])< VERTICAL)
           { /* face verticale */
             //printf("Face verticale %d\n", (fac1+j)->nofac_fichier);
                for(i=0;i<nbfac2;i++)
 		  { /* test si en 2D chaque point de fac1 est dans le clip fac2 */
                       pc=(fac3+j)->debut_projete; /* on reprend l'original source */
                       while(pc)
	                 { pcir=pc->debut_support;   /* contour a clipper */
	                   in=face_dans_clip(pcir,fac4+i);
                           if(!in) break;
                           
                              pcir=pc->debut_interieur;
		              while(pcir)
	  	                 { in=face_dans_clip(pcir,fac2+i);
                                   if(!in) break;
                                    
	   	                   pcir=pcir->suc;
                                     
	   	                 }
	                      if(!in) break;
                              pc=pc->suc;
	                  }

                      if(in)
                       { /* retient la face fac1 */
                         copie_face_projete(fac3+j,1,fac1+j,0);
                         break;
                       }
                  }
           }
        } 
  
  nbf_out=0; noma_out=0;
  output_face_sur_fichier(fac1,nbfac1,0,0,fdest,&nbf_out,&noma_out);
  rewind(fdest);
  ecrit_en_tete(fdest,nbf_out,noma_out,englob);
  desalloue_fface(face_resultat,0);

}

/*________________________________________________________________________*/
/*________________________________________________________________________*/
int face_dans_clip(pcir,fac)
struct circuit *pcir;
struct modelisation_face *fac;
{
 int oui,i;
 for(i=0;i<pcir->nbp-1;i++)
  { /*printf("%f %f \n",pcir->x[i],pcir->y[i]);*/
    oui = point_dans_face(pcir->x[i],pcir->y[i],fac,1);
    if(!oui) break;
  }
 return(oui);
}


/*________________________________________________________________________*/
int format_entree()
{
  printf("\n   *fenetre_fic_m*  fichier_in(.cir) fichier_fenetre(.cir) fichier_out(.cir) \n\n");
}

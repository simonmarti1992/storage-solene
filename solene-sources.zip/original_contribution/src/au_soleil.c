/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */
 
/*
cc au_soleil.c  ~marenne/newsolene/solutile.o  ~marenne/newsolene/geomutile.o ~marenne/newsolene/lib_solene_94.o  ~marenne/newsolene/solaire.o -o au_soleil -lm

*/


/* execute_gen_val de SOL_N_SOLARIS */
/* les parametres en entree:

  fichier_in(.cir) 
  fichier_in(.mas)
  jour/mois
  hh1:mn1
  hh2:mn2
  pas(hh:mn)
  calcul_sans_masque(1 oui; 0 non)
        fichier_in(.mas) sans masque
   
    les parametres en sortie , les descripteurs:
   
  au_soleil_
  si calcul_sans_masque
      au_soleil_sans_masque 
  
*/

#include<solene.h>

int test_ensoleille();

/*_________________________________________________________________*/
main(argc,argv) 
int argc;char **argv;

{
FILE *fpcir,*fpmas1,*fpmas2,*fpval;
int sans_masque;
char buf[256],*s_dir,c;
int nojour,nomois,jo,mo,indice_date;
int hh1,hh2,pas,minute;
int nbfac,nomax,nofac,nb_contour,nb_pas,nb_date;
double englob[10];
int *nbc_face,*no_face;
int i,j,k,kk,ind_valeur,h_deb,m_deb,temps,nbcontour,indice;
float x,vmin_gen,vmax_gen;
float *valeur;
struct modelisation_face *fac;

 if(argc<9) { format_entree(); exit(0); }
 sscanf(argv[7],"%d",&(sans_masque));
 if(sans_masque && argc<11) { format_entree(); exit(0); }

//	s_dir=(char *)getenv("PWD");

printf("\nAU_SOLEIL\n\n");


/*lecture des parametres*/

         s_dir="";

		 sprintf(buf,"%s.cir",argv[1]);

         //compose_nom_complet(buf,s_dir,argv[1],"cir");
         if((fpcir=fopen(buf,"r"))==NULL)
            { printf("\n impossible ouvrir %s\n",buf); exit(0);
            }

		 sprintf(buf,"%s.mas",argv[2]);
        // compose_nom_complet(buf,s_dir,argv[2],"mas");
         if((fpmas1=fopen(buf,"r"))==NULL)
            { printf("\n impossible ouvrir %s\n",buf); exit(0);
            }
    if(sans_masque)
      {
		 sprintf(buf,"%s.mas",argv[8]);
 		
		//compose_nom_complet(buf,s_dir,argv[8],"mas");
         if((fpmas2=fopen(buf,"r"))==NULL)
            { printf("\n impossible ouvrir %s\n",buf); exit(0);
            }
      }

  	 sscanf(argv[3],"%d%c%d",&nojour,&c,&nomois);
/*printf("jour mois %d %d\n",nojour,nomois);*/
         sscanf(argv[4],"%d%c%d",&hh1,&c,&minute);
         hh1=hh1*60+minute;
         sscanf(argv[5],"%d%c%d",&hh2,&c,&minute); 
         hh2=hh2*60+minute;
         sscanf(argv[6],"%d%c%d",&pas,&c,&minute);
         pas=pas*60+minute;
/*printf("hh1 hh2 pas %d %d %d\n",hh1,hh2,pas);*/

   /* lecture de geom.cir FACE/FACE */


       lit_en_tete(fpcir,&nbfac,&nomax,englob);

       printf(" Traite %d faces\n",nbfac);
   nbc_face =alloue_int(nbfac,1023);
   no_face =alloue_int(nbfac,1023);
   nb_contour=0;
	/* alloue une seule face */
   fac=alloue_face(1,34);

   for(i=0;i<nbfac;i++)
     { lit_fic_cir3d(fpcir,1,fac);
       no_face[i]=fac->nofac_fichier;
       nbc_face[i]=nb_contour_face(fac,1);
       nb_contour+=nbc_face[i];
       desalloue_contour_face(fac);
     }
   desalloue_fface(fac,1);
    

printf("     soit  %d contours\n\n",nb_contour);




 /* calcul du nombre de pas */
   nb_pas=1;
   i=hh1;
   while(i<hh2)
    { nb_pas++;
      i=i+pas;
    }
/*printf("nb de pas %d\n",nb_pas);*/

 /* allouer nb_contour*nb_de_pas valeurs*/
   valeur=alloue_float(nb_contour*nb_pas,1023);

   for(j=0;j<nb_contour*nb_pas;j++)
	   valeur[j] = 0;

 /* lit en tete des .mas  et determine indice de la bonne date */
     
        fscanf(fpmas1,"%d",&nb_date);
	for(j=0;j<nb_date;j++)
         { fscanf(fpmas1,"%d %d",&jo,&mo);
           if(mo == nomois && jo == nojour) indice_date=j;

         }
        fscanf(fpmas1,"%d %d",&i,&i);
/* printf("indice de la bonne date %d\n", indice_date);*/

    if(sans_masque)
      { 
        fscanf(fpmas2,"%d",&i);
	for(j=0;j<nb_date;j++) fscanf(fpmas2,"%d %d",&i,&i);
        fscanf(fpmas2,"%d %d",&i,&i);
      }



/* examine les contours et determine les valeurs */
/* stocke les valeurs dans valeur contour  apres contour */
/* soit nb_contour*nb_pas valeurs */
/* AVEC_MASQUE */

 /*printf("AVEC_MASQUE\n");*/


     ind_valeur=0;

     for(j=0;j<nbfac;j++)
       { fscanf(fpmas1,"\n%c%d %d",&c,&nofac,&nbcontour);
         /*printf("FACE %d\n",nofac);*/

         for(k=0;k<nbcontour;k++)  
           { /*printf("test contour %d\n",k+1);*/

             /* evalue valeurs en fonction du temps AVEC MASQUE pour chaque contour */

test_ensoleille(nb_pas,pas,nb_date,indice_date,hh1,&ind_valeur,valeur,fpmas1);
/*   
             for(kk=0;kk<nb_pas;kk++)
	       { printf("valeurs : %f\n",valeur[ind_valeur-nb_pas+kk]);
               }
	    printf("ind_valeur %d \n", ind_valeur);
*/    
           }

       }
   fclose(fpmas1);

/* constitue les fichiers .val correspondants */
/* avec les valeurs en fonction du temps AVEC MASQUE*/

 printf(" Cree les Descripteurs au soleil Avec Masque : \n");

  temps=hh1;
   for(i=0;i<nb_pas;i++)
     { 

	/* calcule min_max pour le pas i AVEC MASQUE */
        vmin_gen=100000000.; vmax_gen=-vmin_gen;
        indice=i;
        for(j=0;j<nbfac;j++)
           { for(k=0;k<nbc_face[j];k++)
               { if(valeur[indice] < vmin_gen) vmin_gen=valeur[indice];
                 if(valeur[indice] > vmax_gen) vmax_gen=valeur[indice];
                 indice+=nb_pas;
               }
           }    

       /* open fichier .val pour le pas i */
       /* VOIR A COMPOSER LE NOM */
        if(sans_masque)sprintf(buf,"%s%d.val",argv[9],i);
        else 
         {
           sprintf(buf,"%s%d.val",argv[8],i);
         }
        printf("   %s\n",buf);

        fpval=fopen(buf,"w");

        fprintf(fpval,"%5d %5d %15.3f %15.3f\n",nbfac,nomax,vmin_gen,vmax_gen);

       /* stocke les valeurs pour le pas i */
         indice=i;
         for(j=0;j<nbfac;j++)
           {
             /* printf("Face %d\n",no_face[j]);*/
             fprintf(fpval,"f%d %d\n",no_face[j],nbc_face[j]);

             for(k=0;k<nbc_face[j];k++)
               { 
                 /* printf("Contour %d indice %d\n",k+1,indice);*/

                 fprintf(fpval,"%10.3f\n",valeur[indice]);
                 indice+=nb_pas;
               }
           }    
          fclose(fpval);
          temps+=pas;
     }

/* evalue valeurs en fonction du temps SANS MASQUE*/
/* SANS_MASQUE */

if(sans_masque)
 {
    /*printf("SANS_MASQUE\n");*/

    ind_valeur=0;

    for(j=0;j<nbfac;j++)
       { fscanf(fpmas2,"\n%c%d %d",&c,&nofac,&nbcontour);
         /*printf("FACE %d\n",nofac);*/

         for(k=0;k<nbcontour;k++)  
           { /*printf("test contour %d\n",k+1);*/
             /* evalue valeurs en fonction du temps SANS MASQUE pour chaque contour */

test_ensoleille(nb_pas,pas,nb_date,indice_date,hh1,&ind_valeur,valeur,fpmas2);
           }

       }

   fclose(fpmas2);



/* constitue les fichiers .val correspondants */
/* avec les valeurs en fonction du temps SANS MASQUE*/

 printf(" Cree les Descripteurs au soleil Sans Masque : \n");

   temps=hh1;
   for(i=0;i<nb_pas;i++)
     { 
	/* calcule min_max pour le pas i SANS MASQUE */
        vmin_gen=100000000.; vmax_gen=-vmin_gen;
        indice=i;
        for(j=0;j<nbfac;j++)
           { for(k=0;k<nbc_face[j];k++)
               { if(valeur[indice] < vmin_gen) vmin_gen=valeur[indice];
                 if(valeur[indice] > vmax_gen) vmax_gen=valeur[indice];
                 indice+=nb_pas;
               }
           }    


       /* open fichier .val pour le pas i */
       /* VOIR A COMPOSER LE NOM */

        sprintf(buf,"%s%d.val",argv[10],i);
        printf("   %s\n",buf);
        fpval=fopen(buf,"w");

        fprintf(fpval,"%5d %5d %15.3f %15.3f\n",nbfac,nomax,vmin_gen,vmax_gen);

       /* stocke les valeurs pour le pas i */
         indice=i;
         for(j=0;j<nbfac;j++)
           { fprintf(fpval,"f%d %d\n",no_face[j],nbc_face[j]);

             for(k=0;k<nbc_face[j];k++)
               { fprintf(fpval,"%10.3f\n",valeur[indice]);

                 indice+=nb_pas;
               }
           }    
          fclose(fpval);
          temps+=pas;

     }

  }

 free(valeur); free(nbc_face); free(no_face);

	creer_OK_Solene();
	printf("Fin du traitement au_soleil\n");

}

/*_________________________________________________________________*/

int test_ensoleille(nb_pas,pas,nb_date,ind_date,hh1,ind_valeur,valeur,pf_mas)
int nb_pas,pas,nb_date,ind_date,hh1,*ind_valeur;
float *valeur;
FILE *pf_mas;
{
  int nb_per,dh[50],dm[50],fh[50],fm[50];
  float val[50];
  int i,k,kk,temps,h_deb,m_deb;
  double x,y,z,oui;
  char c;

/*printf("nb_pas pas nb_date ind_date %d %d %d %d\n",nb_pas,pas,nb_date,ind_date);*/
/*printf("hh1 ind_valeur %d %d\n",hh1,*ind_valeur);*/

             fscanf(pf_mas,"\n%c",&c);

  for(i=0;i<nb_date;i++)
     { fscanf(pf_mas,"%d",&nb_per);
       for(k=0;k<nb_per;k++)
          { fscanf(pf_mas,"%d %d %d %d %f",dh+k,dm+k,fh+k,fm+k,val+k);
      /* printf("%d %d %d %d %f\n",dh[k],dm[k],fh[k],fm[k],val[k]); */
          }


       /* test ensoleillement sur ce jour */
       if(i==ind_date)  
          {  temps=hh1;
             for(kk=0;kk<nb_pas;kk++)
              { x=temps/60.;
                h_deb=x;
                m_deb=temps-h_deb*60.;
/*printf("a %d H %d\n",h_deb,m_deb);*/
                heure_et_minute_EN_heure_double(h_deb,m_deb,&z); 
		oui=0;
                for(k=0;k<nb_per;k++)
                  { heure_et_minute_EN_heure_double(dh[k],dm[k],&x);
 		    heure_et_minute_EN_heure_double(fh[k],fm[k],&y);
		    if(x<=z && y>=z) oui=1;
                  }
                temps+=pas;
                valeur[*ind_valeur]=oui;
/*printf(" valeur oui %f %f\n",oui,valeur[*ind_valeur]);*/
		(*ind_valeur)++;
              }

          }
    }
}



/*_________________________________________________________________*/

int format_entree()
{
 printf(" la fonction a comme parametre ENTREE :\n");
 printf("\t fichier_in(.cir)\n"); 
 printf("\t fichier_in(.mas)\n");
 printf("\t jour/mois\n");
 printf("\t hh1:mn1\n");
 printf("\t hh2:mn2\n");
 printf("\t pas(hh:mn)\n");
 printf("\t calcul_sans_masque(1 oui; 0 non)\n");
 printf("\t       fichier_in(.mas) sans masque\n");
   
 printf("           comme parametres en SORTIE, les descripteurs .val :\n");
   
 printf("\t nom du descripteur : au_soleil_\n");
 printf("\t si calcul_sans_masque\n");
 printf("\t    nom du descripteur : au_soleil_sans_masque\n\n"); 
}

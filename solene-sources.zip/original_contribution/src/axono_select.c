/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */
 
/*

cc axono_select.c solutile.o geomutile.o traite.o poly_op_poly.o face_op_face.o -o axono_select lib_solene_94.o -lm

*/
/*
 realise axono d'un fichier en tenant compte d'un fichier masque
 et ne retient que les parties visibles
*/
#include<solene.h>
#include<ctype.h>


extern double coef_discol;


/*_________________________________________________________________*/
main(argc,argv)                         /* AXONO */
int argc;char **argv;
{int i;
 char c[2];
 char buf[256],nom_out[256],*s_dir;
double x,y,z;

      //   s_dir=(char *)getenv("PWD");

	 s_dir=""; //(char *)getenv("PWD");


   singularite=0; non_singularite=0; nb_etat=0;
   normale_orientee=1; traitement_faces_cachees=1;
   pb_masque=0; colle_max=coef_discol*DISCOL;

         obs.xo=0; obs.yo=0; obs.zo=0;

         if(argc<7)format_entree_axono();
         printf("\n CALCUL D'UNE VUE AXONOMETRIQUE \n");

		 
		 sprintf(buf,"%s.cir",argv[1]);
       //  compose_nom_complet(buf,s_dir,argv[1],"cir");
         if((fp=fopen(buf,"r"))==NULL)
            { printf("\n impossible ouvrir %s\n",buf); exit(0);}

		 sprintf(buf,"%s.cir",argv[2]);
   //      compose_nom_complet(buf,s_dir,argv[2],"cir");
         if((hfp=fopen(buf,"r"))==NULL)
            { printf("\n impossible ouvrir %s\n",buf); exit(0);}


  	 sscanf(argv[3],"%lf",&(obs.x));
         sscanf(argv[4],"%lf",&(obs.y));
         sscanf(argv[5],"%lf",&(obs.z));

		 sprintf(nom_out,"%s.cir",argv[6]);
      //   compose_nom_complet(nom_out,s_dir,argv[6],"cir");
         printf(" fichier a traiter %s \n",buf);
         printf(" observateur %lf %lf %lf \n",obs.x,obs.y,obs.z);
	  printf(" fichier resultat = %s \n", nom_out);

         for(i=7;i<argc;i++)
            { sscanf(argv[i],"%c%c",c,c+1);
              if(*c!='-')format_entree_axono();
              if(*(c+1)=='n') normale_orientee=0;
	      else if(*(c+1)=='t') traitement_faces_cachees=0;
              else format_entree_axono();
            }

	 tranfo();
	 traite_heliodon_axono(nom_out);

	creer_OK_Solene();
	printf("\n\nFin du Traitement Axono SELECT\n");

}	
/*_________________________________________________________________*/
format_entree_axono()
{
  printf("\n   format d'entree des parametres \n\n");
  printf("*axono_select* fichier_select(.cir) fichier_entree(.cir) xobs yobs zobs fichier_sortie(.cir) [-n]\n\n");
  exit(0);
}
/*____________________________________________________________________*/
/*____________________________________________________________________*/
/*      TRAITE_HELIODON_AXONO                   		      */
/*____________________________________________________________________*/
/*____________________________________________________________________*/

/*_________________________________________________________________*/
int traite_heliodon_axono(nom_out)
char *nom_out;
{FILE *fcop;
 int i,nbf,nbfac1,nbfac2,numax,nomax,vu;
 struct modelisation_face *fac1,*fac2;
 double englob[10],englob1[10];


printf(" lit_fac1\n");
       lit_en_tete(fp,&nbfac1,&numax,englob);
       fac1=alloue_face(nbfac1,34);
       lit_fic_cir3d(fp,nbfac1,fac1);
       fclose(fp);
printf(" lit_fac2\n");
       lit_en_tete(hfp,&nbfac2,&numax,englob1);
       fac2=alloue_face(nbfac2,34);
       lit_fic_cir3d(hfp,nbfac2,fac2);
       fclose(hfp);
       init_fenetre_affichage();

       if(normale_orientee) printf(" VISIBILITE par normale\n");

       for(i=0;i<nbfac1;i++)
           {  if(normale_orientee==0) vu=1;
              else vu=visible_axono(fac1+i);
              if(vu && traitement_faces_cachees==0)
                { copie_face_projete(fac1+i,1,fac1+i,0);
                }
              else if(vu)
	        { tran_face(fac1+i,1,fac1+i,0);
	          tran_normale((fac1+i)->vnorm);
                }
	   }
       for(i=0;i<nbfac2;i++)
           {  if(normale_orientee==0) vu=1;
              else vu=visible_axono(fac2+i);
              if(vu && traitement_faces_cachees==0)
                { copie_face_projete(fac2+i,1,fac2+i,0);
                }
              else if(vu)
	        { tran_face(fac2+i,1,fac2+i,0);
	          tran_normale((fac2+i)->vnorm);
                }
	   }


       if(traitement_faces_cachees)
         { cal_fen_aff();
           printf(" NORMALISE\n");
           for(i=0;i<nbfac1;i++) normalise_face(fac1+i,0);
           for(i=0;i<nbfac2;i++) normalise_face(fac2+i,0);

           printf(" COPIE\n");
           for(i=0;i<nbfac1;i++) copie_face_projete(fac1+i,0,fac1+i,1);
           for(i=0;i<nbfac2;i++) copie_face_projete(fac2+i,0,fac2+i,1);


           printf(" TRAITE VU/CACHE ... \n");
           traite_moins_hel(fac1,nbfac1,fac2,nbfac2); 


           printf(" fin\n");
           for(i=0;i<nbfac1;i++)
	      {denormalise_face(fac1+i,0);
	       tran_face_inverse(fac1+i,0);
               tran_normale_inverse(fac1[i].vnorm);
	      }
	 }
     
         /* stocke resultat */
      printf(" STOCKE RESULTAT dans %s\n\n",nom_out);
      fcop=fopen(nom_out,"w");
      nbf=0;  nomax=0;
      ecrit_en_tete(fcop,nbf,nomax,englob);
      output_face_sur_fichier(fac1,nbfac1,0,0,fcop,&nbf,&nomax);
      rewind(fcop);
       ecrit_en_tete(fcop,nbf,nomax,englob);
       fclose(fcop); 
       desalloue_fface(fac1,nbfac1);
       desalloue_fface(fac2,nbfac2);

}

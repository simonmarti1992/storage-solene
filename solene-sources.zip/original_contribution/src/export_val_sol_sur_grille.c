/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

// export_val_sol_sur_grille.c



// D. GROLEAU (f�vrier 2004)


// exporte les valeurs d'un sol triangul� sur une grille carr�e
// le fichier de sortie (.txt) contient, ligne /ligne de grille 
//	x y z=0 valeur     (x,y sont le centre de gravit� de la maille)
//	x y z=0 valeur
//	x y z=0 valeur
//	x y z=0 valeur
//  ....

// NOTA: n'exporte que les �l�ments de grille recevant une valeur

#include<solene.h>


// DECLARATIONS FUNCTIONS

double	cherche_val_de_sol();
int     point_dans_face_modif1();
int		point_dans_fenetre();
void	pointXY();
void	format_entree();

// DECLARATION GLOBAL
	// info Grille
int nl,nc ;
double xor,yor,dx,dy ;
int nb_pb;

/*_________________________________________________________________*/
main(argc,argv)
int argc;char **argv;
{

 char 	buf[512],*s_dir;
 double englob[10];
 int	i,j,nbff,nomax,n,nof,nbc;

 FILE *fp;

 struct modelisation_face *ff;
 double xp ,yp ;
 double x1,y1,x2,y2,x3,y3,x4,y4;

 double *valeura,val;
 double minv,maxv;

 printf("\nFonction Solene : export_val_sol_sur_grille\n\n");

 if(argc !=10)format_entree();

	s_dir=(char *)getenv("PWD");

 nb_pb=0;

sscanf(argv[1],"%d",&nl);
sscanf(argv[2],"%d",&nc);


sscanf(argv[3],"%lf",&xor);
sscanf(argv[4],"%lf",&yor);
sscanf(argv[5],"%lf",&dx);
sscanf(argv[6],"%lf",&dy);


 
printf("\n Grille : %d lignes,  %d colonnes\n",nl,nc);
printf(" Origine : %f,  %f\n",xor,yor);
printf(" Maille : dx =  %f,  dy= %f\n",dx,dy);


// ouvre le fichier de sol existant
//___________________________________________________
  compose_nom_complet(buf,s_dir,argv[7],"cir");
  if((fp=fopen(buf,"r"))==NULL)
        { printf("\n impossible ouvrir %s\n",buf);
          exit(0);
		}
   lit_en_tete(fp,&nbff,&nomax,englob);
   ff=alloue_face(nbff,35);
   lit_fic_cir3d(fp,nbff,ff);
   fclose(fp);
   printf("\nFichier de sol :  %s (%d faces)\n",buf,nbff);

   nbc = nbcontours_total(ff, nbff);


// ouvre et lit le fichier de valeurs du sol
//___________________________________________________
  compose_nom_complet(buf,s_dir,argv[8],"val");
  if((fp=fopen(buf,"r"))==NULL)
	{ printf("impossible ouvrir %s\n",buf);
	  exit(0);
	}
   printf("Descripteur � exporter: %s\n",buf);

   /* lit seulement  pour val min et max  */	
   fscanf(fp,"%d %d %f %f\n",&i,&i,&minv,&maxv);
   rewind(fp);
	
  // Allocation du tableau des valeurs associ�es aux contours*/
  valeura = alloue_double(nbc,456);
  lect_fic_val(fp, valeura);
  fclose(fp);

// ouvre le fichier de valeurs � exporter
//___________________________________________________
  compose_nom_complet(buf,s_dir,argv[9],"txt");
  if((fp=fopen(buf,"w"))==NULL)
	{ printf("impossible ouvrir %s\n",buf);
	  exit(0);
	}
   printf("\nFichier d'exportation valeur_grille: %s\n",buf);

	n=0 ; 
	nof=0 ;
    for(i=0;i<nl;i++) 
    { for (j=0 ;j<nc ;j++)
		{ // traite une maille de 4 points
		  pointXY(i,j,&x1,&y1) ;
		  pointXY(i,j+1,&x2,&y2) ;
		  pointXY(i+1,j,&x3,&y3) ;
		  pointXY(i+1,j+1,&x4,&y4) ;
		  // centre de gravit�
		  xp = (x1+x2+x3+x4)/4;
		  yp = (y1+y2+y3+y4)/4;
		 // cherche dans quel contour du sol il tombe et prendre sa valeur de descripteur;
		 val= cherche_val_de_sol(ff,nbff,xp,yp,valeura);
		 if(val != -9999999.99)
		 {
		  fprintf(fp,"%15.3f %15.3f %15.3f %15.3f\n",xp,yp,0., val) ;
		  nof++;
		 }
	 }
	}

	fclose (fp);

    desalloue_double(valeura) ;
    desalloue_fface(ff,nbff);


   printf("nb de point de grille cr��es : %d\n",nof);
   printf("nb de NON_correspondances : %d\n",nb_pb);


   printf("\nFin du traitement export_val_sol_sur_grille\n");
   creer_OK_Solene();
}

/*____________________________________________________________________*/
void pointXY(i,j,xp,yp)
int i,j;
double *xp,*yp ;
{
 *yp=(i)*dy+yor;  
 *xp=(j)*dx+xor;
 //printf("xp,yp %f %f \n",*xp,*yp);

}
 

/*_________________________________________________________________*/
double cherche_val_de_sol(fac1,nbff,xp,yp,valeur)
struct modelisation_face *fac1;
int nbff;
double xp,yp;
double *valeur;
{
 int i,in;
 int noc, nbc;

 noc=0;
	for(i=0;i<nbff;i++)
	{
	  nbc = nb_contour_face(fac1+i,1);
	  in= point_dans_face_modif1(xp,yp,fac1+i,1);
      if(in)
		{ // le point vis� est dans le contour no in de la face
		  // calcul d du plan
		  return(valeur[noc+in-1]);
		}
	  noc+=nbc;
    }

	printf("pb : n'a pas trouv� de face de sol correspondant � ce point\n");
	nb_pb++;
	return(-9999999.99);

}

/*________________________________________________________________________*/
int point_dans_face_modif1(xp,yp,face,projete)
double xp,yp;
struct modelisation_face *face;
int projete;
{             /* si pt interieur a face : return(le no du contour de 1 � n) */
              /* cherche pour chaque contour de la face */
              /* avec verification si trou */
 int idedan,isur;
 struct contour *pcont;
 struct circuit *pcir;
 int noc;

 noc =0;
   if(projete)pcont=face->debut_projete; else pcont=face->debut_dessin;
   if((point_dans_fenetre(xp,yp,face->fen))==0) return(0);
   while(pcont)	   
       { pcir=pcont->debut_support; 
                 /* test pt / fenetre circuit */
         if(point_dans_fenetre(xp,yp,pcir->fen))
            { inpoly(&idedan,&isur,xp,yp,pcir);
              if(isur==1) return(noc+1); // MODIFICATION aulieu de 0
              if(idedan)
                 {         /* test si point ds trou ; si oui idedan=0 */
	           pcir=pcont->debut_interieur;
                   while(pcir)    
				   {    /* test pt / fenetre circuit */
                        if(point_dans_fenetre(xp,yp,pcir->fen))
                          { inpoly(&idedan,&isur,xp,yp,pcir);
                            //if(idedan || isur) return(0);
                            if(idedan ) return(0);
                          }
	                pcir=pcir->suc;
				   }
                  return(noc+1);
                 }
            }
         pcont=pcont->suc;
		 noc++;
       } 
  return(0);
}

/*_________________________________________________________________*/
void format_entree()
{

  printf("\n    export_val_sol_sur_grille nl nc xor yor dx dy fichier_sol_in(.cir)  fichier_valeurs_sol(.val) fichier_val_grille_out(.txt)  \n\n");
  exit(0);
}



/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */
 
/* capitoul_solene.c */

// D.GROLEAU septembre 2006

//cc -o capitoul_solene capitoul_solene.c solutile.o geomutile.o lib_solene_94.o -lm
 


// Conversion fichier produit par Jean Philippe Gastellu-Etchegorry dans le projet CAPITOUL (.src) en fichier SOLENE (.cir) */
// On pourrait associer un ou plusieurs descripteurs au fichier .cir 
// en fonction des caract�ristiques des faces  pr�sentes dans .src

/* Format du fichier .src

  138  //nblignes (donc de faces � lire)
1 0.441386 4.441386 -0.250000 0.441386 4.058614 -0.250000 0.441386 4.441386 4.787424 1.000000 0.000000 0.000000 0 1 11
1 0.058614 4.441386 -0.250000 0.441386 4.441386 -0.250000 0.058614 4.441386 4.787424 0.000000 1.000000 0.000000 0 1 11
1 0.058614 4.058614 -0.250000 0.058614 4.441386 -0.250000 0.058614 4.058614 4.787424 -1.000000 0.000000 0.000000 0 1 11

sur chaque ligne, un polygone
	1: un parall�logramme ou 0: un triangle
	les coordonn�es de 3 points de la face x,y,z; (si parall�logramme, reconstruire le 4�me point)
	les coodonn�es composantes de la normale (x,y,z)
	2 indices qui permettent de sp�cifier les propri�t�s optiques  de la face
	1 indice qui indique la nature de l'�l�ment

*/

/*---------------------------------------------------------------------------*/
#include<solene.h>

// DECLARATIONS
void convertit();
void format_entree();


// en GLOBAL
FILE *fi,*fo;


/*________________________________________________________*/
main(argc,argv)
int  argc;
char *argv[];    /* ou **argv */

{
 int nbfaces;
 char *s_dir;
 char nom_in[512],nom_out[512];


	s_dir=(char *)getenv("PWD");

	if(argc!=3)format_entree();

  printf("\nFonction Solene:  capitoul_solene\n\n");
  printf("Convertit fichier .src en .cir\n");

 /* LIT et traite les PARAMETRES IN et OUT */

            compose_nom_complet(nom_in,s_dir,argv[1],"src");
            if((fi=fopen(nom_in,"r"))==NULL) 
               { printf(" impossible ouvrir %s\n",nom_in);
   	             format_entree();
               }
			printf("Fichier IN .src : %s\n",nom_in);

			//lit nb de faces � convertir
			fscanf(fi,"%d",&nbfaces);

            compose_nom_complet(nom_out,s_dir,argv[2],"cir");
            if((fo=fopen(nom_out,"w"))==NULL) 
               { printf(" impossible ouvrir %s\n",nom_out);
   	             format_entree();
               }
			printf("Fichier OUT .cir : %s\n",nom_out);




 /* CONVERTIT .src en .cir */
 
   convertit(nbfaces);

 // FIN

 fclose(fi); fclose(fo);

 printf("\n ...conversion terminee : %d faces generees\n\n",nbfaces);


 creer_OK_Solene();
 printf("\nFin capitoul_solene\n");
 printf("_____________________________\n");

}

//______________________________________________________
void convertit(nbfaces)
int nbfaces;
{ 
  int i;
  int type;
  double x1,y1,z1;
  double x2,y2,z2;
  double x3,y3,z3;
  double x4,y4,z4;
  double xn,yn,zn;
  int indice1,indice2,indice3;

  fprintf(fo,"%5d  %5d\n",nbfaces,nbfaces);

 // initialise boite englobante 
  fprintf(fo,"0.00   0.00\n");
  fprintf(fo,"0.00   0.00\n");
  fprintf(fo,"0.00   0.00\n");
  fprintf(fo,"0.00   0.00\n");
  fprintf(fo,"0.00   0.00\n");

 // Recupere les nbfaces � convertir */
 for(i=0;i<nbfaces;i++)
  { 
    //printf(" lit face no %d \n",i+1);
	fscanf(fi,"%d",&type);
    fscanf(fi,"%lf %lf %lf",&x1,&y1,&z1);
    fscanf(fi,"%lf %lf %lf",&x2,&y2,&z2);
    fscanf(fi,"%lf %lf %lf",&x3,&y3,&z3);
    fscanf(fi,"%lf %lf %lf",&xn,&yn,&zn);
	fscanf(fi,"%d %d %d",&indice1,&indice2,&indice3);


	//printf(" ecrit face no %d \n",i+1);*/
    fprintf(fo,"f%d 1\n",i+1);
    fprintf(fo,"  %lf %lf %lf\n",xn,yn,zn);

	if(type==0 )
	{ fprintf(fo,"c0\n 4\n");  // triangle
	}
	else if(type==1)
	{ fprintf(fo,"c0\n 5\n");  // parallelogramme
	}
	else 
	{ printf("PB de type de figure (on attend 0 ou 1)\n");  
	  exit(0);
	}


	// �crit les 3 premiers points
	fprintf(fo,"  %lf %lf %lf\n",x1,y1,z1);
	fprintf(fo,"  %lf %lf %lf\n",x2,y2,z2);
	fprintf(fo,"  %lf %lf %lf\n",x3,y3,z3);
	// �crit le 4�me point si parall�logramme
	if(type==1)
	{ x4= x2 + (x1-x2) + (x3-x2);
	  y4= y2 + (y1-y2) + (y3-y2);
	  z4= z2 + (z1-z2) + (z3-z2);
	  fprintf(fo,"  %lf %lf %lf\n",x4,y4,z4);
	}

	// �crit le dernier point identique au premier
	fprintf(fo,"  %lf %lf %lf\n",x1,y1,z1);
 } // Fin FOR i
 
}


//______________________________________________________
void format_entree()
{
 printf("\n  capitoul_solene f_CAPITOUL(.src) f_solene(.cir)   \n");
 printf("\n");   
 printf("\tIN	f_CAPITOUL : Nom du fichier .src a convertir \n");
 printf("\tOUT	f_solene   : Nom du fichier .cir des faces transformees dans Solene \n");
 exit(0);
}


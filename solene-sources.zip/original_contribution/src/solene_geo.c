/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/*__________________________  solene_geo.c   __________________________ */
//
// D.Groleau, janvier 2006
/*______________________________________________________________________    */
/* Pour couplage Solene - N3S   (r�cup�ration des temperatures de surface de solene 
Transforme un fichier de geometrie.cir 		 
 en un fichier  ASCII 	d'extension .geo	      
 Constitue la liste des 3 coordonnees des contours des faces 
 en recensant les points en double, triple ... 
 pour ne constituer qu'une liste de noeuds
 Dans .geo
	Ecrit les points : CORNERS
	Ecrit les faces  : PLANES (les contours en r�f�rence aux no des points recoll�s)
*/                            		   

/*______________________________________________________________________  */


#include<solene.h>



// declare functions
int ajoute_point();
int cherche_no_point();
void format();
//
#define MAXTAB 5000
#define EPSILONE 0.001


/*_________________________________________________________________*/
main(argc,argv)           
int argc;char **argv;
	{

/*--------------*/
/* Declarations */
/*--------------*/

	char nom_geometrie[256];				/* fichier de geometrie lu */
	char nom_resultat[256];					/* fichier resultat (centres de gravite + valeurs) */
	
	int nbfac;			    /* nombre de faces d'apres le fichier de geometrie */
	double englob[10];
	struct modelisation_face *fac;	/* faces */
 	FILE *pfcir,  *pfgeo ;	/* pointeurs pour manips fichiers */
	int nomax;			/* numero maxi des faces */
	char *rep_courant;		/* repertoire courant */
	int nf;					/* Pour balayage faces et contours */
	struct contour *pcont;		/* id. */
	struct circuit *pcir;		/* id. */
	int		 noc;
	int i,id;

    double tabx[MAXTAB], taby[MAXTAB], tabz[MAXTAB];
    int    nbtab ;

/*-----------------------------*/
/* lecture parametres commande */
/*-----------------------------*/

	rep_courant = (char *)getenv("PWD");  

   	if(argc!=3) format(); 
 
	printf("\nFonction Solene : solene_geo\n");

    compose_nom_complet(nom_geometrie,rep_courant,argv[1],"cir");  
        printf("\n\nFichier de geometrie Solene: %s \n",nom_geometrie); 


	compose_nom_complet(nom_resultat,rep_courant,argv[2],"geo");  
        printf("Fichier de geom�trie Geo  : %s \n",nom_resultat);


/* fichiers en input */

       if((pfcir=fopen(nom_geometrie,"r"))==NULL)
		{
        	printf("\n impossible ouvrir %s\n",nom_geometrie); 
			exit(0);
		}

	   /* lecture fichier geometrie a traiter */
       lit_en_tete(pfcir,&nbfac,&nomax,englob);      
       fac=alloue_face(nbfac,34);
       lit_fic_cir3d(pfcir,nbfac,fac);
       fclose(pfcir);

/*------------------------------------------------------------*/
/* constitue la liste des noeuds pour geo
	� partir des pts du contour de solene                     */
/*------------------------------------------------------------*/
  noc =0;
  for(nf=0;nf<nbfac;nf++) 
  {
	  pcont=(fac+nf)->debut_projete;
      while(pcont) 	
      { pcir=pcont->debut_support;  
	    for(i=0;i<pcir->nbp-1;i++)
		{
		  //Sauvegarde des coordonnees des points du contour 
          ajoute_point(pcir->x[i],pcir->y[i],pcir->z[i], tabx, taby, tabz, &nbtab);
		}
		noc++;
 		pcont=pcont->suc; 
       } 
  }

/*------------------------------------------------------------*/
/* �criture du fichier  GEO									  */
/*------------------------------------------------------------*/

// OUVRE fichier OUT .geo
  if((pfgeo=fopen(nom_resultat,"w"))==NULL)
		{
        	printf("\n impossible ouvrir %s\n",nom_resultat); 
			exit(0);
		}
// Ecrit en commentaire nom du fichier geo
  fprintf (pfgeo,";%s\n",nom_resultat);

// Ecrit un Mat�riau Bidon
  fprintf (pfgeo,"ABS bidon = <02 02 03 03 04 04> L <10 10 10 10 10 10>{128 128 128}\n");

// Ecrit les coordonn�es des points avec leur no : CORNERS
  fprintf (pfgeo,"CORNERS\n",nbtab);

  for (i=0; i<nbtab ; i++)
  {
	fprintf (pfgeo,"%6d %15.5lf %15.5lf %15.5lf \n", i+1,tabx[i],taby[i],tabz[i]); 
  }

// Ecrit les contours des faces comme une liste de no de points : PLANES
  fprintf (pfgeo,"PLANES\n",nbtab);

  noc =0;
  for(nf=0;nf<nbfac;nf++) 
  {
	  pcont=(fac+nf)->debut_projete;
      while(pcont) 	
      { pcir=pcont->debut_support; 
	  	// commence le contour avec son no
		fprintf (pfgeo,"[%d / ",noc+1);

	    for(i=0;i<pcir->nbp-1;i++)
		{
		  //Sauvegarde des coordonnees des points du contour 
          id= cherche_no_point(pcir->x[i],pcir->y[i],pcir->z[i], tabx, taby, tabz, nbtab);
		  if(id==-1)
		  { printf("PB: ne trouve pas un point\n");
		    exit(0);
		  }
		  fprintf (pfgeo,"%d ",id);

		}
		// termine le contour
		fprintf (pfgeo,"/ bidon* ]\n",id);

		noc++;
 		pcont=pcont->suc; 
       } 
  }

  fclose(pfgeo);

/* Desallocations */
    desalloue_fface(fac,nbfac);
       	
	printf(" Fin du traitement solene_geo\n\n");
}

/*_________________________________________________________________*/
int ajoute_point(x,y,z, tabx, taby, tabz, nbtab)
double x, y, z ;
double *tabx, *taby, *tabz ;
int *nbtab;

{  
  int nb,i ;
  double dx, dy, dz;
	// ajoute un point dans la table si le point est different et place sa valeur associ�e
  nb = *nbtab ;
  for (i=0 ;i<nb ;i++)
  {  dx = *(tabx+i) - x ;
     dy = *(taby+i) - y ;
     dz = *(tabz+i) - z ;
     if (fabs(dx) < EPSILONE && fabs(dy) < EPSILONE && fabs(dz) < EPSILONE) 
	 { // le point existe d�j�
		 return(0);
	 }
  }

 // ajoute le point dans la table et  sa valeur ...
  *(tabx+nb) = x ;
  *(taby+nb) = y ;
  *(tabz+nb) = z ;

  if((nb+1) > MAXTAB)
  { printf("trop de points %d ... stop\n\n" , MAXTAB) ;
    exit(0);
  }
   *nbtab = *nbtab+1 ;
   return(1) ; 
}


/*_________________________________________________________________*/
int cherche_no_point(x,y,z, tabx, taby, tabz, nbtab)
double x, y, z ;
double *tabx, *taby, *tabz ;
int nbtab;

{  
  int i ;
  double dx, dy, dz;
	// cherche un point dans la table et rencvoie son indice +1
  for (i=0 ;i<nbtab ;i++)
  {  dx = *(tabx+i) - x ;
     dy = *(taby+i) - y ;
     dz = *(tabz+i) - z ;
     if (fabs(dx) < EPSILONE && fabs(dy) < EPSILONE && fabs(dz) < EPSILONE) 
	 { // le point existe 
		 return(i+1);
	 }
  }

 
   return(-1) ; 
}
/*_________________________________________________________________*/
void format()
	{
  	printf("\n   format d'entree des parametres \n\n");
  	printf("solene_geo  fichier_IN_solene(.cir)  fichier_OUT_geo(.geo)\n"); 
	printf("\n");
	
  	exit(0);
	}

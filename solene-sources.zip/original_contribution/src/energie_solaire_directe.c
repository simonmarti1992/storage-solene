/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/*
cc energie_solaire_directe.c  ~marenne/newsolene/solutile.o  ~marenne/newsolene/geomutile.o ~marenne/newsolene/lib_solene_94.o  ~marenne/newsolene/solaire.o -o energie_solaire_directe -lm

*/


/* execute_gen_val de SOL_N_SOLARIS */

#include<solene.h>

int test_ensoleille();

/*_________________________________________________________________*/
main(argc,argv) 
int argc;char **argv;

{
FILE *fpcir,*fpmas1,*fpmas2,*fpval,*fpval_abs,*fpval_ref,*fpval1,*fpval2;
int sans_masque;
char buf[256],buf1[256],buf2[256],*s_dir,c;
int nojour,nomois,jo,mo,indice_date;
int hh1,hh2,pas,minute;
int nbfac,nomax,nofac,nb_contour,nb_pas,nb_date;
double englob[10],*nx_face,*ny_face,*nz_face,*abs_contour,*ref_contour;
int *nbc_face,*no_face;
int i,j,k,kk,ind_valeur,h_deb,m_deb,temps,nbcontour,indice,no_contour,bidon;
float x,vmin_gen,vmax_gen,vmin_gen1,vmax_gen1,vmin_gen2,vmax_gen2;
float epsilon_ciel_perez,delta_ciel_perez;
double latitude,vnorm[3];
float *valeur;

struct modelisation_face *fac;

 if(argc<16) { format_entree(); exit(0); }
 sscanf(argv[12],"%d",&(sans_masque));
 if(sans_masque && argc<20) { format_entree(); exit(0); }

	s_dir=(char *)getenv("PWD");

printf("\nENERGIE_SOLAIRE_DIRECTE\n\n");


/* ouverture des fichiers */

         compose_nom_complet(buf,s_dir,argv[1],"cir");
         if((fpcir=fopen(buf,"r"))==NULL)
            { printf("\n impossible ouvrir %s\n",buf); exit(0);
            }

		 printf("%s \n",buf);

         compose_nom_complet(buf,s_dir,argv[2],"mas");
         if((fpmas1=fopen(buf,"r"))==NULL)
            { printf("\n impossible ouvrir %s\n",buf); exit(0);
            }

		 printf("%s \n",buf);


    if(sans_masque)
      {  compose_nom_complet(buf,s_dir,argv[13],"mas");
         if((fpmas2=fopen(buf,"r"))==NULL)
            { printf("\n impossible ouvrir %s\n",buf); exit(0);
            }
		 	printf("%s \n",buf);
      }
		
      /*open les .val : coef absorption, reflexion*/

         compose_nom_complet(buf,s_dir,argv[7],"val");
         if((fpval_abs=fopen(buf,"r"))==NULL)
            { printf("\n impossible ouvrir %s\n",buf); exit(0);
            }

		 printf("%s \n",buf);

         compose_nom_complet(buf,s_dir,argv[8],"val");
         if((fpval_ref=fopen(buf,"r"))==NULL)
            { printf("\n impossible ouvrir %s\n",buf); exit(0);
            }

		printf("%s \n",buf);

  	 sscanf(argv[3],"%d%c%d",&nojour,&c,&nomois);
//printf("jour mois %d %d\n",nojour,nomois);
         sscanf(argv[4],"%d%c%d",&hh1,&c,&minute);
         hh1=hh1*60+minute;
         sscanf(argv[5],"%d%c%d",&hh2,&c,&minute); 
         hh2=hh2*60+minute;
         sscanf(argv[6],"%d%c%d",&pas,&c,&minute);
         pas=pas*60+minute;
//printf("hh1 hh2 pas %d %d %d\n",hh1,hh2,pas);

 /* calcul du nombre de pas */
   nb_pas=1;
   i=hh1;
   while(i<hh2)
    { nb_pas++;
      i=i+pas;
    }
//printf("nb de pas %d\n",nb_pas);

   /* lecture de geom.cir FACE/FACE */


       lit_en_tete(fpcir,&nbfac,&nomax,englob);

       printf(" Traite %d faces\n",nbfac);
   nbc_face =alloue_int(nbfac,1023);
   no_face = alloue_int(nbfac,1023);
   nx_face = alloue_double(nbfac,1023);
   ny_face = alloue_double(nbfac,1023);
   nz_face = alloue_double(nbfac,1023);
   

   nb_contour=0;
	/* alloue une seule face */
   fac=alloue_face(1,34);

   for(i=0;i<nbfac;i++)
     { lit_fic_cir3d(fpcir,1,fac);
       no_face[i]=fac->nofac_fichier;
       nbc_face[i]=nb_contour_face(fac,1);
       nx_face[i]=fac->vnorm[0];
       ny_face[i]=fac->vnorm[1];
       nz_face[i]=fac->vnorm[2];
       nb_contour+=nbc_face[i];
       desalloue_contour_face(fac);
     }
   desalloue_fface(fac,1);
   fclose(fpcir);


printf("     soit  %d contours\n\n",nb_contour);

/* stocke les coef abs et ref pour les contours*/

  abs_contour=alloue_double(nb_contour,1023);
  ref_contour=alloue_double(nb_contour,1023);
  fscanf(fpval_abs,"%d %d %f %f",&i,&i,&x,&x);
  fscanf(fpval_ref,"%d %d %f %f",&i,&i,&x,&x);
  indice=0;
  for(i=0;i<nbfac;i++)
     { fscanf(fpval_abs,"\n%c%d%d\n",&c,&nofac,&bidon);
     { fscanf(fpval_ref,"\n%c%d%d\n",&c,&nofac,&bidon);
       for(k=0;k<nbc_face[i];k++)
               { fscanf(fpval_abs,"%lf",&abs_contour[indice]);
                 fscanf(fpval_ref,"%lf",&ref_contour[indice]);
		 indice++;
               }
           }    

     }
   fclose(fpval_abs); fclose(fpval_ref);

   

/* lit les valeurs epsilon_ciel_perez, delta_ciel_perez, latitude en degres */

  	 sscanf(argv[9],"%f",&epsilon_ciel_perez);
  	 sscanf(argv[10],"%f",&delta_ciel_perez);
  	 sscanf(argv[11],"%lf",&latitude);


 /* allouer nb_contour*nb_de_pas valeurs *2 */

   valeur=alloue_float(nb_contour*nb_pas*2,1023);

   for(j=0;j<nb_contour*nb_pas*2;j++) valeur[j]=0;

 /* lit en tete des .mas  et determine indice de la bonne date */
     

    fscanf(fpmas1,"%d",&nb_date);
	
	for(j=0;j<nb_date;j++)
         { fscanf(fpmas1,"%d %d",&jo,&mo);
			  
           if(mo == nomois && jo == nojour) indice_date=j;

         }
        fscanf(fpmas1,"%d %d",&i,&i);

/* printf("indice de la bonne date %d\n", indice_date);*/

    if(sans_masque)
      { 
        fscanf(fpmas2,"%d",&i);
	for(j=0;j<nb_date;j++) fscanf(fpmas2,"%d %d",&i,&i);
        fscanf(fpmas2,"%d %d",&i,&i);
      }


/* examine les contours et determine les valeurs */
/* stocke les valeurs dans valeur contour  apres contour */
/* soit nb_contour*nb_pas valeurs */
/* AVEC_MASQUE */

 printf("AVEC_MASQUE\n");


     ind_valeur=0;

     for(j=0;j<nbfac;j++)
       { fscanf(fpmas1,"\n%c%d %d",&c,&nofac,&nbcontour);
         /*printf("FACE %d\n",nofac);*/
		vnorm[0]=nx_face[j];
		vnorm[1]=ny_face[j];
		vnorm[2]=nz_face[j];

         for(k=0;k<nbcontour;k++)  
           { /*printf("test contour %d\n",k+1);*/

             /* evalue valeurs en fonction du temps AVEC MASQUE pour chaque contour */

energie_directe(nb_pas,pas,nb_date,indice_date,hh1,&ind_valeur,valeur,fpmas1,latitude,vnorm,nojour,nomois);

/*        for(kk=0;kk<nb_pas;kk++)
	       { printf("valeurs : %f\n",valeur[ind_valeur-nb_pas+kk]);
           }
	      printf("ind_valeur %d \n", ind_valeur);
 */
		  }

       }
   fclose(fpmas1);

/* constitue les fichiers .val correspondants */
/* avec les valeurs en fonction du temps AVEC MASQUE*/

 printf(" Cree les Descripteurs au soleil Avec Masque : \n");

  temps=hh1;
   for(i=0;i<nb_pas;i++)
     { 

	/* calcule min_max pour le pas i AVEC MASQUE */
        vmin_gen=10000000.; vmax_gen=-vmin_gen;
		
        vmin_gen1=vmin_gen; vmax_gen1=-vmin_gen;
        vmin_gen2=vmin_gen; vmax_gen2=-vmin_gen;
        no_contour=0;
        indice=i;
        for(j=0;j<nbfac;j++)
           { for(k=0;k<nbc_face[j];k++)
               { x=valeur[indice];
                 test_min_max(x,&vmin_gen,&vmax_gen);

                 x=valeur[indice]*abs_contour[no_contour];
                 test_min_max(x,&vmin_gen1,&vmax_gen1);

                 x=valeur[indice]*ref_contour[no_contour];
                 test_min_max(x,&vmin_gen2,&vmax_gen2);
		         no_contour++;
                 indice+=nb_pas;
               }
           }    

		
       /* open fichier .val pour le pas i */
       /* VOIR A COMPOSER LE NOM */
        if(sans_masque)
           { sprintf(buf,"%s%d.val",argv[14],i);
             sprintf(buf1,"%s%d.val",argv[15],i);
             sprintf(buf2,"%s%d.val",argv[16],i);
           }
        else 
           { sprintf(buf,"%s%d.val",argv[13],i);
             sprintf(buf1,"%s%d.val",argv[14],i);
             sprintf(buf2,"%s%d.val",argv[15],i);
           }
        printf("   %s\n",buf);
        printf("   %s\n",buf1);
        printf("   %s\n",buf2);

        fpval=fopen(buf,"w");
        fpval1=fopen(buf1,"w");
        fpval2=fopen(buf2,"w");

        fprintf(fpval,"%5d %5d %15.3f %15.3f\n",nbfac,nomax,vmin_gen,vmax_gen);
        fprintf(fpval1,"%5d %5d %15.3f %15.3f\n",nbfac,nomax,vmin_gen1,vmax_gen1);
        fprintf(fpval2,"%5d %5d %15.3f %15.3f\n",nbfac,nomax,vmin_gen2,vmax_gen2);

		
       /* stocke les valeurs pour le pas i */
         no_contour=0;
         indice=i;
         for(j=0;j<nbfac;j++)
           {
             /* printf("Face %d\n",no_face[j]);*/
             fprintf(fpval,"f%d %d\n",no_face[j],nbc_face[j]);
             fprintf(fpval1,"f%d %d\n",no_face[j],nbc_face[j]);
             fprintf(fpval2,"f%d %d\n",no_face[j],nbc_face[j]);

             for(k=0;k<nbc_face[j];k++)
               { 
                 /* printf("Contour %d indice %d\n",k+1,indice);*/

                 fprintf(fpval,"%10.3f\n",valeur[indice]);
                 fprintf(fpval1,"%10.3f\n",valeur[indice]*abs_contour[no_contour]);
                 fprintf(fpval2,"%10.3f\n",valeur[indice]*ref_contour[no_contour]);
		         no_contour++;
                 indice+=nb_pas;

               }
           }    
          fclose(fpval); fclose(fpval1); fclose(fpval2);
          temps+=pas;
     }

/* evalue valeurs en fonction du temps SANS MASQUE*/
/* SANS_MASQUE */

if(sans_masque)
 {
    printf("SANS_MASQUE\n");

    ind_valeur=nb_contour*nb_pas;

    for(j=0;j<nbfac;j++)
       { fscanf(fpmas2,"\n%c%d %d",&c,&nofac,&nbcontour);
         /*printf("FACE %d\n",nofac);*/
		vnorm[0]=nx_face[j];
		vnorm[1]=ny_face[j];
		vnorm[2]=nz_face[j];


         for(k=0;k<nbcontour;k++)  
           { /*printf("test contour %d\n",k+1);*/
             /* evalue valeurs en fonction du temps SANS MASQUE pour chaque contour */

energie_directe(nb_pas,pas,nb_date,indice_date,hh1,&ind_valeur,valeur,fpmas2,latitude,vnorm,nojour,nomois);
           }

       }

   fclose(fpmas2);



/* constitue les fichiers .val correspondants */
/* avec les valeurs en fonction du temps SANS MASQUE*/

 printf(" Cree les Descripteurs au soleil Sans Masque : \n");

   temps=hh1;
   for(i=0;i<nb_pas;i++)
     { 
	/* calcule min_max pour le pas i SANS MASQUE */
        vmin_gen=100000000.; vmax_gen=-vmin_gen;
        vmin_gen1=vmin_gen; vmax_gen1=-vmin_gen;
        vmin_gen2=vmin_gen; vmax_gen2=-vmin_gen;
        no_contour=0;
        indice=nb_contour*nb_pas+i;
        for(j=0;j<nbfac;j++)
           { for(k=0;k<nbc_face[j];k++)
               { x=valeur[indice];
                 test_min_max(x,&vmin_gen,&vmax_gen);

                 x=valeur[indice]*abs_contour[no_contour];
                 test_min_max(x,&vmin_gen1,&vmax_gen1);

                 x=valeur[indice]*ref_contour[no_contour];
                 test_min_max(x,&vmin_gen2,&vmax_gen2);
		         no_contour++;
                 indice+=nb_pas;
               }
           }    


       /* open fichiers .val pour le pas i */
       /* VOIR A COMPOSER LE NOM */

        sprintf(buf,"%s%d.val",argv[17],i);
        sprintf(buf1,"%s%d.val",argv[18],i);
        sprintf(buf2,"%s%d.val",argv[19],i);
        printf("   %s\n",buf);
        printf("   %s\n",buf1);
        printf("   %s\n",buf2);

        fpval=fopen(buf,"w");
        fpval1=fopen(buf1,"w");
        fpval2=fopen(buf2,"w");

        fprintf(fpval,"%5d %5d %15.3f %15.3f\n",nbfac,nomax,vmin_gen,vmax_gen);
        fprintf(fpval1,"%5d %5d %15.3f %15.3f\n",nbfac,nomax,vmin_gen1,vmax_gen1);
        fprintf(fpval2,"%5d %5d %15.3f %15.3f\n",nbfac,nomax,vmin_gen2,vmax_gen2);

       /* stocke les valeurs pour le pas i */
         no_contour=0;
         indice=nb_contour*nb_pas+i;
         for(j=0;j<nbfac;j++)
           { 
             fprintf(fpval,"f%d %d\n",no_face[j],nbc_face[j]);
             fprintf(fpval1,"f%d %d\n",no_face[j],nbc_face[j]);
             fprintf(fpval2,"f%d %d\n",no_face[j],nbc_face[j]);


             for(k=0;k<nbc_face[j];k++)
               { 
 		         fprintf(fpval,"%10.3f\n",valeur[indice]);
                 fprintf(fpval1,"%10.3f\n",valeur[indice]*abs_contour[no_contour]);
                 fprintf(fpval2,"%10.3f\n",valeur[indice]*ref_contour[no_contour]);
		         no_contour++;

                 indice+=nb_pas;
               }
           }    
          fclose(fpval); fclose(fpval1); fclose(fpval2);
          temps+=pas;

     }

  }

 free(valeur); free(nbc_face); free(no_face);
 free(nx_face); free(ny_face); free(nz_face);
 free(abs_contour); free(ref_contour); 

creer_OK_Solene();
printf("\nFin energie_solaire_directe\n\n");

}

/*_________________________________________________________________*/

int energie_directe(nb_pas,pas,nb_date,ind_date,hh1,ind_valeur,valeur,pf_mas,latitude,vnorm,nojour,nomois)
int nb_pas,pas,nb_date,ind_date,hh1,*ind_valeur;
float *valeur;
FILE *pf_mas;
double latitude,*vnorm;
int nojour,nomois;
{
  int nb_per,dh[50],dm[50],fh[50],fm[50];
  float val[50];
  int i,k,kk,temps,h_deb,m_deb;
  double x,y,z,oui,xyz[3],ang,a,h,xyzsol[3];
  char c;

/*
printf("nb_pas pas nb_date ind_date %d %d %d %d\n",nb_pas,pas,nb_date,ind_date);
printf("hh1 ind_valeur %d %d\n",hh1,*ind_valeur);
*/
             fscanf(pf_mas,"\n%c",&c);

  for(i=0;i<nb_date;i++)
     { fscanf(pf_mas,"%d",&nb_per);
       for(k=0;k<nb_per;k++)
          { fscanf(pf_mas,"%d %d %d %d %f",dh+k,dm+k,fh+k,fm+k,val+k);
      /*printf("%d %d %d %d %f\n",dh[k],dm[k],fh[k],fm[k],val[k]);*/ 
          }


       /* test ensoleillement sur ce jour */
       if(i==ind_date)  
          {  temps=hh1;
             for(kk=0;kk<nb_pas;kk++)
              { x=temps/60.;
                h_deb=x;
                m_deb=temps-h_deb*60.;
/*printf("a %d H %d\n",h_deb,m_deb);*/
                heure_et_minute_EN_heure_double(h_deb,m_deb,&z); 
	        	oui=0;
                for(k=0;k<nb_per;k++)
                  { heure_et_minute_EN_heure_double(dh[k],dm[k],&x);
 		            heure_et_minute_EN_heure_double(fh[k],fm[k],&y);
		            if(x<=z && y>=z) oui=1;
                  }
		if(oui)
                  { /*evalue energie solaire directe */
                   info_solaire(latitude,nojour,nomois,h_deb,m_deb,xyzsol,&a,&h);


                   valeur[*ind_valeur]=rii(h,2)*vincid(xyzsol,vnorm,&ang)*1.;
				   if(valeur[*ind_valeur] < 0. ) valeur[*ind_valeur] = 0;

                  }

                temps+=pas;
/*printf(" valeur oui %f %f\n",oui,valeur[*ind_valeur]);*/
		(*ind_valeur)++;
              }

          }
    }
}

/*_________________________________________________________________*/
int test_min_max(x,vmin_gen,vmax_gen)
float x,*vmin_gen,*vmax_gen;
{


		 if(x < *vmin_gen) *vmin_gen=x;
                 if(x > *vmax_gen) *vmax_gen=x;
}

/*_________________________________________________________________*/

int format_entree()
{
 printf("\n la fonction a comme parametre ENTREE :\n\n");
 printf("\t fichier_in(.cir)\n"); 
 printf("\t fichier_in(.mas)\n");
 printf("\t jour/mois\n");
 printf("\t hh1:mn1\n");
 printf("\t hh2:mn2\n");
 printf("\t pas(hh:mn)\n");

printf("\t coef_absorption au solaire(.val)\n");
printf("\t coef_reflexion au solaire(.val)\n");
printf("\t epsilon_ciel_perez\n");
printf("\t delta_ciel_perez\n");
printf("\t latitude en degres\n");

 printf("\t calcul_sans_masque(1 oui; 0 non)\n");
 printf("\t       fichier_in(.mas) sans masque (si calcul_sans_masque=1)\n");
   
 printf("\n           comme parametres en SORTIE, les descripteurs:\n\n");
   
 printf("\t energie_solaire_directe_Incidente\n");
 printf("\t energie_solaire_directe_Absorbee\n");
 printf("\t energie_solaire_directe_Reflechie\n");

 printf("\t           et si calcul_sans_masque=1\n");
 printf("\t energie_solaire_directe_Sans_Masque_Incidente\n");
 printf("\t energie_solaire_directe_Sans_Masque_Absorbee\n");
 printf("\t energie_solaire_directe_Sans_Masque_Reflechie\n");
  
}

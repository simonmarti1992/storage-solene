/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */


/*

cc sup_faces_non_visible.c solutile.o geomutile.o  lib_solene_94.o -o test_normale_fic -lm

*/
// soumet un fichier de faces.cir
// a plusieurs vues axonom�triques (d�finies dans un fichier)
// et supprime les faces visible dans aucune des vues


#include<solene.h>


// FUNCTIONS
void format_entree_test_normale_fic();

//______________________________________________________________________
main(argc,argv) 
int argc;char **argv;
{
 char nom_in[512], nom_vis[512],nom_out[512],*s_dir;
 char ligne_commande[512];
 FILE *fp;
 int i;
 float xv,yv,zv;

 if(argc!=4){ format_entree_test_normale_fic();return(0); }

	s_dir=(char *)getenv("PWD");

  printf("\n Supprime les faces de fichier_in.cir visibles dans aucune des vues axono\n");

	// nom de fichiers in,vis et out
    sprintf(nom_in,"%s",argv[1]);
    compose_nom_complet(nom_vis,s_dir,argv[2],"txt");
    sprintf(nom_out,"%s",argv[3]);

 // open fichier des points de vue

  if((fp=fopen(nom_vis,"r"))==NULL)
        { printf("\n impossible ouvrir %s\n",nom_vis); exit(0);}

   printf("\n le fichier_in :  %s\n",nom_in);
   printf(" le fichier_vis:  %s\n",nom_vis);
   printf(" le fichier_out:  %s\n",nom_out);

   // traitement 
   // realise cahque vue et ne conserve que les faces vues
   i=0;
   while((fscanf(fp,"%f %f %f",&xv,&yv,&zv))!=-1)
   {
	 printf("\nvue :%f %f %f \n",xv,yv,zv);
	 if(i==0)
	 {
      sprintf(ligne_commande,"axono %s %f %f %f %\\ffff1",nom_in,xv,yv,zv, getenv(SOLENETEMP)); //SII DFA 24-4-2006
      //sprintf(ligne_commande,"axono %s %f %f %f ffff1",nom_in,xv,yv,zv);
	  printf("%s\n",ligne_commande);
      system(ligne_commande);
	  // resultat dans fff3
      sprintf(ligne_commande,"copy %s\\ffff1.cir %s\\ffff3.cir", getenv(SOLENETEMP), getenv(SOLENETEMP)); // SII DFA 24-4-2006
      //sprintf(ligne_commande,"copy ffff1.cir ffff3.cir");
	  printf("%s\n",ligne_commande);
      system(ligne_commande);
	 }
	 else
	 {
	  sprintf(ligne_commande,"axono %s %f %f %f %s\\ffff2",nom_in,xv,yv,zv, getenv(SOLENETEMP)); // SII DFA 24-4-2006
	  printf("%s\n",ligne_commande);
      system(ligne_commande);

	  sprintf(ligne_commande,"nofic_op_nofic %s\\ffff1 ou %s\\ffff2 %s\\ffff3", getenv(SOLENETEMP), getenv(SOLENETEMP), getenv(SOLENETEMP)); // SII DFA 24-4-2006
	  printf("%s\n",ligne_commande);
      system(ligne_commande);
	  // resultat dans fff3 // et aussi dans fff1

      sprintf(ligne_commande,"copy %s\\ffff3.cir %s\\ffff1.cir", getenv(SOLENETEMP), getenv(SOLENETEMP)); //SII DFA 24-4-2006
	  printf("%s\n",ligne_commande);
      system(ligne_commande);
	 }
	 i++;
   }
 //construit le fichier nom_out.cir avec les faces contenues dans fff3

   sprintf(ligne_commande,"nofic_op_nofic %s et %s\\ffff3 %s",nom_in,getenv(SOLENETEMP), nom_out); //SII DFA 24-4-2006
   printf("\n%s\n",ligne_commande);
   system(ligne_commande);

  // detruit fichier temporaires
 sprintf(ligne_commande,"del %s\\ffff1.cir", getenv(SOLENETEMP)); //SII DFA 24-4-2006
 system(ligne_commande);

 sprintf(ligne_commande,"del %s\\ffff2.cir", getenv(SOLENETEMP));//SII DFA 24-4-2006
 system(ligne_commande);

 sprintf(ligne_commande,"del %s\\ffff3.cir", getenv(SOLENETEMP));//SII DFA 24-4-2006
 system(ligne_commande);

 creer_OK_Solene();

 printf("Fin du traitement\n\n");

}
/*_________________________________________________________________*/
void format_entree_test_normale_fic()
{
  printf("\n   sup_faces_non_visibles  fichier_in(.cir) fichier_des_vues(.txt) fichier_out(.cir)\n\n");
  printf("\n Supprime les faces de fichier_in.cir) visibles dans aucune des vues axono\n");
  printf(" d�finies dans le fichier_des_vues(.txt) par une liste de pts de vue (xv,yv,zv)\n");
  printf(" et met le r�sultat dans fichier_out.cir) \n\n");

}

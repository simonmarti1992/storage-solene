/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/* fluent_to_solene.c	*/
/*______________________________________________________________________*/

//Dominique Groleau janvier 2003
//D. GROLEAU decembre 2006 
//			constitue les contours d'une m�me face si m�me normale et (c'est la modif) m�me d du plan
//			VOI //MODIF 9 DEC 2006

/*
R�cup�re les maillages de fluent 
le fichier fluent.msh est d�coup� en 2
	AVEC SEULEMENT LES COORDONN2ES DE POINTS: fichier des points
	AVEC SEULEMENT LES FACETTES (MAILLES): fichier des faces
Le fichier g�om�trie Solene constirue une face par ensemble de facettes (mailles)
cons�cutives du fichier de face situ�es dans le m�me plan
*/


#include<solene.h>

// declare Fonctions
double calcul_le_d_du_plan_du_contour();
int change_de_face();
int  ecrit_en_tete();
void format_entree();
int lit_fic_point();
int normale_avec_3pts();
void place_point();


// declare Global

double *x,*y,*z;


/*_________________________________________________________________*/
main(argc,argv)           
int argc;char **argv;
{
	int i,k,kk,id;
	int nb_point,nbfac,nbp,noc,nop[6],nbcont;
	double xp[6],yp[6],zp[6];
	double vnorm[3], vnorm_prec[3];
//MODIF 9 DEC 2006
	double d,d_prec;
//FIN MODIF 9 DEC 2006
	long pointe;

 	char nom_point[256],nom_face[256],nom_geom[256],buf[256];
	char *s_dir;

 	FILE *pfic,*pficr;
	double englob[10];

	s_dir=(char *)getenv("PWD");
   	if(argc!=4) format_entree();

	printf("Fonction: fluent_to_solene\n");

	for(i=0;i<10;i++) englob[i]=0;

// lit fichier points Fluent
	compose_nom_complet(nom_point,s_dir,argv[1],"msh");
    printf("\n  fichier de points Fluent : %s \n", nom_point);
	if ((pfic=fopen(nom_point,"r"))==NULL)
      { 
		printf("\n  impossible ouvrir %s\n\n", nom_point); 
		exit(0);
      }
	//lit les points
	nb_point = lit_fic_point(pfic);
	fclose(pfic);

	// test
	/*
	for(i=0;i<nb_point;i++)
	{ printf("%f %f %f\n", x[i],y[i],z[i]);
	}
	*/

// open fichier face Fluent
	compose_nom_complet(nom_face,s_dir,argv[2],"msh");
    printf("\n  fichier de faces Fluent : %s \n", nom_face);
	if ((pfic=fopen(nom_face,"r"))==NULL)
      { 
		printf("\n  impossible ouvrir %s\n\n", nom_face); 
		exit(0);
      }

// open fichier out geom Solene
	compose_nom_complet(nom_geom,s_dir,argv[3],"cir");
    printf("\n  fichier de g�om�trie Solene : %s \n", nom_geom);
	if ((pficr=fopen(nom_geom,"w"))==NULL)
      { 
		printf("\n  impossible ouvrir %s\n\n", nom_geom); 
		exit(0);
      }
    // ecrit en tete
	nbfac=0;
	ecrit_en_tete(pficr,nbfac, nbfac, englob);

// Lit le fichier de faces
	nbcont=0; noc=0;
	while(1)
	{ 
	  // LIT UN CONTOUR (une maille)
	  id= fscanf(pfic,"%d", &nbp); // nb de points
	  //printf("\n   contour no %d, nombre de points %d\n",nbcont+1,nbp);
	  if(id==EOF) break;  //1 c'est bon; 0 on arr�te
	  	  //printf("   id %d\n",id);

	  nbcont++;
	  // lit les no des points	  
	  for(k=0;k<nbp;k++)
	  {
	   fscanf(pfic,"%x", nop+k);
	   place_point(nop[k],xp+k,yp+k,zp+k);
	   //printf("%d ", nop[k]);
	  }
	  // lit 2 valeur en plus
	  fscanf(pfic,"%d %d", nop,nop+1);
	  // calcule normale  
	  normale_avec_3pts(xp,yp,zp,vnorm);
	  //MODIF 9 DEC 2006
	  // calcule aussi d du plan
	  d=calcul_le_d_du_plan_du_contour(xp,yp,zp,vnorm);
	  //printf("%15.5f %15.5f %15.5f %15.5f \n",vnorm[0],vnorm[1],vnorm[2],d);
	  //FIN MODIF 9 DEC 2006

	  if(noc==0) // c'est le 1er contour de la premi�re face
	  {
		nbfac=1;
		// ecrit la face 1
		pointe=ftell(pficr);
		fprintf(pficr,"f%d %5d\n",nbfac,1);
		fprintf(pficr,"%f %f %f\n",vnorm[0],vnorm[1],vnorm[2]);
		// stocke la normale
		for(kk=0;kk<3;kk++) {vnorm_prec[kk]=vnorm[kk];}
		//MODIF 9 DEC 2006
		d_prec=d;
		//FIN MODIF 9 DEC 2006

		noc=1;
		// �crit le contour
		fprintf(pficr,"c0\n%d\n",nbp+1);
		for(k=0;k<nbp;k++)
			{ fprintf(pficr,"%f %f %f\n",xp[k],yp[k],zp[k]);
			}
		fprintf(pficr,"%f %f %f\n",xp[0],yp[0],zp[0]);
	  }
	  else       // c'est un contour quelconque
	  {	
		//MODIF 9 DEC 2006
		//if(change_de_face(vnorm,vnorm_prec))
	    if(change_de_face(vnorm,vnorm_prec,d,d_prec))
		//FIN MODIF 9 DEC 2006

		{ // changement de face
		  // modifie le nb de contour de la face en cours
		  fseek(pficr,pointe,SEEK_SET);
		  fprintf(pficr,"f%d %5d\n",nbfac,noc);
		  // ajoute  une face
		  nbfac++;
		  // ecrit la nouvelle face
		  fseek(pficr,0,SEEK_END);
		  pointe=ftell(pficr);
		  fprintf(pficr,"f%d %5d\n",nbfac,1);
		  fprintf(pficr,"%f %f %f\n",vnorm[0],vnorm[1],vnorm[2]);
		  // stocke la normale
		  for(kk=0;kk<3;kk++) {vnorm_prec[kk]=vnorm[kk];}
		  //MODIF 9 DEC 2006
		  d_prec=d;
		  //FIN MODIF 9 DEC 2006

		  noc=1;
		  // �crit le contour
		  fprintf(pficr,"c0\n%d\n",nbp+1);
		  for(k=0;k<nbp;k++)
			{ fprintf(pficr,"%f %f %f\n",xp[k],yp[k],zp[k]);
			}
		  fprintf(pficr,"%f %f %f\n",xp[0],yp[0],zp[0]);

		}
	    else
		{ // ajoute le contour � la face en cours
		  noc++;
		  // �crit le contour
		  fprintf(pficr,"c0\n%d\n",nbp+1);
		  for(k=0;k<nbp;k++)
			{ fprintf(pficr,"%f %f %f\n",xp[k],yp[k],zp[k]);
			}
		  fprintf(pficr,"%f %f %f\n",xp[0],yp[0],zp[0]);
		}

	  }
	} // fin de WHILE

	// ajuste le nb de contours de la derni�re face
	fseek(pficr,pointe,SEEK_SET);
	fprintf(pficr,"f%d %5d\n",nbfac,noc);

	printf("  nombre de faces g�n�r�es : %d\n",nbfac);
	printf("  nombre de contours lus : %d\n",nbcont);

	
// FIN du TRAITEMENT de r�cup�ration
	fclose(pfic);
    // re-ecrit en tete
	rewind(pficr);
	ecrit_en_tete(pficr,nbfac, nbfac, englob);
	fclose(pficr);

	desalloue_double(x);
    desalloue_double(y);
    desalloue_double(z);


// CONSTITUE LES FACES ENGLOBANTES DES MAILLES
	printf("\n Unit les mailles d'une m�me face\n");
	sprintf(buf,"union_contour_face %s %s_masque",argv[3],argv[3]);
	system(buf);

	creer_OK_Solene();
	printf("ATTENTION: v�rifier les normales\n");
	printf("\n\nFin de fluent_to_solene\n");
	exit(0);
}

/*------------------------------------------------------------*/
void place_point(nop,xp,yp,zp)
int nop;
double *xp,*yp,*zp;
{
	nop--;
	*xp= x[nop];
	*yp= y[nop];
	*zp= z[nop];
}
/*------------------------------------------------------------*/
//MODIF 9 DEC 2006
//int change_de_face(vn1,vn2)
int change_de_face(vn1,vn2,d,d_prec)
double *vn1,*vn2;
double d, d_prec;
{
	double epsi;
	epsi=0.0001;
//	if(fabs(vn1[0]-vn2[0])<epsi && fabs(vn1[1]-vn2[1])<epsi && fabs(vn1[2]-vn2[2])<epsi ) return(0);
	if(fabs(vn1[0]-vn2[0])<epsi && fabs(vn1[1]-vn2[1])<epsi && fabs(vn1[2]-vn2[2])<epsi && fabs(d-d_prec)<epsi ) return(0);
	return(1);
}


/*------------------------------------------------------------*/
int lit_fic_point(fp)
FILE *fp;
{
int i,id;
double xbidon;
	// Lit une premi�re fois pour compter le nombre de points
	i=0;
	while(1)
	{ 
	  id= fscanf(fp,"%lf %lf %lf", &xbidon,&xbidon,&xbidon);
	  if(id==EOF) break;
	  i++;
	}
	printf("  nombre de points lus dans le fichier : %d\n",i);

	// Lit une seconde fois les coordonn�es des points
	rewind(fp);
	x= alloue_double(i,1278);
	y= alloue_double(i,1278);
	z= alloue_double(i,1278);
	i=0;
	while(1)
	{ 
	  id= fscanf(fp,"%lf %lf %lf", x+i,y+i,z+i);
	  if(id==EOF) break;
	  i++;
	}
	return(i);
}

//MODIF 9 DEC 2006
/*------------------------------------------------------------*/
// calcule le d du plan du contour
double calcul_le_d_du_plan_du_contour(xp,yp,zp,vnorm)
double *xp,*yp,*zp,*vnorm;
{
 double d;

      d=-(vnorm[0])*(xp[0]);
      d-=(vnorm[1])*(yp[0]);
      d-=(vnorm[2])*(zp[0]);
	  return(d);
}
//FIN MODIF 9 DEC 2006

/*_________________________________________________________________*/
/* Format de la fonction  */
void format_entree()
{
 printf("fluent_to_solene   point_fluent(.msh) face_fluent(.msh) geom_solene(.cir) \n\n");
 printf("\nla fonction a comme parametres en ENTREE :\n");
 printf("\t point_fluent(.msh)   // fichier des coordonn�es\n"); 
 printf("\t face_fluent(.msh)    // fichier des faces\n");  
 printf("\n              comme parametres en SORTIE :\n");
 printf("\t geom_solene(.cir)    // fichier solene des mailles Fluent\n\n");
 printf("\nNOTA: le programme g�n�re aussi  geom_solene_MASQUE(.cir)\n");
 printf("\t                      // fichier solene des faces Fluent non maill�es\n\n");
 exit(0);
}



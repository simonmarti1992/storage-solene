/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */
 
/*__________________________  df_visib_distance.c   ________________________________  */
/*                          
/*______________________________________________________________________  */
/* Pour traitement pbs visibilite D. Follut 				              */
/* Ce programme determine pour les patchs d'un fichier "test"  visibles   */
/* (d'un fichier .vis) et par rapport � un fichier .cir d'observateurs    */
/* les valeurs des distances                                         */
/* le resultat est un fichier de type .dis contenant les valeurs 0        */
/* (si non visible) ou distance (si  visible)                         */
/* a la ligne l, colonne c: visibilite du patch numero c du fichier test  */
/* depuis le patch numero l du fichier reference                          */
/* ce fichier de valeurs peut ensuite etre exploite en conjonction avec   */
/* un certain nombre de fichiers de descripteurs                          */
/*______________________________________________________________________  */

/* Rappel ligne de compilation */
/*
cc df_visib_distance.c ./UTILS/solutile.o ./UTILS/lib_solene_94.o ./UTILS/geomutile.o  -o df_visib_distance -lm
*/


#include<solene.h>
#include<ctype.h>
#include<malloc.h>
#include<math.h>



/* Declarations de structures */

struct vertex { double x, y, z; };
struct vector { double cx, cy, cz; };
struct triangle { struct vertex a, b, c; };


/* Fonctions */
extern int option_calcul_z;   /* option CALCUL du Z ds FACE-OP-FACE 1=coincidence_faces */
                              /* utilise ds singul.c epure_polygone */
			      /* et dans face_op_face.c             */
extern 	double coef_discol;
extern 	int z_axono_pers;


/*** Ajoutees par M.J.A. 02-98 ***/
/*** et 03/99 */

int nbcontours_total();
int nb_contour_face();
void centre_de_gravite();
void traitement_faces();
void lect_ff_param();
void format_usage();

/*** ***/

/*** ***/
/* Autres fonctions preexistantes */

struct vertex average();
double longueur_arete_poly();


/* Variables globales */
/* n'ayant pu etre supprimees: */


double vnf[3];

FILE *pfacvis, *pfang;		/* fichier de visibilit� et de distance */

/*_________________________________________________________________*/
main(argc,argv)           
int argc;char **argv;
	{

/* Fichiers et structures de donnees */
	char nom_in[256];	/* plan d'observation */
	char nom_test[256];	/* fichier regarde (maille) */
	char nom_fvis[256];	/* fichier IN de facteurs de visibilite */
	char nom_fang[256];	/* fichier OUT des distances  */

	int nbfac,nbfac_test;           /* Nombres de faces */
	int  nc_total_test;	            /* Nombres de contours test*/ 

	struct modelisation_face *fac,*fac_test;
 	FILE *pfic,*pfict;
	int nomax, nomaxt;
	double englob[10];

	float *vis, *ang;
/* Autres */
	int im = 0;
	char *s_dir;

/* initialisation */
   	pi=4*atan(1.);


/* lecture parametres commande */
	s_dir = (char *)getenv("PWD");  

   	if(argc!=5) format_usage();
 
    compose_nom_complet(nom_in,s_dir,argv[1],"cir");  
    printf("\n\nDistance visible a partir du fichier a traiter : %s \n",nom_in);

    compose_nom_complet(nom_test,s_dir,argv[2],"cir");  
    printf("vers fichier test: %s \n",nom_test);

    compose_nom_complet(nom_fvis,s_dir,argv[3],"vis");  
    printf("avec fichier de visibilite: %s \n",nom_fvis);

    compose_nom_complet(nom_fang,s_dir,argv[4],"dis");  
    printf("Resultat fichier des distances : %s \n",nom_fang);

/* ouvre les fichiers a traiter et ecrit en tete fichier resultat */

       if((pfic=fopen(nom_in,"r"))==NULL)
		{ printf("\n impossible ouvrir %s\n",nom_in); 
		  exit(0);
		}
                      
       if((pfict=fopen(nom_test,"r"))==NULL)
		{ printf("\n impossible ouvrir %s\n",nom_test); 
		  exit(0);
		}

       if((pfacvis=fopen(nom_fvis,"rb"))==NULL)
		{ printf("\n impossible ouvrir %s\n",nom_fvis); 
		  exit(0);
		}

	   if((pfang=fopen(nom_fang,"wb"))==NULL)
		{ printf("\n impossible ouvrir %s\n", nom_fang); 
		  exit(0);
		}

/* lecture fichier a traiter */
       lit_en_tete(pfic,&nbfac,&nomax,englob);
       fac=alloue_face(nbfac,34);
       lit_fic_cir3d(pfic,nbfac,fac);
       fclose(pfic);

/* lecture  fichier test */
       lit_en_tete(pfict,&nbfac_test,&nomaxt,englob);
       fac_test=alloue_face(nbfac_test,34);
       lit_fic_cir3d(pfict,nbfac_test,fac_test);
       fclose(pfict);

/* lancement du calcul */

	   /* Comptage des contours des faces test */
       nc_total_test =  nbcontours_total(fac_test, nbfac_test);
	   printf("nc_total_test %d\n",nc_total_test);

	   /* alloue autant de valeurs float pour visibilite (in) et distance (out) */
	   vis = alloue_float(nc_total_test,4534);
	   ang= alloue_float(nc_total_test,4532);

	   /* traite */
	   
       traitement_faces(nbfac, fac, nbfac_test, fac_test, vis, ang, nc_total_test);

	fclose(pfacvis);
	fclose(pfang);

	desalloue_float(vis);
	desalloue_float(ang);
    desalloue_fface(fac,nbfac);
    desalloue_fface(fac_test,nbfac_test);

	printf("Fin du traitement df_visib_distance\n");
	exit(0);
}

/*___________________________________________________________________________________*/
void traitement_faces(nbfac, fac, nbfac_test, fac_test, vis, ang, nc_total)
int nbfac;
struct modelisation_face *fac;
int nbfac_test;
struct modelisation_face *fac_test;
float *vis, *ang;
int  nc_total;

{ 
int nf,noc,comptc,i,j,k,jecompte;
struct contour *pcont, *pcont_test;
struct circuit *cir_emetteur, *cir_test;
double xg, yg, zg;

comptc=0;
for(nf=0;nf<nbfac;nf++) //passe en revue chaque contour de geometrie � traiter
  {	
	noc=0;
    pcont=(fac+nf)->debut_projete;
    while(pcont) 	/* Balayage des contours de la face courante */   
      { 
		obs.xo=0; obs.yo=0; obs.zo=0; 

		cir_emetteur=pcont->debut_support;   /* Pointeur sur le contour courant */

		centre_de_gravite(cir_emetteur, &obs.xo, &obs.yo, &obs.zo);
		noc++; 
		comptc++;
		//printf("Face numero %d, contour numero %d >>>> indice contour interne %d\n", (fac+nf)->nofac_fichier, noc, comptc); 


       /* initialise nc_total valeurs des distances */
		for (i=0;i<nc_total;i++) ang[i]=0.;

		/* lit une ligne du fichier de visibilit� correspondant a nc_total contours des faces test */
		lect_ff_param(pfacvis, vis, nc_total, comptc-1, -1);

		/* si Visibilite avec les contours des faces tests */
		/* calcul des distances du contour courant emetteur */
		/* vers les contours des autres faces du fichier */
		jecompte=0;
        for(j=0;j<nbfac_test;j++)
		  {
	        pcont_test=(fac_test+j)->debut_projete;
            while(pcont_test) 	/* Balayage des contours de la face test */   
             { 
		       cir_test=pcont_test->debut_support;   /* Pointeur sur le contour courant */
			   if(vis[jecompte])
			     { 
				   centre_de_gravite(cir_test, &xg, &yg, &zg);

				   xg=xg-obs.xo;
				   yg=yg-obs.yo;
				   zg=zg-obs.zo;

				   /* Calcul de la distance entre centres de gravite */
				   /* du patch observateur et du patch observe */

				   ang[jecompte] = (float)(sqrt(xg*xg + yg*yg + zg*zg));
				   //printf("dist %f\n",ang[jecompte]);
			     }
			   jecompte++;
		       pcont_test=pcont_test->suc; /* Passage au contour suivant de la face test courante */
		     }
		  }

		// ecrit les nb_contour_face_test valeurs de distance
        fwrite(ang,sizeof(float),nc_total,pfang);

        // ecrit les nb_contour_face valeurs de face_test
		/*
        for(k=0;k<nc_total;k++)
          {  printf("%f ",ang[k]);
		     fwrite(ang+k,sizeof(float),1,pfang);
          }
		 */

		pcont=pcont->suc; /* Passage au contour suivant de la face courante */
	  }	
   }

}

/*_____________________________________________________________________*/
/* Lecture des facteurs de visibilite dans fichier */

void lect_ff_param(pff, ligne_ff, nb_contour, i, j)
FILE *pff;
float *ligne_ff;
int nb_contour;
int i; /* Ligne */
int j; /* colonne */
/* Lit une ligne specifiee dans un fichier de facteurs */
/* arranges en Fij , i et j variant de 0 a nb_contour-1 */
/* si j positif, donne la seule valeur Fij */
/* sinon donne toute la ligne i */
{int f;
fseek(pff,(i*nb_contour)*sizeof(float),SEEK_SET);
fread(ligne_ff, sizeof(float), nb_contour, pff);

/* if (j<0)
	{printf("Ligne %d ", i+1);
	for (f=0;f<nb_contour;f++)
		printf(" %f ", ligne_ff[f]);
	printf("\n"); 
	}
else
	{printf("Valeur F de %d vers %d: %f\n", i+1,j+1,ligne_ff[j]); 
	}
*/

}

/*___________________________________
int nbcontours_total(fac, nbfac)
struct modelisation_face *fac;
int nbfac;
// Permet de recuperer le nombre de contours total 
//d'un tableau de facew 
{ int comptc = 0;
  int nf;

  for(nf=0;nf<nbfac;nf++) 
	{ comptc+=nb_contour_face(fac+nf,1);
    }

  return comptc;
}
*/

/*_________________________________________________________________
void centre_de_gravite(pcir, xg, yg, zg)
struct circuit *pcir;
double *xg, *yg, *zg;
{
 int k;
 if (pcir->nbp <2)
  { printf("Erreur calcul centre de gravite\n");
    exit(0);
  }
 *xg=0.0; *yg=0.0; *zg=0.0;
 for(k=0;k<pcir->nbp-1;k++) 
   { 
	*xg+=pcir->x[k];
    *yg+=pcir->y[k];
    *zg+=pcir->z[k];
   }

 *xg=*xg/(pcir->nbp-1);
 *yg=*yg/(pcir->nbp-1);
 *zg=*zg/(pcir->nbp-1);

}
*/

/*_________________________________________________________________*/
void format_usage()
{
   printf("\n   format d'entree des parametres \n\n");
   printf("df_visib_distance  fichier_des_obs_in(.cir)  fichier_test_in(.cir)\n"); 
   printf("fichier_facteurs_visibilite_in(.vis)  fichier_facteurs_distance_out(.dis)\n\n");
	
   exit(0);
}

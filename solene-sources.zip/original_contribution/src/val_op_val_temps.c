/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

//  val_op_val_temps


// D.GROLEAU novembre 2002
// D.GROLEAU mai 2003 
//		2eme fichier val non fonction du temps
// //
// effectue op�ration sur  2 descripteurs fonction du temps
// ex :global = direct + diffus
// fait l'op�ration des .val correspondant sur une p�riode avec un pas de temps

#include<solene.h>

// DECLARE FUNCTIONS

void format_entree();
void met_extension ();
void test_min_max();


/*_________________________________________________________________*/
main(argc,argv) 
int argc;char **argv;

{
FILE *fpval1,*fpval2,*fpvalr;
char buf[256],nom_val1[256],nom_val2[256],nom_valr[256],*s_dir,c;
int hh1,hh2,pas,minute;
int nbfac,nomax,nofac,nbcont;
int i,j,gk,temps,indice;
double vmin_gen,vmax_gen;

float xh_heure;
int h_heure,m_minute ,nb_pas;
char extension[32];
int op;
int fonction_temps;

double valeur,v1,v2;

 if(argc != 8 && argc != 9) { format_entree(); exit(0); }

	s_dir=(char *)getenv("PWD");

printf("Commande : val_op_val_temps\n\n");

fonction_temps=1;

// argv[1] et argv[3] contiennent les noms des fichiers val 1 et 2
		 printf("%s \n",buf);

	// lit operateur
	sscanf(argv[2],"%c",&c);
	printf("operateur : %s\n",argv[2]);
	if(c=='+') op=1;
	else if(c=='-') op=2;
	else if(c=='x') op=3;
	else if(c=='/') op=4;
	else format_entree();
		
	//  heures debut et fin , pas
         sscanf(argv[4],"%d%c%d",&hh1,&c,&minute);
         hh1=hh1*60+minute;
         sscanf(argv[5],"%d%c%d",&hh2,&c,&minute); 
         hh2=hh2*60+minute;
         sscanf(argv[6],"%d%c%d",&pas,&c,&minute);
         pas=pas*60+minute;
         printf(" de hh1 %d a hh2 %d par pas de %d\n",hh1,hh2,pas);

 
 /* calcul du nombre de pas */
   nb_pas=1;
   i=hh1;
   while(i<hh2)
    { nb_pas++;
      i=i+pas;
    }
printf("nb de pas %d\n",nb_pas);

// fichier val2 operande fonction ou non du temps
 if (argc==9) 	sscanf(argv[8],"%d",&fonction_temps);


/* constitue le fichier .val correspondant */
/* avec les valeurs en fonction du temps */

 printf(" Cree les fichiers de Descripteur resultat  : \n");

  temps=hh1;
   for(i=0;i<nb_pas;i++)
     { 
		xh_heure= (float)temps/60;
		h_heure= (int) xh_heure;
		m_minute= temps-h_heure*60;
		printf(" heure_minute %d H %d\n",h_heure,m_minute);

		// appel extension 
		  met_extension(temps,extension);

		// ouvre val 1 en Input
		  sprintf(buf,"%s%s",argv[1],extension);
          compose_nom_complet(nom_val1,s_dir,buf,"val");
          printf("  descripteur val1 : %s \n", nom_val1);
	      if ((fpval1=fopen(nom_val1,"r"))==NULL)
            { 
				printf("\n  impossible ouvrir %s\n\n", nom_val1); 
				exit(0);
            }

		// ouvre val 2 en Input
		  if(fonction_temps)
		  { sprintf(buf,"%s%s",argv[3],extension);
		  }
		  else
		  { sprintf(buf,"%s",argv[3]);
		  }
          compose_nom_complet(nom_val2,s_dir,buf,"val");
          printf("  descripteur val2 : %s \n", nom_val2);
	      if ((fpval2=fopen(nom_val2,"r"))==NULL)
            { 
				printf("\n  impossible ouvrir %s\n\n", nom_val2); 
				exit(0);
            }

		// ouvre val resultat en Output
		  sprintf(buf,"%s%s",argv[7],extension);
          compose_nom_complet(nom_valr,s_dir,buf,"val");
          printf("			descripteur val resultat : %s \n", nom_valr);
	      if ((fpvalr=fopen(nom_valr,"w"))==NULL)
            { 
				printf("\n  impossible ouvrir %s\n\n", nom_valr); 
				exit(0);
            }

		// Lit en effectuant l'op�ration et �crit le resultat
			fscanf(fpval1,"%d %d %lf %lf",&nbfac,&nomax,&vmin_gen,&vmax_gen);	
			fscanf(fpval2,"%d %d %lf %lf",&nbfac,&nomax,&vmin_gen,&vmax_gen);
			
			/* calcule min_max pour le pas i  */
			vmin_gen=10000000.; vmax_gen=-vmin_gen;

			fprintf(fpvalr,"%6d %6d %15.4f %15.4f\n",nbfac,nomax,vmin_gen,vmax_gen);	


        indice=0;
        for(j=0;j<nbfac;j++)
           { 
			fscanf(fpval1,"\n%c%d%d\n",&c,&nofac,&nbcont);
			fscanf(fpval2,"\n%c%d%d\n",&c,&nofac,&nbcont);
			fprintf(fpvalr,"f%d %d\n",nofac,nbcont);
				 for(gk=0;gk<nbcont;gk++) 
					{ fscanf(fpval1,"%lf\n",&v1);
					  fscanf(fpval2,"%lf\n",&v2);
					 if(op==1)
					 {
					  valeur= v1 + v2; 
					 }
					 else if(op==2)
					 {
					  valeur= v1 - v2; 
					 }
					 else if(op==3)
					 {
					  valeur= v1 * v2; 
					 }
					 else if(op==4)
					 {
					  if(v2) valeur= v1 / v2; 
					  else valeur = 99999999;
					 }

					 test_min_max(valeur,&vmin_gen,&vmax_gen);
					 fprintf(fpvalr,"%12.4f\n",valeur);

					 indice++;
					}
            }
		fclose(fpval1);
		fclose(fpval2);
        rewind(fpvalr);
   		fprintf(fpvalr,"%6d %6d %15.4f %15.4f\n",nbfac,nomax,vmin_gen,vmax_gen);	
		fclose(fpvalr);
		
		temps+=pas;
      }  // fin for i (nb de pas)

creer_OK_Solene();
printf("\nFin val_op_val_temps\n\n");

}


/*_________________________________________________________________*/
void test_min_max(x,vmin_gen,vmax_gen)
double x;
double *vmin_gen,*vmax_gen;
{
		 if(x < *vmin_gen) *vmin_gen =  x;
         if(x > *vmax_gen) *vmax_gen =  x;
}


//_____________________________________________________
void met_extension (temps,extension)
int temps;
char *extension;
{  // modele energie diffuse meteo
	float xh_heure;
	int h_heure, m_minute;

		xh_heure= (float)temps/60;
		h_heure= (int) xh_heure;
		m_minute= temps-h_heure*60;
		//printf(" heure_minute %d H %d\n",h_heure,m_minute);
		//construit extension pour fichier val heure
		if(h_heure>=10 && m_minute >=10)
		{
		 sprintf(extension,"_%dH%d",h_heure,m_minute);
		}
		else if(h_heure>=10 && m_minute <10)
		{
		 sprintf(extension,"_%dH0%d",h_heure,m_minute);
		} 
		else if(h_heure<10 && m_minute >=10)
		{
		 sprintf(extension,"_0%dH%d",h_heure,m_minute);
		} 
		else if(h_heure <10 && m_minute <10)
		{
		 sprintf(extension,"_0%dH0%d",h_heure,m_minute);
		} 
		//printf("extension %s\n",extension);
}


/*_________________________________________________________________*/

void format_entree()
{
 printf("\n la fonction val_op_val_temps\n a comme parametre ENTREE :\n\n");
 printf("\t nom_generique fichier val 1\n");
 printf("\t operateur (+ - x /)\n"); 
 printf("\t nom_generique fichier val 2\n");
 printf("\t hh1:mm1\n");
 printf("\t hh2:mm2\n");
 printf("\t pas(hh:mn)\n");

 printf("\n comme parametres en SORTIE:\n\n");
 printf("\t nom_generique fichier resultat\n");

 printf("\n comme parametre OPTIONNEL en ENTREE:\n\n");
 printf("\t fonction_temps\n");

 printf("\nNOTA: Le programme ajoute une extension _hhHmm au nom de fichier correspondant � l'heure du calcul\n");
 printf("\nNOTA: Si fonction_temps =1 (d�faut), le fichier val2 est fonction du temps\n");
 printf("\n      si 0, le fichier val2 est le meme quelque soit le temps\n");
 printf("\n");
 exit(0);
  
}

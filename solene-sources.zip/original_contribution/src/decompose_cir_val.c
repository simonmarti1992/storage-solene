/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */
 
/*
cc decompose_cir_vals.c   solutile.o geomutile.o -o decompose_cir_vals lib_solene_94.o -lm
*/

/***********************************************************************/
/* decompose le fichier de faces "fichier_3D" en zones homogenes pour  */
/* pour une pers.                          			       */
/* Les fichiers de sortie sont un fichier (.eta) et un fichier (.val)  */
/***********************************************************************/
#include<solene.h>
//include</home/cerma.0/marenne/newsolene/solene.h>
#include<ctype.h>


FILE *pmas,*ficetat;

int nb_etat;
struct modelisation_face *ff;
int nbff,nbfmax;

/*_________________________________________________________________*/
main(argc,argv)			
 int argc;char **argv;
{int i;

  char buf[256],argument[256],*s_dir;
  double vmin,vmax;
  char chbuf[5000];        //SII

        if(argc<4)format_entree_decompose_cir_vals();

         s_dir=(char *)getenv("PWD");
  printf("\n DECOMPOSITION DE CHAQUE FACE EN SURFACES HOMOGENES \n");
  printf(" et creation de descripteurs associes\n");
       sprintf(buf,"decompose_face ");

      for(i=1;i<argc;i++)sprintf(buf,"%s %s",buf,argv[i]);
      printf("\n commande = %s \n",buf);
      system(buf);

/* test si decompose_face s'est bien passe */
		
	  // SII Modif DFA 18-04-2006
		sprintf(chbuf,"%s\\OK_SOLENE",getenv(SOLENETEMP));
     	if(test_si_nom_existe(chbuf))
		{
			sprintf(chbuf,"del %s\\OK_SOLENE",getenv(SOLENETEMP));
			system(chbuf);
		}
		else { printf("\n PB execution de decompose_face\n");
	      exit(0);
	     }
		//Fin Modif SII

      nb_etat=argc-3;

printf(" sortie \n");

    /* constitue les fichiers (.val) a partir du fichier (.eta) */
    compose_nom_complet(buf,s_dir,argv[argc-1],"eta");
    if((ficetat=fopen(buf,"r"))==NULL)
           {printf("\n impossible ouvrir %s\n",buf); exit(0);}

   /* lit le fichier .eta */
     fscanf(ficetat,"%d %d %d",&nbff,&nbfmax,&nbcontour);
     ff=alloue_face(nbff,35);
 printf(" lit le fichier (.eta)nb_etat= %d nbff = %d \n",nb_etat,nbff);
      alloue_contour(ff,nbff,nb_etat);
      lit_fic_etat_contour(ficetat,ff,nbff,nb_etat);
      fclose(ficetat);


 /* ecrit les fichiers .val */
 vmin=0.;  vmax=1.;
 for(i=0;i<nb_etat;i++)
     {sprintf(argument,"%s_%d",argv[argc-1],i);
      compose_nom_complet(buf,s_dir,argument,"val");
      pmas=fopen(buf,"w");
      fprintf(pmas,"%5d %5d% 15.3f %15.3f",nbff,nbfmax,vmin,vmax);
      traite_etat(ff,nbff,i);
      fclose(pmas);
     }
  desalloue_fface(ff,nbff);

  creer_OK_Solene();


}

/*_________________________________________________________________*/
traite_etat(ff,nbff,kk)
int nbff,kk;
struct modelisation_face *ff;
{int i;
 struct contour *pcont;

         for(i=0;i<nbff;i++)
           { pcont=(ff+i)->debut_projete;  
             fprintf(pmas,"\nf%d %d",(ff+i) ->nofac_fichier,nb_contour_face(ff+i,1)); 
             while(pcont)	   
               {fprintf(pmas,"\n"); 
                if(pcont->etat[kk]==1)fprintf(pmas," 1");
		else fprintf(pmas," 0");
  		pcont=pcont->suc;
	       }
	   }
}
/*_________________________________________________________________*/
int lit_fic_etat_contour(pfic,f1,nbf1,no_etat)
FILE *pfic;
struct modelisation_face *f1;
int nbf1,no_etat;
{ char c;
 int k,kk,nbcont,i,j;
 struct contour *pc;

 for(k=0;k<nbf1;k++)
	{fscanf(pfic,"\n%c%d %d",&c,&kk,&nbcont);
	(f1+k)->nofac_fichier=kk;
        /*printf("\n face no %d   \n",(f1+k)->nofac_fichier); */
 	 (f1+k)->debut_projete=alloue_contour(1);
	 pc=(f1+k)->debut_projete;
         for(i=0;i<nbcont;i++)
            {if(i){pc->suc=alloue_contour(2); pc=pc->suc;}
	     fscanf(pfic,"\n%c",&c);
	     for(j=0;j<no_etat;j++)
	         {fscanf(pfic,"%d",&kk);
		  pc->etat[j]=kk; 
                 }
            }
        }
}

/*_________________________________________________________________*/
format_entree_decompose_cir_vals()
{
  printf("\n   format d'entree des parametres \n\n");
  printf(" *decompose_cir_vals* fichier_orig(.cir) fichier1(.cir)  fichier 2(.cir) ----- fichier_sortie(.cir .val) \n\n");
  exit(0);
}

/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */
 
/*__________________________________________________________________________________________________________*/
/*                         Confort thermique																*/
/*Ce programme permet le calcul de l'indice de confort thermique PMV (ainsi que le PPD)						*/
/*tel qu'il est d�fini par Fanger [Thermal comfort 1970]. Les param�tres en entr�e sont						*/ 
/*							*/
/*la temp�rature,la vitesse et l'humidite relative de l'air � la station meteo,								*/
/*les temp�ratures moyennes radiantes (issue du programme proc_out_mrt)										*/
/*En consid�rant un individu "standard" de 1.7 m et de 70 Kg (surface de Dubois = 1.8 m2)					*/
/*il suffit de donner la valeur de m�tabolisme (relatif � l'activit�) exprim�e en met (1 met =58.2 W/m2)	*/
/*ainsi que la r�sitance thermique des v�tements exprim�e en clo (1 clo = 0.155 m2 �C/W).					*/
/*Dans ce m�me programme nous avons calculer la quantit� de sueur �vacu�e par un individu sur 1 heure		*/
/*en faisant un bilan thermique bas�e sur les travaux r�alis�s par l'Universit� de S�ville					*/	
/*(principe de calcul d�velop� pour de l'EXPO'92).															*/
/* Enfin nous calculons l'indice DISC (selon Berglund 1984)	

// SI Temp_radiante =0 ; les valeurs rendues de confort =999	


// http://atmos.es.mq.edu.au/~rdedear/test/runn.html  site ou calcul confort											*/
/*__________________________________________________________________________________________________________*/
/* 		Jerome Vinet, CERMA, EAN,juin 1999		*/

//   Rappel ligne de compilation
//cc confort_ext.c ./UTILS/solutile.o ./UTILS/geomutile.o ./UTILS/lib_solene_94.o -o confort -lm


/* Fichiers inclus */
#include<solene.h>

/*Declarations

/* Pointeur global de fichier pour facteurs de forme */
FILE *fp;

/* Procedures auxiliaires */
void	usage();
void	lecture();
int		sauve_tableau();

/* Calculs intermediares */
double pression_sat();
double calc_hconv();
double calc_hconv_sev();
double calc_fcl();
double calc_fpcl();
double calc_temp_peau1();
double calc_temp_peau2();
double calc_temp_vet();
double calc_temp_vet_sev();
/* Calculs*/
void calc_PMV();
void calc_sueur();

main(argc,argv)           
int argc;
char **argv;

{

/* DECLARATIONS DE VARIABLES */

	/** DONNEES **/

	/*** Microclimat ***/
char nom_temp_air[256]; /* fichier (lu) pour la temperature de l'air */
double *temp_air;/* valeurs */
char nom_humidite_air[256]; /* fichier (lu) pour l'humidite de l'air */
double *humidite_air;/* valeurs */
char nom_vitesse_air[256]; /* fichier (lu) pour la vitesse de l'air */
double *vitesse_air;/* valeurs */
char nom_temp_mrt[256]; /* fichier (lu) pour les temperatures radiantes moyennes */
double *TMR; /* valeurs */

	/*** Individu ***/

double metabolisme; /* valeur du metabolisme */
double vet; /* valeur de la resistance thermique des vetements */

	/*** Divers ***/

const double stefan = 5.67e-8;

	/** RESULTATS **/
char nom_PMV[256]; /* fichier (cree) des indices PMV */
double *PMV; /* valeurs */
char nom_PPD[256]; /* fichier (cree) des indices PPD */
double *PPD; /* valeurs */
char nom_sueur[256]; /* fichier (cree) des quantites de sueur regulatrice evacuee par un individu en une heure */
double *sueur; /* valeurs */
char nom_DISC[256]; /* fichier (cree) des quantites de sueur regulatrice evacuee par un individu en une heure */
double *DISC; /* valeurs */

	/* variables auxiliaires */
int im = 1;		/* impression=oui */
int nbfac;		/* Nombre de faces dans modele geometrique */
int nb_contour_total; 	/* Nombre de contours total */
int *nb_cont_face;	/* Nombre de contours par face */
int *numero_face;	/* Numeros affectes aux faces */

int gi;
int gk;
int numero_contour;
int nofac;
int nbcont;
double val_min, val_max;
double *auxiliaire;
int test_erreur = 0;
int OK_sauvegarde = 0;

/** (pour compatibilite avec programmes existants) **/

char *s_dir;
char c;
/* Pointeur de fichier pour lecture nombre de contours */
FILE *pfic;
/* Pointeurs de fichier pour ecriture descripteurs resultats */
FILE *pfic_PMV;
FILE *pfic_PPD;
FILE *pfic_sueur;
FILE *pfic_DISC;

	
	/* DEBUT PROG */
s_dir=(char *)getenv("PWD");

if(argc != 11) usage();

 
	/* lecture parametres commande */

compose_nom_complet(nom_temp_air,s_dir,argv[1],"val");
printf("  Temperature de l'air : %s \n", nom_temp_air);

compose_nom_complet(nom_humidite_air,s_dir,argv[2],"val");
printf("  Humidite relative de l'air : %s \n", nom_humidite_air);

compose_nom_complet(nom_vitesse_air,s_dir,argv[3],"val");
printf("  Vitesse de l'air: %s \n", nom_vitesse_air);

compose_nom_complet(nom_temp_mrt,s_dir,argv[4],"val");
printf("  Temperature moyenne radiante : %s \n", nom_temp_mrt);

sscanf(argv[5],"%lf", &metabolisme);
printf("  Metabolisme: %f\n", metabolisme);

sscanf(argv[6],"%lf", &vet);
printf("  Resistance thermique des vetements: %f\n", vet);

printf("  ---------------------------------\n");

compose_nom_complet(nom_PMV,s_dir,argv[7],"val");
printf("  Valeurs de PMV calculees : %s \n", nom_PMV);

compose_nom_complet(nom_PPD,s_dir,argv[8],"val");
printf("  Valeurs de PPD calculees : %s \n", nom_PPD);

compose_nom_complet(nom_sueur,s_dir,argv[9],"val");
printf("  Quantites de sueur par individu et par heure (C): %s\n", nom_sueur);

compose_nom_complet(nom_DISC,s_dir,argv[10],"val");
printf("  Valeurs des indices DISC (C): %s\n", nom_DISC);

printf("  ---------------------------------\n");


	/* LECTURE D'UN FICHIER .val POUR NBRE DE CONTOURS TOTAL */
	/* Lecture du fichier des temperatures d'air */
nb_contour_total=0;
if ((pfic=fopen(nom_temp_air,"r"))==NULL)
            	{ 
		printf("\n  *** impossible ouvrir %s ***\n\n", nom_temp_air); 
		goto fin;
            	}
fscanf(pfic,"%d %d %lf %lf",&nbfac,&nomax,&val_min,&val_max);	
numero_face=(int *)malloc(nbfac*sizeof(int));
nb_cont_face=(int *)malloc(nbfac*sizeof(int));
for(gi=0;gi<nbfac;gi++)
		{
		fscanf(pfic,"\n%c%d%d\n",&c,&nofac,&nbcont);
		numero_face[gi]=nofac;
		nb_cont_face[gi]=nbcont;
		nb_contour_total+=nbcont;
		auxiliaire=(double *)malloc(nbcont*sizeof(double));
		for(gk=0;gk<nbcont;gk++)
			fscanf(pfic,"%lf\n",auxiliaire+gk);
		free(auxiliaire);
		}
	
fclose(pfic);
printf("nombre total de contours: %d\n", nb_contour_total);	

	/* allocations memoire */

temp_air = alloue_double(nb_contour_total,2);
humidite_air = alloue_double(nb_contour_total,3);
vitesse_air = alloue_double(nb_contour_total,4);
TMR = alloue_double(nb_contour_total,5);
PMV = alloue_double(nb_contour_total,6);
PPD = alloue_double(nb_contour_total,7);
sueur = alloue_double(nb_contour_total,8);
DISC = alloue_double(nb_contour_total,9);

printf("\n\nOK toutes allocations\n\n");


	/*** LECTURE DES FICHIERS POUR DONNEES ***/
lecture(nom_temp_air,temp_air); /* Lecture du fichier des temperatures d'air */
lecture(nom_humidite_air,humidite_air); /* Lecture du fichier des humidites d'air */
lecture(nom_vitesse_air,vitesse_air);	/* Lecture du fichier des vitesses d'air */
lecture(nom_temp_mrt,TMR);	/* Lecture du fichier des temperatures radiantes moyennes */

				/***___________***/
				/***           ***/
				/*** RESULTATS ***/
				/***___________***/


	/*** CALCUL DES PMV,PPD ***/

printf("\nDebut du calcul PMV, PPD...");
printf("\n");

metabolisme = metabolisme*58.2; /* conversion des met en W/m2 */


for (numero_contour = 0;numero_contour<nb_contour_total;numero_contour++)
{
	// calcul seulement si tempRadiante #0
 if(TMR[numero_contour])
	calc_PMV(metabolisme,temp_air[numero_contour],humidite_air[numero_contour],vet,TMR[numero_contour],vitesse_air[numero_contour],PMV+numero_contour,PPD+numero_contour);
 else
 { PMV[numero_contour] =999.;
   PPD[numero_contour] =999.;
 }
}
/*** SAUVEGARDE DES PMV, PPD, PMV*, PPD* ***/
	
	/* ecriture resultats des PMV */
	printf("\n>>> Sauvegarde finale des PMV  ... \n");
	
	OK_sauvegarde = sauve_tableau(pfic_PMV,nom_PMV,nbfac,nomax,nb_contour_total,numero_face,nb_cont_face,PMV);
	if (!OK_sauvegarde)
		{printf("*** Attention, probleme de sauvegarde pour les PMV calculees. ***\n");
		 goto fin;}

	/* ecriture resultats des PPD */
	printf("\n>>> Sauvegarde finale des PPD  ... \n");
	
	OK_sauvegarde = sauve_tableau(pfic_PPD,nom_PPD,nbfac,nomax,nb_contour_total,numero_face,nb_cont_face,PPD);
	if (!OK_sauvegarde)
		{printf("*** Attention, probleme de sauvegarde pour les PPD calculees. ***\n");
		 goto fin;}


	/*** CALCUL sueur et DISC ***/

printf("\nDebut du calcul Sueur...");
printf("\n");

for (numero_contour = 0;numero_contour<nb_contour_total;numero_contour++)
{
 if(TMR[numero_contour])
	calc_sueur(metabolisme,temp_air[numero_contour],humidite_air[numero_contour],vet,TMR[numero_contour],vitesse_air[numero_contour],sueur+numero_contour,DISC+numero_contour);
 else
 { sueur[numero_contour] =999.;
   DISC[numero_contour] =999.;
 }
}
	/*** SAUVEGARDE sueur et DISC ***/
	
	/* ecriture resultats des quantites de sueur */
	printf("\n>>> Sauvegarde finale des quantites de sueur ... \n");
	
	OK_sauvegarde = sauve_tableau(pfic_sueur,nom_sueur,nbfac,nomax,nb_contour_total,numero_face,nb_cont_face,sueur);
	if (!OK_sauvegarde)
		{printf("*** Attention, probleme de sauvegarde pour les quantit�s de sueur calculees. ***\n");
		 goto fin;}

	/* ecriture resultats des DISC */
	printf("\n>>> Sauvegarde finale des DISC ... \n");
	
	OK_sauvegarde = sauve_tableau(pfic_DISC,nom_DISC,nbfac,nomax,nb_contour_total,numero_face,nb_cont_face,DISC);
	if (!OK_sauvegarde)
		{printf("*** Attention, probleme de sauvegarde pour les DISC. ***\n");
		 goto fin;}

fin:;
printf("Fin\n\n");


desalloue_double(temp_air);
desalloue_double(humidite_air);
desalloue_double(vitesse_air);
desalloue_double(TMR);
desalloue_double(PMV);
desalloue_double(PPD);
desalloue_double(sueur);
desalloue_double (DISC);
		
}


/********************** PROCEDURES *********************************/

/*_______________________*/
/* Format de la fonction */
/*_______________________*/

void usage()
	{
  	printf("\n format d'entree des parametres:\n\n");
  	printf("\t *Confort thermique en exterieur* \n");
	printf("\t temp_air(.val) humidite_relative_air(.val) vitesse_air(.val) temp_moyenne_radiante(.val) \n");
	printf("\t metabolisme_en_met (1met=58.2W/m2:repos) vetements_en_clo (0.5:tenue ete, 1:tenue int hiver) \n");
	printf("\t PMV(.val) PPD(.val) sueur(.val) DISC(.val) \n\n");
  	exit(0);
	}
/*_________________________________________________________________*/
/* Ouverture et lecture fichier au "bon" format (.val) et remplissage tableau 'valeur' */
void lecture(char *nom, double *valeur)
{
	FILE *pfic;

	if ((pfic=fopen(nom,"r"))==NULL)
       {printf("\n  impossible ouvrir %s\n\n", nom); 
		exit(0);}
	
	lect_fic_val(pfic,valeur);

	fclose(pfic);

}

/*_________________________________________________________________*/
/* Lecture fichier au "bon" format et remplissage tableau 'valeur' */
/*_________________________________________________________________*/

void lect_fichier(pfic, nbfac, nomax, valeur)
FILE *pfic;
int nbfac;
int nomax;
double *valeur;
{ double val_min;
  double val_max;
  int num_cont, num_face, num_cont_liste;
  int nofac, nbcont_face;
  char c;

  fscanf(pfic,"%d %d %lf %lf",&nbfac,&nomax,&val_min,&val_max);
  num_cont_liste = 0;
  for(num_face=0;num_face<nbfac;num_face++)
	{
	fscanf(pfic,"\n%c%d%d\n",&c,&nofac,&nbcont_face);
	for(num_cont=0;num_cont<nbcont_face;num_cont++)	
		{	
		fscanf(pfic,"%lf\n",valeur+num_cont_liste);
		num_cont_liste++;
		}
	}
}

/*_______________________________________________________________________________________________*/
/* Sauvegarde d'un tableau de valeurs (descripteurs) associees a un fichier de faces et contours */
/*_______________________________________________________________________________________________*/

int sauve_tableau(pf, nom_fichier, nbfac, nomax, nb_contour_total, numero_face, nb_cont_face, tab)

FILE *pf;
char *nom_fichier;
int nbfac;
int nomax;
int *numero_face;
int *nb_cont_face;

double *tab;
{ 
double mini, maxi;
int i, k, num;
int sauvOK = 1;

if ((pf= fopen(nom_fichier,"w"))==NULL)
	sauvOK = 0;
else
	{mini=maxi=tab[0];
	for(i=0;i<nb_contour_total;i++)
		{
		if(tab[i]<mini) mini=tab[i];
		if(tab[i]>maxi) maxi=tab[i];
		} 

	fprintf (pf,"%5d %5d %8.3lf %8.3lf\n", nbfac, nomax, mini, maxi);   

	num=0;
	for(i=0;i<nbfac;i++)
		{
		fprintf (pf,"f%d %d\n",numero_face[i],nb_cont_face[i]);
		for(k=0;k<nb_cont_face[i];k++)
			{
			fprintf (pf,"    %8.3f\n",tab[num]);
			num++;
			}
		}
	fclose(pf);
	}
return sauvOK;
}


/*___________________________________________________________________________________*/
/* Calcul des pressions de vapeur d'eau a partir de la formule de Magnus [Guyot 1996]*/
/* Pression exprim�e en Pascal														 */
/*___________________________________________________________________________________*/

double calc_pression_sat(T)

double T; /* temperature de l'air ou de la peau */

{
	double exp; /* exposant utilise dans le calcul*/

	exp = 7.45*T/(235+T);
	return (double)(6.1070*pow(10,exp)*100);
}

/*_______________________________________________________________*/
/* Temperature de la peau estim�e par Fanger (1)				 */
/*_______________________________________________________________*/

double calc_temp_peau1(metabolisme)

double metabolisme;

{
	return (35.7-0.0275*metabolisme);		
}

/*_______________________________________________________________*/
/* Temperature de la peau estim�e  par S�ville (2)				 */
/*_______________________________________________________________*/

double calc_temp_peau2(metabolisme,temp_air,vet)

double metabolisme;
double temp_air;
double vet;
{
	return (29.55+0.196*temp_air-1.064*(metabolisme/58.2)*(1-0.295*vet));
}


/*______________________________________________________________________________*/
/* Rapport de la surface du corps habill� � la surface du corps nu selon Fanger */
/*______________________________________________________________________________*/

double calc_fcl(vet)

double vet;

{
	if (vet*0.155<=0.078) 
		return (double)(1+1.29*vet*0.155);
	else 
		return (double)(1.05+0.645*vet*0.155);
}


/*_____________________________________________*/
/* coefficient d'echange convectif selon Fanger*/
/* en condition de convection mixte ou forc�e  */
/*_____________________________________________*/


double calc_hconv (vitesse_air)

double vitesse_air;

{
		return (double) 12.1*pow(vitesse_air,0.5);
	
}

/*_____________________________________________*/
/* coefficient d'echange convectif				*/
/*  selon les travaux de Seville			   */
/*_____________________________________________*/


double calc_hconv_sev(vitesse_air)

double vitesse_air;
{
	return (double) (8.6*pow(vitesse_air,0.53));
}

/*________________________________________________________________*/
/* coefficient de permeation des vetements dans travaux de Seville*/
/*________________________________________________________________*/

double calc_fpcl(vitesse_air,vet)


double vitesse_air;
double vet;

{	
	double hconv_sev;	/*Seville*/

	hconv_sev = calc_hconv_sev (vitesse_air);
	return (double) (1/(1+0.143*hconv_sev*vet));

}

/*________________________________________________________*/
/* temperature des vetements d'apr�s les travaux de Fanger*/
/*________________________________________________________*/

double calc_temp_vet(temp_air,metabolisme,vet,TMR,vitesse_air)

double temp_air;
double metabolisme;
double vet;
double TMR;
double vitesse_air;

{
	double fcl;
	double hconv;
	double temp_vet; /* temperature de vetement calculee */
	double temp_vet_iter; /* temperature de vetement pour iteration */
	double delta_temp; /* difference de temperature */
	double abs_delta = 0.2; /*valeur absolue de difference de temperature */
	const double delta_temp_lim = 0.1;  /* difference max de temperature entre 2 iterations */

		temp_vet_iter=temp_air; /*Initialisation*/
		fcl = calc_fcl(vet);
		hconv = calc_hconv(vitesse_air);
		
		
		while (abs_delta > delta_temp_lim)
		
		{	
			temp_vet = 35.7-(0.028*metabolisme)-(vet*0.155)*(3.96e-8*fcl*(pow((273+temp_vet_iter),4)-pow((273+TMR),4))+fcl*hconv*(temp_vet_iter-temp_air));
			delta_temp = temp_vet_iter-temp_vet;
			abs_delta=fabs(delta_temp);
			temp_vet_iter = (temp_vet_iter+temp_vet)/2; /* faire attention au calcul divergent*/
		}	

	return temp_vet;
}

/*_________________________________________________________*/
/* temperature des vetements d'apr�s les travaux de Seville*/
/*_________________________________________________________*/

double calc_temp_vet_sev(metabolisme,temp_air,vet,TMR,vitesse_air)

double metabolisme;
double temp_air;
double vet;
double TMR;
double vitesse_air;

{
	double temp_peau2;
	double hconv_sev;	/*Seville*/
	double fcl;
	double temp_vet_sev;
	double conv;
	double GLO;
	double hrad;
	double temp_vet_iter; /* temperature de vetement pour iteration */
	double delta_temp; /* difference de temperature  */
	const double delta_temp_limite = 0.1;  /* difference max de temperature entre 2 iterations */
	double abs_delta = 0.2; /* valeur absolue de la difference de temperature  */

	const double abs_sol_vet = 0.7; /*coefficient d'absorption solaire des vetements*/
	const double emis_vet = 0.9; /*coefficient d'�missivite des vetements */

		temp_vet_iter=temp_air; /*Initialisation*/
		temp_peau2=calc_temp_peau2(metabolisme,temp_air,vet);
		hconv_sev=calc_hconv_sev (vitesse_air);
		fcl = calc_fcl(vet);
		
		while (abs_delta > delta_temp_limite)
		
		{
		
		conv = hconv_sev*fcl*(temp_vet_iter-temp_air);
		hrad = 5.9 * emis_vet;
		GLO = hrad*fcl*(temp_vet_iter-TMR);
		temp_vet_sev=temp_peau2-0.155*vet*(conv+GLO);
		delta_temp = temp_vet_sev-temp_vet_iter;
		abs_delta = fabs(delta_temp);

		temp_vet_iter=(temp_vet_iter+temp_vet_sev)/2; /* faire attention au calcul divergent*/
		}
		
	return temp_vet_sev;
}


/*______________________________*/
/* Calcul  PMV, PPD, PMV*, PPD*	*/
/*______________________________*/

void calc_PMV(metabolisme,temp_air,humidite_air,vet,TMR,vitesse_air,PMV,PPD)

double metabolisme;
double temp_air;
double humidite_air;
double vet;
double TMR;
double vitesse_air;
double *PMV;
double *PPD;


{	double temp_vet;
	double hconv;
	double fcl;
	double pression_air;
	double pertes_par_diff;
	double pertes_par_sudation;
	double pertes_resp_latente;
	double pertes_resp_sensible;
	double pertes_par_ray;
	double pertes_par_conv;
	double coeffA;
	double coeffB;
	double stefan = 5.67e-8;
	double feff = 0.95; /* pour un homme debout */
	double emis_vet = 0.9; /*coefficient d'�missivite des vetements */


		coeffA = 0.303*exp(-0.036*metabolisme)+0.028;
//		printf ("coeffA: %f\n", coeffA);

		pression_air = calc_pression_sat(temp_air)*humidite_air/100;
//		printf ("temperature de l'air : %f\n", temp_air);
//		printf ("pression saturante de l'air: %f\n", pression_air);
		pertes_par_diff = 3.05e-3*(5733-6.99*metabolisme-pression_air);
//		printf ("pertes par diffusion: %f\n", pertes_par_diff);
		pertes_par_sudation = 0.42*(metabolisme-58.15);
//		printf ("pertes par sudation: %f\n", pertes_par_sudation);
		pertes_resp_latente = 1.7e-5*metabolisme*(5867.-pression_air);
//		printf ("pertes par respiration latente: %f\n", pertes_resp_latente);
		pertes_resp_sensible = 0.0014*metabolisme*(34.-temp_air);
//		printf ("pertes par respiration sensible: %f\n", pertes_resp_sensible);
		fcl = calc_fcl(vet);
//		printf ("fcl: %f\n", fcl);
		hconv=calc_hconv (vitesse_air);
//		printf ("vitesse de l'air: %f\n", vitesse_air);
//		printf ("hconv: %f\n", hconv);
		temp_vet = calc_temp_vet(temp_air,metabolisme,vet,TMR,vitesse_air);
//		printf ("TMR: %f\n", TMR);
//		printf ("temperature des vetements: %f\n", temp_vet);		
		pertes_par_ray = 3.96e-8*fcl*(pow((273+temp_vet),4)-pow((273+TMR),4));
//		printf ("Pertes par rayonnement: %f\n", pertes_par_ray);
		pertes_par_conv = fcl*hconv*(temp_vet-temp_air);
//		printf ("Pertes par convection: %f\n", pertes_par_conv);
	
		*PMV = (coeffA*(metabolisme-pertes_par_diff-pertes_par_sudation-pertes_resp_latente-pertes_resp_sensible-pertes_par_ray-pertes_par_conv));
//		printf ("PMV: %f\n", *PMV);

		coeffB = 0.03353*pow(*PMV,4)+0.2179*pow(*PMV,2);
		*PPD = 100.-95.*exp(-coeffB);
	
}
	
/*__________________________________*/
/* Calcul  SUEUR (d'apr�s Seville)	*/
/*__________________________________*/

void calc_sueur(metabolisme,temp_air,humidite_air,vet,TMR,vitesse_air,sueur,DISC)

double metabolisme;
double temp_air;
double humidite_air;
double vet;
double vitesse_air;
double TMR;
double *DISC;
double *sueur;

{	double hconv_sev;
	double temp_vet_sev;
	double temp_peau2;
	double fcl;
	double fpcl;
	double pression_air; /* pression partielle de la vapeur d'eau de l'air */
	double pression_sat_air; /* pression de vapeur d'eau de l'air � saturation */
	double pression_sat_peau; /* pression de vapeur d'eau saturante � la tempertaure de la peau */
	double pertes_par_diff;
	double pertes_resp_latente;
	double pertes_resp_sensible;
	double pertes_par_conv;
	double ray_GLO;
	double hrad;
	double sueur_calc;
	double Emax;
	double Epeau;
	double w;
	
	

	const double abs_sol_peau = 0.7; /*coefficient d'absorption solaire de la peau*/
	const double emis_vet = 0.9; /*coefficient d'�missivite des vetements */
	const double trans_sol_vet = 0.1; /*coefficient de transmission solaire des vetements*/
	const double abs_sol_vet = 0.7; /*coefficient d'absorption solaire des vetements*/


		pression_sat_air = calc_pression_sat(temp_air)/1000.; /* pression en kPa */
//		printf ("pression de l'air a saturation: %f\n", pression_sat_air);
		pression_air = pression_sat_air*(humidite_air/100.); /* pression en kPa */
//		printf ("pression partielle de l'air : %f\n", pression_air);
		temp_peau2 = calc_temp_peau2(metabolisme,temp_air,vet);
//		printf ("Temperature de la peau: %f\n", temp_peau2);
		pression_sat_peau = calc_pression_sat(temp_peau2)/1000.; /* pression en kPa */
//		printf ("pression saturante a la temperature de la peau : %f\n", pression_sat_peau);
		pertes_resp_latente = 0.0173*metabolisme*(5.87-pression_air);
//		printf ("pertes_resp_latente : %f\n", pertes_resp_latente);
		pertes_resp_sensible = 0.0014*metabolisme*(34.-temp_air);
//		printf ("pertes_resp_sensible : %f\n", pertes_resp_sensible);
		fcl = calc_fcl(vet);
//		printf ("fcl : %f\n", fcl);
		hconv_sev = calc_hconv_sev (vitesse_air);
//		printf ("hconv_sev: %f\n", hconv_sev);
		temp_vet_sev = calc_temp_vet_sev(metabolisme,temp_air,vet,TMR,vitesse_air);
//		printf ("Temperature des vetements: %f\n", temp_vet_sev);
		pertes_par_conv = fcl*hconv_sev*(temp_vet_sev-temp_air);
//		printf ("pertes_par_conv  : %f\n", pertes_par_conv );
		hrad = 5.9 * emis_vet;
//		printf ("TMRcor  : %f\n", TMRcor );
		ray_GLO = hrad*fcl*(temp_vet_sev-TMR);
//		printf ("ray_GLO : %f\n", ray_GLO);
		pertes_par_diff = 4+1.2*(pression_sat_peau-pression_air);
//		printf ("pertes_par_diff : %f\n", pertes_par_diff);

		

		sueur_calc = metabolisme-pertes_par_conv-ray_GLO-pertes_resp_latente-pertes_resp_sensible-pertes_par_diff;
		
		if (sueur_calc<0)
			sueur_calc = 0;
		else
			sueur_calc = sueur_calc*1.8*60./41.; /* sueur exprimee en gramme par heure par individu */
		
		*sueur = sueur_calc;

//		printf ("Sueur  : %f\n", *sueur );

		fpcl = calc_fpcl(vitesse_air,vet);
		Emax = 16.7*hconv_sev*fpcl*(pression_sat_peau-pression_air);
		Epeau = pertes_par_diff+sueur_calc*41./(60.*1.8);
		w = Epeau/Emax;

		*DISC = 4.13*w+0.013;  /* Indice formule par Berglund */
//		printf ("DISC  : %f\n", *DISC );
		

}

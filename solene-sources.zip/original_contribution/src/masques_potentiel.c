/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/*
cc masques_potentiel.c solutile.o geomutile.o solaire.o lib_solene_94.o -o masques_potentiel -lm
*/

#include<solene.h>
#include<ctype.h>
#include <stdlib.h>
#include <sys/stat.h>

int nbf1,numax;
FILE *pf1,*pf2;
double calcul_val_face();

double latitude;

struct position { double x;
	          double y;
		  double z;
	          int heure;
		  struct position *suc;
		};

#define NB_DATE_MAX 100
struct position *mois_fin[NB_DATE_MAX],*position_deb;
int hlever[NB_DATE_MAX],mlever[NB_DATE_MAX],hcoucher[NB_DATE_MAX],mcoucher[NB_DATE_MAX];
int pas;

int nb_date,jour[NB_DATE_MAX],mois[NB_DATE_MAX];

/*_________________________________________________________________*/
main(argc,argv) 
int argc;char **argv;
{int i,j;
 char c[2],*s_dir,buf[512];
 double englob[10];

 if(argc<6)format_entree_soleil_potentiel();

   printf("\n CALCUL DE L'ENSOLEILLEMENT POTENTIEL \n");

	//s_dir=(char *)getenv("PWD");

	s_dir="";
	sprintf(buf,"%s.cir",argv[1]);
  //compose_nom_complet(buf,s_dir,argv[1],"cir");
  if((pf1=fopen(buf,"r"))==NULL)
      { printf("\n impossible ouvrir %s\n",buf);
        exit(0);
      }
  printf(" %s \n",buf);

     sscanf(argv[2],"%lf",&latitude);
    /* lit le pas d'evaluation en minute */
     sscanf(argv[3],"%d",&pas);

  /* lit fichier.cir */

  lit_en_tete(pf1,&nbf1,&numax,englob);

  /* open fichier out .mas */
		sprintf(buf,"%s.mas",argv[4]);
      //compose_nom_complet(buf,s_dir,argv[4],"mas");
      if((pf2=fopen(buf,"w"))==NULL)
          {printf("\n impossible ouvrir %s\n",buf); exit(0);}

/* lit les dates a examiner */

    nb_date=0;
    for(i=5;i<argc;i++)
	{  	 
	  sscanf(argv[i],"%d%c%d",jour+nb_date,c,mois+nb_date);
          if(c[0]!='/')format_entree_soleil_potentiel();
	  if(jour[nb_date]<1|| jour[nb_date]>31)
		{ printf(" Erreur dans le jour : %d/%d\n",jour[nb_date],mois[nb_date]);
		  format_entree_soleil_potentiel();
		}
	  if(mois[nb_date]<1||mois[nb_date]>12)
		{ printf(" Erreur dans le mois : %d/%d\n",jour[nb_date],mois[nb_date]);
		  format_entree_soleil_potentiel();
		}
	  printf("   simule pour le jour: %d/%d\n",jour[nb_date],mois[nb_date]);
	  nb_date++;
	}
    if(nb_date==0)
	{ printf("\n   AUCUNE DATE a simuler\n");
	  format_entree_soleil_potentiel();
	}

     enregistre_positions_du_soleil();
/*
     liste_position_du_soleil();  
     exit(0);
*/

   /* ecrit en tete .mas */
	fprintf(pf2,"%d ",nb_date);
	for(i=0;i<nb_date;i++)
	  { fprintf(pf2," %d %d",jour[i],mois[i]);
	  }
        fprintf(pf2,"\n");

        fprintf(pf2,"%5d %5d\n",nbf1,numax);

  /* realise traitement */

  	traite_masc_potent();

//printf("\n");
creer_OK_Solene();
	printf("\n\nFin du Traitement masques_potentiel\n");
}
/*_________________________________________________________________*/
int traite_masc_potent()

{int k,i,nbtrou,nbcontour,nofac,nbp,kk,j;
 char c[2];
 double norm[3],x,y,z,val;

      for(k=0;k<nbf1;k++)
         {
	  fscanf(pf1,"\n%c%d %d",c,&nofac,&nbcontour);
	   //printf("  lit la face no %d\n ",nofac);
	  fprintf(pf2,"f%d %d\n",nofac,nbcontour);

          fscanf(pf1,"%lf %lf %lf",norm,norm+1,norm+2);

	  val=calcul_val_face(norm,nbcontour);

       	  for(i=0;i<nbcontour;i++)
      	     { /* printf(" \n contour no %d ",i); */
	      fscanf(pf1,"\n%c%d",c,&nbtrou);
              fscanf(pf1,"%d",&nbp);
	      for(kk=0;kk<nbp;kk++)
		fscanf(pf1,"%lf%lf%lf",&x,&y,&z);
	      for(j=0;j<nbtrou;j++)
                {fscanf(pf1,"\n%c",c);
                 fscanf(pf1,"%d",&nbp);
	         for(kk=0;kk<nbp;kk++)
			fscanf(pf1,"%lf%lf%lf",&x,&y,&z);
	        }

             }
           }
}
/*_________________________________________________________________*/

double calcul_val_face(norm,nbcontour) 
double *norm;
{
 double val,heure;
 int i,deb,debut,j,k,rendu,heure_cour;
 int nbper[NB_DATE_MAX],dh[NB_DATE_MAX*2],dm[NB_DATE_MAX*2],fh[NB_DATE_MAX*2],fm[NB_DATE_MAX*2];
 struct position *pt;
 
 deb=0; rendu=0;
 for(i=0;i<nb_date;i++)
	{nbper[i]=0;
	 if(i==0)pt=position_deb;
	 else pt=mois_fin[i-1]->suc;
	 debut=0;
	  while(pt!=mois_fin[i]->suc)
		{val=norm[0]*pt->x+norm[1]*pt->y+norm[2]*pt->z;
		 if(val>0&&deb==0)
	   	    {nbper[i]++;
		     if(debut==0)
			{dh[rendu]=hlever[i];
			 dm[rendu]=mlever[i];
			 debut=1;
			}
		     else
			{heure=pt->heure-pas/2;
			 dh[rendu]=heure/60;
		         dm[rendu]=heure-dh[rendu]*60;
			}
		         deb=1;
                    }
		  else if(val<0&&deb==1)
		    {heure=heure_cour+pas/2;
		     fh[rendu]=heure/60;
		     fm[rendu]=heure-fh[rendu]*60;

		     deb=0;  rendu++;
		    }
                 heure_cour=pt->heure;  debut=1; 
		 pt=pt->suc;
		}
	 if(deb==1)
		    {fh[rendu]=hcoucher[i];
		     fm[rendu]=mcoucher[i];
		     deb=0; rendu++;
		    }

	}
/* ecrit le fichier .mas */
  for(i=0;i<nbcontour;i++)
	{fprintf(pf2,"c\n");
         rendu=0;
	 for(k=0;k<nb_date;k++)
	    {fprintf(pf2,"%2d",nbper[k]);
             for(j=0;j<nbper[k];j++)
   		{ fprintf(pf2," %2d %2d %2d %2d 100",dh[rendu],dm[rendu],fh[rendu],fm[rendu]);
		  rendu++;
   		}
	     fprintf(pf2,"\n");
	    }
	}

}
/*_________________________________________________________________*/

enregistre_positions_du_soleil()

{struct position *pt;
 double xyzsol[3],a,h,heure_lever,lati,declin;
 int hdeb,hfin,mindeb,heur;
 int i,j;
 int  nojour,nomois,hh,minute;

 lati=angrad(latitude);

 position_deb=NULL;
 for(j=0;j<nb_date;j++)
   {/* info date */
    nomois=mois[j];
    nojour=jour[j];
/*printf("%d/%d\n",nojour,nomois);*/
    i=numjour(nojour,nomois);
    i=(i-1)%365+1;     
    declin=declinaison(i);   
    heure_lever=anglev(declin,lati);

    anglehoraire_EN_heure_et_minute(heure_lever,&hdeb,&mindeb);
    hlever[j]=hdeb; mlever[j]=mindeb;
    hdeb=hdeb*60+mindeb; hfin=1440-hdeb;
    hcoucher[j]=hfin/60; mcoucher[j]=hfin-hcoucher[j]*60;
/*
printf(" deb,fin = %d %d - %d:%d %d:%d\n",hdeb,hfin,hlever[j],mlever[j],hcoucher[j],mcoucher[j]);
*/

    heur=0; while(heur<=hdeb)heur=heur+pas;
    while(heur<hfin)
	{hh=heur/60; minute=heur-hh*60;
	 if(position_deb==NULL)
		{position_deb=(struct position *)malloc(sizeof(*pt));
		 pt=position_deb;
		}
	 else{ pt->suc=(struct position *)malloc(sizeof(*pt));
               pt=pt->suc;
             }
         info_solaire(latitude,nojour,nomois,hh,minute,xyzsol,&a,&h);
	 pt->x=xyzsol[0]; pt->y=xyzsol[1]; pt->z=xyzsol[2];
	 pt->heure=hh*60+minute; 
         heur+=pas;
	}
   mois_fin[j]=pt;
   }
   pt->suc=NULL;

}

/*_________________________________________________________________*/
int format_entree_soleil_potentiel()
{
  printf("\n   *masques_potentiel*   fichier_entree(.cir)  latitude  precision_minute fichier_out(.mas) jour/mois [jour/mois] ...\n\n");
  exit(0);
}
/*_________________________________________________________________*/

liste_position_du_soleil()
{int i;
 struct position *pt;
 
 printf("\n position du soleil\n\n");
 for(i=0;i<nb_date;i++)
	{if(i==0)pt=position_deb;
	 else pt=mois_fin[i-1]->suc;
	 printf("\n mois %d %ld\n\n",i,pt);
	  while(pt!=mois_fin[i]->suc)
		{printf("     %lf %lf %lf \n",pt->x,pt->y,pt->z);
		 pt=pt->suc;
		}

	}
}

/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */


/*

cc transmet_flux.c    pers_util.o solutile.o geomutile.o face_op_face.o solaire.o  poly_op_poly.o  traite.o  -lm


  D. GROLEAU
  J. VINET
  D. GROLEAU modifi� 18 d�c 2002
  D. GROLEAU modifi� 18 d�c 2003  (met extension ..H.. aux fichiers de transmission r�sultat)

  //si recompile, v�rifier nb de param�tres de coplanaire (sens de la normale): OK dec2005


  on entre les taux de transmission des vitres du masque (0 si opaque)
*/

/* Calcul de la transmission au travers des surfaces non opaques dans une scene (vitre ou arbre)            
                                                                                         
 On d�termine pour chaque face du fichier_in, le flux transmis � travers des masques qui 
 sont dans fichier_masque, les valeurs du masque (0 pour opaque et 1 pour plus ou moins  
 transparent) sont dans fichier.val                                                      
 On peut tenir compte des transparences des parois vitr�es en fonction de l'angle d'incidence 
 On determine le masque par rapport au centre de gravite de chaque contour de chaque face
 pour evaluer les flux solaires transmis � un temps T                                                                         
 ou pour une journee entre un instant initial et un instant final avec un pas de temps dT

 En sortie on r�cup�re la valeur du  coef transmission, on peut donc ainsi multiplier    
 cette valeur par celle du flux incident afin de calculer le flux incident transmis.
 Le coefficient relatif � la transmission est globale, il correspond � la valeur du flux solaire
 re�u � l'ombre de l'abre divis� par le flux solaire re�u par une surface �quivalent au soleil.


  ATTENTION les faces vitres sont definies deux fois (chacun avec sa transparence);                  
  une fois avec la normale dans un sens ,une autre avec la normale dans le sens oppos�

   Pour les arbres volume, la face est d�finie une seule fois; leur mettre les normales habituelles 
   et leur attribuer la transmission de l'arbre

     			    // attention, on conserve les faces transparentes qui regardent vers le ciel
					// donc on inverse la normale des faces transparentes
					// seulement pour le test de visibilit�


 */
// pour le moment ne calcule pas les flux transmis 
//(bien que  tout soit l� pour le faire avec les "valeurs de flux  Perrin de Brichambaut"


// d�clarations

#include<solene.h>


void	calcul_min_max();
void	donnees_du_jour();
float	evalue_flux();
void	format_entree();
void	imprime_en_tete_face();
void	imprime_flux();
void	inverse_normale();
void	lit_val_opaque_vitre();
void	masque_sol_transmis();
void	met_extension ();
void	ouvre_fic_resultat_val();
int		point_dans_face();
void	reecrit_les_min_max();
float	taux_transmis_vitre();
void	traite_transmis();



extern int option_calcul_z;   // option CALCUL du Z ds FACE-OP-FACE 1=oui 
                              // utilise ds singul.c epure_polygone       
							  // et dans face_op_face.c                   
extern double coef_discol;

#define FI 1
#define TYPE_CIEL 2
#define NB_MAX_FIC_VAL 96     // on impose pour un nombre de fichiers de transmission egal a 50 

struct sauve_normale { double vn[3];
					 } ;

struct solval {  int	heure,minute;
				 double xyzsol[3];
				 double rnormal,b,g,diffus;
				 int	soleil_la;
			   } *solv;

double	tgvis,covis,sinvis;
float	*val_min,*val_max,*valeur;

FILE	*pval[NB_MAX_FIC_VAL]; // fichier de transmission

 
//_____________________________________________________________________
// programme principal

main(argc,argv)           

// d�clarations

int argc;char **argv;
{int	i,jj,k,noc;
 char	nom_in[256],nom_masc[256],nom_val[256],c;    


 FILE	*pfic;
 struct modelisation_face *fac ; // g�om�trie � traiter
 int	nbfac,nomax;

 FILE	*pfic1;
 struct modelisation_face *fac1; // g�om�trie masque
 int 	nbfac1;
 struct sauve_normale	*s_norm;

 double englob[10];
 struct contour *pcont;
 struct circuit *pcir;

 double	*vitre; // opaque ou non opaque

 int 	mois,jour,minute,nb_pas;
 int	hh1,hh2,pas; // hh1 et hh2 heure de d�but et de fin en minutes, pas intervalle de tps en minutes
 double latitude,ang,vnf[3]; 

 char	nom_transmis[256];  // fichier resultats 
 
 int	nb_type_fic=1; // si on ne consid�re que la transmission


  printf("Fonction Solene : transmet_flux\n\n");
// test en lecture des donn�es
 if (argc != 10) format_entree();
   
   // initialisation 

   singularite=0; non_singularite=0; nb_etat=0;
   pb_masque=0; colle_max=coef_discol*DISCOL;
   pi=4*atan(1.);

   ang=89.9;
   ang=pi*ang/180.;
   tgvis=tan(ang); covis=cos(ang); sinvis=sin(ang);


   // lecture des param�tres d'entr�e 
   
   compose_nom_complet(nom_in,"",argv[1],"cir");
   printf("\n Fichier a traiter : %s \n",nom_in);

   compose_nom_complet(nom_masc,"",argv[2],"cir");
   printf(" Fichier masque : %s \n",nom_masc);

   compose_nom_complet(nom_val,"",argv[3],"val");
   printf(" Fichier val : %s \n",nom_val);

   sscanf(argv[4],"%lf",&latitude);
   printf(" Latitude : %lf \n",latitude);
   if(latitude<-66 || latitude>66) 
	   { printf("   *** -66 < latitude < 66 ***\n");
	     exit(0);
	   }
	
   latitude=latitude*pi/180.; // la latitude entre en degr� et est transform�e en radian

   sscanf(argv[5],"%d%c%d",&jour,&c,&mois);
   if(c!='/')format_entree();
   printf("\n   Date = %d/%d\n",jour,mois);

   sscanf(argv[6],"%d%c%d",&hh1,&c,&minute); // instant initial transform� en minutes
   if(c != ':')format_entree();
   hh1=hh1*60+minute;

   sscanf(argv[7],"%d%c%d",&hh2,&c,&minute); // instant final transform� en minutes
   if(c != ':')format_entree();
   hh2=hh2*60+minute;

   sscanf(argv[8],"%d%c%d",&pas,&c,&minute); // pas de temps transform� en minutes
   if(c != ':')format_entree();
   pas=pas*60+minute;

   printf("     hh1 hh2 pas %d %d %d\n",hh1,hh2,pas);

   compose_nom_complet(nom_transmis,"",argv[9],"val");
   printf(" Fichier val OUT : %s \n",nom_transmis);

   //calcul du nombre de pas et test d�passement
   
   nb_pas = 1;
   i = hh1;
   while (i<hh2)
         { nb_pas++;
           i+= pas;
         }
   printf("nb de pas theoriques %d\n",nb_pas);

   if(nb_pas > NB_MAX_FIC_VAL)
    { printf("il faut nbpas < NB_MAX_FIC_VAL\n\n"); 
      exit(0);
    }

  // pr�pare les donn�es du jour et �value nb de pas de tps 
   
	donnees_du_jour(latitude,mois,jour,nb_pas,hh1,hh2,pas);

  // ouvre les fichiers � traiter 
  // et �crit en_t�te fichier r�sultat 
       if((pfic1=fopen(nom_in,"r"))==NULL)
            { printf("\n impossible ouvrir %s\n",nom_in); exit(0);
            }

       if((pfic=fopen(nom_masc,"r"))==NULL)
            { printf("\n impossible ouvrir %s\n",nom_masc); exit(0);
            }

  // lecture en_t�te pfic1 

       lit_en_tete(pfic1,&nbfac,&nomax,englob);
       printf("Traite %d faces\n",nbfac);

  // lit le fichier masque  pfic 
  // alloue fac1 pour traitement 

       lit_en_tete(pfic,&nbfac1,&i,englob);
       printf("avec Masque de %d faces\n\n",nbfac1);
       fac1=alloue_face(nbfac1,35);
       lit_fic_cir3d(pfic,nbfac1,fac1);
       fclose(pfic);

  // alloue vitre pour traitement parois opaques(0)/vitr�es(#1)

       vitre=alloue_double(nbfac1,123);
	   lit_val_opaque_vitre(nom_val,vitre);


   // Ouvre le fichiers flux transmis  r�sultat
   // et alloue les valeurs que pour un contour (soit nb_pas)
   // Les valeurs sont ecrites dans des .val apr�s traitement de chaque contour

	  ouvre_fic_resultat_val(nb_pas,argv[9],nbfac,nomax,hh1,pas);


  // sauvegarde les normales initiales du masque 

      s_norm=(struct sauve_normale *) malloc(nbfac1*sizeof(*s_norm));

	  for(i=0; i<nbfac1; i++)
	  { (s_norm+i)->vn[0] = (fac1+i)->vnorm[0]; 
	    (s_norm+i)->vn[1] = (fac1+i)->vnorm[1]; 
	    (s_norm+i)->vn[2] = (fac1+i)->vnorm[2]; 
	  }

   // observateur regarde vers le haut � la verticale de l'oeil 
       obs.x=0; obs.y=0; obs.z=-1; 


      // traitement pour chaque contour de chaque face de nom_in 
	printf("Traitement en cours ...\n");

       fac=alloue_face(1,34);

       for(i=0;i<nbfac;i++) // Boucle sur les faces
           { lit_fic_cir3d(pfic1,1,fac);
			 //printf(" traite face no %d \n",fac->nofac_fichier);

			 // imprime ds les .val en_t�te de face
			 imprime_en_tete_face(fac,nb_pas);

			 // normale de la face pour tester si eclair�e ou non
			 vnf[0]=fac->vnorm[0]; 
			 vnf[1]=fac->vnorm[1]; 
			 vnf[2]=fac->vnorm[2]; 

	         noc=0;
             pcont=fac->debut_projete; 
             while(pcont) // Boucle sur les contours	   
               { pcir=pcont->debut_support;
                 obs.xo=0; obs.yo=0; obs.zo=0; 
                 for(k=0;k<pcir->nbp-1;k++) 
                       { obs.xo+=pcir->x[k];
                         obs.yo+=pcir->y[k];
                         obs.zo+=pcir->z[k];
						}
                 obs.xo=obs.xo/(pcir->nbp-1);
                 obs.yo=obs.yo/(pcir->nbp-1);
                 obs.zo=obs.zo/(pcir->nbp-1);
                 noc++;

				 // APPEL PROCEDURE A CHAQUE CONTOUR Attention � ajuster si n�cessaire
				 for (jj=0; jj< nb_pas * nb_type_fic ;jj++) 
					valeur[jj]=(float)1.;

                 masque_sol_transmis(nbfac1,fac1,fac,nb_pas,vnf,s_norm,vitre);

                 pcont=pcont->suc;
               } 
             desalloue_contour_face(fac);
           }




	   // FIN

	   //d�sallocation des fichiers

       desalloue_fface(fac,1);
       desalloue_fface(fac1,nbfac1);
       desalloue_int(vitre);
	   desalloue_float(valeur);
       free(s_norm);
	   free(solv);
	   
       fclose(pfic1);

	   // r�ecrit les min_max

	   reecrit_les_min_max(nbfac,nomax,nb_pas);
	   desalloue_float(val_min);
	   desalloue_float(val_max);


	   creer_OK_Solene();

       printf("Fin du Traitement Transmet_flux\n");
}
// Fin du programme principal


/*_________________________________________________________________________*/

// les sous-programmes


/*_________________________________________________________________________*/
void masque_sol_transmis(nbfac1,fac1,fac0,nb_pas,vnf,s_norm,vitre)
int		nbfac1,nb_pas;
struct	modelisation_face *fac1; // g�om�trie masque
struct	modelisation_face *fac0; // face en traitement
double	*vnf;
struct  sauve_normale *s_norm;
double	*vitre;

{  int i;
   int indice; // indice d'iteration pour le traitement des valeurs (transmission, ...)
   int    avec_meme_normale;

   avec_meme_normale = 1;

// TRANSFORMATION fichier "masque" et COUPE PYRAMIDE , si vu 
     tranfo();

   /* ancien
  
       for(i=0;i<nbfac1;i++)
	   { 		  
	      if(!(coplanaire(fac0,1,fac1+i,1,0.00001)))
              { 
				// si c'est une vitre , on la consid�re toujours potentiellement visible
				 if(vitre[i] || visible_pers(fac1+i,1))
                   { 
                     tran_face(fac1+i,1,fac1+i,0);
                     tran_normale((fac1+i)->vnorm);
										 
                     if((fac1+i)->debut_dessin) 
                        { calcul_d_du_plan(fac1+i,0);
						  //liste_face(fac1+i,0);
                          face_dans_vision(fac1+i,0);
                        }
                   }
               }
         }
	fin ancien */

// NOUVEAU
       for(i=0;i<nbfac1;i++)
		{ //printf(" Examine avec face %d\n",(fac1+i)->nofac_fichier);
		  //if((fac1+i)->nofac_fichier != fac0->noface_fichier)
	      if(!(coplanaire(fac0,1,fac1+i,1,0.0001,avec_meme_normale,1000)))
              { //printf(" qui ne sont pas coplanaire\n");
			    // attention, on conserve les faces transparentes qui regardent vers le ciel
			    // donc on inverse la normale des faces transaparentes
			    // seulement pour le test de visibilit�
			    if(vitre[i])
				{ inverse_normale(fac1+i);
				}
				
				if(visible_pers(fac1+i,1))
                { 
					 //printf(" avec face Visible  %d\n",(fac1+i)->nofac_fichier);
					 if(vitre[i])
					 { inverse_normale(fac1+i);
					 }


                     tran_face(fac1+i,1,fac1+i,0);
                     tran_normale((fac1+i)->vnorm);
                     if((fac1+i)->debut_dessin) 
                     { calcul_d_du_plan(fac1+i,0);
                       face_dans_vision(fac1+i,0);
					 }
                 }
                 else
				 { 
				   if(vitre[i])
				   { inverse_normale(fac1+i);
				   }
				 }
               }
          }

// FIN NOUVEAU




 // PERSPECTIVE 
       init_fenetre_affichage();
       for(i=0;i<nbfac1;i++)
	  { if((fac1+i)->debut_dessin)
                pers_conic_face(fac1+i,0);
	  }

 
  // r�ajuste la fen�tre � l'angle de vision 
       fen_aff[0]=-tgvis; fen_aff[1]=-tgvis; 
       fen_aff[3]=tgvis; fen_aff[4]=tgvis; 
       cal_fen_aff();
              // attention si angvis proche de 90 
              // on �vite fen_aff[6]=0 
       if(fen_aff[6]<0.008) fen_aff[6]=0.008;

  // NORMALISATION 
       for(i=0;i<nbfac1;i++)
			{ if((fac1+i)->debut_dessin)
               { normalise_face(fac1+i,0);
               }
			}

  // TRAITE LA TRANSMISSION  

        traite_transmis(nbfac1,fac1,nb_pas,vnf,vitre,s_norm);


	// Ecriture dans fichiers .val pour TRANSMISSION

		indice =0;
		for(i=0;i<nb_pas;i++)
			{ 
				fprintf(pval[indice],"%f\n",valeur[indice]);
				calcul_min_max(valeur[indice],val_min+indice,val_max+indice);
				indice++;
			}

   // Ecriture dans fichiers .val pour ....

  //  r�inverse la normale et d�sallocation face->dessin  
        for(i=0;i<nbfac1;i++)
		{ // restaurer la normale
          (fac1+i)->vnorm[0] = (s_norm+i)->vn[0];
          (fac1+i)->vnorm[1] = (s_norm+i)->vn[1];
          (fac1+i)->vnorm[2] = (s_norm+i)->vn[2];
              
		  // d�sallouer la face en perspective
           if((fac1+i)->debut_dessin)
             { desalloue_chaine_contour((fac1+i)->debut_dessin);
              (fac1+i)->debut_dessin=NULL;
             }
        }

}

/*__________________________________________________________________*/
void traite_transmis(nbfac1,fac1,nb_pas,vnf,vitre,s_norm)
int		nbfac1;
struct	modelisation_face	*fac1;
double  *vnf;
int		nb_pas;
double		*vitre;
struct	sauve_normale	*s_norm;
{
 int	i,ang;
 double xyzt[3],xp,yp,zp,cos_ang_inc,bidon;

 
 // boucle d'�valuation
   for(i=0;i<nb_pas;i++)
     {
          
	  if((solv+i)->soleil_la)
	  {
		    // TRAITE  POSITION du soleil i
            // TEST SI FACE AU SOLEIL ang_inc >0 

		cos_ang_inc=vincid(vnf,(solv+i)->xyzsol,&bidon);
		ang=(int)angdeg(acos(cos_ang_inc));

		if(cos_ang_inc > 0) 
	    { tranp((solv+i)->xyzsol[0],(solv+i)->xyzsol[1],(solv+i)->xyzsol[2],xyzt,xyzt+1,xyzt+2);

              // coupe par pyramide de vision: retient ou non le point Soleil
              if(xyzt[2]<0 && fabs(xyzt[0]/xyzt[2])<tgvis && fabs(xyzt[1]/xyzt[2]) < tgvis) 
                {         
                    // AU SOLEIL, MET SOLEIL EN PERSPECTIVE
                  xp=-xyzt[0]/xyzt[2];
                  yp=-xyzt[1]/xyzt[2];
                  zp=0;
                  normalise_point(xp,yp,zp,&xp,&yp,&zp);

                   // TEST MASQUE ET TRANSPARENCE 
				   // ET EVALUE FLUX INCIDENT     

		          valeur[i] = evalue_flux(nbfac1,fac1,xp,yp,(solv+i)->xyzsol,i,vitre,s_norm);
                }

	          else
			  { valeur[i] = (float)0.;   // face non eclairee 
			  }
         }
	    else 
		{
          valeur[i] = (float)0.; // face � l'ombre
		}
	  }

	  else
	  { // SOLEIL NON LEVE
          valeur[i] = (float)0.; // face � l'ombre
	  }
         
     } // fin du FOR

}

/*__________________________________________________________________*/
float evalue_flux(nbfac1,fac1,xp,yp,xyz,ind,vitre,s_norm)
int		nbfac1;
struct	modelisation_face	*fac1;
double 	xp,yp,*xyz;
int		ind;
double   *vitre;
struct	sauve_normale	*s_norm;

{
 float 	taux_transmission;
 int	i,angle_incidence;
 double	vnn[3],cos_ang_inc,bidon;

 // le point est au soleil : ind, indice  du temps soleil
 // test si dans masque

 taux_transmission=(float)1.;
 for(i=0;i<nbfac1;i++)
 
 { if((fac1+i)->debut_dessin)
       { if(point_dans_face(xp,yp,fac1+i,0))
	     {  
	       if(vitre[i]==0) 
	         {  //  ds face Opaque, alors a l'ombre
	           return((float)0.);
	         }
	       else    
	         {  // si ds face Vitr�e, alors Transmission du flux
	            // �valuer taux de transmission

			  // on consid�re que le vitrage re�oit toujours le soleil
		      vnn[0] = (s_norm+i)->vn[0];  
		      vnn[1] = (s_norm+i)->vn[1];
		      vnn[2] = (s_norm+i)->vn[2];
   			  cos_ang_inc=fabs(vincid(vnn,xyz,&bidon));

			  angle_incidence=(int)angdeg(acos(cos_ang_inc));
	          taux_transmission*=taux_transmis_vitre(vitre[i],angle_incidence);
				  
				  // continue si vitrage lui-m�me masque 
			 }  
		                        
	     }
       }
   }

 return(taux_transmission);
}

/*__________________________________________________________________*/
float taux_transmis_vitre(trans_vitre,angle_incidence)
int angle_incidence;
double trans_vitre;
{ 
 double taux;
    /* type_vitre 1 : simple vitrage                 */
    /* type_vitre 2 : double vitrage                 */
    /* type_vitre 3 : vitrage TOTALEMENT TRANSPARENT */

 // c'est VOLONTAIRE ON NE S'OCCUPE  NI ANGLE INCIDENCE NI TYPE DE VITRAGE pour le moment !
 // on �tudie ici le cas d'un arbre qui ne laisse passer que quelques % du flux incident

 return((float)trans_vitre);

 /*
 if(type_vitre==3) return((float)1.);

 else if(type_vitre==1)
		{
			// dans le cas ou l'arbre transmet ... % apr�s deux faces (racine carr�e de transmission % par face)
		transmission = transmission / 100; // pour transmformer les pourcentages
		transmission = sqrt(transmission);
		return ((float)(transmission));
		}
*/

		/* simple vitrage */
        /* de 0 a 40 deg : 5 85 10 (absorbe transmis reflechi) */
	    /* 60            : 5 80 15                             */
	    /* 70            : 5 70 25                             */
	    /* 90            : 0  0  0                             */
	    /* diffus        : 5 75 20                             */

 /*
  { if(angle_incidence <= 40)
	{ return((float).85);
	}
     else if(angle_incidence <= 60)
	{ taux= (85.-80.)/(60.-40.); // taux par degre 
	  taux= 85-(angle_incidence-40) *taux;
	  return((float)(taux/100.));
	}
     else if(angle_incidence <= 70)
	{ taux= (80.-70.)/(70.-60.); // taux par degre 
	  taux= 80-(angle_incidence-60) *taux;
	  return((float)(taux/100.));
	}
    else if(angle_incidence <=90)
	{ taux= (70.-0.)/(90.-70.); // taux par degre 
	  taux= 70-(angle_incidence-70) *taux;
	  return((float)(taux/100.));
	}
  } 
 */
/*

 else if(type_vitre==2) /* double vitrage */
            /* de 0 a 40 deg : 10 76 14 (absorbe transmis reflechi) */
	        /* 65            : 10 60 30                             */
	        /* 75            : 10 40 50                             */
	        /* 90            :  0  0  0                             */
	        /* diffus        :  9 61 30                             */
/*
 { if(angle_incidence <= 40)
	{ return((float).76);
	}
     else if(angle_incidence <= 65)
	{ taux= (76.-60.)/(65.-40.); // taux par degre 
	  taux= 76-(angle_incidence-40) *taux;
	  return((float)(taux/100.));
	}
     else if(angle_incidence <= 75)
	{ taux= (60.-40.)/(75.-65.); // taux par degre 
	  taux= 60-(angle_incidence-65) *taux;
	  return((float)(taux/100.));
	}
     else if(angle_incidence <=90)
	{ taux= (40.-0.)/(90.-75.); // taux par degre 
	  taux= 40-(angle_incidence-75) *taux;
	  return((float)(taux/100.));
	}
   }


 else return((float)1.);
*/
}

/*__________________________________________________________________*/

void donnees_du_jour(latitude,mois,jour,nb_pas,hh1,hh2,deltapas)

double	latitude;
int		mois,jour;
int		nb_pas,hh1,hh2, deltapas;
{
 int 	i,hdeb,mindeb,hfin,minfin,deb,hh,minu;
 double	declin,heure_lever,ang_hor,b1,g1,azi,haut;
 int	lever_minute,coucher_minute;

 // donn�es pour le jour 
    i=numjour(jour,mois);
    i=(i-1)%365+1;          
    declin=declinaison(i);   
    heure_lever=anglev(declin,latitude);
    anglehoraire_EN_heure_et_minute(heure_lever,&hdeb,&mindeb);
    anglehoraire_EN_heure_et_minute(-heure_lever,&hfin,&minfin);

 // transforme en minutes lever et coucher 
   lever_minute=60*hdeb+mindeb;
   coucher_minute=60*hfin+minfin;

 // �value les valeurs utiles solaires � chaque pas de temps 
 // ALLOUE nb_pas valeurs
   solv=(struct solval *)malloc(nb_pas*sizeof(*solv));
   if(solv ==NULL)
   { printf(" Pb allocation dans transmission.c\n");
     exit(0);
   }

 // point de d�part de investigation

 // �value valeurs utiles solaires au pas de temps

 i=0; deb = hh1;
 do
     {
       if(deb > lever_minute && deb < coucher_minute) 
	   { 
		 (solv+i)->soleil_la=1;
             //  POSITION du soleil
          hh=deb/60; minu=deb%60;
		  (solv+i)->heure=hh; (solv+i)->minute=minu;
          heure_et_minute_EN_anglehoraire(hh,minu,&ang_hor);
          azihaut(latitude,declin,ang_hor,&azi,&haut);
          vcompxyz(azi,haut,(solv+i)->xyzsol);

             //  RAYNT NORMAL
	     (solv+i)->rnormal=rii(haut,TYPE_CIEL);

             //  RAYNT AU SOL
	     b1=rbsolclair(haut,(solv+i)->rnormal);
	     g1=rgsolclair(haut,TYPE_CIEL);

	     if(FI==1)
	      { (solv+i)->b=b1; (solv+i)->g=g1;
	      }
	     else if (FI==0) 
	      { (solv+i)->b=0; (solv+i)->g=b1=0;
	      }
	     else  
	      { (solv+i)->b=rbsol(b1,FI); (solv+i)->g=rgsol(g1,FI);
	      }
	    (solv+i)->diffus=(solv+i)->g-(solv+i)->b;
	   }
	   else
	   { (solv+i)->soleil_la=0;
             //  SOLEIL PAS LA
	   }

	   i++;
       deb+=deltapas;
     } while ( deb <= hh2 && deb < coucher_minute );

}

/*__________________________________________________________________*/
void lit_val_opaque_vitre(nom,vitre)
char 	*nom;
double	*vitre;
{                       // du fichier Masque : nbfac1 faces
 FILE 	*fval;
 char	c;
 int	numax;
 int	i,j, nbface,no_face,nb_contour;
 float	vmin,vmax; 
 float	type_de_face;


 if((fval=fopen(nom,"r"))==NULL)
        { printf("Impossible ouvrir %s",nom);
	      exit(0);
	    }

 fscanf(fval,"%d %d %f %f",&nbface,&numax,&vmin,&vmax);

 for(i=0;i<nbface;i++)
   { fscanf(fval,"\n%c%d %d",&c,&no_face,&nb_contour);

     for(j=0;j<nb_contour;j++)
	  { fscanf(fval,"%f",&type_de_face);
	  }

	 vitre[i]=type_de_face;  //  0 opaque; vitre= valeur de transmission
   }

 fclose(fval);
}


/*__________________________________________________________________*/
void imprime_flux(flux,nb_pas)
float	*flux;
int		nb_pas;
{
 int 	i;

 for(i=0;i<nb_pas;i++)
   { if((solv+i)->minute <10)
     printf("heure : %2d:0%d  flux transmis : %f\n",(solv+i)->heure,(solv+i)->minute,flux[i]);
      else printf("heure : %2d:%d  flux transmis : %f\n",(solv+i)->heure,(solv+i)->minute,flux[i]);
 
   }
}


//______________________________________________________________

void ouvre_fic_resultat_val(nb_pas,nom_trans,nbfac0,nomax0,hh1,pas)
int		nb_pas,nbfac0,nomax0;
char	*nom_trans;
int		hh1,pas;
{
   int	indice; // pour le traitement de la transmission
   char	buf[256],nom_fic[256];
   int	nb_type_fic,i;
   float	mini,maxi;
   char		extension[12];
   int		temps;

  nb_type_fic = 1;  // Transmission, ....

  // ouvre nb_pas fichier.val de r�sultat pour Transmission
  indice=0;
  mini=(float)0. ; maxi=(float)1; // 00.

  temps=hh1;
  for(i=0;i<nb_pas; i++)
   {
	  	// appel extension 
	 met_extension(temps,extension);

     sprintf(buf,"%s%s",nom_trans,extension);
     compose_nom_complet(nom_fic,"",buf,"val");
     printf("Resultat  fichier transmission : %s\n",nom_fic);

     if ((pval[indice]=fopen(nom_fic,"w"))==NULL)
      {
       printf ("\n impossible ouvrir %\n\n",nom_fic); 
	   exit(0);
      }
	  
    fprintf (pval[indice],"%d %d %f %f\n",nbfac0, nomax0, mini,maxi);
    indice++;

	temps+=pas;
   }

  // ouvre nb_pas fichier.val de r�sultat pour ...


 // Alloue les valeurs contenant les nbpas valeurs_min et valeurs_max pour tous les fichiers .val cumul�s

	indice = nb_pas * nb_type_fic;

	val_min = alloue_float(indice,113);
	val_max = alloue_float(indice,1567);
	for (i=0;i<nb_pas;i++)  // initialise pour Transmission
	  {
	    val_min[i]=(float)0.; val_max[i]=(float)1; // 00.
	  }
	// initialiser pour la suite si necessaire

 // Alloue les valeurs � stocker pour un contour

	valeur = alloue_float(indice);
}

//_____________________________________________________

void met_extension (temps,extension)
int temps;
char *extension;
{
	float xh_heure;
	int h_heure, m_minute;
		xh_heure= (float)temps/60;
		h_heure= (int) xh_heure;
		m_minute= temps-h_heure*60;
		//printf(" heure_minute %d H %d\n",h_heure,m_minute);
		//construit extension pour fichier val heure
		if(h_heure>=10 && m_minute >=10)
		{
		 sprintf(extension,"_%dH%d",h_heure,m_minute);
		}
		else if(h_heure>=10 && m_minute <10)
		{
		 sprintf(extension,"_%dH0%d",h_heure,m_minute);
		} 
		else if(h_heure<10 && m_minute >=10)
		{
	     sprintf(extension,"_0%dH%d",h_heure,m_minute);
		} 
		else if(h_heure <10 && m_minute <10)
		{
		 sprintf(extension,"_0%dH0%d",h_heure,m_minute);
		} 
		//printf("extension %s\n",extension);
}

/*_________________________________________________________________*/
void imprime_en_tete_face(fac0,nb_pas)
struct	modelisation_face *fac0;
int		nb_pas;
{
  int i,indice;

  //printf("imprime entete face %d\n", (fac0) ->nofac_fichier);
        indice=0;
	                   /** Transmission **/
        for(i=0;i<nb_pas;i++)
         {
	      fprintf (pval[indice],"f%d %d\n",(fac0) ->nofac_fichier,nb_contour_face(fac0,1));   
    	  indice++;
         }
	                    /** .... **/
        
}
//_________________________________________________________________
void reecrit_les_min_max(nbfac0,nomax0,nb_pas)
int nbfac0,nomax0,nb_pas;
{
 int	indice,i;
 // r�ecrit les min max des nb_pas fichier.val de r�sultat pour Transmission
  indice=0;
  for(i=0;i<nb_pas; i++)
   {
	  rewind(pval[indice]);
      fprintf (pval[indice],"%d %d %f %f\n",nbfac0, nomax0, val_min[indice],val_max[indice]);
      indice++;
   }
 // r�ecrit les min max des nb_pas fichier.val de r�sultat pour ...

}

/*_________________________________________________________________*/

void calcul_min_max(valeur,val_min,val_max)
float valeur;
float *val_min,*val_max;

{ 
  if(valeur < *val_min) *val_min = valeur;
  if(valeur > *val_max) *val_max = valeur;
}

/*_________________________________________________________________*/
void inverse_normale(fac0)
struct modelisation_face *fac0;
{
		fac0->vnorm[0]= -fac0->vnorm[0]; 
	    fac0->vnorm[1]= -fac0->vnorm[1];
		fac0->vnorm[2]= -fac0->vnorm[2];
}


/*_________________________________________________________________*/
void format_entree()
{
  printf("\n   format d'entree des parametres\n\n");
  printf("transmet_flux  fichier_in(.cir) fichier_masque(.cir) fic_masque_opaque/vitre(.val) \n\n");
  printf("latitude jour/mois h_debut:m_debut h_fin:m_fin h_pas:m_pas \n\n");
  printf("coef_transmis(.val)\n\n");
  exit(0);
}



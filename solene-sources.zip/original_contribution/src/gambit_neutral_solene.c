/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/* gambit_neutral_solene.c */

// D.GROLEAU novembre 2003


// solutile.o geomutile.o lib_solene_94.o -lm

#include<solene.h>
//#include<solene.h>  // ne sait pas pourquoi ne veut pas cela

// FUNCTIONS
void centre_gravite_element();
void centre_gravite_face();
int cherche_chaine();
void decode_ligne_commande_macro();
int ecrit_en_tete();
void enregistre_face();
void format_entree();
void gere_parametre();
int lit_ligne_commande();
int no_appartenance();

//EN GLOBAL

FILE *fi,*fo,*fap,*fg;

#define MAXCORD 36000
#define EPSI    0.001

int parc;
char ligne_commande[2048],*parv[128],met_param[2048];

char   buf[512],nom_in[512],nom_out[512],nom_app[512];
double xmin,ymin,zmin,xmax,ymax,zmax;
double x[MAXCORD],y[MAXCORD],z[MAXCORD];
int    nopt[MAXCORD];
int    nbpoint;
int    nbfac_enr;
double tx,ty,tz,rot1,rot2,rot3,rot4;



 double *xp,*yp,*zp;
 double *xge,*yge,*zge;
 double *xgf,*ygf,*zgf;
 int *nop1,*nop2,*nop3,*nop4;

/* gambit_neutral_solene.c */

// D.GROLEAU novembre 2003


// solutile.o geomutile.o lib_solene_94.o -lm
 

/*________________________________________________________*/
main(argc,argv)
int  argc;
char *argv[];    /* ou **argv */

{
 char *s_dir;
 int ilu;
 double englob[10];

 int i, k, nb_point, nb_elem, no_point, nbp_elem, bidon,no_elem;

	s_dir=(char *)getenv("PWD");

 if(argc!=4)format_entree();
 
 /* lit et traite les parametres */

printf("Fonction Solene : gambit_neutral_solene\n");
            compose_nom_complet(nom_in,s_dir,argv[1],"neu");
            if((fi=fopen(nom_in,"r"))==NULL) 
               { printf(" impossible ouvrir %s\n",nom_in);
   	           format_entree();
               }
            printf("\nLit fichier : %s\n",nom_in);

            compose_nom_complet(nom_out,s_dir,argv[2],"cir");
            if((fo=fopen(nom_out,"w"))==NULL) 
               { printf(" impossible ouvrir %s\n",nom_out);
   	           format_entree();
               }

             printf("Ecrit geometrie : %s\n\n",nom_out);

            compose_nom_complet(nom_app,s_dir,argv[3],"txt");
            if((fap=fopen(nom_app,"w"))==NULL) 
               { printf(" impossible ouvrir %s\n",nom_app);
   	           format_entree();
               }

             printf("Ecrit correspondance Face Element : %s\n\n",nom_app);


    // ecrit en tete de GEOMETRIE
for(i=0;i<10;i++) englob[i]=0;
	nbfac=0;
	ecrit_en_tete(fo,nbfac, nbfac, englob);

// cherche   chaine de caract�res NUMNP

 ilu=cherche_chaine("NUMNP");
 printf("retour ilu = %d\n",ilu);
 if(ilu == 1) 
 {  
   // lit nb de points et nb d'�l�ments 
   fscanf(fi, "%d %d %d %d %d %d", &nb_point,&nb_elem, &bidon, &bidon,&bidon,&bidon);

   printf("nbpoint : %d, nbelement : %d\n",nb_point,nb_elem);


   // allocation des coordonnees des points

    xp=alloue_double(nb_point,12);
    yp=alloue_double(nb_point,12);
    zp=alloue_double(nb_point,12);

   // allocation des no de points de chaque �l�ment (4 par �l�ments)

	nop1=alloue_int(nb_elem,13);
	nop2=alloue_int(nb_elem,13);
	nop3=alloue_int(nb_elem,13);
	nop4=alloue_int(nb_elem,13);

   // allocation des centres de gravit�s des elements

	xge=alloue_double(nb_elem,14);
    yge=alloue_double(nb_elem,14);
	zge=alloue_double(nb_elem,14);

   // allocation des centres de gravit�s des faces

	xgf=alloue_double(4*nb_elem,14);
    ygf=alloue_double(4*nb_elem,14);
	zgf=alloue_double(4*nb_elem,14);



   // cherche   chaine de caract�res NODAL

   ilu=cherche_chaine("NODAL");

   if(ilu == 1) 

   {   // lit les coordonn�es des points 

     for(i=0;i<nb_point;i++)
	 {
    	 fscanf(fi, "%d %lf %lf %lf ", &no_point,xp+i, yp+i, zp+i);
         //printf(" %d %f %f %f\n",no_point,xp[i],yp[i],zp[i]);
	 }

     // cherche   chaine de caract�res ELEMENTS/CELLS

     ilu=cherche_chaine("ELEMENTS/CELLS");
	 if(ilu == 1) 
	 {   
       // lit les �l�menst volumiques
       for(i=0;i<nb_elem;i++)
	   {
	     fscanf(fi, "%d %d %d ", &bidon, &bidon,&nbp_elem);
         //printf(" element de %d sommets \n",nbp_elem);

			 // lit les 4 no des sommets

		 if(nbp_elem!=4) {printf("erreur pas 4 points\n"); exit(0);}
		 fscanf(fi, "%d", nop1+i);
				//printf(" %d ",nop1[i]);
		 fscanf(fi, "%d", nop2+i);
				//printf(" %d ",nop2[i]);
		 fscanf(fi, "%d", nop3+i);
				//printf(" %d ",nop3[i]);
		 fscanf(fi, "%d", nop4+i);
				//printf(" %d ",nop4[i]);
		 //printf("\n");
	   }

	   // calcule les x,y,z centre de gravit� des �l�ments
	   for(i=0;i<nb_elem;i++)
	   { centre_gravite_element(i) ;
	   }

	   // calcule les x,y,z centre de gravit� des faces des �l�ments
	   k=0;
	   for(i=0;i<nb_elem;i++)
	   { centre_gravite_face(i,k) ;
	     k=k+4;
	   }

	   // imprime les x,y,z centre de gravit� des faces
	   /*
	   k=0;
	   for(i=0;i<nb_elem;i++)
	   { 
		   printf("%f %f %f\n",xgf[k],ygf[k],zgf[k]);
		   printf("%f %f %f\n",xgf[k+1],ygf[k+1],zgf[k+1]);
		   printf("%f %f %f\n",xgf[k+2],ygf[k+2],zgf[k+2]);
		   printf("%f %f %f\n",xgf[k+3],ygf[k+3],zgf[k+3]);
		   k=k+4;
	   }
	   */

      // cherche faces externes (n'appartenant qu' � un �l�ment)

	   k=0;
       for(i=0;i<nb_elem;i++)

	   {
		   no_elem=no_appartenance(k,i,nb_elem);
		   if(no_elem)
		   { // retient la face et son appartenance � l'�l�ment
			 //printf("la face 1 (points 1,2,3: %d,%d,%d) de l'�l�ment %d est externe\n",nop1[i],nop2[i],nop3[i],i);
                   fprintf(fap," %15.4f %15.4f %15.4f %15.4f %15.4f %15.4f\n", xgf[k], ygf[k], zgf[k], xge[i], yge[i], zge[i]);
                   enregistre_face(nbfac+1, nop1[i],nop2[i],nop3[i]);
			 nbfac++;
		   }

		   k++;
		   no_elem=no_appartenance(k,i,nb_elem);
		   if(no_elem)
		   { // retient la face et son appartenance � l'�l�ment
			 //printf("  la face 2 (points 1,2,4: %d,%d,%d) de l'�l�ment %d est externe\n",nop1[i],nop2[i],nop4[i],i);
                   fprintf(fap," %15.4f %15.4f %15.4f %15.4f %15.4f %15.4f\n", xgf[k], ygf[k], zgf[k], xge[i], yge[i], zge[i]);
                   enregistre_face(nbfac+1, nop1[i],nop2[i],nop4[i]);
			 nbfac++;
		   }

		   k++;
		   no_elem=no_appartenance(k,i,nb_elem);
		   if(no_elem)
		   { // retient la face et son appartenance � l'�l�ment
			 //printf("  la face 3 (points 1,3,4: %d,%d,%d) de l'�l�ment %d est externe\n",nop1[i],nop3[i],nop4[i],i);
                   fprintf(fap," %15.4f %15.4f %15.4f %15.4f %15.4f %15.4f\n", xgf[k], ygf[k], zgf[k], xge[i], yge[i], zge[i]);
                   enregistre_face(nbfac+1, nop1[i],nop3[i],nop4[i]);
			 nbfac++;
		   }

		   k++;
		   no_elem=no_appartenance(k,i,nb_elem);
		   if(no_elem)
		   { // retient la face et son appartenance � l'�l�ment
			 //printf("  la face 4 (points 2,3,4: %d,%d,%d) de l'�l�ment %d est externe\n",nop2[i],nop3[i],nop4[i],i);
                   fprintf(fap," %15.4f %15.4f %15.4f %15.4f %15.4f %15.4f\n", xgf[k], ygf[k], zgf[k], xge[i], yge[i], zge[i]);
                   enregistre_face(nbfac+1, nop2[i],nop3[i],nop4[i]);
			 nbfac++;
		   }
		   k++;
	   }
	 }
   }
 }

// Reecrit EnTete Geometrie
	rewind(fo);
	ecrit_en_tete(fo,nbfac, nbfac, englob);
	fclose(fo);

fclose(fap);

desalloue_double(xp);
desalloue_double(yp);
desalloue_double(zp);

desalloue_double(xgf);
desalloue_double(ygf);
desalloue_double(zgf);

desalloue_double(xge);
desalloue_double(yge);
desalloue_double(zge);

desalloue_int(nop1);
desalloue_int(nop2);
desalloue_int(nop3);
desalloue_int(nop4);


   	creer_OK_Solene();

	printf("ATTENTION: Verifier les normales\n");
	printf("Fin du Traitement\n");
}



//____________________________________________________

void centre_gravite_element(i)

int i;// indice de  l'element

{
  xge[i]= (xp[nop1[i]-1]+xp[nop2[i]-1]+xp[nop3[i]-1]+xp[nop4[i]-1])/4;
  yge[i]= (yp[nop1[i]-1]+yp[nop2[i]-1]+yp[nop3[i]-1]+yp[nop4[i]-1])/4;
  zge[i]= (zp[nop1[i]-1]+zp[nop2[i]-1]+zp[nop3[i]-1]+zp[nop4[i]-1])/4;
}

//____________________________________________________

void centre_gravite_face(i,k)

int i;// indice de  l'element
int k; // indice ou stocker dans xgf,ygf,zgf

{

	//1ere face de l�l�ment
  xgf[k]=   (xp[nop1[i]-1]+xp[nop2[i]-1]+xp[nop3[i]-1])/3;
  ygf[k]=   (yp[nop1[i]-1]+yp[nop2[i]-1]+yp[nop3[i]-1])/3;
  zgf[k]=   (zp[nop1[i]-1]+zp[nop2[i]-1]+zp[nop3[i]-1])/3;

	//2eme face de l�l�ment
  xgf[k+1]= (xp[nop1[i]-1]+xp[nop2[i]-1]+xp[nop4[i]-1])/3;
  ygf[k+1]= (yp[nop1[i]-1]+yp[nop2[i]-1]+yp[nop4[i]-1])/3;
  zgf[k+1]= (zp[nop1[i]-1]+zp[nop2[i]-1]+zp[nop4[i]-1])/3;

	//3eme face de l�l�ment

  xgf[k+2]= (xp[nop1[i]-1]+xp[nop3[i]-1]+xp[nop4[i]-1])/3;
  ygf[k+2]= (yp[nop1[i]-1]+yp[nop3[i]-1]+yp[nop4[i]-1])/3;
  zgf[k+2]= (zp[nop1[i]-1]+zp[nop3[i]-1]+zp[nop4[i]-1])/3;

	//4eme face de l�l�ment

  xgf[k+3]= (xp[nop2[i]-1]+xp[nop3[i]-1]+xp[nop4[i]-1])/3;
  ygf[k+3]= (yp[nop2[i]-1]+yp[nop3[i]-1]+yp[nop4[i]-1])/3;
  zgf[k+3]= (zp[nop2[i]-1]+zp[nop3[i]-1]+zp[nop4[i]-1])/3;

}

//___________________________________________________

 int no_appartenance(k,i,nb_elem)

	 int k,i,nb_elem; // indice de face , indice d'�l�ment

 {

	 int j,kk;

//printf("Compare %f %f %f\n",xgf[k],ygf[k],zgf[k]);

	 kk=0;
	 for(j=0;j<nb_elem;j++)
	 { if(j!=i)
		{ kk=j*4;
		  if(fabs(xgf[k]-xgf[kk]) < EPSI && fabs(ygf[k]-ygf[kk]) < EPSI && fabs(zgf[k]-zgf[kk]) < EPSI)
			{ return(0);
			}
		  kk++;
		  if(fabs(xgf[k]-xgf[kk]) < EPSI && fabs(ygf[k]-ygf[kk]) < EPSI && fabs(zgf[k]-zgf[kk]) < EPSI)
			{ return(0);
			}
		  kk++;
		  if(fabs(xgf[k]-xgf[kk]) < EPSI && fabs(ygf[k]-ygf[kk]) < EPSI && fabs(zgf[k]-zgf[kk]) < EPSI)
			{ return(0);
			}
		  kk++;
		  if(fabs(xgf[k]-xgf[kk]) < EPSI && fabs(ygf[k]-ygf[kk]) < EPSI && fabs(zgf[k]-zgf[kk]) < EPSI)
			{ return(0); 
			}
		}
	 }
	 return(1); // face externe
 }

//________________________________________________________
void enregistre_face(nbfac,n1,n2,n3)
int nbfac,n1,n2,n3 ;
{
 double xpf[3], ypf[3], zpf[3],vnorm[3] ;
 int i,no[3];
 
      no[0]= n1-1;
      no[1]= n2-1;
      no[2]= n3-1;
	fprintf(fo,"f%d 1\n",nbfac);
	for(i=0;i<3;i++)
	{ xpf[i]= xp[no[i]];
	  ypf[i]= yp[no[i]];
	  zpf[i]= zp[no[i]];
	}
	normale_avec_3pts(xpf,ypf,zpf,vnorm);
	fprintf(fo,"%f %f %f \n", vnorm[0], vnorm[1], vnorm[2]);
	fprintf(fo,"c0 \n");
	fprintf(fo,"4 \n");
	for(i=0;i<3;i++)
	{ fprintf(fo,"%f %f %f \n", xpf[i],ypf[i], zpf[i]);
	}
	fprintf(fo,"%f %f %f \n", xpf[0],ypf[0], zpf[0]);

}

/*______________________________________________________*/

int cherche_chaine(s)

char *s;

{

 int ilu;

ilu=0;

while(ilu==0)

  {  ligne_commande[0]=0;

     ilu=lit_ligne_commande(); if(ilu){ilu=2; break;}

     if(ligne_commande[0]!=0)

       { decode_ligne_commande_macro();

         gere_parametre(ligne_commande);

         /*if( parc > 1)printf(" parv = %s \n",parv[0]); */

         if( parc > 1 && (strcmp(parv[0],s))==0) ilu=1;

       }
   }

 return(ilu);

}


/*_________________________________________________________________*/
int lit_ligne_commande()
{
  int i;   /* lit ligne de commande ds ligne_commande sur console */
  //char c;

  
  i=-1;
  do
    { i++; 
      if((fscanf(fi,"%c",ligne_commande+i))==EOF)
		{   ligne_commande[i]=0;
			return(1);
		}
		
	/*printf("i= %d c=%c\n",i,ligne_commande[i]);*/
    }while(ligne_commande[i]!='\n');

  ligne_commande[i]=0;
  //printf("ligne = %s\n",ligne_commande);
  return(0); 


}


/*_________________________________________________________________*/
void decode_ligne_commande_macro()
{
   /* epure la ligne de commande */
   /* enleve les blancs consecutifs et met fin de chaine des que # */
  int i,j,ignore_car;

  ignore_car=0;
  i=0;   /* ieme caractere de ligne_commande */
  j=0;   /* jeme caracter de ligne epuree  */
  while(1)
    { if(ligne_commande[i]==0) break;
      if(ignore_car) i++;
      else if(ligne_commande[i]==' ' || ligne_commande[i]=='	')
         { if(j!=0 && ligne_commande[j-1]!=' ') 
               { /*ligne_commande[j]=ligne_commande[i]; */
                 ligne_commande[j]=' ';

		         j++;
               }
           i++;
         }
/* ne traite pas (ligne_commande[i]=='#' */
/*       else if(ligne_commande[i]=='#') */

      else
         { ligne_commande[j]=ligne_commande[i]; 
           j++; i++;
         }
    }
  if(ligne_commande[j-1]==' ') j--; 
  ligne_commande[j]=0;
//if(ligne_commande[0]!=0) printf("ligne epuree = %s \n",ligne_commande);
}

/*_________________________________________________________________*/
void gere_parametre(ligne_commande)
char *ligne_commande;
{       
        /* etablit les parametres de ligne_commande ds *parv[] */
        /* construit un parametre jusqu'a un BLANC */
  int i,j,nb;
  //char par[128];
  //char *s;
  
  nb=0;  /* 1er parametre */
  i=0;   /* 1er caractere de ligne_commande */
  j=0;   /* 1er caractere du parametre  */
  parv[nb]=&met_param[j];
  while(1)
    { if(ligne_commande[i]==' ')
         { met_param[i]=0; nb++; parv[nb]=&met_param[i+1];
         }
      else 
         { met_param[i]=ligne_commande[i]; 
           if(ligne_commande[i]==0 || ligne_commande[i]=='\n') break;
         }
      i++;
    }
  nb++; parc=nb;

  //printf("nb param %d\n",parc); 
  //for(i=0;i<nb;i++) printf("%s\n",parv[i]); 
}

/*______________________________________________________*/
void format_entree()
{
printf("\n  gambit_neutral_solene gambit_in(.neu) f_solene_out(.cir) f_ap_face_to_element_out(.txt) \n");
printf("\n");   
printf("   Lecture d'un fichier Gambit Neutral\n");
printf("   Produit en sortie:  \n");
printf("        - le fichier.cir des faces enveloppe \n");
printf("        - un fichier.txt d'appartenance des faces enveloppe aux elements volumiques \n");
printf("              sous la forme : x y z (gravite face) x y z (gravite element\n");
printf("\n");   
exit(0);
}


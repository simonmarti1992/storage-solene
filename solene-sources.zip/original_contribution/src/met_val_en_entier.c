/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/*

met_val_en_entier


D. GROLEAU  mai 2005  (� partir d'un fichier de valeurs)

Prend la valeur enti�re d'un fichier de valeurs 


solutile.o geomutile.o lib_solene_94.o

*/

#include<solene.h>

// DECLARATIONS FUNCTIONS

int ecrit_en_tete();
void format_entree();



/*_________________________________________________________________*/
main(argc,argv)
 int argc;char **argv;
{
 char 	buf[512],*s_dir;
 int	nbff, nomax;
 FILE	*fv_IN,*fv_OUT;
 int	i,j;
 float	minv,maxv, valeur;
 int	nofac, nbcont;
 char	c;
 int	valint;


 printf("Fonction Solene : met_val_en_entier\n\n");

 if(argc<3)format_entree();

	s_dir=(char *)getenv("PWD");

    // open Fichier VAL_IN
  compose_nom_complet(buf,s_dir,argv[1],"val");
  if((fv_IN=fopen(buf,"r"))==NULL)
        { printf("\n impossible ouvrir %s\n",buf); exit(0);}

    // cree Fichier VAL_OUT
  compose_nom_complet(buf,s_dir,argv[2],"val");
  if((fv_OUT=fopen(buf,"w"))==NULL)
        { printf("\n impossible ouvrir %s\n",buf); exit(0);}

    // lit VAL_IN, prend val enti�re et stocke dans VAL_OUT
    fscanf(fv_IN,"%d %d %f %f\n",&nbff,&nomax,&minv,&maxv);
	i=(int)minv;
	j=(int)maxv;
    fprintf(fv_OUT,"%d %d %d %d\n",nbff,nomax,i,j);
    
	for(i=0;i<nbff;i++)
	{
	fscanf(fv_IN,"\n%c%d%d\n",&c,&nofac,&nbcont);
	fprintf(fv_OUT,"f%d %d\n",nofac,nbcont);
	for(j=0;j<nbcont;j++)	
		{	
		fscanf(fv_IN,"%f\n",&valeur);
		valint= (int) valeur;
		fprintf(fv_OUT," %d\n",valint);
		}
	}

   fclose(fv_IN);
   fclose(fv_OUT);

   printf("\nFin du traitement met_val_en_entier\n");
  		creer_OK_Solene();

}

/*_________________________________________________________________*/
void format_entree()
{
  printf("\n    met_val_en_entier  fichier_in(.val) fichier_out(.val) \n\n");
  printf("\n    prend les valeurs  de fichier_in.val et les stocke en entier (sans d�cimale) dans fichier_out.val \n\n");
  exit(0);
}

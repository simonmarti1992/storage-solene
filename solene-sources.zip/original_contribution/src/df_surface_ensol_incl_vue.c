/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */
 
/***** surface_ensol_incl_vue.c *************/
/**** pour these D. Follut ****/
/*** M.J. Antoine, CERMA, 1999 ***/

/* permet de determiner le pourcentage de surface ensoleillee */
/* horizontale ou verticale vue par chaque contour d'un fichier-observateur */

/*   Rappel ligne de compilation */

/* cc surface_ensol_incl_vue.c   ./UTILS/solutile.o ./UTILS/geomutile.o  ./UTILS/lib_solene_94.o -o surface_ensol_incl_vue -lm */
   
 
/* Fichiers inclus */
#include<solene.h>
#include<ctype.h>
//#include<unistd.h>


void usage();
int info_faces_contours();
int sauve_tableau();
void lect_fichier();
void lect_ff_param();
void determine_incl();
void traitement_surfaces();

FILE *pfacvis;

main(argc,argv)           
int argc;
char **argv;
{ 
char *dir_courant;

char nom_descr_obs_in[256];
/* fichier de descripteurs lu pour observateurs */
double *descr_obs_in;
int nb_contour_obs;
int nbfac_obs, nomax_obs;
int no_contour_obs;
int *nb_cont_face_obs, *numero_face_obs;
double min_obs, max_obs;


char nom_fvis[256];
/* fichier (lu) pour facteurs de visibilite */
float *ligne_fvis;
/* valeurs */


char nom_surfaces_test[256];
/* fichier (lu) pour surfaces du fichier test */
double *surfaces_test;
/* valeurs */
char nom_fluxsol_test[256];
/* fichier (lu) pour flux solaire du fichier test */
double *fluxsol_test;
/* valeurs */
char nom_geom_test[256];
/* fichier (lu) pour geometrie du fichier-test */
struct modelisation_face *fac_test;
/* faces */
FILE *pfic_geom;
int nb_contour_test;
int nbfac_test, nomax_test;
int no_contour_test;
int *nb_cont_face_test, *numero_face_test;
double min_test, max_test;

FILE *pfic_descr;

int *test_inclinaison; /* vaut 1 si la surface a l'inclinaison recherchee, 0 sinon */

char nom_pourc_surfaces_vues[256];
/* fichier (cree) pour descripteur fichier observateur */
/* (pourcentage de surfaces ensoleillees vues, horizontales ou verticales) */
double *pourc_surfaces_vues;
/* valeurs */

/* Autres */
double englob[10];
double mini, maxi; char c;
int ind_fac, ind_cont, compteur;
int OK_sauv=0;
double *auxiliaire;
char incl; /* ='h' ou 'v' suivant qu'on veut compter les surfaces horixontales ou verticales */

double seuil_sol = 18.0;
/* Seuil sur le flux solaire incident pour considerer qu'une facette est ensoleillee ou non */

/*** Lecture des parametres de la commande ***/

dir_courant=(char *)getenv("PWD");

if (argc<8)usage();

sscanf(argv[1], "%c", &incl); 

if ((incl != 'h') && (incl != 'v'))
	incl = 'v';

compose_nom_complet(nom_descr_obs_in,dir_courant,argv[2],"val");
printf("Fichier de descripteur observateur (entree): %s \n", nom_descr_obs_in);

compose_nom_complet(nom_fvis,dir_courant,argv[3],"vis");
printf("Facteurs de visibilite : %s \n", nom_fvis);

compose_nom_complet(nom_geom_test,dir_courant,argv[4],"cir");
printf("Geometrie du fichier test: %s \n", nom_geom_test);

compose_nom_complet(nom_surfaces_test,dir_courant,argv[5],"val");
printf("Surfaces du fichier test: %s \n", nom_surfaces_test);

compose_nom_complet(nom_fluxsol_test,dir_courant,argv[6],"val");
printf("Flux solaires du fichier test: %s \n", nom_fluxsol_test);

compose_nom_complet(nom_pourc_surfaces_vues,dir_courant,argv[7],"val");

if (incl=='h')
	printf("Pourc. de surfaces horizontales ensoleillees vues par fichier observateur (resultat): %s \n", nom_pourc_surfaces_vues);
else
	printf("Pourc. de surfaces verticales ensoleillees vues par fichier observateur (resultat): %s \n", nom_pourc_surfaces_vues);

/*** Ouverture des fichiers ***/

	/* Lecture d'un fichier .val pour infos fichier observateur*/
	

if ((pfic_descr=fopen(nom_descr_obs_in,"r"))==NULL)
            	{ 
		printf("\n  *** impossible ouvrir %s ***\n\n", nom_descr_obs_in); 
		goto fin;
            	}
fscanf(pfic_descr,"%d %d %lf %lf",&nbfac_obs,&nomax_obs,&min_obs,&max_obs);

numero_face_obs=(int *)malloc(nbfac_obs*sizeof(int));
if (numero_face_obs==NULL)
	{printf("Probleme d'allocation numero face (descripteur observateur), arret.\n\n");
	 exit(0);}
nb_cont_face_obs=(int *)malloc(nbfac_obs*sizeof(int));
if (nb_cont_face_obs==NULL)
	{printf("Probleme d'allocation nombre contours par face (descripteur observateur), arret.\n\n");
	 exit(0);}
fclose(pfic_descr);

nb_contour_obs = info_faces_contours(pfic_descr, nom_descr_obs_in, nbfac_obs, numero_face_obs, nb_cont_face_obs);
printf("Nombre de contours du fichier observateur: %d\n", nb_contour_obs);


pourc_surfaces_vues = (double*)malloc(nb_contour_obs*sizeof(double));
if (pourc_surfaces_vues==NULL)
	{printf("Probleme allocation descripteurs fichier observateur (% surfaces), abandon.\n");
	 exit(0);}

	/* Ouverture fichier de facteurs de visibilite */

if((pfacvis=fopen(nom_fvis,"rb"))==NULL)
		{
           	printf("\n impossible ouvrir %s\n",nom_fvis); 
		exit(0);
		}

	/* Ouverture descripteur du fichier test */

nb_contour_test=0;
if ((pfic_descr=fopen(nom_surfaces_test,"r"))==NULL)
            	{ 
		printf("\n  *** impossible ouvrir %s ***\n\n", nom_surfaces_test); 
		goto fin;
            	}
fscanf(pfic_descr,"%d %d %lf %lf",&nbfac_test,&nomax_test,&min_test,&max_test);	


numero_face_test=(int *)malloc(nbfac_test*sizeof(int));
if (numero_face_test==NULL)
	{printf("Probleme d'allocation numero face (descripteur test), arret.\n\n");
	 exit(0);}
nb_cont_face_test=(int *)malloc(nbfac_test*sizeof(int));
if (nb_cont_face_test==NULL)
	{printf("Probleme d'allocation nombre contours par face (descripteur test), arret.\n\n");
	 exit(0);}

nb_contour_test = info_faces_contours(pfic_descr, nom_surfaces_test, nbfac_test, numero_face_test, nb_cont_face_test);
printf("Nombre de contours du fichier test: %d\n", nb_contour_test);



surfaces_test = (double*)malloc(nb_contour_test*sizeof(double));
if (surfaces_test==NULL)
	{printf("Probleme allocation surfaces fichier-test, abandon.\n");
	 exit(0);}

fluxsol_test = (double*)malloc(nb_contour_test*sizeof(double));
if (fluxsol_test==NULL)
	{printf("Probleme allocation flux solaires fichier-test, abandon.\n");
	 exit(0);}

test_inclinaison = (int*)malloc(nb_contour_test*sizeof(int));
if (test_inclinaison==NULL)
	{printf("Probleme allocation descripteurs inclinaison, abandon.\n");
	 exit(0);}

pfic_descr=fopen(nom_surfaces_test, "r");	
lect_fichier(pfic_descr, nbfac_test, nomax_test, surfaces_test);
fclose(pfic_descr);

pfic_descr=fopen(nom_fluxsol_test, "r");	
lect_fichier(pfic_descr, nbfac_test, nomax_test, fluxsol_test);
fclose(pfic_descr);

/* Seuillage pour selectionner les contours ensoleilles */

for (ind_cont=0;ind_cont<nb_contour_test;ind_cont++)
	{if (fluxsol_test[ind_cont]<=seuil_sol)
		fluxsol_test[ind_cont]=0.0;
	 else
		fluxsol_test[ind_cont]=1.0;
	}


/* Ouverture geometrie du fichier-test */

if ((pfic_geom=fopen(nom_geom_test,"r"))==NULL)
            	{ 
		printf("\n  *** impossible ouvrir %s ***\n\n", nom_geom_test); 
		goto fin;
            	}

lit_en_tete(pfic_geom,&nbfac_test,&nomax_test,englob);
      
fac_test=alloue_face(nbfac_test,34);
lit_fic_cir3d(pfic_geom,nbfac_test,fac_test);

fclose(pfic_geom);


/* Allocation 1 ligne de facteurs de visibilite */
ligne_fvis =(float *) malloc(nb_contour_test*sizeof(float));
if (ligne_fvis == NULL)
	{printf("\n*** Probleme d'allocation facteurs de visibilite.\n");
	exit(0);}



/******************************************************************/
/* Traitement en combinant descripteurs et facteurs de visibilite */
/******************************************************************/

determine_incl(incl, nbfac_test, fac_test, test_inclinaison);

traitement_surfaces(nb_contour_obs, pfacvis, ligne_fvis, nb_contour_test, surfaces_test, fluxsol_test, test_inclinaison, pourc_surfaces_vues);	


/*** Sauvegarde fichier descripteurs resultat ***/

OK_sauv = sauve_tableau(pfic_descr, nom_pourc_surfaces_vues, nbfac_obs, nomax_obs, nb_contour_obs, numero_face_obs, nb_cont_face_obs,
0.0, pourc_surfaces_vues);


free(numero_face_obs);
free(nb_cont_face_obs);
free(numero_face_test);
free(nb_cont_face_test);
free(fac_test);
free(test_inclinaison);
free(ligne_fvis);
free(pourc_surfaces_vues);
free(surfaces_test);
free(fluxsol_test);
fclose(pfacvis);

fin:;
}

/*_____________________________________________________________________*/
void usage()
{printf(" surface_ensol_incl_vue h/v descripteur-observateur(.val) fichier_visibilite(.vis) geometrie-test (.cir) \n");
 printf(" surfaces-test(.val) flux_solaire_test (.val) surfaces-vues-par-observateur(.val) \n\n");
 printf("Choisir 'h' pour surfaces horizontales, ou 'v' pour surfaces verticales.\n");
 exit(0);
}

/*_____________________________________________________________________*/
int info_faces_contours(pfic, nom, nbfac, numero_face, nb_cont_face)
FILE *pfic;
char nom[256];
int nbfac;
int *numero_face;
int *nb_cont_face;
{
/* LECTURE D'UN FICHIER nom.val POUR DETERMINER NBRE DE CONTOURS TOTAL */
/* - remplit les tableaux de numeros de faces et nombre de contours par face */
/* Remarque: le nombre de faces doit deja avoir ete lu dans le fichier, */
/* on doit proceder en deux temps */
	
int nb_contour_total=0;
int nbf, nomx;
int numero, nb_contours;
int f, ct;
double val_min, val_max;
char c;
double *auxiliaire;

nbf=0;
nomx=0;
val_min=0.0;
val_max=0.0;

if ((pfic=fopen(nom,"r"))==NULL)
            	{ 
		printf("\n  compte contours: impossible ouvrir %s\n\n", nom); 
		exit(0);
            	}
fscanf(pfic,"%d %d %lf %lf",&nbf,&nomx,&val_min,&val_max);

for(f=0;f<nbfac;f++)
		{
		fscanf(pfic,"\n%c%d%d\n",&c,&numero,&nb_contours);
		numero_face[f] = numero;
		nb_cont_face[f] = nb_contours;
		nb_contour_total+=nb_cont_face[f];
		auxiliaire=(double *)malloc(nb_cont_face[f]*sizeof(double));
		for(ct=0;ct<nb_cont_face[f];ct++)
			fscanf(pfic,"%lf\n",auxiliaire+ct);
		free(auxiliaire);
		}
fclose(pfic);

return nb_contour_total;

}


/*______________________________________________________________________________________*/
int sauve_tableau(pf, nom_fichier, nbfac, nomax, nb_contour_total, numero_face, nb_cont_face, decalage, tab)
/* Sauvegarde d'un tableau de valeurs (descripteurs) associees a un fichier de faces et contours */
/* avec eventuellement un decalage (utile pour conversion Kelvin->Celsius) */
FILE *pf;
char *nom_fichier;
int nbfac;
int nomax;
int *numero_face;
int *nb_cont_face;
double decalage;
double *tab;
{ 
double mini, maxi;
int i, k, num;
int sauvOK = 1;

if ((pf= fopen(nom_fichier,"w"))==NULL)
	sauvOK = 0;
else
	{mini=maxi=tab[0]-decalage;
	for(i=0;i<nb_contour_total;i++)
		{
		if(tab[i]-decalage<mini) mini=tab[i]-decalage;
		if(tab[i]-decalage>maxi) maxi=tab[i]-decalage;
		} 

	fprintf (pf,"%5d %5d %8.3lf %8.3lf\n", nbfac, nomax, mini, maxi);   

	num=0;
	for(i=0;i<nbfac;i++)
		{
		fprintf (pf,"f%d %d\n",numero_face[i],nb_cont_face[i]);
		for(k=0;k<nb_cont_face[i];k++)
			{
			fprintf (pf,"    %8.3f\n",tab[num]-decalage);
			num++;
			}
		}
	fclose(pf);
	}
return sauvOK;

}	


/*_____________________________________________________________________*/
void determine_incl(incl, nbfac, fac, test_inclinaison)
char incl;
int nbfac;
struct modelisation_face *fac;
int *test_inclinaison;
{ /* Remplit le tableau 'test_inclinaison' de 0 ou de 1 suivant que les contours */
  /* ont l'inclinaison souhaitee ou pas */


int compt_contours=0;
int nf;
struct contour *pcont;
struct circuit *pcir;
double tol = 1e-3;	/* Tolerance sur composante /z de la normale pour determiner l'inclinaison */

for(nf=0;nf<nbfac;nf++) 
	{pcont=(fac+nf)->debut_projete;
	 
         while(pcont) 	/* Balayage des contours de la face courante */   
               	{ pcir=pcont->debut_support;   /* Pointeur sur le contour courant */
		  
		  if (incl=='h') 
			{if (fabs((fac+nf)->vnorm[2]-1.0) < tol)	/* face horizontale, normale = (Oz) */
				test_inclinaison[compt_contours] = 1;
			 else
				test_inclinaison[compt_contours] = 0;
			}
		  else
			{if (fabs((fac+nf)->vnorm[2]) <tol)		/* face verticale */
				test_inclinaison[compt_contours] = 1;
			 else
				test_inclinaison[compt_contours] = 0;
			}

                  compt_contours++;
 		  pcont=pcont->suc; /* Passage au contour suivant de la face courante */
               	}			
        }

}


/*_____________________________________________________________________*/
void traitement_surfaces(nb_contour_obs, pfacvis, ligne_fvis, nb_contour_test, surfaces_test, fluxsol_test, test_inclinaison, pourc_surfaces_vues)
int nb_contour_obs;
FILE *pfacvis;
float *ligne_fvis;
int nb_contour_test;
double *surfaces_test;
double *fluxsol_test;
int *test_inclinaison;
double *pourc_surfaces_vues;
{/*** Exploite les fichiers de facteur de visibilite (represente par le pointeur pfacvis) */
/* et de descripteurs du fichier-test (tableaux 'surfaces_test' et 'fluxsol_test') pour fournir un descripteur sur */
/* fichier observateur (tableau 'pourc_surfaces_vues') ***/
/* L'info d'inclinaison est contenue dans le tableau 'test_inclinaison' dont les valeurs sont */
/* egales a 1 si les contours ont l'inclinaison souhaitee, et 0 sinon */
/* On calcule les pourcentages de surfaces ensoleillees vues ayant l'inclinaison choisie */
/* (horizontales ou verticales) ***/

int no_contour_obs, no_contour_test;
double surface_ensol_vue_totale;
double surface_ensol_incl_vue;
double surface_vue;

for (no_contour_obs=0;no_contour_obs<nb_contour_obs;no_contour_obs++)

	{lect_ff_param(pfacvis, ligne_fvis, nb_contour_test, no_contour_obs, -1); 
	 surface_ensol_vue_totale = 0.0;
	 surface_ensol_incl_vue = 0.0;

	 /**** le pourcentage est calcule par rapport a la surface ensoleillee vue ***/
	 
	 for (no_contour_test=0;no_contour_test<nb_contour_test;no_contour_test++)
		{surface_vue = ligne_fvis[no_contour_test]*surfaces_test[no_contour_test]*fluxsol_test[no_contour_test];
		 surface_ensol_vue_totale+=surface_vue;
		 surface_ensol_incl_vue+=surface_vue*test_inclinaison[no_contour_test];
		}
	 
	 if (surface_ensol_vue_totale != 0.0)
	 	pourc_surfaces_vues[no_contour_obs] = 100.0*surface_ensol_incl_vue/surface_ensol_vue_totale;
	  else
		pourc_surfaces_vues[no_contour_obs] = 0.0;
	 
	}
}



/*_________________________________________________________________*/
/* Lecture fichier au "bon" format (.val) et remplissage tableau 'valeur' */
void lect_fichier(pfic, nbfac, nomax, valeur)
FILE *pfic;
int nbfac;
int nomax;
double *valeur;
{ double val_min;
  double val_max;
  int num_cont, num_face, num_cont_liste;
  int nofac, nbcont_face;
  char c;

  fscanf(pfic,"%d %d %lf %lf",&nbfac,&nomax,&val_min,&val_max);
  num_cont_liste = 0;
  for(num_face=0;num_face<nbfac;num_face++)
	{
	fscanf(pfic,"\n%c%d%d\n",&c,&nofac,&nbcont_face);
	for(num_cont=0;num_cont<nbcont_face;num_cont++)	
		{	
		fscanf(pfic,"%lf\n",valeur+num_cont_liste);
		num_cont_liste++;
		}
	}
}



/*_____________________________________________________________________*/
/* Lecture des facteurs de visibilite dans fichier */

void lect_ff_param(pff, ligne_ff, nb_contour, i, j)
FILE *pff;
float *ligne_ff;
int nb_contour;
int i; /* Ligne */
int j; /* colonne */
/* Lit une ligne specifiee dans un fichier de facteurs */
/* arranges en Fij , i et j variant de 0 a nb_contour-1 */
/* si j positif, donne la seule valeur Fij */
/* sinon donne toute la ligne i */
{int f;
fseek(pff,(i*nb_contour)*sizeof(float),SEEK_SET);
fread(ligne_ff, sizeof(float), nb_contour, pff);

/* if (j<0)
	{printf("Ligne %d ", i+1);
	for (f=0;f<nb_contour;f++)
		printf(" %f ", ligne_ff[f]);
	printf("\n"); 
	}
else
	{printf("Valeur F de %d vers %d: %f\n", i+1,j+1,ligne_ff[j]); 
	}
*/

}


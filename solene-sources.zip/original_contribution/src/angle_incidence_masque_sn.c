/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */
 
/*
cc angle_incidence_masque_sn  ~marenne/newsolene/solutile.o  ~marenne/newsolene/geomutile.o ~marenne/newsolene/lib_solene_94.o  ~marenne/newsolene/solaire.o -o energie_solaire_directe -lm

*/
/* construit sur le mod�le de angle_incidence_solaire */

// D.GROLEAU septembre 2002

// en fonction du temps 
// evalue angle incidence entre la normale aux contours et le rayon solaire
// evalue aussi angle entre le rayon de vis�e d�fini par
//		le centre de gravit� du contour
//		et un point de vis�e sp�cifi� par l'ordinateur
// �value aussi (� partir des donn�es par contours)
//		le pourcentage de masque de la face 
//		le pourcentage de surface normale ensoleill�e de la face

// une analyse pr�alable de l'ensoleillement des contours est obligatoire (h�liodon ou masque) .mas
//
// d�velopp� pour Mohamed Benzerzour pour analyse ensoleillement des rues seoln orinetation
// et rampport H/L

// INFOS de CALCUL
// cr�e en cours de calcul 4 descripteurs des contours, contenus dans vecteur VALEUR
//	descripteur 1 : angle d'incidence solaire (entre normale face et rayon solaire)
//					vaut -1 si pas ensoleill�
//	descripteur 2 : angle de visibilit� (entre observateur-vis�e et rayon solaire)
//					vaut -1 si pas soleil pas visibilte
//	descripteur 3 : surface du contour si � l'ombre, sinon 0
//	descripteur 4 : surface normale du contour si au soleil, sinon 0

// INFOS D'ENREGISTREMENT DANS LES .VAL
//	descripteur 1 : idem au calcul
//	descripteur 2 : idem au calcul
//	descripteur 3 : %masque de la face = somme des surf_des_contours_�_l'ombre / surface totale face
//					cette valeur est attribu�e � l'ensemble des contours d'une face
//					0% pas de masque, 100% totalement masqu�
//	descripteur 4 : %surface normale ensoleill�e de la face = (100-%masque)*cos(angle d'incidence)
//					cette valeur est attribu�e � l'ensemble des contours d'une face
//					0% pas de surface ensoleill�e,
//					100% l'ensemble de la face est ensoleill�e � incidence normale

// NOTA , on remarque que le descripteur 4 calcul� lors du traitement n'est pas utilis� dans les r�sultas finaux
// mais conserv� pour extension ou modification future

// NOTA  si on souhaite calcul� le flux solaire re�u par la face � instant t
// alors
// Flux_solaire_direct_incident_de_la_face = 
//			   Surface_de_la_face
//			 * %surface_normale_au_soleil_de_la_face (t)
//			 * FLUX_NORMAL_SOLAIRE (t)
//
// les valeurs �tant prises � l'instant t

// NOTA , les fichiers .val sont index�s par la date et l'heure

#include<solene.h>

// DECLARE FUNCTIONS

void energie_directe();
void format_entree();
void met_extension ();
int test_ensoleille();
void test_min_max();

// en GLOBAL
int nb_contour;
double *vx_visee,*vy_visee,*vz_visee;
double visee_x,visee_y,visee_z;
double *surf_contour;
/*_________________________________________________________________*/
main(argc,argv) 
int argc;char **argv;

{
FILE *fpcir,*fpmas1,*fpsurf,*fpval,*fpval1,*fpval2,*fpval3;
char buf[256],buf1[256],buf2[256],buf3[256],*s_dir,c;
int nojour,nomois,jo,mo,indice_date;
int hh1,hh2,pas,minute;
int nbfac,nomax,nofac,nb_pas,nb_date;
double englob[10],*nx_face,*ny_face,*nz_face;
int *nbc_face,*no_face;
int i,j,k,ind_valeur,temps,nbcontour,no_contour;
int indice, indice_dep;
float x,vmin_gen,vmax_gen,vmin_gen1,vmax_gen1,vmin_gen2,vmax_gen2,vmin_gen3,vmax_gen3,vmin_gen4,vmax_gen4;
double latitude,vnorm[3];
float *valeur;
double surf_face;
double surf_norm, cumul_surf_ombre, masque, angle_incid;

int noc;
struct contour *pcont;
struct circuit *pcir;
float xh_heure;
int h_heure,m_minute;
char extension[32];

// pour angle_incidence
double x_visee,y_visee,z_visee;

struct modelisation_face *fac;

 if(argc<16) { format_entree(); exit(0); }

	s_dir=(char *)getenv("PWD");

printf("Commande : angle_incidence_masque_sn\n\n");
printf("Evalue : Angle incidence: (normale,soleil) et (visee,soleil)\n");
printf("Evalue : Pourcentage Masque et Pourcentage Surface_Normale_Au_Soleil\n\n");


/* ouverture des fichiers : geom, mas, surface*/

         compose_nom_complet(buf,s_dir,argv[1],"cir");
         if((fpcir=fopen(buf,"r"))==NULL)
            { printf("\n impossible ouvrir %s\n",buf); exit(0);
            }

		 printf("geometrie : %s \n",buf);

         compose_nom_complet(buf,s_dir,argv[2],"mas");
         if((fpmas1=fopen(buf,"r"))==NULL)
            { printf("\n impossible ouvrir %s\n",buf); exit(0);
            }

		 printf("ensoleillement : %s \n",buf);

         compose_nom_complet(buf,s_dir,argv[3],"val");
         if((fpsurf=fopen(buf,"r"))==NULL)
            { printf("\n impossible ouvrir %s\n",buf); exit(0);
            }

		 printf("surface : %s \n",buf);
		
	// jour mois heure pas
  	     sscanf(argv[4],"%d%c%d",&nojour,&c,&nomois);
         //printf("jour mois %d %d\n",nojour,nomois);
         sscanf(argv[5],"%d%c%d",&hh1,&c,&minute);
         hh1=hh1*60+minute;
         sscanf(argv[6],"%d%c%d",&hh2,&c,&minute); 
         hh2=hh2*60+minute;
         sscanf(argv[7],"%d%c%d",&pas,&c,&minute);
         pas=pas*60+minute;
         //printf("hh1 hh2 pas %d %d %d\n",hh1,hh2,pas);

      /* point de vis�e */

		sscanf(argv[8],"%lf",&x_visee);
  		sscanf(argv[9],"%lf",&y_visee);
  		sscanf(argv[10],"%lf",&z_visee);

	   /* lit  latitude en degres */

  	 sscanf(argv[11],"%lf",&latitude);


 /* calcul du nombre de pas */
   nb_pas=1;
   i=hh1;
   while(i<hh2)
    { nb_pas++;
      i=i+pas;
    }
//printf("nb de pas %d\n",nb_pas);

   /* lecture de geom.cir  */
   lit_en_tete(fpcir,&nbfac,&nomax,englob);

   fac=alloue_face(nbfac,34);
   lit_fic_cir3d(fpcir,nbfac,fac);
   fclose(fpcir);

       printf(" Traite %d faces\n",nbfac);
   nbc_face =alloue_int(nbfac,1023);
   no_face = alloue_int(nbfac,1023);
   nx_face = alloue_double(nbfac,1023);
   ny_face = alloue_double(nbfac,1023);
   nz_face = alloue_double(nbfac,1023);
   

   nb_contour=0;

   for(i=0;i<nbfac;i++)
     { 
       no_face[i]=(fac+i)->nofac_fichier;
       nbc_face[i]=nb_contour_face(fac+i,1);
       nx_face[i]=(fac+i)->vnorm[0];
       ny_face[i]=(fac+i)->vnorm[1];
       nz_face[i]=(fac+i)->vnorm[2];
       nb_contour+=nbc_face[i];
     }
   printf("     soit  %d contours\n\n",nb_contour);

   // alloue nb_contour valeurs pour vecteur de visee

   vx_visee = alloue_double(nb_contour,1025);
   vy_visee = alloue_double(nb_contour,1025);
   vz_visee = alloue_double(nb_contour,1025);

   // alloue nb_contour valeurs pour surface des contours
   // et affecte les valeurs lues dans fichie surface.val
   surf_contour = alloue_double(nb_contour,1025);
   lect_fic_val(fpsurf, surf_contour);
   fclose(fpsurf);


   // affecte les valeurs vecteur visee
   noc=0;
    for(i=0;i<nbfac;i++)
     { 
  	   pcont=(fac+i)->debut_projete; 
	   while(pcont)	   
               { pcir=pcont->debut_support;
		         centre_de_gravite(pcir, &obs.xo, &obs.yo, &obs.zo);
	
				 vx_visee[noc]= x_visee - obs.xo;
				 vy_visee[noc]= y_visee - obs.yo;
				 vz_visee[noc]= z_visee - obs.zo;
                 noc++;				  
                 pcont=pcont->suc;
               } 
	 }
   desalloue_fface(fac,nbfac);
   fclose(fpcir);

 /* allouer nb_contour*nb_de_pas valeurs *4 */
   // et initialise � -1 (pas visible)

   valeur=alloue_float(nb_contour*nb_pas*4,1023);
   for(j=0;j<nb_contour*nb_pas*4;j++) valeur[j]= -1;

 /* lit en tete des .mas  et determine indice de la bonne date */
     
    fscanf(fpmas1,"%d",&nb_date);
	
	for(j=0;j<nb_date;j++)
         { fscanf(fpmas1,"%d %d",&jo,&mo);			  
           if(mo == nomois && jo == nojour) indice_date=j;
         }
        fscanf(fpmas1,"%d %d",&i,&i);

/* printf("indice de la bonne date %d\n", indice_date);*/

 
/* examine les contours et determine les valeurs */
/* stocke les valeurs dans valeur contour  apres contour */
/* soit nb_contour*nb_pas valeurs */

     ind_valeur=0;
     noc=0;
     for(j=0;j<nbfac;j++)
       { fscanf(fpmas1,"\n%c%d %d",&c,&nofac,&nbcontour);
         //printf("FACE %d\n",nofac);
		vnorm[0]=nx_face[j];
		vnorm[1]=ny_face[j];
		vnorm[2]=nz_face[j];

		for(k=0;k<nbcontour;k++)  
		{ //printf("test contour %d\n",k+1);

		 visee_x= vx_visee[noc];
		 visee_y= vy_visee[noc];
		 visee_z= vz_visee[noc];
		 		//printf("visee %f %f %f\n",visee_x,visee_y,visee_z);
		
             /* evalue valeurs en fonction du temps pour chaque contour */

energie_directe(nb_pas,pas,nb_date,indice_date,hh1,&ind_valeur,valeur,fpmas1,latitude,vnorm,nojour,nomois,surf_contour[noc]);
		 
	      //printf("ind_valeur %d \n", ind_valeur);

		 noc++;
		}
		 // on reajuste les valeurs pour face en sortie pour
		 // 3eme descripteur 
		 // 4eme descripteur 


       }
   fclose(fpmas1);
/*
   printf("toutes les valeurs\n");
        for(i=0;i<4*nb_pas*nb_contour;i++)
	       { printf("valeurs : %f\n",valeur[i]);
		   }
*/

/* constitue les fichiers .val correspondants */
/* avec les valeurs en fonction du temps */

 printf(" Cree les Descripteurs  : \n");

  temps=hh1;
   for(i=0;i<nb_pas;i++)
     { 
		xh_heure= (float) (temps/60);
		h_heure= (int) xh_heure;
		m_minute= temps-h_heure*60;
		//printf(" heure_minute %d H %d\n",h_heure,m_minute);
	/* calcule min_max pour le pas i AVEC MASQUE */
        vmin_gen=10000000.; vmax_gen=-vmin_gen;
		
        vmin_gen1=vmin_gen; vmax_gen1=-vmin_gen;
        vmin_gen2=vmin_gen; vmax_gen2=-vmin_gen;
        vmin_gen3=0; vmax_gen3=100;
        vmin_gen4=0; vmax_gen4=100;
        //no_contour=0;
        indice=i;
        for(j=0;j<nbfac;j++)
           { for(k=0;k<nbc_face[j];k++)
               { x=valeur[indice];
                 test_min_max(x,&vmin_gen1,&vmax_gen1);

                 x=valeur[indice+nb_contour*nb_pas];
                 test_min_max(x,&vmin_gen2,&vmax_gen2);

				 // entre 0 et 100 % pour pourcentage de masque
				 // entre 0 et 100 % pour pourcentage de surf_normale au soleil

		         //no_contour++;
                 indice+=nb_pas;
               }
           }    
		//printf("pas %d min %f max %f\n", i,vmin_gen1,vmax_gen1);
		//printf("pas %d min %f max %f\n", i,vmin_gen2,vmax_gen2);
		//printf("pas %d min %f max %f\n", i,vmin_gen3,vmax_gen3);
		//printf("pas %d min %f max %f\n", i,vmin_gen4,vmax_gen4);
		
       /* open fichier .val pour le pas i */
       /* COMPOSE LE NOM des fichiers .val avec extension date et heure */
		  met_extension(temps,nojour,nomois,extension);
			 sprintf(buf,"%s%s.val",argv[12],extension);
             sprintf(buf1,"%s%s.val",argv[13],extension);
             sprintf(buf2,"%s%s.val",argv[14],extension);
             sprintf(buf3,"%s%s.val",argv[15],extension);
   
        printf("   %s\n",buf);
        printf("   %s\n",buf1);
        printf("   %s\n",buf2);
        printf("   %s\n",buf3);

        fpval=fopen(buf,"w");
        fpval1=fopen(buf1,"w");
        fpval2=fopen(buf2,"w");
        fpval3=fopen(buf3,"w");

        fprintf(fpval,"%5d %5d %15.3f %15.3f\n",nbfac,nomax,vmin_gen1,vmax_gen1);
        fprintf(fpval1,"%5d %5d %15.3f %15.3f\n",nbfac,nomax,vmin_gen2,vmax_gen2);
        fprintf(fpval2,"%5d %5d %15.3f %15.3f\n",nbfac,nomax,vmin_gen3,vmax_gen3);
        fprintf(fpval3,"%5d %5d %15.3f %15.3f\n",nbfac,nomax,vmin_gen4,vmax_gen4);

		
       //
	   // stocke les valeurs pour le pas i */
         no_contour=0;
         indice=i;
         for(j=0;j<nbfac;j++)
           {
			 cumul_surf_ombre = 0;
			 surf_face =0;
             /* printf("Face %d\n",no_face[j]);*/
             fprintf(fpval,"f%d %d\n",no_face[j],nbc_face[j]);
             fprintf(fpval1,"f%d %d\n",no_face[j],nbc_face[j]);
             fprintf(fpval2,"f%d %d\n",no_face[j],nbc_face[j]);
             fprintf(fpval3,"f%d %d\n",no_face[j],nbc_face[j]);

			 indice_dep=indice;
			 angle_incid=-1;
             for(k=0;k<nbc_face[j];k++)
               { 
                 /* printf("Contour %d indice %d\n",k+1,indice);*/

                 fprintf(fpval,"%10.3f\n",valeur[indice]);
				 // cherche si la face a au moins un contour ensoleill�
				 if(valeur[indice] !=-1) angle_incid=valeur[indice];
                 fprintf(fpval1,"%10.3f\n",valeur[indice + nb_contour*nb_pas]);
				 // 3eme descripteur : cumul surface des contours � l'ombre pour la face
				 cumul_surf_ombre += valeur[indice + 2*(nb_contour*nb_pas)];
				 // cumul la surface des contours
				 surf_face += surf_contour[no_contour];

		         no_contour++;
                 indice+=nb_pas;

               }
			 // ecrit pour les contours de la face les 3eme et 4eme descripteur
			 masque = (cumul_surf_ombre*100.) / surf_face;
			 surf_norm=0;
			 if (angle_incid != -1)
			 { // la face a au moins un contour ensoleill�
			     angle_incid = angrad((double) angle_incid);
				 surf_norm= (100-masque) * cos(angle_incid);
			 }
			
             for(k=0;k<nbc_face[j];k++)
             { 
               fprintf(fpval2,"%10.3f\n",masque);
               fprintf(fpval3,"%10.3f\n",surf_norm);
			 }

           }    
          fclose(fpval); fclose(fpval1);
          fclose(fpval2); fclose(fpval3);
          temps+=pas;
     }

 desalloue_float(valeur); 
 desalloue_int(nbc_face); 
 desalloue_int(no_face);
 desalloue_double(nx_face);
 desalloue_double(ny_face);
 desalloue_double(nz_face);
 	   desalloue_double(vx_visee,nb_contour);
 	   desalloue_double(vy_visee,nb_contour);
 	   desalloue_double(vz_visee,nb_contour);


creer_OK_Solene();
printf("\nFin angle_incidence_solaire\n\n");

}

/*_________________________________________________________________*/

void energie_directe(nb_pas,pas,nb_date,ind_date,hh1,ind_valeur,valeur,pf_mas,latitude,vnorm,nojour,nomois,s_contour)
int nb_pas,pas,nb_date,ind_date,hh1,*ind_valeur;
float *valeur;
FILE *pf_mas;
double latitude,*vnorm;
int nojour,nomois;
double s_contour;
{
  int nb_per,dh[50],dm[50],fh[50],fm[50];
  float val[50];
  int i,k,kk,temps,h_deb,m_deb;
  double x,y,z,oui,xyz[3],ang,a,h,xyzsol[3],cos_angle;
  char c;
  int vu;

/*
printf("nb_pas pas nb_date ind_date %d %d %d %d\n",nb_pas,pas,nb_date,ind_date);
printf("hh1 ind_valeur %d %d\n",hh1,*ind_valeur);
*/
             fscanf(pf_mas,"\n%c",&c);

  for(i=0;i<nb_date;i++)
     { fscanf(pf_mas,"%d",&nb_per);
       for(k=0;k<nb_per;k++)
          { fscanf(pf_mas,"%d %d %d %d %f",dh+k,dm+k,fh+k,fm+k,val+k);
      /*printf("%d %d %d %d %f\n",dh[k],dm[k],fh[k],fm[k],val[k]);*/ 
          }


       /* test ensoleillement sur ce jour */
       if(i==ind_date)  
          {  temps=hh1;
             for(kk=0;kk<nb_pas;kk++)
              { x=temps/60.;
                h_deb=(int)x;
                m_deb=(int)(temps-h_deb*60.);
/*printf("a %d H %d\n",h_deb,m_deb);*/
                heure_et_minute_EN_heure_double(h_deb,m_deb,&z); 
	        	oui=0;
                for(k=0;k<nb_per;k++)
                  { heure_et_minute_EN_heure_double(dh[k],dm[k],&x);
 		            heure_et_minute_EN_heure_double(fh[k],fm[k],&y);
		            if(x<=z && y>=z) oui=1;
                  }
		if(oui) // au soleil
                  { //evalue angle_incidence solaire (1er descripteur)
                   info_solaire(latitude,nojour,nomois,h_deb,m_deb,xyzsol,&a,&h);

				   cos_angle=vincid(xyzsol,vnorm,&ang);
                   valeur[*ind_valeur]=(float) angdeg(ang);
				   // surface � l'ombre =0 (3eme descripteur)
                   valeur[*ind_valeur + 2*(nb_contour*nb_pas)]=0;
				   // surface normale au soleil (4�me descripteur)
				   valeur[*ind_valeur + 3*(nb_contour*nb_pas)]= (float)( s_contour*cos_angle);
                  }
		else  // � l'ombre
		{
				   // surface � l'ombre  (3eme descripteur)
                   valeur[*ind_valeur + 2*(nb_contour*nb_pas)]= (float) s_contour;
				   // surface normale au soleil (4�me descripteur) =0
				   valeur[*ind_valeur + 3*(nb_contour*nb_pas)]= 0;
		}
		// �value angle_soleil_visee (2eme descripteur)
		// verifier que visee possible compte tenu de la normale
		xyz[0]= visee_x;
		xyz[1]= visee_y;
		xyz[2]= visee_z;
		vu= vuparsol(xyz[0],xyz[1],xyz[2],vnorm[0],vnorm[1],vnorm[2]);

		if(vu && oui)
		{ // vision possible
		  cos_angle=vincid(xyzsol,xyz,&ang);
		  valeur[*ind_valeur+nb_contour*nb_pas]= (float) angdeg(ang);

		}


                temps+=pas;
/*printf(" valeur oui %f %f\n",oui,valeur[*ind_valeur]);*/
		(*ind_valeur)++;
              }

          }
    }
}

/*_________________________________________________________________*/
void test_min_max(x,vmin_gen,vmax_gen)
float x,*vmin_gen,*vmax_gen;
{
		 if(x < *vmin_gen) *vmin_gen= (float) x;
         if(x > *vmax_gen) *vmax_gen= (float) x;
}

//_____________________________________________________
void met_extension (temps,jour,mois,extension)
int temps, jour,mois;
char *extension;
{
	float xh_heure;
	int h_heure, m_minute;
	char buf[16];

		xh_heure= (float)temps/60;
		h_heure= (int) xh_heure;
		m_minute= temps-h_heure*60;
		printf(" heure_minute %d H %d\n",h_heure,m_minute);
		//construit extension pour fichier val heure
		
		if(h_heure>=10 && m_minute >=10)
		{
		 sprintf(buf,"_%dH%d",h_heure,m_minute);
		}
		else if(h_heure>=10 && m_minute <10)
		{
		 sprintf(buf,"_%dH0%d",h_heure,m_minute);
		} 
		else if(h_heure<10 && m_minute >=10)
		{
		 sprintf(buf,"_0%dH%d",h_heure,m_minute);
		} 
		else if(h_heure <10 && m_minute <10)
		{
		 sprintf(buf,"_0%dH0%d",h_heure,m_minute);
		} 
		printf("extension %s\n",buf);


		//construit extension pour fichier val : jour mois
		if(jour>=10 && mois >=10)
		{
		 sprintf(extension,"_%d_%d%s",jour,mois,buf);
		}
		else if(jour>=10 && mois <10)
		{
		 sprintf(extension,"_%d_0%d%s",jour,mois,buf);
		} 
		else if(jour<10 && mois >=10)
		{
		 sprintf(extension,"_0%d_%d%s",jour,mois,buf);
		} 
		else if(jour<10 && mois <10)
		{
		 sprintf(extension,"_0%d_0%d%s",jour,mois,buf);
		} 

		printf("extension %s\n",extension);
}




/*_________________________________________________________________*/

void format_entree()
{
 printf("\n la fonction angle_incidence_masque_sn\n a comme parametre ENTREE :\n\n");
 printf("\t fichier_geometrie_in(.cir)\n"); 
 printf("\t fichier__masque_in(.mas)\n");
 printf("\t fichier_surface_in(.val)\n");
 printf("\t jour/mois\n");
 printf("\t hh1:mn1\n");
 printf("\t hh2:mn2\n");
 printf("\t pas(hh:mn)\n");

 printf("\t x_visee\n");
 printf("\t y_visee\n");
 printf("\t z_visee\n");
 printf("\t latitude\n");
 
 printf("\n           comme parametres en SORTIE, les descripteurs:\n\n");
   
 printf("\t incident_normal(.val)\n");
 printf("\t incident_visee(.val)\n");
 printf("\t pourcentage_masque_face(.val)\n");
 printf("\t pourcentage_surface_normale_au_soleil_face(.val)\n");

 printf("\n NOTA: les r�sultats masque et surface_normale se rapportent aux faces\n");
 printf(" la meme valeur est donc attribu�e � tous les contours de la face\n");

  
}

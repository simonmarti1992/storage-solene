/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

// D.Groleau mars 2001
/*
cc vu_dun_point.c   solutile.o geomutile.o lib_solene_94.o 
*/

/*****************************************************************/
/* calcule geometrie vue dans la pers, decompose et produit descripteur vu */
/*****************************************************************/

#include<solene.h>
#include<ctype.h>



/*_________________________________________________________________*/
main(argc,argv)			
 int argc;char **argv;
{
char *s_dir;
char buf[256],buf1[512],buf2[500];
float ox, oy, oz, vx,vy,vz;

         s_dir=(char *)getenv("PWD");

         if(argc<11)format_entree();

//COMPOSE  et lance LA COMMANDE pour pers 


	sscanf(argv[2],"%f",&ox);
	sscanf(argv[3],"%f",&oy);
	sscanf(argv[4],"%f",&oz);
	sscanf(argv[5],"%f",&vx);
	sscanf(argv[6],"%f",&vy); 
	sscanf(argv[7],"%f",&vz);
	vx=ox+vx;
	vy=oy+vy;
	vz=oz+vz;
	
	sprintf(buf,"pers %s %s %s %s %f %f %f %s %s\\XXXXVU",
		 argv[1],argv[2],argv[3],argv[4],vx, vy, vz ,argv[8],getenv(SOLENETEMP));


	printf("\n %s\n",buf);
    system(buf);

	//test si la commande pers s'est bien passe */
	if(!existOkSolene())
	    { printf("\n PB execution de pers ou pers_select\n");
	      exit(0);
	    }
	cleanOkSolene();

// compose et lance la commande decompose_cir_val
    sprintf(buf2,"decompose_cir_val %s %s\\XXXXVU %s",argv[1],getenv(SOLENETEMP), argv[9]);
	printf("\n commande = %s\n",buf2);
	system(buf2);

      /* test si la commande decompose_face s'est bien passe */

      	if(!existOkSolene())
		{ printf("\n PB execution de decompose_face\n");
	      exit(0);
	    }
		cleanOkSolene();

	// del de \\XXXXVU
	//	cleanFileTmpSolene("XXXXVU.cir");
	// del fichier creer argv[9].eta
   compose_nom_complet(buf,s_dir,argv[9],"eta");
   sprintf(buf1,"del %s",buf);
   printf("%s\n",buf1);
   system(buf1);

	// renomme le fichier descripteur nom_out_0.val en argv[10].val
   sprintf(buf,"%s_0",argv[9]);
   compose_nom_complet(buf1,s_dir,buf,"val");

   compose_nom_complet(buf,s_dir,argv[10],"val");
   sprintf(buf2,"copy %s %s",buf1,buf);
   printf("%s\n",buf2);
   system(buf2);

  sprintf(buf2,"del %s",buf1);
  printf("%s\n",buf2);
  system(buf2);
     
creer_OK_Solene();

/* liste_des_pointeurs(); */

}


/*_________________________________________________________________*/
format_entree()
{
  printf("\nFormat d'entree des parametres \n\n");
  printf(" *vu_dun_point* fichier_geom_in(.cir) ox oy oz vx vy vz angle_vue geom_out(.cir) descripteur_vu(.val)[-n]\n\n");
  printf("\n   ox, oy,oz : position de l'oeil \n");
  printf("   vx, vy,vz : vecteur indiquant la direction de visee \n\n");
  exit(0);
}

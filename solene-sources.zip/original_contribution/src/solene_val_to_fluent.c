/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

/*__________________________  solene_val_to_fluent   __________________________ */

// D.Groleau, janvier 2003
// modifi�    decembre 2003 (opere une s�lection sur les contours a retenir)

/*______________________________________________________________________    */
/* Pour couplage Solene - Fluent   r�cup�ration des temperatures de surface de solene 
Utilitaire : a partir d'un fichier de geometrie.cir triangul�		 
 et d'un fichier de descripteur .val, sauve un fichier ASCII 		      
 exploitable par FLUENT.
 Constitue la liste des centre de gravit� des contours				
 et leur associe la valeur du contour
*/                            		   
/*
 le fichier resultat :
	((solene-prof point nb_de_centre_de_gravit�s)
	(x
	centre1 centre2 ....
	.....                )
	(y
	centre1 centre2 ....
	.....                )
	(z
	centre1 centre2 ....
	.....                )
	(temp
		temp_centre1 temp_centre2 ....
	.....                              )
  )
*/
/*______________________________________________________________________  */


#include<solene.h>


// declare functions
void format();
int lit_fic_retenir();
int test_si_retient();

#define HMAX 56  // nb de valeurs max a retenir


/*_________________________________________________________________*/
main(argc,argv)           
int argc;char **argv;
	{

/*--------------*/
/* Declarations */
/*--------------*/

	char nom_geometrie[256];				/* fichier de geometrie lu */
	char nom_valeur[256];					/* fichier de valeur lu (descripteur) */ 
	char nom_type[256];					    /* fichier de valeurs : type de surface */
	char nom_type1[256];					/* fichier texte des valeurs types de surface a retenir */
	char nom_resultat[256];					/* fichier resultat (centres de gravite + valeurs) */
	
	int nbfac;			    /* nombre de faces d'apres le fichier de geometrie */
	int nbfac_val;			/* nombre de faces d'apres le fichier de valeurs */
	double englob[10];
	int nb_contour_total;		/* nombre total de contours */
	double *valeur, *type_surf;				/* valeurs lues */
	struct modelisation_face *fac;	/* faces */
 	FILE *pficg, *pficv, *pficr ;	/* pointeurs pour manips fichiers */
	int nomax;			/* numero maxi des faces */
	int nomax_val;
	double maxi, mini;		/* valeurs mini et maxi lues */
	char *rep_courant;		/* repertoire courant */
	int nf;					/* Pour balayage faces et contours */
	struct contour *pcont;		/* id. */
	struct circuit *pcir;		/* id. */
	int		 noc;
	double xg, yg, zg;
	float val_retenir[HMAX];  // les valeurs type de surface � retenir
	int   nb_val_retenir;
	int i,nchange, nb_contour_retenu;

/*-----------------------------*/
/* lecture parametres commande */
/*-----------------------------*/

	rep_courant = (char *)getenv("PWD");  

   	if(argc<6) format(); 
 
	printf("\n\nFonction : Solene_val_to_fluent\n");

    compose_nom_complet(nom_geometrie,rep_courant,argv[1],"cir");  
        printf("\n\nFichier de geometrie : %s \n",nom_geometrie); 

	compose_nom_complet(nom_valeur,rep_courant,argv[2],"val");  
        printf("Fichier de valeur a transmettre   : %s \n",nom_valeur);

	compose_nom_complet(nom_type,rep_courant,argv[3],"val");  
        printf("Fichier de type de surface    : %s \n",nom_type);

	compose_nom_complet(nom_type1,rep_courant,argv[4],"txt");  
        printf("Fichier des types de surface a retenir    : %s \n",nom_type1);

	compose_nom_complet(nom_resultat,rep_courant,argv[5],"dat");  
        printf("Fichier des valeurs pour fluent     : %s \n",nom_resultat);


/* fichiers en input */

       if((pficg=fopen(nom_geometrie,"r"))==NULL)
		{
        	printf("\n impossible ouvrir %s\n",nom_geometrie); 
			exit(0);
		}

	   /* lecture fichier geometrie a traiter */
       lit_en_tete(pficg,&nbfac,&nomax,englob);      
       fac=alloue_face(nbfac,34);
       lit_fic_cir3d(pficg,nbfac,fac);
       fclose(pficg);
	   
	   // nb de contours du fichier
	   nb_contour_total = nbcontours_total(fac, nbfac);
      
	// Lecture du fichier des valeurs
       if((pficv=fopen(nom_valeur,"r"))==NULL)
		{
            printf("\n impossible ouvrir %s\n",nom_valeur); 
			exit(0);
  		}
          
	fscanf(pficv,"%d %d %lf %lf",&nbfac_val,&nomax_val,&mini,&maxi);
	if ((nbfac_val != nbfac) || (nomax_val != nomax))
	{ printf("--- Incoherence entre fichiers .cir et .val, verifiez vos donnees ... ---\n");
	 exit(0);
	}
	rewind(pficv);

		// Allocation du tableau des valeurs 
	valeur = alloue_double(nb_contour_total,456);
	lect_fic_val(pficv, valeur);
	fclose(pficv);

	// Lecture du fichier des valeurs de types de surface
       if((pficv=fopen(nom_type,"r"))==NULL)
		{
            printf("\n impossible ouvrir %s\n",nom_type); 
			exit(0);
  		}
          
	fscanf(pficv,"%d %d %lf %lf",&nbfac_val,&nomax_val,&mini,&maxi);
	if ((nbfac_val != nbfac) || (nomax_val != nomax))
	{ printf("--- Incoherence entre fichiers .cir et .val, verifiez vos donnees ... ---\n");
	 exit(0);
	}
	rewind(pficv);

		// Allocation du tableau des valeurs 
	type_surf = alloue_double(nb_contour_total,456);
	lect_fic_val(pficv, type_surf);
	fclose(pficv);

	// Lecture du fichier des valeurs de types de surface a retenir
       if((pficv=fopen(nom_type1,"r"))==NULL)
		{
            printf("\n impossible ouvrir %s\n",nom_type1); 
			exit(0);
  		}
	nb_val_retenir = lit_fic_retenir(pficv,val_retenir);
	for(i=0;i<nb_val_retenir;i++) {printf("retient les contours ayantun type de surface egal a %f\n",val_retenir[i]);}
	fclose(pficv);


/*------------------------------------------------------------------------------*/
/* �criture du fichier des x y z (centre de gravit�) val des noeuds pour FLUENT */
/*	seulement ceux dont la valeur type de surface est a retenir                 */
/*------------------------------------------------------------------------------*/
  if((pficr=fopen(nom_resultat,"w"))==NULL)
		{
        	printf("\n impossible ouvrir %s\n",nom_resultat); 
			exit(0);
		}
  fprintf (pficr,"((%s point %6d)\n",argv[5],nb_contour_total);

  // ecriture de la coordonn�e x
  nb_contour_retenu=0;
  fprintf(pficr,"(x\n");
  noc =0;
  nchange=0;
  for(nf=0;nf<nbfac;nf++) 
  {
	  pcont=(fac+nf)->debut_projete;
      while(pcont) 	
      { pcir=pcont->debut_support;   	
		if(test_si_retient(noc,type_surf,nb_val_retenir,val_retenir))
		{
		    nb_contour_retenu++;
			centre_de_gravite(pcir,&xg,&yg,&zg);
			fprintf(pficr," %f",xg);
			nchange++;
			if(nchange%4==0)fprintf(pficr,"\n");
		}
		noc++;
 		pcont=pcont->suc; 
       } 
  }
  fprintf(pficr,")\n");

  // ecriture de la coordonn�e y
  fprintf(pficr,"(y\n");
  noc =0;
  nchange=0;
  for(nf=0;nf<nbfac;nf++) 
  {
	  pcont=(fac+nf)->debut_projete;
      while(pcont) 	
      { pcir=pcont->debut_support;   	
		if(test_si_retient(noc,type_surf,nb_val_retenir,val_retenir))
		{
			centre_de_gravite(pcir,&xg,&yg,&zg);
			fprintf(pficr," %f",yg);
			nchange++;
			if(nchange%4==0)fprintf(pficr,"\n");
		}
		noc++;
		pcont=pcont->suc; 
       } 
  }
  fprintf(pficr,")\n");

    // ecriture de la coordonn�e z
  fprintf(pficr,"(z\n");
  noc =0;
  nchange=0;
  for(nf=0;nf<nbfac;nf++) 
  {
	  pcont=(fac+nf)->debut_projete;
      while(pcont) 	
      { pcir=pcont->debut_support;   	
		if(test_si_retient(noc,type_surf,nb_val_retenir,val_retenir))
		{
			centre_de_gravite(pcir,&xg,&yg,&zg);
			fprintf(pficr," %f",zg);
			nchange++;
			if(nchange%4==0)fprintf(pficr,"\n");
		}
		noc++;
 		pcont=pcont->suc; 
       } 
  }
  fprintf(pficr,")\n");

    // ecriture de la valeur
  fprintf(pficr,"(temp\n");
  noc =0;
  nchange=0;
  for(nf=0;nf<nbfac;nf++) 
  {
	  pcont=(fac+nf)->debut_projete;
      while(pcont) 	
      { pcir=pcont->debut_support;   	
		if(test_si_retient(noc,type_surf,nb_val_retenir,val_retenir))
		{
			fprintf(pficr," %f",valeur[noc]);
			nchange++;
			if(nchange%4==0)fprintf(pficr,"\n");
		}
		noc++;
 		pcont=pcont->suc; 
       } 
  }
  fprintf(pficr,")\n");
  fprintf(pficr,")\n");
  // reajuste le nb de contours retenu
  rewind(pficr);
  fprintf (pficr,"((%s point %6d)\n",argv[5],nb_contour_retenu);
  fclose(pficr);

 printf("nb de contours retenu : %d\n",nb_contour_retenu);
/* Desallocations */
    desalloue_fface(fac,nbfac);
	desalloue_double(valeur);
	desalloue_double(type_surf);
       	
	printf(" fin du traitement\n\n");
}


/*------------------------------------------------------------*/
int lit_fic_retenir(fp,val_r)
FILE	*fp;
float	*val_r;
{
int i,id;
	i=0;
	while(1)
	{ if (i > HMAX)
		{ printf("trop de lignes dans le fichier meteo (max %d)\n\n",HMAX);
		  exit(0);
		}
	  id= fscanf(fp," %f", val_r+i);

	  if(id==EOF) break;
	  i++;
	}
	printf("	nombre de lignes lues dans le fichier des valeurs a retenir : %d\n",i);
	return(i);

}
/*_________________________________________________________________*/
int test_si_retient(noc,type_surf,nb_val_retenir,val_retenir)
int noc;
double *type_surf;
int nb_val_retenir;
float *val_retenir;
{
	int i;

	// test si retient le contour d'indice no en comparant sa valeur type_surf
	// aux nb_val_retenir val de val_retenir
	for (i=0;i<nb_val_retenir;i++)
	{ if(type_surf[noc]==val_retenir[i])
		{ //printf("retientle contour  %d\n",noc+1);
		  return(1);
		}
	}
	return(0);
}

/*_________________________________________________________________*/
void format()
	{
  	printf("\n   format d'entree des parametres \n\n");
  	printf("solene_val_to_fluent  fichier_a_traiter(.cir)  fichier_valeur(.val) fichier_val_tri(.val) val_tri(.txt) fichier_resultat_fluent(.dat) \n\n");	
  	exit(0);
	}

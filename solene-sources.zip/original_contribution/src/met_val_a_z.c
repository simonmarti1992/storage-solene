/*
 *  Copyright 1980-2007 Dominique Groleau, Christian Marenne, Francis 
 *                                  Miguet (CERMA, UMR 1563 AAU, CNRS / Ecole 
 *                                  d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

// met_val_a_z

// D.GROLEAU janv 2004


// Calcule le Z moyen d'un contour et construit le descripteur correspondant



#include<solene.h>


// DECLARATIONS FUNCTIONS

void format_entree();
void trans_face();



/*_________________________________________________________________*/
main(argc,argv)
 int argc;char **argv;
{
 char 		buf[512],*s_dir;
 double		englob[10];
 int		nbff,nomax;
 FILE		*fp,*fpval2;
 struct modelisation_face *ff;
 struct contour *pcont;
 struct circuit *pcir;

 int		j,k,noc;
 double		vmin,vmax;

  printf("\n\nCommande:  met_val_a_z\n\n");

  if(argc!=3)format_entree();

	s_dir=(char *)getenv("PWD");

  compose_nom_complet(buf,s_dir,argv[1],"cir");
  if((fp=fopen(buf,"r"))==NULL)
        { printf("\n impossible ouvrir %s\n",buf); exit(0);}
   lit_en_tete(fp,&nbff,&nomax,englob);
   ff=alloue_face(nbff,35);
   lit_fic_cir3d(fp,nbff,ff);
   fclose(fp);

   printf(" geometrie_IN : %s (%d faces)\n",buf,nbff);
       
  compose_nom_complet(buf,s_dir,argv[2 ],"val");
  if((fpval2=fopen(buf,"w"))==NULL)
	{ printf("impossible ouvrir %s\n",buf);
	  exit(0);
	}
	
  printf(" descripteur_OUT : %s\n",buf);

// calcul le z moyen par contour
  
   fprintf(fpval2,"%7d %7d %15.3f %15.3f\n",nbff,nomax,1000000,-1000000);

   for(j=0;j<nbff;j++) 
    {
	  
	   // calcul le Z moyen sur le premier contour
        pcont=(ff+j)->debut_projete; 
		noc=0;
		while(pcont)	   
        { 
		  pcir=pcont->debut_support;
		  centre_de_gravite(pcir, &obs.xo, &obs.yo, &obs.zo);
          noc++;

					//printf("FACE %d  Contour %d\n",(ff)->nofac_fichier,noc); 
				    //printf("   %lf %lf %lf\n",obs.xo,obs.yo,obs.zo);

          pcont=pcont->suc;
		}
	   fprintf(fpval2,"f%d %d\n",(ff+j)->nofac_fichier,noc);
	   for(k=0;k<noc;k++) 
	   { fprintf(fpval2,"%15.6f\n",obs.zo);
	   }

	   if(obs.zo < vmin) vmin = obs.zo;
	   if(obs.zo > vmax) vmax = obs.zo;
    }

/* stocke le fichier val */
     rewind(fpval2);
     fprintf(fpval2,"%7d %7d %15.3f %15.3f\n",nbff,nomax,vmin,vmax);
	 fclose(fpval2);


	desalloue_fface(ff,nbff);
	
	creer_OK_Solene();

}

/*_________________________________________________________________*/
void format_entree()
{
  printf("\n    met_z_a_val  fichier_in(.cir)  fichier_out(.val)\n\n");
   exit(0);
}




/*
 *  Copyright 2006-2010 Julien Bouyer (CERMA, UMR 1563 AAU, CNRS / 
 *                                  Ecole d'Architecture de Nantes, France.)
 *  Copyright 2010-2013 Laurent Malys (CERMA, UMR 1563 AAU, CNRS /
 *                                  Ecole d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

// ==========================================================
// descriptif de la fonction
// ==========================================================
//
// developpe par Julien Bouyer
// mise a jour des fonctions utilisees dans these J.Bouyer
// derniere mise a jour : juillet 2010
//
// - permet de calculer les temperatures de surface d'une scene (.cir)
// maillee (triangulee) en fonction de la nature de ses surfaces
// (modeles d'amenagements possibles : batiment, sol, arbres),
// des conditions meteo, des conditions initiales sur unb pas de temps
// de reference dt
// - permet aussi de calculer le comportement thermique d'un batiment
// identifie dans la scene : calcul des temperatures internes et ou de
// la consommation energetique durant dt
// - peut etre couplee avec des outils de CFD (Saturne, Fluent)
// par interface python ou C
//
// Modification de Laurent Malys
// developpement : juillet 2011
//
// - integration d'un type de surface supplementaire avec prise en compte de la transpiration
// - choix des parametres de la vegetation avec 4 descripteurs supplememtaires

#include "includes/sim_ts.h"

void utilisation(int argc)
//------------------------------------------------------------------------------------
// rapelle le format d'appel a la fonction a l'utilisateur s'il commet
// une erreur
//------------------------------------------------------------------------------------
{
	if (argc != 40) {
		printf("\nATTENTION : le nombre d'argument doit etre egal a 25 \n\n");
		printf("      FORMAT DE LA FONCTION :\n\n");
		printf("      0   nom de la fonction \n");
		printf("      1   pas de tps \n");
		printf("      2   surfaces facettes (.val) \n");
		printf("      3   facteurs de forme (.fac) \n");
		printf("      4   facteurs de vue du ciel (.val) \n");
		printf("      5   temperature de l'air exterieur (.val) \n");
		printf("      6   humidite de l'air exterieur (.val) \n");
		printf("      7   coefficient d'echange superficiel convectif (hc)(.val) \n");
		printf("      8   flux IR atmospherique horizontal \n");
		printf("      9   flux solaires directs (.val) \n");
		printf("      10  flux solaires diffus (.val) \n");
		printf("      11  composition des materiaux de surface (.txt) \n");
		printf("      12  numero classe paroi (.val) \n");
		printf("      13  numero type paroi (.val) \n");
		printf("      14  albedo des facettes (.val) \n");
		printf("      15  emissivite des facettes (.val) \n");
		printf("      16  transmitivite des facettes (.val) \n");
		printf("      17  coefficient d'evaporation du sol (f) (.val)\n");
		printf("      18  conditions limites du sous-sol (1m) \n");
		printf("      19  temperatures de surface exterieure initiales (.val) \n");
		printf("      20  TN1 int initiales (noeud 1 pour les surfaces des batiments et sol) (.val)\n");
		printf("      21  TN2 int initiales (pour le sol) (.val)\n");
		printf("      22  Ta initiales (pour les parois vegetales) (.val)\n");
		printf("      23  Tse_veg initiales (pour les parois vegetales) (.val)\n");
		printf("      24  temperatures de surface exterieure calculees (.val) \n");
		printf("      25  TN1 calculees (noeud 1 pour les surfaces des batiments et sol) (.val)\n");
		printf("      26  TN2 calculees (noeud 2 pour le sol) (.val)\n");
		printf("      27  Ta (pour les parois vegetales) (.val)\n");
		printf("      28  Tse_veg (pour les parois vegetales) (.val)\n");
		printf("      29  Coefficient facade vegetale (.txt)\n");
		printf("      30  Chemin vers les repertoires des sorties auxiliaires (.txt)\n");
		printf("      31  Cf\n");
		printf("      32  Ca\n");
		printf("      33  h_ainf\n");
		printf("      34  h_pa\n");
		printf("      35  LAI\n");
		printf("      36  v\n");
		printf("      37  Teau\n");
		printf("      38  Qeau\n");
		printf("      39  Répartition flatent");
		printf("\n");
		exit(0);
	}
}

// ==========================================================
// programme principal
// ==========================================================
int main(int argc, char *argv[]) {

  // DECLARATION DES VARIABLES
  //##################################################################################################################
  
  // VARIABLES GEOMETRIQUES
  
  int nb_facette; // nb de contour total de la geometrie
  int nb_face, no_face_max; // nb de faces et n de la face max de la geometrie
  int *tab_no_face; // tableau des n de faces de la geometrie
  int *tab_nb_contour_face; // tableau des nb de contours par faces de la geometrie

  // DONNEES D'ENTREE : NOMS FICHIERS & VARIABLES D'ACCUEIL
  
  char nom_fic_paroi[TAILLE_CHAINE_NOM_FICHIER]; // nom du fichier des caracteristiques de paroi
  int nb_paroi; // nb de parois
  paroi *tab_paroi; // tableau des differentes classes generales parois

  paroi *surf_bat; // tableau de la classe des autres enveloppes de batiment
  paroi *surf_sol; // tableau de la classe des sols
  
  char nom_fic_sortie_aux[TAILLE_CHAINE_NOM_FICHIER]; // nom du fichier contenant les chemins vers les sorties aux // laurent

  char nom_fic_sol[TAILLE_CHAINE_NOM_FICHIER]; // nom du fichier des caracteristiques des sous sols
  prop_sol info_sol; // caracteristiques des sols

  int jour;
  int jour_ref;
  double moy_Tair;
  double max_Tair;
  double min_Tair;

  char nom_fic_surface[TAILLE_CHAINE_NOM_FICHIER]; // nom du fichier descripteur des surfaces
  double *surface; // tableau des surfaces
  
  char nom_fic_classe_paroi[TAILLE_CHAINE_NOM_FICHIER]; // nom du fichier descripteur de la classe de paroi
  double *classe_paroi; // tableau des classes de paroi
  
  char nom_fic_id_paroi[TAILLE_CHAINE_NOM_FICHIER]; // nom du fichier descripteur des nID de parois
  double *id_paroi; // tableau des identificateurs des n ID de parois ext (1 : murs / 2 : vitrages / 3 : toiture )
  
  char nom_fic_flux_sol_dir[TAILLE_CHAINE_NOM_FICHIER]; // nom du fichier descripteur des flux solaires directs incidents
  double *flux_sol_dir; // tableau des des flux solaires directs incidents
  
  char nom_fic_flux_sol_diff[TAILLE_CHAINE_NOM_FICHIER]; // nom du fichier descripteur des flux solaires diffus incidents
  double *flux_sol_diff; // tableau des des flux solaires diffus incidents
  
  char nom_fic_fciel[TAILLE_CHAINE_NOM_FICHIER]; // nom du fichier des facteurs de forme
  double *fciel; // valeur des facteurs de forme
  
  FILE *pf_fform; // pointeur du fichier des facteurs de forme
  char nom_fform[TAILLE_CHAINE_NOM_FICHIER]; // nom du fichier des facteurs de forme
  float *fform; // valeur des facteurs de forme
  
  char nom_fic_hc_ext[TAILLE_CHAINE_NOM_FICHIER]; // nom du fichier descripteur des h_conv
  double *hc_ext; // tableau des des h_conv

  char nom_fic_TSext_init[TAILLE_CHAINE_NOM_FICHIER]; // nom du fichier descripteur des temperature de surf exterieures init
  double *TSext_init; // temperature de surfaces des facettes init
  
  char nom_fic_TNint1_init[TAILLE_CHAINE_NOM_FICHIER]; // nom du fichier descripteur des temperatures interieures 1er noeud init
  double *TNint1_init; // temperature interieures 1er noeud des facettes init
  
  char nom_fic_TNint2_init[TAILLE_CHAINE_NOM_FICHIER]; // nom du fichier descripteur des temperatures 2e noeud init
  double *TNint2_init; // temperature interieures 2e noeud des facettes init

  char nom_fic_Ta_init[TAILLE_CHAINE_NOM_FICHIER]; // nom du fichier descripteur des temperatures Ta init
  double *Ta_init; // temperature interieures 2e noeud des facettes init

  char nom_fic_Tse_veg_init[TAILLE_CHAINE_NOM_FICHIER]; // nom du fichier descripteur des temperatures Tse_veg init
  double *Tse_veg_init; // temperature Tse_veg init

  char nom_fic_albedo[TAILLE_CHAINE_NOM_FICHIER]; // nom du fichier descripteur des albedo
  double *albedo; // tableau des des albedo
  
  char nom_fic_emissivite[TAILLE_CHAINE_NOM_FICHIER]; // nom du fichier descripteur des emissivites
  double *emissivite; // tableau des des emissivites
  
  char nom_fic_transmission[TAILLE_CHAINE_NOM_FICHIER]; // nom du fichier descripteur des transmitivites solaires (vitrages bat etude + arbres)
  double *transmission; // tableau des des transmitivites solaires (vitrages bat etude + arbres)
  
  char nom_fic_Text[TAILLE_CHAINE_NOM_FICHIER]; // nom du fichier descripteur de la temperature de l'air a proximite des facettes
  double *Text; // temperature de l'air a proximite des facettes
  
  char nom_fic_w_ext[TAILLE_CHAINE_NOM_FICHIER]; // nom du fichier descripteur de la masse de vapeur d'eau dans l'air a proximite des facettes
  double *w_ext; // masse de vapeur d'eau dans l'air a proximite des facettes
  
  char nom_fic_f_evap_sol[TAILLE_CHAINE_NOM_FICHIER]; // nom du fichier descripteur coefficient de potentiel evaporatif du sol
  double *f_evap_sol; // coefficient de potentiel evaporatif du sol
  
  double flux_atm; // flux IR atmospherique au pas de temps courant
  
  // DONNEES DE SORTIE : NOMS FICHIERS & VARIABLES D'ACCUEIL
  
  char nom_fic_TSext[TAILLE_CHAINE_NOM_FICHIER]; // nom du fichier descripteur des temperature de surf exterieures
  double *TSext; // temperature de surfaces des facettes
  
  double *TSext_pow4;// température puissance 4 pour le bilan GLO // modif laurent malys 12/2010
  
  char nom_fic_TNint1[TAILLE_CHAINE_NOM_FICHIER]; // nom du fichier descripteur des temperature interieures noeud 1
  double *TNint1; // temperature de interieures noeud 1 des facettes
  
  char nom_fic_TNint2[TAILLE_CHAINE_NOM_FICHIER]; // nom du fichier descripteur des temperature interieures noeud 2
  double *TNint2; // temperature de interieures noeud 2 des facettes

 char nom_fic_Ta[TAILLE_CHAINE_NOM_FICHIER]; // nom du fichier descripteur des temperatures Ta // laurent
  double *Ta; // temperature Ta // laurnet 
  
 char nom_fic_Tse_veg[TAILLE_CHAINE_NOM_FICHIER]; // nom du fichier descripteur des temperature Tse_veg // laurent
  double *Tse_veg; // temperature Tse_veg // laurent
 

  // param vegetation 
 char nom_fic_Cf[TAILLE_CHAINE_NOM_FICHIER]; // lauren
  double *Cf; // laurent
  
 char nom_fic_Ca[TAILLE_CHAINE_NOM_FICHIER]; // laurent
  double *Ca; // laurent
    
 char nom_fic_h_ainf[TAILLE_CHAINE_NOM_FICHIER]; // laurent
  double *h_ainf; // laurent
      
 char nom_fic_h_pa[TAILLE_CHAINE_NOM_FICHIER]; // laurent
  double *h_pa; // laurent

 char nom_fic_LAI[TAILLE_CHAINE_NOM_FICHIER]; // laurent
  double *LAI; // laurent

 char nom_fic_vit[TAILLE_CHAINE_NOM_FICHIER]; // laurent
  double *vit; // laurent

  double Teau;
  double Qeau;
  double alpha_flat;

  char nom_fic_Flux_Latent[TAILLE_CHAINE_NOM_FICHIER]; // nom du fichier des flux latents (pour les sols, utile pour couplage)
  double *Flux_Latent;


  char nom_fic_Flux_Rad_Net_Abs[TAILLE_CHAINE_NOM_FICHIER]; // nom du fichier des flux radiatifs net absorbes (pour les arbres, utile pour couplage)
  double *Flux_Rad_Net_Abs;
  
  char nom_fic_humidite_rel_air[TAILLE_CHAINE_NOM_FICHIER];
  double *humidite_rel_air; // humidite relative de l'air ext
  
  char *ext_tps_val; // contenu de l'extension horaire + extension .val a la fin des fichiers de resultat
  
  // ensemble des flux Grandes Longueurs d'Ondes (GLO) calculees : (IR thermique)
  

  double *GLO_Ciel_Emis; // densites de flux GLO emis vers le ciel
  double *GLO_Ciel_Recu; // densites de flux GLO emis recu du ciel
  double *GLO_Ciel_Net; // densites de flux GLO total net echange avec le ciel
  char nom_fic_GLO_Ciel_Net[TAILLE_CHAINE_NOM_FICHIER];
  double *GLO_Scene_Emis; // densites de flux GLO emis vers les surfaces urbaines
  double *GLO_Scene_Recu; // densites de flux GLO recu des surfaces urbaines
  double *GLO_Scene_Net; // densites de flux GLO total net echange avec les surfaces urbaines
  char nom_fic_GLO_Scene_Net[TAILLE_CHAINE_NOM_FICHIER];
  double *GLO_Total_Emis; // densites de flux GLO TOTAL emis
  double *GLO_Total_Recu; // densites de flux GLO TOTAL recu
  double *GLO_Total_Net; // densites de flux GLO TOTAL net echange
  char nom_fic_GLO_Total_Net[TAILLE_CHAINE_NOM_FICHIER];  

  // ensemble des flux Courtes Longueurs d'Ondes (CLO) calculees : (solaire = visible + IR solaire)
  double *flux_sol_abs; // flux solaire global absorbe par chaque facette (en W/m)
  double flux_min; // pour tester les flux d'entree
  int nb_err; // pour tester les flux d'entree
  int test_flux; // pour tester les flux d'entree
 
 // VARIABLES PHYSIQUES AMENAGEMENT
  
  listeRCparoi *RCsurf_bat; // listes de Rthermique equivalentes et de C int/ext des autres enveloppes de bat
  listeRCparoi *RCsurf_sol; // listes de Rthermique equivalentes et de C int/ext des sols
  
  double h_int_bat = 9; // pour les amenagements types "enveloppes autres batiments"
  
  double z_ref; // profondeur de reference ou le flux de conduction est nul
  double Tsol_ref; // condition limite de temperature a la profondeur z_ref dans le sol
  double Rsol; // resistance thermique du sol (pour epaisseur = z_ref)
  double Csol; // capacite equivalente du sol (pour epaisseur = z_ref)
  
  double lambda_sol; // conductivite th du sol
  double Cp_sol; // capacite thermique du sol
  double rho_sol; // masse volumique du sol
  
  // OUTILS DE RESOLUTION
  
  // pour le calcul matriciel

  double *matBAT; // matrice de resolution autres bat
  double *vecBAT_in; // vecteur de resolution autres bat
  double *vecBAT_out; // vecteur des temperatures inconnues autres bat

  double *matSOL; // matrice de resolution sols
  double *vecSOL_in; // vecteur de resolution sols
  double *vecSOL_out; // vecteur des temperatures inconnues sols

  double *matVEG ; // matrice de resolution enveloppes végétales // laurent
  double *vecVEG_in; // vecteur de resolution enveloppes végétales // laurent
  double *vecVEG_out; // vecteur des temperatures inconnues enveloppes végétales // laurent

  // pour les iterations
  double *TSext_old_1, *TSext_old_2; // vecteur des temperatures inconnues aux 2 pas de calcul precedent
  double *TNint1_TEMP; // pour stocker les TNint1 du sol et des parois pdt les iterations
  double *TNint2_TEMP; // pour stocker les TNint2 du sol et des parois pdt les iterations
  double *Ta_TEMP; // pour stocker les TNint2 du sol et des parois pdt les iteration
  double *Tse_veg_TEMP; // pour stocker les TNint2 du sol et des parois pdt les iterations
  
  double deltaT; // vecteur des differences de temperature entre T et Told
  double somme_deltaT; // somme des differences de temperature entre T et Told
  
  // VARIABLES PROPRES A L'ALGORITHME
  
  double dt; // pas de temps de simulation (sec)
  
  int i, j; // compteurs
  int iter; // compteur des iterations de calcul
  double eps1, eps2; // critere du test de convergence (ecart max, moyenne des ecarts)
  int ratio_face_non_cv; // pourcentage acceptable de face non convergees
  int n_face_non_cv_old_1, n_face_non_cv_old_2; // nb de faces non convergee aux deux pas de temps precedents
  double lambda_relax; // coef de sous relaxation pour la convergence des TSext
  int test_Ts; // valeur entiere du test de convergence de Ts
  
  clock_t dateDebut, dateFin; // date de declenchement et d'arret du chronometre

  // DECLARATION DES VARIABLES BATIMENT
  //##################################################################################################################
  
  int nb_facette_bat ;				// nb de contour du batiment d'etude
  int nb_niv ;                                        // nombre de niveaux du batiment d'etude
  int n ;					        // nombre de noeuds de calcul pour le batiment d'etude
  int nn ;						// n : dimension de la matrice batiment
  double Hniv = 3 ;				// hauteur standard d'un niveau du bat d'etude
  Sniveau *Sniv ;                                  // surface des entites constructives par niveau du batiment d'etude
  paroi *mur ;		       			// tableau des differentes type de parois par classe : murs
  paroi *vitrage ;					// ... : vitrages
  paroi *toiture ;					// ... : parois
  paroi *plancher_int ;				// ... : planchers intermediaires
  paroi *plancher_bas ;				// ... : plancher bas RDC
  paroi *interieur ;                                // ... : parois interieures
	
  char nom_fic_in_air[TAILLE_CHAINE_NOM_FICHIER];			// nom du fichier descripteur des entrees d'air neuf dans le batiment de calcul
  double *in_air;						// tableau des entrees d'air neuf dans le batiment de calcul
	
  char nom_fic_niveau[TAILLE_CHAINE_NOM_FICHIER];			// nom du fichier descripteur des entrees d'air neuf dans le batiment de calcul
  double *niveau;						// tableau des entrees d'air neuf dans le batiment de calcul
  char nom_fic_Tnoeuds_init[TAILLE_CHAINE_NOM_FICHIER] ;		// nom du fichier contenant la matrice des temperatures nodales int du batiment de calcul

  double *T2_init ; // temperature de niveau au noeud 2 initiale (murs)
  double *T4_init ; // temperature de niveau au noeud 4 initiale (vitrages)
  double *T5_init ; // temperature de niveau au noeud 5 initiale (plancher)
  double *T6_init ; // temperature de niveau au noeud 6 initiale (plafond)
  double *T7_init ; // temperature de niveau au noeud 7 initiale (surf paroi int)
  double *T8_init ; // temperature de niveau au noeud 8 initiale (int paroi int)
  double *T9_init ; // temperature de niveau au noeud 9 initiale (Tmr)
  double *T10air_init ; // temperature de niveau au noeud 10 initiale (Tair)
  double *T12_init ; // temperature de niveau au noeud 12 initiale (plafond sous toiture)
  double *Tsol_bis_init ; // temperature de niveau au noeud 5bis initiale (milieu couche de sous-sol)
 
  char nom_fic_Tnoeuds_out[TAILLE_CHAINE_NOM_FICHIER] ;
  double *T2 ;
  double *T4 ;
  double *T5 ;
  double *T6 ;
  double *T7 ;
  double *T8 ;
  double *T9 ;
  double *T10air ;
  double *T12 ;
  double *Tsol_bis ;
  double *Pconv ;
  double *Platent ;
  
  // variable intermediaire pour le calcul des puissances ou  de Tair au noeud 10
  double *inconnue ; // Pconv pour le regime force / T10 (air int) pour le regime libre
  
  // flux solaires transmis par les ouvertures et absorbe par les murs, vitrages, planchers, plafonds, parois int, pour chaque niveau
  double *Ft_mur, *Ft_vit, *Ft_plc, *Ft_plf, *Ft_int ;
  
  // VARIABLES PHYSIQUES DU BATIMENT
  
  listeRCparoi *RCmur, *RCvit, *RCtoit, *RCplc_int, *RCplc_bas, *RCint ;		// listes de resistance thermique equivalentes et de capacites int/ext des parois du bat d'etude
  double *Rcv_i, *Rrad_i;			// resistance convective et radiative interieure
    
  double *hc_int ; // voir [Fraisse et Virgone p.9] : plancher (1.6 W/m.K), plafond (6.1 W/m.K), murs (4.1 W/m.K) > moyenne hc_int = 4 / attribution des valeurs dans le main
  double hr_int = 5 ;		// on retrouve bien h_int(global) biblio d'environ 9 W/m.K avec h_int = hr_int + hc_int moyen !!!
    
  double abs_plc = 0.4 ;	// absorptivite solaire des planchers (couleur gris clair)  (cf. E.Mazria : Le guide de la maison solaire)
  double abs_vit = 0.13 ;	// absorptivite solaire des vitrages (cote interieur) (cf. Memento St Gobain "CLIMAPLUS N" p.286)
    
  double *Cai ;			// capacite de la masse d'air du niveau
  double *Rra ;			// resistance de la masse d'air du niveau
    
  double T10consigne ; 			// temperature de consigne interieure
  double Tc_occup_ete = 26.0 ; 	// temperature de consigne ete/occupation (cf. These S.Filfli)
  double Tc_occup_hiv = 19.0 ; 	// temperature de consigne hiver/occupation (cf. These S.Filfli)
  double Tc_inoccup_hiv = 15.0 ; 	// temperature de consigne hiver/occupation (cf. These S.Filfli)
    
  double ps_equip ;				// charges sensibles dues aux equipements(eclairage, bureautique), ramene au m de plancher
  double *Ps_equip ;				// charges sensibles dues aux equipements(eclairage, bureautique) (W)
  double *Ps_occup ;				// charges sensibles dues aux occupants (W)
  double *Pl_occup ;				// charges latentes dues aux occupants (W)
  double taux_occup ;				// taux d'occuation d'un etage de batiment (occupant / m)
  double taux_occup_max = 0.064 ;	// taux d'occuation maximum pour definir le debit courant de ventilation (celui du bat bureau "BEETHOVEN") independemment de l'occupation reelle au tps courant
  double debit_hyg_indiv = 15 ;	// debit hygienique de ventilation (m3 / occupant.m) (cf. NF EN ISO 13790)
  int saison ;					// ete (0) / hiver (1)
    
  int *alpha ;			// alpha = indicateur du regime de simulation : Force (0), Libre (1), Mixte (2)
  int alpha_arg ;			// alpha lu en argument
 
  double *A ;						// matrice de resolution bat etude
  double *b ;						// vecteur de resolution bat etude
  double *T ;						// vecteur des temperatures inconnues bat etude

  int test_Tconsigne ;				// valeur entiere du test de comparaison entre Tair(niv) et Tconsigne
	
  
  // LECTURE DES ENTREES
  //##################################################################################################################
  
  printf("\n[ DEBUT EXECUTION ]\n");
  //------------------------------------------------------------------------------------
  
  utilisation(argc); // test sur le nombre d'arguments & format de l'appel a la fonction
  
  printf("\n[ LECTURE DES ENTREES ]\n");
  //------------------------------------------------------------------------------------
  
  // PAS DE TEMPS (nombre entier)
  dt = atof(argv[1]);
  printf("\nPas de temps de simulation : %f s", dt);
  
  // lecture du 1er descripteur(.val) pour obtenir les elements geometriques necessaires
  complement_extension(nom_fic_surface, argv[2], "val");
  printf("\nFichier de base de calcul des contours : %s", nom_fic_surface);
  // lecture du nombre de faces dans descripteur
  nb_face = total_face(nom_fic_surface);
  printf("\n     # Nombre de faces : %d", nb_face);
  // allocation du tableau de n de face
  tab_no_face = allocation_tableau_int(nb_face);
  // allocation du tableau de nb de contours par face
  tab_nb_contour_face = allocation_tableau_int(nb_face);
  // analyse geometrique complete	
  analyse_face_contour(nom_fic_surface, &no_face_max, &nb_facette,
		       tab_no_face, tab_nb_contour_face);
  printf("\n     # Nombre total de contours : %d", nb_facette);
  
  // SURFACES DES CONTOURS (*.val)
  surface = allocation_tableau_double(nb_facette);
  complement_extension(nom_fic_surface, argv[2], "val");
  printf("\nFichier descripteur de surface : %s", nom_fic_surface);
  lecture_descripteur(nom_fic_surface, surface);
  
  // FACTEUR DE FORME AVEC LA SCENE (*.fac)
  complement_extension(nom_fform, argv[3], "fac");
  printf("\nFichier des facteurs de forme: %s", nom_fform);
  fform = allocation_tableau_float(nb_facette);
  
  // FACTEUR VUE DU CIEL (*.val)
  fciel = allocation_tableau_double(nb_facette);
  complement_extension(nom_fic_fciel, argv[4], "val");
  printf("\nFichier descripteur des facteurs d'ouverture au ciel : %s",
	 nom_fic_fciel);
  lecture_descripteur(nom_fic_fciel, fciel);
  
  // TEMPERATURE D'AIR EXT (*.val)
  Text = allocation_tableau_double(nb_facette);
  complement_extension(nom_fic_Text, argv[5], "val");
  printf("\nFichier descripteur des temperatures d'air proche des parois : %s",
	 nom_fic_Text);
  lecture_descripteur(nom_fic_Text, Text);
  
  // CHARGE D'HUMIDITE DE L'AIR EXTERIEUR (caractere)
  w_ext = allocation_tableau_double(nb_facette);
  complement_extension(nom_fic_w_ext, argv[6], "val");
  printf(
	 "\nFichier descripteur de la charge d'humidite de l'air exterieur : %s",
	 nom_fic_w_ext);
  lecture_descripteur(nom_fic_w_ext, w_ext);
  
  // COEF DE CONVECTION EXTERIEUR (*.val)
  hc_ext = allocation_tableau_double(nb_facette);
  complement_extension(nom_fic_hc_ext, argv[7], "val");
  printf("\nFichier descripteur des hc : %s", nom_fic_hc_ext);
  lecture_descripteur(nom_fic_hc_ext, hc_ext);
  
  // FLUX IR ATMOSPHERIQUE (scalaire)
  flux_atm = atof(argv[8]);
  printf("\nFlux IR atmospherique : %f", flux_atm);
  
  // FLUX SOLAIRE DIRECT (*.val)
  flux_sol_dir = allocation_tableau_double(nb_facette);
  complement_extension(nom_fic_flux_sol_dir, argv[9], "val");
  printf("\nFichier descripteur des flux solaires directs incidents : %s",
	 nom_fic_flux_sol_dir);
  lecture_descripteur(nom_fic_flux_sol_dir, flux_sol_dir);
  
  // FLUX SOLAIRE DIFFUS (*.val)
  flux_sol_diff = allocation_tableau_double(nb_facette);
  complement_extension(nom_fic_flux_sol_diff, argv[10], "val");
  printf("\nFichier descripteur des flux solaires diffus incidents : %s",
	 nom_fic_flux_sol_diff);
  lecture_descripteur(nom_fic_flux_sol_diff, flux_sol_diff);
  
  // COMPOSITION DES SURFACES (*.txt)
  complement_extension(nom_fic_paroi, argv[11], "txt");
  printf("\nFichier des proprietes des parois : %s", nom_fic_paroi);
  nb_paroi = lecture_nb_paroi(nom_fic_paroi);
  printf("\n     # Nombre de paroi : %d", nb_paroi);
  tab_paroi = allocation_struct_paroi(nb_paroi);
  lecture_donnees_paroi(nom_fic_paroi, tab_paroi);
  
  // CLASSE DES SURFACES (*.val)
  classe_paroi = allocation_tableau_double(nb_facette);
  complement_extension(nom_fic_classe_paroi, argv[12], "val");
  printf("\nFichier descripteur des classes de parois : %s",
	 nom_fic_classe_paroi);
  lecture_descripteur(nom_fic_classe_paroi, classe_paroi);
  
  // IDENTIFICATEUR DES SURFACES (*.val)
  id_paroi = allocation_tableau_double(nb_facette);
  complement_extension(nom_fic_id_paroi, argv[13], "val");
  printf("\nFichier descripteur des identifiants de parois : %s",
	 nom_fic_id_paroi);
  lecture_descripteur(nom_fic_id_paroi, id_paroi);
  
  // ALBEDOS (*.val)
  albedo = allocation_tableau_double(nb_facette);
  complement_extension(nom_fic_albedo, argv[14], "val");
  printf("\nFichier descripteur des albedos : %s", nom_fic_albedo);
  lecture_descripteur(nom_fic_albedo, albedo);
  
  // EMISSIVITES (*.val)
  emissivite = allocation_tableau_double(nb_facette);
  complement_extension(nom_fic_emissivite, argv[15], "val");
  printf("\nFichier descripteur des emissivites IR : %s", nom_fic_emissivite);
  lecture_descripteur(nom_fic_emissivite, emissivite);
  
  // TRANSMITIVITES (*.val)
  transmission = allocation_tableau_double(nb_facette);
  complement_extension(nom_fic_transmission, argv[16], "val");
  printf("\nFichier descripteur des coefficients de transmission solaire : %s",
	 nom_fic_transmission);
  lecture_descripteur(nom_fic_transmission, transmission);
  
  // COEFFICIENT D'EVAPORATION DES SOLS (*.val)
  f_evap_sol = allocation_tableau_double(nb_facette);
  complement_extension(nom_fic_f_evap_sol, argv[17], "val");
  printf("\nFichier descripteur des coefficients d'evaporation du sol : %s",
	 nom_fic_f_evap_sol);
  lecture_descripteur(nom_fic_f_evap_sol, f_evap_sol);
  
  // CONDITIONS LIMITES DANS LE SOL
  complement_extension(nom_fic_sol, argv[18], "txt");
  printf("\nFichier des proprietes du sous sol (physique et meteo) : %s",
	 nom_fic_sol);
  lecture_donnees_sol(nom_fic_sol, &info_sol);
  
  // TEMPERATURES DE SURFACE INITIALES(*.val)
  TSext_init = allocation_tableau_double(nb_facette);
  complement_extension(nom_fic_TSext_init, argv[19], "val");
  printf("\nFichier descripteur des Tsurface ext init : %s",
	 nom_fic_TSext_init);
  lecture_descripteur(nom_fic_TSext_init, TSext_init);
  
  // TEMPERATURES NODALES INTERIEURES 1 INITIALES POUR LES SURFACES DE BATIMENTS ET LES SOLS (*.val)
  TNint1_init = allocation_tableau_double(nb_facette);
  complement_extension(nom_fic_TNint1_init, argv[20], "val");
  printf(
	 "\nFichier descripteur des Tnodales 1 initiales des batiments et sols : %s\n\n",
	 nom_fic_TNint1_init);
  lecture_descripteur(nom_fic_TNint1_init, TNint1_init);
  
  // TEMPERATURES NODALES INTERIEURES 2 INITIALES POUR LES SURFACES DE BATIMENTS ET LES SOLS (*.val)
  TNint2_init = allocation_tableau_double(nb_facette);
  complement_extension(nom_fic_TNint2_init, argv[21], "val");
  printf("\nFichier descripteur des Tnodales 2 initiales des batiments et sols : %s\n\n",
	 nom_fic_TNint2_init);
  lecture_descripteur(nom_fic_TNint2_init, TNint2_init);

  // TEMPERATURES NODALES Ta INITIALES POUR LES PAROIS VEGETALES (*.val) // laurent
  Ta_init = allocation_tableau_double(nb_facette);
  complement_extension(nom_fic_Ta_init, argv[22], "val");
  printf("\nFichier descripteur des Tnodales 2 initiales des batiments et sols : %s\n\n",
	 nom_fic_Ta_init);
  lecture_descripteur(nom_fic_Ta_init, Ta_init);
 
  // TEMPERATURES NODALES TSE_VEG INITIALES POUR LES PAROIS VEGETALES (*.val) // laurent
  Tse_veg_init = allocation_tableau_double(nb_facette);
  complement_extension(nom_fic_Tse_veg_init, argv[23], "val");
  printf("\nFichier descripteur des Tnodales 2 initiales des batiments et sols : %s\n\n",
	 nom_fic_Tse_veg_init);
  lecture_descripteur(nom_fic_Tse_veg_init, Tse_veg_init);
    
  Cf = allocation_tableau_double(nb_facette);
  complement_extension(nom_fic_Cf, argv[31], "val");
  printf("\nFichier descripteur Cf : %s\n\n",
	 nom_fic_Cf);
  lecture_descripteur(nom_fic_Cf, Cf);

  Ca = allocation_tableau_double(nb_facette);
  complement_extension(nom_fic_Ca, argv[32], "val");
  printf("\nFichier descripteur Ca : %s\n\n",
	 nom_fic_Ca);
  lecture_descripteur(nom_fic_Ca, Ca);
  
  h_ainf = allocation_tableau_double(nb_facette);
  complement_extension(nom_fic_h_ainf, argv[33], "val");
  printf("\nFichier descripteur h_ainf : %s\n\n",
	 nom_fic_h_ainf);
  lecture_descripteur(nom_fic_h_ainf, h_ainf);

  h_pa = allocation_tableau_double(nb_facette);
  complement_extension(nom_fic_h_pa, argv[34], "val");
  printf("\nFichier descripteur h_pa : %s\n\n",
	 nom_fic_h_pa);
  lecture_descripteur(nom_fic_h_pa, h_pa);

  LAI = allocation_tableau_double(nb_facette);
  complement_extension(nom_fic_LAI, argv[35], "val");
  printf("\nFichier descripteur LAI : %s\n\n",
	 nom_fic_LAI);
  lecture_descripteur(nom_fic_LAI, LAI);
    
  vit = allocation_tableau_double(nb_facette);
  complement_extension(nom_fic_vit, argv[36], "val");
  printf("\nFichier descripteur vit : %s\n\n",
	 nom_fic_vit);
  lecture_descripteur(nom_fic_vit, vit);

  // FLUX IR ATMOSPHERIQUE (scalaire)
  Teau = atof(argv[37]);
  printf("\nTemp refroidissement eau : %f", Teau);
 
  Qeau = atof(argv[38]);
  printf("\nqte eau : %f", Qeau);
    
  alpha_flat = atof(argv[39]);
  printf("\nrepartition flatent : %f", alpha_flat);
    

    
  // PRETRAITEMENT
  //##################################################################################################################
  
  
  printf("\n[ INITIALISATION DES VARIABLES THERMO-PHYSIQUES ASSOCIEES AUX SURFACES D'AMENAGEMENTS ]\n");
  //===============================================================================================================
  
  // CATEGORIE SURFACES GENERIQUES DE BATIMENTS (numero classe : 6)
  //------------------------------------------------------------------------------------
  
  printf("\nInitialisation des surfaces generiques de batiments");
  
  // allocation memoire de la structure de donnees de paroi correspondante
  surf_bat = allocation_struct_paroi(nb_paroi);
  
  // attribution des caracteristiques du fichier de paroi a la structure de paroi correspondante
  for (i = 0; i < nb_paroi; i++) {
    switch (tab_paroi[i].classe) {
    case 6:
    case 10:
      surf_bat[tab_paroi[i].id] = tab_paroi[i];
      break;
    default:
      break; // correspond aux autres types de facettes (batiment d'etude, sol, arbres, eau, ...)
    }
  }
  
  // allocation memoire de la structure de resitances & capacites
  RCsurf_bat = (listeRCparoi*) calloc(nb_paroi, sizeof(listeRCparoi));
  
  // calcul des resistances thermiques equivalentes et capacites int/ext surfaciques des parois
  for (i = 0; i < nb_paroi; i++) {
    calcul_RCparoi_surfacique(&surf_bat[i], &RCsurf_bat[i]);
  }
  free(surf_bat);
  
  // CATEGORIE SURFACE DE SOL (numero classe : 7)
  //------------------------------------------------------------------------------------
  
  printf("\nInitialisation des surfaces de sols");
  
  // calcul humidite relative
  humidite_rel_air = allocation_tableau_double(nb_facette);
  for (i = 0; i < nb_facette; i++)
    humidite_rel_air[i] = calcul_HR(Text[i], w_ext[i]);
  
  // proprietes du sous-sol
  lambda_sol = info_sol.lambda_sol;
  Cp_sol = info_sol.cp_sol;
  rho_sol = info_sol.rho_sol;
  z_ref = info_sol.z_ref;
  
  // proprietes meteo du modele de sol
  jour = info_sol.i_jour;
  jour_ref = info_sol.i_jour_ref;
  moy_Tair = info_sol.moy_Tair;
  max_Tair = info_sol.max_Tair;
  min_Tair = info_sol.min_Tair;
  
  // caracteristiques de la vegetation
  /* Cf = info_veg.Cf; */
  /* Ca = info_veg.Ca; */
  /* h_ainf = info_veg.h_ainf; */
  /* h_pa = info_veg.h_pa; */

  // calculs
  calcul_proprietes_sol(z_ref, rho_sol, Cp_sol, lambda_sol, &Rsol, &Csol); // proprietes de la couche profonde sous le revetement (amenagement)
  Tsol_ref = calcul_Tref_profondeur(z_ref, jour, jour_ref, moy_Tair,
				    max_Tair, min_Tair, lambda_sol, Cp_sol, rho_sol);
  printf("\n\tTemperature de reference sous sol (profondeur %2.2f m) : %f\n",
	 z_ref, Tsol_ref);
  
  // allocation memoire des structures (paroi) de sol
  surf_sol = allocation_struct_paroi(nb_paroi);
  
  // attribution des caracteristiques du fichier paroi a la structure de paroi correspondante
  for (i = 0; i < nb_paroi; i++)
    switch (tab_paroi[i].classe) {
    case 7:
      surf_sol[tab_paroi[i].id] = tab_paroi[i];
      break;
    default:
      break; // correspond aux autres types de facettes (bat etude, autres batiments, eau, arbres)
    }

  // allocation memoire de la structure de resitances & capacites
  RCsurf_sol = (listeRCparoi*) calloc(nb_paroi, sizeof(listeRCparoi));
  
  // calcul des resistances thermiques equivalentes et capacites int/ext surfaciques des parois
  for (i = 0; i < nb_paroi; i++)
		calcul_RCparoi_surfacique(&surf_sol[i], &RCsurf_sol[i]);
  free(surf_sol);
  
  // allocation des variables de sortie utilisees pour le couplage
  Flux_Latent = allocation_tableau_double(nb_facette); // flux latent evacue par les feuilles

  
  // CATEGORIE "ARBRES" (numero classe : 8)
  //------------------------------------------------------------------------------------
  
  // on initialise simplement les temperatures de feuillages a Tair
  // dans la partie "INITIALISATION DES TEMPERATURES DE FACETTES"
  
  // ALLOCATION DES VARIABLES DE SORTIE UTILISEES POUR LE COUPLAGE
  Flux_Rad_Net_Abs = allocation_tableau_double(nb_facette); // flux radiatif total net absorbe par les feuillages d'arbres
  

  // CATEGORIE "ETENDUES D'EAU" (numero classe : 9)
  //------------------------------------------------------------------------------------
  
  // pas de modele de bassin d'eau pour l'instant
  // voir pour fixer une condition de temperature de surface
  // (Tair au pire des cas, ou mieux Teau provenant de fichiers meteo type RT2005)
  // dans la partie "INITIALISATION DES TEMPERATURES DE FACETTES
  
  
  // CATEGORIE "PAROI VEGETALE" (autres amenagements)(numero classe : 10)
  //------------------------------------------------------------------------------------
  
  Ta = allocation_tableau_double(nb_facette);
  Tse_veg = allocation_tableau_double(nb_facette);
  
  /*if (RESOLUTION_BATIMENT)
    printf("\n[ INITIALISATION DES VARIABLES THERMO-PHYSIQUES ASSOCIEES AU BATIMENT D'ETUDE ENERGETIQUE ]\n");
    //===============================================================================================================
    
    // allocation memoire des structures de paroi
    mur = allocation_paroi(nb_paroi) ;
    vitrage = allocation_paroi(nb_paroi) ;
    toiture = allocation_paroi(nb_paroi) ;
    plancher_int = allocation_paroi(1) ;
    plancher_bas = allocation_paroi(1) ;
    interieur = allocation_paroi(1) ;
    
    // attribution des donnees du fichier_paroi aux structures_paroi correspondantes
    for(i=0 ; i<nb_paroi ; i++)
    switch (tab_paroi[i].classe) // test a choix multiple sur la classe de surface
    {
    case 0 : mur[tab_paroi[i].id] = tab_paroi[i] ; break ;
    case 1 : vitrage[tab_paroi[i].id] = tab_paroi[i] ; break ;
    case 2 : toiture [tab_paroi[i].id] = tab_paroi[i] ; break ;
    case 3 : plancher_int = &tab_paroi[3] ; break ;	// ATTENTION : ne fonctionne que si le descripteur id_paroi est fixe a 3
    case 4 : plancher_bas = &tab_paroi[4] ; break ;	// ATTENTION : ne fonctionne que si le descripteur id_paroi est fixe a 4
    case 5 : interieur = &tab_paroi[5] ; break ;	// ATTENTION : ne fonctionne que si le descripteur id_paroi est fixe a 5
    default : break ; // corrEsepond aux autres batiments (classe > 5)
    }
    
    // allocation memoire des structures de resitances & capacites du batiment d'etude
    RCmur = (listeRCparoi*) calloc(nb_paroi, sizeof(listeRCparoi)) ;		// nb type de mur ext / vitrages / toiture = nb_paroi
    RCvit = (listeRCparoi*) calloc(nb_paroi, sizeof(listeRCparoi)) ;
    RCtoit = (listeRCparoi*) calloc(nb_paroi, sizeof(listeRCparoi)) ;
    RCplc_int = (listeRCparoi*) calloc(1, sizeof(listeRCparoi)) ;		// nb type de plancher int / plancher bas / paroi int = 1 (reference)
    RCplc_bas = (listeRCparoi*) calloc(1, sizeof(listeRCparoi)) ;
    RCint = (listeRCparoi*) calloc(1, sizeof(listeRCparoi)) ;
    
    // calcul des resistances thermiques equivalentes et capacites int/ext surfaciques des parois
    for(i=0 ; i<nb_paroi ; i++)
    {
    calcul_RCparoi_surfacique(&mur[i], &RCmur[i]) ;
    calcul_RCparoi_surfacique(&vitrage[i], &RCvit[i]) ;
    calcul_RCparoi_surfacique(&toiture[i], &RCtoit[i]) ;
    calcul_RCparoi_surfacique(plancher_int, RCplc_int) ;
    calcul_RCparoi_surfacique(plancher_bas, RCplc_bas) ;
    calcul_RCparoi_surfacique(interieur, RCint) ;
    }
    free(mur) ;
    free(vitrage) ;
    free(toiture) ;
    // pas de free() pour plancher_int , plancher_bas et interieur car
    // les tableaux de struct a 1 element le free() ne fonctionne alors pas bien
    
    // calcul des resistances convectives et radiatives surfaciques interieures
    Rcv_i = allocation_tableau(6) ;
    Rrad_i = allocation_tableau(6) ;
    hc_int = allocation_tableau(6) ;
    // Attribution des coefs conv. int. selon [Fraisse et Virgone p.9]
    hc_int[0] = 4.1 ; // murs
    hc_int[1] = 4.1 ; // vitrage = coef theo pour les murs
    hc_int[2] = 6.1 ; // toiture = coef theo pour les plafonds
    hc_int[3] = 1.6 ; // plancher : attention � l'indice
    hc_int[4] = 6.1 ; // plafond : attention � l'indice
    hc_int[5] = 4.1 ; // paroi int. = coef theo pour les murs
    
    for(i=0 ; i<6 ; i++)
    calcul_Rint_surfacique(hc_int[i], hr_int, &Rcv_i[i], &Rrad_i[i]) ;
    
    // calcul des surfaces totales des differents "id" & "classes" de parois par niveau
    Sniv = (Sniveau *) calloc(nb_niv, sizeof(Sniveau)) ;
    calcul_surfaces(niveau, id_paroi, classe_paroi, Sniv, surface, nb_niv, nb_paroi, nb_facette) ;
    
    // calcul des variables physiques de l'air interieur (au noeud 10)
    Cai = allocation_tableau(nb_niv);
    Rra = allocation_tableau(nb_facette);
    for (i = 0 ; i < nb_niv ; i++){
    calcul_proprietes_air_int(nb_facette, i, niveau, in_air, taux_occup_max, debit_hyg_indiv, Sniv[i].SURFACE_CL[3], Hniv, Rra, &Cai[i]) ;
    }
    
    // calcul des charges internes
    Ps_equip = allocation_tableau(nb_niv) ;
    Ps_occup = allocation_tableau(nb_niv) ;
    Pl_occup = allocation_tableau(nb_niv) ;
    for (i = 0 ; i < nb_niv ; i++){
    calcul_puissance_occupation(saison, Sniv[i].SURFACE_CL[3], taux_occup, ps_equip, &Ps_equip[i], &Ps_occup[i], &Pl_occup[i]) ;
    }
  */
  
  printf("\n[ CALCUL DES FLUX SOLAIRES EXTERIEURS ABSORBES PAR TOUTES LES FACETTES DE LA GEOMETRIE ]\n");
  //===============================================================================================================
  
  // (1) tester si les flux solaires ont des valeurs negatives (validite
  // des donnees d'entree) et forcage des valeurs negatives a zero
  
  // (1.1) flux directs
  test_flux = test_tableau_val_positif(flux_sol_dir, nb_facette, &flux_min,
				       &nb_err);
  if (!test_flux)
    printf(
	   "\nAttention :\n\tTest des flux direct : %d valeurs negatives forcees a 0 (Fdir min =  %f)\n\t--> Calcul poursuivi\n",
	   nb_err, flux_min);
  
  // (1.2) flux diffus
  test_flux = test_tableau_val_positif(flux_sol_diff, nb_facette, &flux_min,
				       &nb_err);
  if (!test_flux)
    printf(
	   "\nAttention :\n\tTest des flux diffus : %d valeurs negatives forcees a 0 (Fdiff min =  %f)\n\t--> Calcul poursuivi\n",
	   nb_err, flux_min);
  
  // (2) calcul des valeurs
  
  flux_sol_abs = allocation_tableau_double(nb_facette);
  for (i = 0; i < nb_facette; i++) {
    flux_sol_abs[i] = (1.0 - albedo[i]) * (flux_sol_dir[i]
					   + flux_sol_diff[i]);
  }
  
  /*
    printf("\n[ CALCUL DES FLUX SOLAIRES TRANSMIS DANS LE BATIMENT D'ETUDE ]\n");
    //===============================================================================================================
    
    // gestion des flux solaires transmis a l'interieur du(des) batiment(s) d'etude
    // # attention (a voir ulterieurement) :
    // pour une simulation avec plusieurs batiments etudies energetiquement	faire
    // en sorte d'avoir des vecteurs flux transmis a l'interieur
    
    Ft_mur = allocation_tableau(nb_niv) ;
    Ft_vit = allocation_tableau(nb_niv) ;
    Ft_plc = allocation_tableau(nb_niv) ;
    Ft_plf = allocation_tableau(nb_niv) ;
    Ft_int = allocation_tableau(nb_niv) ;
    
    calcul_flux_solaires_int(Sniv, nb_facette, nb_niv, niveau, classe_paroi, flux_sol_dir, flux_sol_diff, transmission, surface, abs_plc, abs_vit, Ft_mur, Ft_vit, Ft_plc, Ft_plf, Ft_int) ; // f traitant uniquement les vitrages (classe 1) du batiment d'etude
  */
  
  printf("\n[ INITIALISATION DES TEMPERATURES DE TOUTES LES FACETTES EXTERIEURES ]\n");
  //===============================================================================================================
  
  // INITIALISATION DES TEMPERATURES DE SURFACE (ET DES NOEUDS DE "SOUS-FACE") DES FACETTES DE LA GEOMETRIE
  
  // (1) preambule, initialisation
  
  TSext = allocation_tableau_double(nb_facette); // temperature de surface des parois
  TSext_pow4 = allocation_tableau_double(nb_facette); // temperature de surface a la puissance 4 pour le calcul GLO // modif laurent malys 12/2010
  
  TNint1 = allocation_tableau_double(nb_facette); // temperature nodales int 1 des batiments et sols (hors batiment d'etude)
  TNint2 = allocation_tableau_double(nb_facette); // temperature nodales int 2 des batiments et sols (hors batiment d'etude)
  for (i = 0; i < nb_facette; i++) {
    TSext[i] = TSext_init[i];
    TNint1[i] = TNint1_init[i];
    TNint2[i] = TNint2_init[i];
    Ta[i] = Ta_init[i];
    Tse_veg[i] = Tse_veg_init[i];
  }
  free(TSext_init);
  free(TNint1_init);
  free(TNint2_init);
  free(Ta_init);
  free(Tse_veg_init);

  // (2) re-initialisation des Tsurface de facettes (TSext) a la valeur T equivalente au soleil
  // Interet : meilleure initialisation du flux GLO, convergence des TSext plus rapide,
  // moins d'iterations
  
  for (i = 0; i < nb_facette; i++) {
    if ((int) (classe_paroi[i]) == 8) // ARBRES
      {
	TSext[i] = Text[i]; // temperature d'air
      } else // BATIMENTS(etude ou autres), SOLS
      {
	j = (int) id_paroi[i]; // pour selectionner les 1eres couches de materiaux des struct de parois corespondantes
	TSext[i] = Teq_soleil(tab_paroi, j, hc_ext[i], Text[i], TSext[i],
			      flux_sol_abs[i]);
      }
  }
  free(tab_paroi); // ATTENTION :  si tab_paroi concerne les autres amenagements que les batiments
  
  /*
    printf("\n[ INITIALISATION DES TEMPERATURES NODALES DU BATIMENT D'ETUDE ENERGETIQUE ]\n");
    //===============================================================================================================
    
    // INITIALISATION DES TEMPERATURES NODALES DU(DES) BATIMENT(S) D'ETUDE
    // ATTENTION (A voir ulterieurement) :
    //	# pour une simulation avec plusieurs batiments etudies energetiquement
    //	# faire en sorte d'avoir des vecteurs de temperatures nodales pour chaque batiment
    
    T2 = allocation_tableau(nb_niv) ;
    T4 = allocation_tableau(nb_niv) ;
    T5 = allocation_tableau(nb_niv) ;
    T6 = allocation_tableau(nb_niv) ;
    T7 = allocation_tableau(nb_niv) ;
    T8 = allocation_tableau(nb_niv) ;
    T9 = allocation_tableau(nb_niv) ;
    T12 = allocation_tableau(nb_niv) ;
    Tsol_bis = allocation_tableau(nb_niv) ;
    inconnue = allocation_tableau(nb_niv) ;
    T10air = allocation_tableau(nb_niv) ;
    Pconv = allocation_tableau(nb_niv) ;
    
    for (i = 0; i < nb_niv ; i++)
    {
    T2[i] = T2_init[i] ;
    T4[i] = T4_init[i] ;
    T5[i] = T5_init[i] ;
    T6[i] = T6_init[i] ;
    T7[i] = T7_init[i] ;
    T8[i] = T8_init[i] ;
    T9[i] = T9_init[i] ;
    T10air[i] = T10air_init[i] ;
    //Pconv[i] = 0 ;
    }
    T12[nb_niv-1] = T12_init[nb_niv-1] ;	// T12 calculee seulement avec les variables du dernier etage
    Tsol_bis[0] = Tsol_bis_init[0] ;		// Tsol_bis calculee seulement avec les variables du RDC
  */
  
  // CALCUL PRINCIPAL
  //##################################################################################################################
  
  printf(
	 "\n[ CALCUL DES TEMPERATURES SURFACIQUES EXTERIEURES ET NODALES - BILAN DE PUISSANCE SENSIBLE ]\n");
  //===============================================================================================================
  
  // PREAMBULE : GESTION DES VARIABLES CALCULATOIRES
  //------------------------------------------------------------------------------------
  
  // OUVERTURE DU FICHIER DES FACTEURS DE FORME
  
  if ((pf_fform = fopen(nom_fform, "rb")) == NULL) {
    printf("\n  Impossible d'ouvrir '%s'\n\n", nom_fform);
    exit(0);
  }
  
  // ALLOCATIONS MEMOIRE VARIABLES DIVERSES
  
  // variables flux GLO
  
  GLO_Ciel_Emis = allocation_tableau_double(nb_facette);
  GLO_Ciel_Recu = allocation_tableau_double(nb_facette);
  GLO_Ciel_Net = allocation_tableau_double(nb_facette);
  GLO_Scene_Emis = allocation_tableau_double(nb_facette);
  GLO_Scene_Recu = allocation_tableau_double(nb_facette);
  GLO_Scene_Net = allocation_tableau_double(nb_facette);
  GLO_Total_Emis = allocation_tableau_double(nb_facette);
  GLO_Total_Recu = allocation_tableau_double(nb_facette);
  GLO_Total_Net = allocation_tableau_double(nb_facette);
  
  // pre-traitement du flux IR atmospherique recu (apres intereflexions)
  
  printf("\nBilan du flux meteo atomspherique IR :");
  calc_flux_atm_intereflexion(flux_atm, emissivite, surface, nb_facette,
			      tab_nb_contour_face, tab_no_face, nb_face, pf_fform, fform, fciel,
			      GLO_Ciel_Recu); // GLO_Ciel calcule en preambule -> seul flux GLO independant des iterations
  /*
  // si batiment en site isole, pas d'intereflexions IR dans la scene
  for (i = 0 ; i<nb_facette ; i++)
  GLO_Ciel_Recu[i] = emissivite[i] * fciel[i] * flux_atm ;
  */
  
  // variables tampons pour toutes les surfaces de la geometrie
  
  TSext_old_1 = allocation_tableau_double(nb_facette);
  TSext_old_2 = allocation_tableau_double(nb_facette);
  TNint1_TEMP = allocation_tableau_double(nb_facette);
  TNint2_TEMP = allocation_tableau_double(nb_facette);
  Ta_TEMP = allocation_tableau_double(nb_facette);
  Tse_veg_TEMP = allocation_tableau_double(nb_facette);  

  // allocations matrices/vecteurs pour calcul surfaces batiments generiques
  
  matBAT = allocation_tableau_double(4);
  vecBAT_in = allocation_tableau_double(2);
  vecBAT_out = allocation_tableau_double(2);
  
  // allocations matrices/vecteurs pour calcul surfaces sols
  
  matSOL = allocation_tableau_double(9);
  vecSOL_in = allocation_tableau_double(3);
  vecSOL_out = allocation_tableau_double(3);
  
  // allocations matrices/vecteurs pour calcul paroi vegetale
  
  matVEG = allocation_tableau_double(16);
  vecVEG_in = allocation_tableau_double(4);
  vecVEG_out = allocation_tableau_double(4);

  // pas d'allocation pour les arbres et pour les autres amenagements
  
  // allocation memoire des matrices et vecteurs de resolution pour batiment de calcul energetique
  /*
  // calcul du nombre de facettes du batiment d'etude :
  // tests comparatifs entre descripteur de classe associee (1)
  // et descripteur de murs+vitrages+toiture (2) niveaux
  // (attention !!! rajouter un test pour savoir s'il y a bien un batiment d'etude)
  
  nb_facette_bat = 0 ;
  j = 0 ;
  for (i = 0; i < nb_facette ; i++){
  //calcul avec les niveaux
  if((niveau[i] >= 0) && (niveau[i] < nb_niv)){
  j++ ;
  }
  // calcul avec les classes de parois
  switch ((int)(classe_paroi[i])){
  case 0 : nb_facette_bat++ ; break ;
  case 1 : nb_facette_bat++ ; break ;
  case 2 : nb_facette_bat++ ; break ;
  default : break ;
  }
  }
  // comparaison
  if (nb_facette_bat != j)
  {
  printf("\n\tATTENTION, probleme dans le calcul des facettes de batiment d'etude...") ;
  printf("\n\tVerifier les descripteurs de niveaux et de classes\n\n") ;
  exit(0) ;
  }
  j = 0 ;
  printf("\n\nCaracteristiques du batiment d'etude :") ;
  printf("\nNombre de facettes correspondant au batiment d'etude : %d", nb_facette_bat) ;
  
  n = nb_facette_bat + nb_niv * 8 + 2 ; // nb de noeuds de calcul
  nn = n*n ; // dim de la matrice batiment
  A = allocation_tableau(nn); // matrice de calcul batiment
  b = allocation_tableau(n); // vecteur de calcul batiment
  T = allocation_tableau(n) ; // vecteur resultat batiment
  alpha = allocation_tableau_int(nb_niv);	// indicateur de regime
  */
  
  // BOUCLE DE CALCUL DES TEMPERATURES INCONNUES (surfaces geometrie et noeuds batiment) ET DE LA PUISSANCE CONVECTIVE
  //##################################################################################################################
  
  // demarrage chronometre
  dateDebut = clock();
  
  // def criteres d'arret de la boucle ((2))
  iter = 0; // initialisation nb iterations
  eps1 = 0.20; // ecart max autorise
  eps2 = 0.05; // moyenne max des ecart autorisee
  ratio_face_non_cv = (int) (0.005 * nb_facette); // nb max de face non conv apres 30 iterations (0.5% du total de facettes)
  n_face_non_cv_old_1 = 0; // nb facettes non CV, iteration courante
  n_face_non_cv_old_2 = 0; // nb facettes non CV, iteration precedente
  /*
  // gestion du regime thermique du batiment de calcul (libre/force/mixte)
  switch (alpha_arg)
  {
  case 0 : // regime force (T10air = Tconsigne utilisateur)
  for (i = 0; i < nb_niv ; i++)
  alpha[i] = 0 ;
  break ;
  case 1 : // regime libre (T10air en evolution libre, Pconv = 0)
  for (i = 0; i < nb_niv ; i++)
  alpha[i] = 1 ;
  break ;
  case 2 : // regime mixte (on part a priori sur une simulation en evolution libre avant d'imposer chauff ou clim)
  for (i = 0; i < nb_niv ; i++)
  alpha[i] = 1 ;
  break ;
  }
  */
  // boucle ((1)) sur le critere de respect des temperature de consignes Tair(niv) si regime force 
  //##################################################################################################################
  /*
    do
    {
    // affichage regime de simulation batiment
    printf("\nRegime thermique du batiment (force[0], libre[1], mixte[2]) : %d", alpha_arg) ;
    
    // remplissage de la matrice de resolution en fonction du alpha
    remplissage_matrice_modele_batiment(A, n, nb_facette, nb_niv, niveau, nb_paroi, id_paroi, classe_paroi, surface, Sniv, in_air, dt, alpha, hc_ext, RCmur, RCvit, RCtoit, RCplc_int, RCplc_bas, RCint, Rcv_i, Rrad_i, Rra, Cai, Rsol, Csol);
    
    
    // boucle ((2)) sur le(s) critere(s) d'arret (eps1 & eps2) pour la convergence des temperatures de surface
    //##################################################################################################################
    
    printf("\n\nDEBUT DU CALCUL ITERATIF :\n") ;
  */
  do {
    // affichage iteration courante
    printf("\n\n-------------\niteration %d", iter);
    
    // MISE A JOUR DES VARIABLES DE CALCUL DES TEMPERATURES DE SURFACE
    //------------------------------------------------------------------------------------
    
    printf("\n\tMise a jour des temperatures de surface de la scene");
    
    for (i = 0; i < nb_facette; i++) {
      // MAJ temperature avant derniere iteration
      if (iter == 0)
	TSext_old_2[i] = TSext[i];
      else
	TSext_old_2[i] = TSext_old_1[i];
      
      // MAJ temperature derniere iteration
      TSext_old_1[i] = TSext[i];
      
      // MAJ des coefficients de sous relaxation
      // solution sous-relax 1
      lambda_relax = 1;
      if (iter > 10)
	lambda_relax = 0.8;
      if (iter > 20)
	lambda_relax = 0.7;
      if (iter > 30)
	lambda_relax = 0.6;
      if (iter > 40)
	lambda_relax = 0.5;
      
      // solution sous-relax 2
      //lambda_relax = 1 ;
      //if((iter > 2)&&((n_face_non_cv_old_2 - n_face_non_cv_old_1) < 100)) lambda_relax = 0.75 ;
      //if((iter > 2)&&((n_face_non_cv_old_2 - n_face_non_cv_old_1) < 10)) lambda_relax = 0.5 ;
      
      // solution sous-relax 3
      //if(iter <= 10) lambda_relax = 1 ;
      //if((iter > 10)&&(iter <= 50)) lambda_relax = 1.125 - (0.5/40)*iter ;
      //if(iter > 50) lambda_relax = 0.5 ;
      
      // MAJ temperature de surface courante
      TSext[i] = (lambda_relax * TSext_old_1[i]) + ((1 - lambda_relax)
						    * TSext_old_2[i]);
    }
    
    // CALCUL DES FLUX GLO_TOTAL_NET ECHANGES (GLOBAL ET DETAIL AVEC LES AUTRES SURFACES ET AVEC LE CIEL)
    //------------------------------------------------------------------------------------
    
    printf("\n\tBilan des flux radiatifs GLO");
    
    // modif laurent malys 12/2010
    for (i = 0; i < nb_facette; i++) {
      TSext_pow4[i] = pow(TSext[i] + 273.15, 4);
    }
    // fin modif laurent malys 12/2010
    
    
    for (i = 0; i < nb_facette; i++) {
      GLO_Total_Net[i] = calc_GLO(i, nb_facette, fciel[i], TSext_pow4,
				  pf_fform, fform, surface,emissivite, GLO_Ciel_Emis, GLO_Ciel_Recu,
				  GLO_Ciel_Net, GLO_Scene_Emis, GLO_Scene_Recu,
				  GLO_Scene_Net, GLO_Total_Emis, GLO_Total_Recu);
    }
    
    // CALCULS CONCERNANT LES SURFACES DES AMENAGEMENTS (modeles "facettes independantes")
    //------------------------------------------------------------------------------------
    
    printf(
	   "\n\tCalcul des TSext des batiments / sols / arbres / autres amenagements");
    

    
    for (i = 0; i < nb_facette; i++) {

    Flux_Latent[i] = calcul_flux_latent(flux_sol_abs[i],
					GLO_Total_Net[i], Text[i], w_ext[i], vit[i],
					f_evap_sol[i], LAI[i]);
      
    

      // FACETTES DE BATIMENTS GENERIQUES
      
      if ((int) classe_paroi[i] == 6) {
	// generation des matrices et vecteurs de calcul
	remplissage_matrice_modele_facetteBAT(matBAT, id_paroi[i],
					      RCsurf_bat, h_int_bat, hc_ext[i], dt);
	remplissage_vecteur_modele_facetteBAT(vecBAT_in, id_paroi[i],
					      RCsurf_bat, h_int_bat, hc_ext[i], dt, flux_sol_abs[i],
					      GLO_Total_Net[i], Text[i], TSext[i], TNint1[i],
					      TNint2[i]);
	
	// resolution
	resolutionSystemeLineaire_LINUX(matBAT, vecBAT_in, vecBAT_out,
					2); // LINUX
	//resolutionSystemeLineaire_WINDOWS(matBAT, vecBAT_in, vecBAT_out, 2); // WINDOWS
	
	// mise a jour des solutions
	TSext[i] = vecBAT_out[0];
	TNint1_TEMP[i] = vecBAT_out[1]; // copie des temperatures nodales face interieure des batiments dans un vecteur tampon
	// TNint2 ne sont pas modifiees car correspondent a la temperature de consigne
	// interieure fixee par l'utilisateur
      }
      
      // FACETTES DE SOLS
	      
      if ((int) classe_paroi[i] == 7) {
	
	// generation des matrice et vecteur de calcul
	remplissage_matrice_modele_sol(matSOL, id_paroi[i], hc_ext[i],
				       RCsurf_sol, Rsol, Csol, dt);
	remplissage_vecteur_modele_sol(vecSOL_in, id_paroi[i],
				       TSext[i], TNint1[i], TNint2[i], Text[i], Tsol_ref,
				       flux_sol_abs[i], GLO_Total_Net[i], Flux_Latent[i],
				       hc_ext[i], RCsurf_sol, Rsol, Csol, dt);
	
	// resolution
	resolutionSystemeLineaire_LINUX(matSOL, vecSOL_in, vecSOL_out,
					3); // LINUX
	//resolutionSystemeLineaire_WINDOWS(matSOL, vecSOL_in, vecSOL_out, 3); // WINDOWS
	
	// mise a jour des solutions
	TSext[i] = vecSOL_out[0];
	TNint1_TEMP[i] = vecSOL_out[1]; // copie des temperatures nodales 1 dans un vecteur tampon
	TNint2_TEMP[i] = vecSOL_out[2]; // copie des temperatures nodales 2 dans un vecteur tampon
      }
      
      // FACETTES DES ARBRES
      
      // le modele thermoradiatif ne modifie par les temperatures de surface des arbres
      // la temperture de surface des arbres est la temperature d'air exterieure meteo (ou issue du couplage)
      // en mode couplage la temperature de feuillage est calculee dans Fluent durant les iterations
      // et assimilee a une temperature d'air
      
      // calcul specifique du flux radiatif total absorbe par le feuillage pour sortie couplage (donnee entree CFD)
      if ((int) classe_paroi[i] == 8) {
	Flux_Rad_Net_Abs[i] = ((1.0 - albedo[i] - transmission[i])
			       * flux_sol_dir[i]) + ((1.0 - albedo[i])
						     * flux_sol_diff[i]) - GLO_Total_Net[i];
      }
      
      // FACETTES DES ENVELOPPES VEGETALES
      
      if ((int) classe_paroi[i] == 10){
	remplissage_matrice_modele_facetteVEG(matVEG, id_paroi[i],
					      RCsurf_bat, h_int_bat, hc_ext[i], dt, Cf[i], Ca[i], h_pa[i], h_ainf[i]);
	remplissage_vecteur_modele_facetteVEG(vecVEG_in, id_paroi[i],
					      RCsurf_bat, h_int_bat, hc_ext[i], dt, flux_sol_abs[i],
					      GLO_Total_Net[i], Text[i], TSext[i], TNint1[i], TNint2[i], 
					      Ta[i], Tse_veg[i], 
					      Flux_Latent[i]*alpha_flat, Flux_Latent[i]*(1-alpha_flat), // en attendant, Flatent de Penman Monteith est réparti feuilles/substrat 
					      h_ainf[i], Ca[i], Cf[i], transmission[i], albedo[i]);
	remplissage_vecteur_modele_facetteVEG_eau(vecVEG_in, Tse_veg[i], Teau, Qeau);

	resolutionSystemeLineaire_LINUX(matVEG, vecVEG_in, vecVEG_out, 4);

	TSext[i] = vecVEG_out[0];
	Ta_TEMP[i] = vecVEG_out[1];
	Tse_veg_TEMP[i] = vecVEG_out[2];
	TNint1_TEMP[i] = vecVEG_out[3];
	
      }
      // FACETTES DES AUTRES AMENAGEMENTS (EAU...)

    }
    printf("--------------------------------------------");
    printf("\n\n[[in]]%f\t%f\t%f\t%f\n",  vecVEG_in[0], vecVEG_in[1], vecVEG_in[2], vecVEG_in[3]);      
    printf("\n[[ou]]%f\t%f\t%f\t%f\n",  vecVEG_out[0], vecVEG_out[1], vecVEG_out[2], vecVEG_out[3]);      
    /*
    // CALCULS CONCERNANT LE BATIMENT D'ETUDE ENERGETIQUE
    //------------------------------------------------------------------------------------
    
    printf("\n\tCalcul des TSext du batiment de calcul energetique") ;
    
    // remplissage du vecteur du syseme lineaire POUR LE BAT D'ETUDE (varie a chaque pas de calcul)
    remplissage_vecteur_modele_batiment(b, n, nb_facette, nb_niv, niveau, nb_paroi, id_paroi, classe_paroi, surface, Sniv, in_air, dt, alpha, hc_ext, Text, TSext, T2, T4, T5, T6, T7, T8, T9, T10consigne, T10air, T12, RCmur, RCvit, RCtoit, RCplc_int, RCplc_bas, RCint, Rcv_i, Rrad_i, Rra, Cai, Rsol, Csol, Tsol_ref, Tsol_bis, flux_sol_abs, GLO_Total_Net, Ft_mur, Ft_vit, Ft_plc, Ft_plf, Ft_int, Ps_equip, Ps_occup);
    
    // resolution Systeme Lineaire
    resolutionSystemeLineaire_LINUX(A, b, T, n); // LINUX
    //resolutionSystemeLineaire_WINDOWS(A, b, T, n); // WINDOWS
    
    // mise a jour des temperatures de surfaces iterees (TSext) a partir du vecteur T resolu
    // ATTENTION : les Tniv_init servent ici de "tampon" pour ne pas ecraser les Tniv
    // elles prennent la valeur des temperatures calculees a l'iteration courante (modification uniquement des TSext)
    vecteurT_vers_variablesT(T, n, nb_facette, nb_niv, niveau, nb_paroi, id_paroi, classe_paroi, TSext, T2_init, T4_init, T5_init, T6_init, T7_init, T8_init, T9_init, T10air_init, T12_init, Tsol_bis_init) ;
    */
    // TEST DE CONVERGENCE DES TEMPERATURE DE SURFACE
    //------------------------------------------------------------------------------------
    
    printf("\n\tTest de convergence des TSext");
    
    test_Ts = 0;
    somme_deltaT = 0;
    n_face_non_cv_old_2 = n_face_non_cv_old_1;
    for (i = 0; i < nb_facette; i++) {
      deltaT = fabs(TSext[i] - TSext_old_1[i]);
      if (deltaT > eps1)
	test_Ts++; // on rajoute 1 au test si l'ecart indiv depasse eps1
      somme_deltaT += deltaT;
    }
    n_face_non_cv_old_1 = test_Ts;
    somme_deltaT = somme_deltaT / nb_facette;
    if (somme_deltaT > eps2)
      test_Ts++; // on rajoute 1 au test si l'ecart global moyen depasse eps2
    
    printf("\n\t-------------");
    printf("\n\tNombre de TSext non convergees : %d [sur %d]",
	   n_face_non_cv_old_1, nb_facette);
    printf("\n\tMoyenne des ecarts de TSext : %.4f", somme_deltaT); // TEST
    
    // TEST DE LA DERNIERE CHANCE !!! (FORCAGE)
    //------------------------------------------------------------------------------------
    
    if (iter > 49) // FORCAGE : on ne va pas au dela de 50 iterations
      {
	if (test_Ts < ratio_face_non_cv) // si seulement 0.5% des facettes reste non convergee
	  {
	    printf(
		   "\nPlus de 99.5% des TSext convergees au bout de 50 iter : simulation stopee",
		   '%');
	    break;
	  } else {
	  printf(
		 "\nSimulation stopee au bout de 50 iterations sans convergence stricte");
	  break;
	}
      }
    iter++;
  } while (test_Ts); // rebouclage tant que test_Ts n'est pas =0
  
  //##################################################################################################################
  // fin de boucle(2)
  
  /*
  // TEST POUR CHANGER DE REGIME (LIBRE --> FORCE) EN FONCTION DE LA VALEUR DE TEMPERATURE OBTENUE AU NOEUD 10
  //------------------------------------------------------------------------------------
  
  test_Tconsigne = 0 ;
  switch (alpha_arg)
  {
  case 0 : // regime FORCE (T10air = Tconsigne utilisateur)
  break ;
  case 1 : // regime LIBRE (T10air en evolution libre, Pconv = 0)
  break ;
  case 2 : // regime MIXTE (on choisi entre libre et force en fonction d'un test entre Tair et Tconsigne)
  // on teste alors la valeur de ce qu'il y a dans la variable
  // T10air_init "tampon" (cf. mise a jour des temperatures de surfaces iterees TSext)
  switch (saison)
  {
  case 0 : // cas ETE
  if (taux_occup == 0.0)		// innoccupation : Tair flottante (pas de test)
  break ;
  else	// occupation : Tair doit etre =< a la consigne clim
  {
  for (i = 0 ; i < nb_niv ; i++)
  {
  if ((alpha[i] == 1) && (T10air_init[i] > Tc_occup_ete))
  {
  printf("\nTair Niveau%d = %f --> Besoin CLIM", i, T10air_init[i]) ;
  test_Tconsigne++ ;
  alpha[i] = 0 ;					// declencher la clim a cet etage
  T10consigne = Tc_occup_ete ;	// definir la consigne associee
  }
  }
  }
  break ;
  case 1 : // cas HIVER
  if (taux_occup == 0.0)		//  innoccupation : Tair doit etre >= a la consigne chauff nuit
  {
  for (i = 0 ; i < nb_niv ; i++)
  if ((alpha[i] == 1) && (T10air_init[i] < Tc_inoccup_hiv))
  {
  printf("\nTair Niveau%d = %f --> Besoin CHAUF (N)", i, T10air_init[i]) ;
  test_Tconsigne++ ;
  alpha[i] = 0 ;					// declencher le chauff a cet etage
  T10consigne = Tc_inoccup_hiv ;	// definir la consigne associee
  }
  }
  else	// occupation : Tair doit etre >= a la consigne chauff jour
  {
  for (i = 0 ; i < nb_niv ; i++)
  if ((alpha[i] == 1) && (T10air_init[i] < Tc_occup_hiv))
  {
  printf("\nTair Niveau%d = %f --> Besoin CHAUF (J)", i, T10air_init[i]) ;
  test_Tconsigne++ ;
  alpha[i] = 0 ;					// declencher le chauff a cet etage
  T10consigne = Tc_occup_hiv ;	// definir la consigne associee
  }
  }
  break ;
  }
  }
  }
  while (test_Tconsigne) ; // rebouclage tant que test_Tconsigne n'est pas =0
  
  //##################################################################################################################
  // fin de boucle(1)
  */
  // RAPPORT D'EXECUTION DU CALCUL ITERATIF
  
  dateFin = clock(); // arret chronometre
  printf("\n----------------------");
  printf("\nRAPPORT FINAL :");
  printf("\n%d iterations", (iter - 1));
  printf("\nMoyenne des ecarts de Ts(exterieures) : %f", somme_deltaT);
  printf("\n----------------------\n");
  
  printf("\n[ MISE A JOUR DES RESULTATS ]\n");
  //------------------------------------------------------------------------------------
  
  // MISE A JOUR DES TEMPERATURES COURANTES A PARTIR DU VECTEURS RESULTATS
  
  // parois des batiments
  
  for (i = 0; i < nb_facette; i++)
    if ((int) classe_paroi[i] == 6) {
      // la temperature de surface TSext[i] est deja attribuee dans la boucle de calcul,
      // il reste uniquement a renseigner les temperatures nodales
      TNint1[i] = TNint1_TEMP[i];
    }
  
  // sols
  
  for (i = 0; i < nb_facette; i++)
    if ((int) classe_paroi[i] == 7) {
      // la temperature de surface TSext[i] est deja attribuee dans la boucle de calcul,
      // il reste uniquement a renseigner les temperatures nodales
      TNint1[i] = TNint1_TEMP[i];
      TNint2[i] = TNint2_TEMP[i];
    }
  
  // arbres

  for (i = 0; i < nb_facette; i++)
    if ((int) classe_paroi[i] == 10) {
      // la temperature de surface TSext[i] est deja attribuee dans la boucle de calcul,
      // il reste uniquement a renseigner les temperatures nodales
      TNint1[i] = TNint1_TEMP[i];
      Ta[i] = Ta_TEMP[i];
      Tse_veg[i] = Tse_veg_TEMP[i];
    }
  
  // pas de temperature nodales pour les arbres
  
  
  // autres amenagements
  
  // pour l'instant pas d'autres modeles d'amenagement supplementaires
  
  
  // batiment d'etude
  /*
  // mise a jour des temperatures et de la puissance convective
  vecteurT_vers_variablesT(T, n, nb_facette, nb_niv, niveau, nb_paroi, id_paroi, classe_paroi, TSext, T2, T4, T5, T6, T7, T8, T9, inconnue, T12, Tsol_bis) ;
  for (i = 0; i < nb_niv ; i++)
  {
  switch (alpha[i])
  {
  case 0 : // regime force (T10air = Tconsigne)
  T10air[i] = T10consigne ;
  Pconv[i] = inconnue[i] ;
  break ;
  case 1 : // regime libre (T10air en evolution libre, Pconv = 0)
  T10air[i] = inconnue[i] ;
  Pconv[i] = 0 ;
  break ;
  }
  }
  // bilan de puissance latente
  Platent = allocation_tableau(nb_niv) ;
  for (i = 0 ; i < nb_niv ; i++){
  Platent[i] = bilan_vapeur_eau(T10air[i], Sniv[i].SURFACE_CL[3], taux_occup_max, debit_hyg_indiv, Pl_occup[i], w_ext[i]) ;
  }
  */
  // DESALLOCATION MEMOIRE DES VARIABLES DE CALCUL
  //------------------------------------------------------------------------------------
  
  // description de la geometrie
  fclose(pf_fform); // fermeture du fichier des facteurs de forme .fac
  free(fform);
  free(fciel);
  free(surface);
  free(id_paroi);
  free(classe_paroi);
  /*	free(in_air) ;
	free(niveau) ;
	free(Sniv) ; */
  
  // variables et parametres physiques d'entree
  free(hc_ext);
  free(f_evap_sol);
  free(emissivite);
  free(albedo);
  free(transmission);
  free(flux_sol_dir);
  free(flux_sol_diff);

  //laurent
  free(Cf);
  free(Ca);
  free(h_ainf);
  free(h_pa);
  free(LAI);
  free(vit);
  /*	free(Ft_mur) ;
	free(Ft_vit) ;
	free(Ft_plc) ;
	free(Ft_plf) ;
	free(Ft_int) ;
	free(RCmur) ;
	free(RCvit) ;
	free(RCtoit) ;
	free(RCplc_int) ;
	free(RCplc_bas) ;
	free(RCint) ;
	free(Rcv_i) ;
	free(Rrad_i) ;
	free(Cai) ;
	free(Rra) ;*/
  
  // outils maths
  /*	free(A) ;
	free(b) ;
	free(T) ;*/
  free(matBAT);
  free(vecBAT_in);
  free(vecBAT_out);
  free(matSOL);
  free(vecSOL_in);
  free(vecSOL_out);
  free(matVEG);
  free(vecVEG_in);
  free(vecVEG_out);

  // temperatures
  free(Text);
  free(TSext_pow4);
  free(TSext_old_1);
  free(TSext_old_2);
  free(TNint1_TEMP);
  free(TNint2_TEMP);
  free(Tse_veg_TEMP);
  free(Ta_TEMP);
  /*	free(inconnue) ;
	free(T10air_init) ;
	free(T2_init) ;
	free(T4_init) ;
	free(T5_init) ;
	free(T6_init) ;
	free(T7_init) ;
	free(T8_init) ;
	free(T9_init) ;
	free(T12_init) ;
	free(Tsol_bis_init) ; */
  
  printf("\n[ STOCKAGE DES RESULTATS ]\n");
  //------------------------------------------------------------------------------------
  
  // TEMPERATURES DE SURFACES EXT CALCULEES
  complement_extension(nom_fic_TSext, argv[24], "val");
  stocke_fichier_val(nom_fic_TSext, nb_face, no_face_max, nb_facette,
		     tab_no_face, tab_nb_contour_face, TSext);
  free(TSext);
  ext_tps_val = nom_fic_TSext + (strlen(nom_fic_TSext) - 14);

  int tt = 15;
  while (ext_tps_val[0] != '_'){
    ext_tps_val = nom_fic_TSext + (strlen(nom_fic_TSext) - tt);
    tt+=1;
  }
 
  
  // TEMPERATURES NODALES INT 1 CALCULEES
  complement_extension(nom_fic_TNint1, argv[25], "val");
  stocke_fichier_val(nom_fic_TNint1, nb_face, no_face_max, nb_facette,
		     tab_no_face, tab_nb_contour_face, TNint1);
  free(TNint1);
  
  // TEMPERATURES NODALES INT 2 CALCULEES
  complement_extension(nom_fic_TNint2, argv[26], "val");
  stocke_fichier_val(nom_fic_TNint2, nb_face, no_face_max, nb_facette,
		     tab_no_face, tab_nb_contour_face, TNint2);
  free(TNint2);

  // TEMPERATURES NODALES Ta CALCULEES // laurent
  complement_extension(nom_fic_Ta, argv[27], "val");
  stocke_fichier_val(nom_fic_Ta, nb_face, no_face_max, nb_facette,
		     tab_no_face, tab_nb_contour_face, Ta);
  free(Ta);

  // TEMPERATURES NODALES TSE_VEG CALCULEES // laurent
  complement_extension(nom_fic_Tse_veg, argv[28], "val");
  stocke_fichier_val(nom_fic_Tse_veg, nb_face, no_face_max, nb_facette,
		     tab_no_face, tab_nb_contour_face, Tse_veg);
  free(Tse_veg);
    
  // STOCKAGE DES FICHIERS OPTIONNELS
  //------------------------------------------------------------------------------------
  
  // variables necessaires pour le couplage
  
  complement_extension(nom_fic_sortie_aux, argv[30], "txt"); // laurent

  lecture_option_resul(nom_fic_sortie_aux, "flux_latent", nom_fic_Flux_Latent);
  if (strcmp(nom_fic_Flux_Latent, "")){
    strcat(nom_fic_Flux_Latent, ext_tps_val);
    stocke_fichier_val(nom_fic_Flux_Latent, nb_face, no_face_max, nb_facette,
		       tab_no_face, tab_nb_contour_face, Flux_Latent);
  }
  free(Flux_Latent);

  lecture_option_resul(nom_fic_sortie_aux, "flux_rad_arbre", nom_fic_Flux_Rad_Net_Abs);
  if (strcmp(nom_fic_Flux_Rad_Net_Abs, "")){
    strcat(nom_fic_Flux_Rad_Net_Abs, ext_tps_val);
    stocke_fichier_val(nom_fic_Flux_Rad_Net_Abs, nb_face, no_face_max, nb_facette,
		       tab_no_face, tab_nb_contour_face, Flux_Rad_Net_Abs);
  }
  free(Flux_Rad_Net_Abs);

  lecture_option_resul(nom_fic_sortie_aux, "humidite_relative", nom_fic_humidite_rel_air);
  if (strcmp(nom_fic_humidite_rel_air, "")){
    strcat(nom_fic_humidite_rel_air, ext_tps_val);
    stocke_fichier_val(nom_fic_humidite_rel_air, nb_face, no_face_max, nb_facette,
		       tab_no_face, tab_nb_contour_face, humidite_rel_air);
  }
  free(humidite_rel_air);

  lecture_option_resul(nom_fic_sortie_aux, "GLO_Scene_Net", nom_fic_GLO_Scene_Net);
  if (strcmp(nom_fic_GLO_Scene_Net, "")){
    strcat(nom_fic_GLO_Scene_Net, ext_tps_val);
    stocke_fichier_val(nom_fic_GLO_Scene_Net, nb_face, no_face_max, nb_facette,
		       tab_no_face, tab_nb_contour_face, GLO_Scene_Net);
  }
  free(GLO_Scene_Net);

  lecture_option_resul(nom_fic_sortie_aux, "GLO_Ciel_Net", nom_fic_GLO_Ciel_Net);
  if (strcmp(nom_fic_GLO_Ciel_Net, "")){
    strcat(nom_fic_GLO_Ciel_Net, ext_tps_val);
    stocke_fichier_val(nom_fic_GLO_Ciel_Net, nb_face, no_face_max, nb_facette,
		       tab_no_face, tab_nb_contour_face, GLO_Ciel_Net);
  }
  free(GLO_Ciel_Net);

  lecture_option_resul(nom_fic_sortie_aux, "GLO_Total_Net", nom_fic_GLO_Total_Net);
  if (strcmp(nom_fic_GLO_Total_Net, "")){
    strcat(nom_fic_GLO_Total_Net, ext_tps_val);
    stocke_fichier_val(nom_fic_GLO_Total_Net, nb_face, no_face_max, nb_facette,
		       tab_no_face, tab_nb_contour_face, GLO_Total_Net);
  }
  free(GLO_Total_Net);



  /* sprintf(nom_fic_Flux_Latent, "flux_latent%s", ext_tps_val); */
  /* stocke_fichier_val(nom_fic_Flux_Latent, nb_face, no_face_max, nb_facette, */
  /* 		     tab_no_face, tab_nb_contour_face, Flux_Latent); */
  /* free(Flux_Latent); */
  
  /* sprintf(nom_fic_Flux_Rad_Net_Abs, "flux_rad_arbre%s", ext_tps_val); */
  /* stocke_fichier_val(nom_fic_Flux_Rad_Net_Abs, nb_face, no_face_max, */
  /* 		     nb_facette, tab_no_face, tab_nb_contour_face, Flux_Rad_Net_Abs); */
  /* free(Flux_Rad_Net_Abs); */
  
  /* // variables supplementaires pour analyse : flux GLO, flux solaires, humidite relative... */
  
  /* sprintf(nom_fic_humidite_rel_air, "humidite_relative%s", ext_tps_val); */
  /* stocke_fichier_val(nom_fic_humidite_rel_air, nb_face, no_face_max, */
  /* 		     nb_facette, tab_no_face, tab_nb_contour_face, humidite_rel_air); */
  /* free(humidite_rel_air); */
  
  // DESALLOCATION DES VARIABLES OPTIONELLES NON STOCKEES
  //------------------------------------------------------------------------------------
  
  free(GLO_Ciel_Emis);
  free(GLO_Ciel_Recu);
  // free(GLO_Ciel_Net);
  free(GLO_Scene_Emis);
  free(GLO_Scene_Recu);
  // free(GLO_Scene_Net);
  free(GLO_Total_Emis);
  free(GLO_Total_Recu);
  // free(GLO_Total_Net);
  
  free(flux_sol_abs);
  
  free(tab_no_face);
  free(tab_nb_contour_face);
  
  // FIN
  //------------------------------------------------------------------------------------
  
  // chronometre
  printf("\n----------------------");
  printf("\nDuree totale de traitement %5.3f secondes", (double) (dateFin
								  - dateDebut) / (double) CLOCKS_PER_SEC);
  printf("\n----------------------\n");
  
  // fin
  printf("\n[ EXECUTION OK ]\n\n");
  return EXIT_SUCCESS;
}


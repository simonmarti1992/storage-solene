/*
 *  Copyright 2010-2013 Laurent Malys (CERMA, UMR 1563 AAU, CNRS /
 *                                  Ecole d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

#ifndef SIM_TS_FILES_H
#define SIM_TS_FILES_H

void complement_extension(char *nom_fichier, char *argument, char *extension);
int lecture_nb_paroi(char *nom_fichier);
void lecture_donnees_paroi(char *nom_fichier, paroi *tableau_paroi);
void lecture_donnees_sol(char *nom_fichier, prop_sol *tableau_sol);
void lecture_descripteur(char *nom_fichier, double *valeur);
void lecture_option_resul(char *nom_fichier, char *nom_variable, char *nom_fichier_val);
int lecture_option_resul_int(char *nom_fichier, char *nom_variable);
double lecture_option_resul_double(char *nom_fichier, char *nom_variable);
double val_max_descripteur(char *nom_fichier);
int total_face(char *nom_fichier);
void analyse_face_contour(char *nom_fichier, int *no_face_max,
			  int *nb_contour_total, int *tab_no_face, int *tab_nb_contour_face);
void lecture_fichier_T_noeuds_init(char *nom_fichier_matrice_noeuds_in,
				   int nb_niv, double *T2init, double *T4init, double *T5init,
				   double *T6init, double *T7init, double *T8init, double *T9init,
				   double *T12init, double *Tsolinit, double *Tairinit);

int test_tableau_val_positif(double *tableau, int dim, double *val_min,
			     int *nb_erreur);

int stocke_fichier_T_noeuds_out(char *nom_fichier_matrice_noeuds_out,
				int nb_niv, double *T2out, double *T4out, double *T5out, double *T6out,
				double *T7out, double *T8out, double *T9out, double *T12out,
				double *Tsolout, double *Tairout, double *Pconv, double *Plat);
int stocke_fichier_val(char *nom_fichier, int nbfac, int nomax,
		       int nb_contour_total, int *numero_face, int *nb_cont_face, double *tab);
void lecture_ff(FILE *pf_fform, float *factf, int ii, int nb_contour_total);
void lecture_ff_mem(float *fform_mem, float *factf, int ii, int nb_contour_total);

#endif

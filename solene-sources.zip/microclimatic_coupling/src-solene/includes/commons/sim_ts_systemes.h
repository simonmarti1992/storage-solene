/*
 *  Copyright 2010-2013 Laurent Malys (CERMA, UMR 1563 AAU, CNRS /
 *                                  Ecole d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

#ifndef SIM_TS_SYSTEMES_H
#define SIM_TS_SYSTEMES_H

void remplissage_matrice_modele_batiment(double *M, int dim, int nb_facette,
					 int nb_niv, double *niveau, int nb_paroi, double *id_paroi,
					 double *classe_paroi, double *surface, Sniveau *Sniv, double *in_air,
					 double dt, int *alpha, double *hc_ext, listeRCparoi *RCmur,
					 listeRCparoi *RCvit, listeRCparoi *RCtoit, listeRCparoi *RCplc_int,
					 listeRCparoi *RCplc_bas, listeRCparoi *RCint, double *Rcv_i,
					 double *Rrad_i, double *Rra, double *Cai, double Rsol, double Csol,
					 double *Cf, double *Ca, double *h_pa, double *h_ainf);
void remplissage_vecteur_modele_batiment(double *V, 
					 int dim, 
					 int nb_facette,
					 int nb_niv, 
					 double *niveau, 
					 double nb_paroi, 
					 double *id_paroi,
					 double *classe_paroi, 
					 double *surface, 
					 Sniveau *Sniv, 
					 double *in_air,
					 double dt, 
					 int *alpha, 
					 double *hc_ext, 
					 double *Text, 
					 double *TSext, 
					 double *Flux_Latent, 
					 double *Flux_Latent_se,
					 double *T2, 
					 double *T4, 
					 double *T5, 
					 double *T6, 
					 double *T7, 
					 double *T8,
					 double *T9, double T10consigne, double *T10air_init, double *T12,
					 listeRCparoi *RCmur, listeRCparoi *RCvit, listeRCparoi *RCtoit,
					 listeRCparoi *RCplc_int, listeRCparoi *RCplc_bas, listeRCparoi *RCint,
					 double *Rcv_i, double *Rrad_i, double *Rra, double *Cai, double Rsol,
					 double Csol, double Tsol, double *Tsol_bis, double *flux_sol_abs,
					 double *GLO_Total_Net, double *Ft_mur, double *Ft_vit, double *Ft_plc,
					 double *Ft_plf, double *Ft_int, double *Ps_equip, double *Ps_occup,
					 double *Tse_veg_old, double *Ta_old, 
					 double *Cf, double *Ca, double *h_ainf, double *h_pa,
					 double *transmission, double *albedo);
void remplissage_matrice_modele_facetteVEG(double *M, int id, 
					   listeRCparoi *RCfacetteBAT, double hc_int, 
					   double hc_ext, double dt, 
					   double Cf, double Ca, double h_pa, double h_ainf);
void remplissage_vecteur_modele_facetteVEG(double *V, int id,
					   listeRCparoi *RCfacetteBAT, double hc_int, double hc_ext, double dt,
					   double Fsol, double Fglo, double Text, double TSext_old,
					   double TSint_old, double Tint, 
					   double Ta_old, double Tse_veg_old,
					   double Flatent, double Flatent_se, /* pour 'Flux latent surface exterieure' */
					   double h_ainf, double Ca, double Cf, double transmission, double albedo);
void remplissage_vecteur_modele_facetteVEG_eau(double *V, double Tse_veg_old, double Teau, double Qeau);
void remplissage_matrice_modele_facetteVEG_2R3C(double *M, int id, 
						listeRCparoi *RCfacetteBAT, double hc_int, 
						double hc_ext, double dt, 
						double Cf, double Ca, double h_pa, double h_ainf);
void remplissage_vecteur_modele_facetteVEG_2R3C(double *V, int id,
						listeRCparoi *RCfacetteBAT, double hc_int, double hc_ext, double dt,
						double Fsol, double Fglo, double Text, double TSext_old,
						double TSint_old, double Tint, 
						double Ta_old, double Tse_veg_old,
						double Flatent, double Flatent_se, /* pour 'Flux latent surface exterieure' */
						double h_ainf, double Ca, double Cf, double transmission, double albedo,
						double Teau, double Qeau, double T3_old);
void remplissage_matrice_modele_facetteBAT(double *M, int id,
					   listeRCparoi *RCfacetteBAT, double hc_int, double hc_ext, double dt);
void remplissage_vecteur_modele_facetteBAT(double *V, int id,
					   listeRCparoi *RCfacetteBAT, double hc_int, double hc_ext, double dt,
					   double Fsol, double Fglo, double Text, double TSext_old,
					   double TSint_old, double Tint);
void remplissage_matrice_modele_sol(double *M, int id, double hc_ext,
				    listeRCparoi *RCsurf_sol, double Rsol, double Csol, double dt);
void remplissage_vecteur_modele_sol(double *V, int id, double TSext_old,
				    double T2_old, double T3_old, double Text, double Tref, double FluxSol,
				    double FluxGLONet, double Flatent, double hc_ext,
				    listeRCparoi *RCsurf_sol, double Rsol, double Csol, double dt);
void remplissage_matrice_modele_sol_VEG(double *M, int id, double hc_ext,
					listeRCparoi *RCsurf_sol, double Rsol, double Csol, double dt,
					double Cf, double Ca, double h_pa, double h_ainf);
void remplissage_vecteur_modele_sol_VEG(double *V, int id, double TSext_old,
					double T2_old, double T3_old, double Text, double Tref, double FluxSol,
					double FluxGLONet, 
					double Flatent, double Flatent_se, 
					double hc_ext,
					listeRCparoi *RCsurf_sol, double Rsol, double Csol, double dt,
					double Ta_old, double Tse_veg_old,
					double h_ainf, double Ca, double Cf, double transmission, double albedo);
void resolutionSystemeLineaire_LINUX(double *A, double *b, double *x, int n);
void resolutionSystemeLineaire_WINDOWS(double *A, double *B, double *X, int dim);
void vecteurT_vers_variablesT(double *V, int dim, int nb_facette, int nb_niv,
			      double *niveau, double nb_paroi, double *id_paroi,
			      double *classe_paroi, double *TSext, double *T2, double *T4,
			      double *T5, double *T6, double *T7, double *T8, double *T9,
			      double *inconnue_noeud_air_int, double *T12, double *Tsol_bis,
			      double *Tse_veg, double *Ta);

#endif

/*
 *  Copyright 2010-2013 Laurent Malys (CERMA, UMR 1563 AAU, CNRS /
 *                                  Ecole d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

#ifndef SIM_TS_RADIATIF_H
#define SIM_TS_RADIATIF_H

int radiog(int im, int *nb_cont_face, int *numero_face, int nbfac,
	   int nb_contour_total, double *exitance_init, double *surf,
	   double *reflex, FILE *pf_fform, float *fform, int flag_arret,
	   double pourc, double *exitance);
void calc_flux_atm_intereflexion(double flux_atmosphere, double *emissivite,
				 double *surf, int nb_facette, int *nb_cont_face, int *numero_face,
				 int nbfac, FILE *pf_fform, float *fform, double *fciel, double *resu);
double calc_GLO(int numero_contour_ref, int numero_contour_total, double fciel,
		double *Tse_pow4, FILE *pf_fform,
		float *fform,
		double *surface,
		double *emissivite, double *GLO_Ciel_Emis, double *GLO_Ciel_Recu,
		double *GLO_Ciel_Net, double *GLO_Scene_Emis, double *GLO_Scene_Recu,
		double *GLO_Scene_Net, double *GLO_Total_Emis, double *GLO_Total_Recu);


#endif

/*
 *  Copyright 2010-2013 Laurent Malys (CERMA, UMR 1563 AAU, CNRS /
 *                                  Ecole d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

#ifndef SIM_TS_CALCUL_H
#define SIM_TS_CALCUL_H

void calcul_surfaces(double *niveau, double *id_paroi, double *classe_paroi,
		     Sniveau *Sniv, double *surface, int nb_niv, int nb_paroi,
		     int nb_contour_total);
void calcul_RCparoi_surfacique(paroi *P, listeRCparoi *RCparoi);
void calcul_Rint_surfacique(double hc_int, double hr_int, double *Rcv_i,
			    double *Rrad_i);
void calcul_proprietes_air_int(int nb_facette, int niv, double *niveau,
			       double *in_air, double taux_occup, double debit_hyg_indiv, double Splc,
			       double Hniv, double *Rra, double *Cai);
void calcul_puissance_occupation(int saison, double surface, double taux_occup,
				 double ps_equip, double *Ps_equip, double *Ps_occup, double *Pl_occup);
double calcul_HS(double Tair, double HR);
double calcul_HR(double Tair, double HS);
double bilan_vapeur_eau(double Tair_int, double surface, double taux_occup,
			double debit_hyg_indiv, double Pl_occup, double w_ext);
void calcul_flux_solaires_int(Sniveau *Sniv, int nb_facette, int nb_niv,
			      double *niveau, double *classe_paroi, double *flux_sol_dir,
			      double *flux_sol_diff, double *transmission, double *surface,
			      double abs_plc, double abs_vit, double *Ft_mur, double *Ft_vit,
			      double *Ft_plc, double *Ft_plf, double *Ft_int);
double calcul_Tref_profondeur(double z_ref, double j, double j_ref,
			      double moy_Tair, double max_Tair, double min_Tair, double lambda_sol,
			      double Cp_sol, double rho_sol);
void calcul_proprietes_sol(double epaisseur, double rho, double Cp,
			   double lambda, double *Rsol, double *Csol);
double calcul_flux_latent(double FluxSol, double FluxGLONet, double Tair,
			  double HS, double v, double f, double LAI);
double Teq_soleil(paroi *tab_paroi, int no_paroi, double hc_ext, double Text,
		  double TSinit, double flux_sol_abs);
double IR_ciel(double Tair);

#endif

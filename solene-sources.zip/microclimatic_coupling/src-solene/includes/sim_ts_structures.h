/*
 *  Copyright 2010-2013 Laurent Malys (CERMA, UMR 1563 AAU, CNRS /
 *                                  Ecole d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

#ifndef SIM_TS_STRUCTURES_H
#define SIM_TS_STRUCTURES_H

typedef struct {
  double lambda_sol; /* conductivite th. du sous sol */
  double cp_sol; /* capa. th. du sous sol */
  double rho_sol; /* masse vol. du sous sol */
  double z_ref; /* profondeur pour la condition limite de temperature */
  int i_jour; /* jour de simulation */
  int i_jour_ref; /* jour de l'annee de la plus basse temperature moyenne du site */
  double moy_Tair; /* moyenne de temperature annuelle du site */
  double max_Tair; /* temperature moy journaliere maximale du site sur l'annee */
  double min_Tair; /* temperature moy journaliere minimale du site sur l'annee */
} prop_sol;

typedef struct {
  int classe; /* 0 : murs ext , 1 : vitrage , 2 : toit , 3 : plancher int , 4 : plancher bas , 5 : parois int */
  int id; /* correspond au descripteur 'id_paroi' defini par l'utilisateur dans la geometrie */
  int n; /* nb de couches de materiau */
  double *e; /* epaisseur de la couche */
  double *l; /* lambda de la couche */
  double *C; /* Cp de la couche */
  double *r; /* rho de la couche */
} paroi;

typedef struct {
  double R; /* resistance thermique equivalente de la paroi */
  double Ce; /* capacite equivalente de surface exterieure */
  double Ci; /* capacite equivalente de surface interieure */
} listeRCparoi;

typedef struct {
  double *SURFACE_CL; 
  double *SURFACE_ID; 
} Sniveau;

#endif

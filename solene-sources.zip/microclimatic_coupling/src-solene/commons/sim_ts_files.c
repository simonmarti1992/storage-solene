/*
 *  Copyright 2010-2013 Laurent Malys (CERMA, UMR 1563 AAU, CNRS /
 *                                  Ecole d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

#include "../includes/sim_ts.h"

void complement_extension(char *nom_fichier, char *argument, char *extension)
/* ------------------------------------------------------------------------------------
 *  complete le nom du fichier par l'extension desiree si elle n'est pas
 *  renseignee par defaut
 * ------------------------------------------------------------------------------------ */ 
{
  if (strcmp((argument + (strlen(argument) - 3)), extension)) {
    sprintf(nom_fichier, "%s.%s", argument, extension);
  } else {
    strcpy(nom_fichier, argument);
  }
}

int lecture_nb_paroi(char *nom_fichier)
/* ------------------------------------------------------------------------------------
 *  Lecture (dans nom_fichier.txt) et renvoi du nb de paroi differentes
 * ------------------------------------------------------------------------------------ */ 
{
  FILE *fparoi;
  int nb_paroi;

  /*verification de l'existance du fichier lu */
  if ((fparoi = fopen(nom_fichier, "r")) == NULL) /* verification de l'emplacement memoire */
    {
      printf("\n\n  ERREUR : Impossible d'ouvrir '%s'\n\n", nom_fichier);
      exit(0);
    }
  
  /* lecture et stockage du nb total de parois differentes */
  if (fscanf(fparoi, "%d", &nb_paroi) != 0){ /* lecture */
    /*printf("\nNombre de parois : %d",nb_paroi) ;	 impression ecran */
    fclose(fparoi);
    return nb_paroi;
  }else{
    printf("erreur lecture nb paroi");
    return 0;
  }
}

void lecture_donnees_paroi(char *nom_fichier, paroi *tableau_paroi)
/* ------------------------------------------------------------------------------------
 *  Lecture du fichier 'nom_fichier.txt' contenant les proprietes thermiques
 *  des materiaux composant la paroi
 *  Remplissage en consequence de la structure 'paroi' dans code
 * ------------------------------------------------------------------------------------ */ 
{
  FILE *fparoi; /* fichier lu */
  int nb_paroi; /* nb de parois */
  
  char nom_paroi[32]; /* nom de la paroi courante lue */
  int *nb_couche; /* tableau du nb de couche pour chaque paroi */
  
  int Classe, ID; /* tableau du nb de couche pour chaque paroi */
  
  char materiau[32]; /* nom du materiau de la couche courante */
  double epaisseur, lambda, cp, rho; /* prop physiques de la couche courante */
  
  int i, j;
  
  /*verification de l'existance du fichier lu */
  if ((fparoi = fopen(nom_fichier, "r")) == NULL) {
    printf("\n\n  ERREUR : Impossible d'ouvrir '%s'\n\n", nom_fichier);
    exit(0);
  }
  
  if (fscanf(fparoi, "%d", &nb_paroi)) /* lecture du nombre total de parois differentes */
    {
      /* impression ecran */ 
      /* printf("Nombre de parois : %d\n",nb_paroi) ; */
      nb_couche = allocation_tableau_int(nb_paroi); /* allocation memoire tableau des nb_couche */
    }
  else
    {
    nb_couche = 0;
    printf("erreur lecture du nombre de couches");
    }
  
  for (i = 0; i < nb_paroi; i++) {
    /* printf("\nParoi [%d]\n",i+1) ;	printf("----------------------------------\n") ; */
    
    if (fscanf(fparoi, "%s %d %d %d", nom_paroi, &Classe, &ID, &nb_couche[i])) /* lecture du nom de paroi (i) */
      {
	tableau_paroi[i].classe = Classe;
	tableau_paroi[i].id = ID;
	tableau_paroi[i].n = nb_couche[i];
	/* printf("Nom paroi : %s    ",nom_paroi) ;			 */
	/* printf("Classe : %d   ",tableau_paroi[i].classe) ; */
	/* printf("ID : %d\n",tableau_paroi[i].id) ;      */
	/* printf("Nombre couches : %d\n",tableau_paroi[i].n) ; */
	
	tableau_paroi[i].e = allocation_tableau_double(nb_couche[i]);
	tableau_paroi[i].l = allocation_tableau_double(nb_couche[i]);
	tableau_paroi[i].C = allocation_tableau_double(nb_couche[i]);
	tableau_paroi[i].r = allocation_tableau_double(nb_couche[i]);
	
	for (j = 0; j < nb_couche[i]; j++) {
	  printf("Couche [%d]   ",j+1) ;
	  if (fscanf(fparoi, "%s %lf %lf %lf %lf", materiau, &epaisseur, &lambda, &cp, &rho))
	    {
	      tableau_paroi[i].e[j] = epaisseur;
	      tableau_paroi[i].l[j] = lambda;
	      tableau_paroi[i].C[j] = cp;
	      tableau_paroi[i].r[j] = rho;
	      /* printf("Materiau : %s\t",materiau); */
	      /* printf("epaisseur [m] = %1.3f   ",tableau_paroi[i].e[j]); */
	      /* printf("lambda [SI] = %5.3f   ",tableau_paroi[i].l[j]); */
	      /* printf("Cp [SI] = %5f   ",tableau_paroi[i].C[j]); */
	      /* printf("rho [SI] = %5.2f\n",tableau_paroi[i].r[j]); */
	    }
	  else
	    {
	      printf("erreur lecture caracteristique couche");
	    }
	}
	/* printf("\n") ; */
      }
    else
      {
	printf("erreur lecture caracteristique paroi");
      }
  }
  printf("----------------------------------\n\n") ;
  fclose(fparoi);
}

void lecture_donnees_sol(char *nom_fichier, prop_sol *tableau_sol) {
  FILE *fic_sol; /* fichier lu */
  char nom_var[32]; /* nom de la variable */
  double val_var; /* valeur de la variable */
  int val_ind; /* valeur de l'indice */
  
  /* verification de l'existance du fichier lu */
  
  if ((fic_sol = fopen(nom_fichier, "r")) == NULL) {
    printf("\n\n  ERREUR : Impossible d'ouvrir '%s'\n\n", nom_fichier);
    exit(0);
  }
  
  /* lecture des donnees */

  /* if (fscanf(fic_sol, "%s %lf", nom_var, &val_var) != 0) */
  /*   { */
  /*     tableau_sol->lambda_sol = val_var; */
  /*     printf("\nlambda sol : %f", val_var); */
  /*     printf("\nlambda sol : %f", tableau_sol->lambda_sol); */
  /*   } */
  tableau_sol->lambda_sol = lecture_option_resul_double(nom_fichier, "lambda_sol");  
  tableau_sol->cp_sol = lecture_option_resul_double(nom_fichier, "cp_sol");  
  tableau_sol->rho_sol = lecture_option_resul_double(nom_fichier, "rho_sol");
  tableau_sol->z_ref =  lecture_option_resul_double(nom_fichier, "z_ref");
  tableau_sol->i_jour = lecture_option_resul_double(nom_fichier, "i_jour");
  tableau_sol->i_jour_ref =  lecture_option_resul_double(nom_fichier, "i_jour_ref");
  tableau_sol->moy_Tair =  lecture_option_resul_double(nom_fichier, "moy_Tair");
  tableau_sol->max_Tair = lecture_option_resul_double(nom_fichier, "max_Tair");
  tableau_sol->min_Tair = lecture_option_resul_double(nom_fichier, "min_Tair");

  /* fermeture du fichier */
  
  fclose(fic_sol);
}

void lecture_descripteur(char *nom_fichier, double *valeur)
/* ------------------------------------------------------------------------------------
 * Ouverture et lecture d'un fichier descripteur 'nom_fichier' (.val)
 * et remplissage du tableau 'valeur'
 * ------------------------------------------------------------------------------------ */ 
{
  double val_min;
  double val_max;
  int num_cont, num_face, num_cont_liste;
  int nbfac, nomax;
  int nofac, nbcont_face;
  char c;
  FILE *pfic;

  /* verification de l'emplacement memoire du fichier */
  if ((pfic = fopen(nom_fichier, "r")) == NULL) {
    printf("\n\n  ERREUR : Impossible d'ouvrir '%s'\n\n", nom_fichier);
    exit(0);
  }
  
  /* lecture des infos en premiere ligne du fichier */
  if (fscanf(pfic, "%d %d %lf %lf", &nbfac, &nomax, &val_min, &val_max) == 0)
    {
      printf("ERREUR lecture descripteur '%s'", nom_fichier);
    }
  /* boucle sur les lignes de faces et de contours */
  num_cont_liste = 0;
  for (num_face = 0; num_face < nbfac; num_face++) {
    if (fscanf(pfic, "\n%c%d%d\n", &c, &nofac, &nbcont_face) == 0)
      {
	printf("ERREUR lecture descripteur '%s'", nom_fichier);
      }
    for (num_cont = 0; num_cont < nbcont_face; num_cont++) {
      if (fscanf(pfic, "%lf\n", valeur + num_cont_liste)== 0)
	{
	  printf("ERREUR lecture descripteur '%s'", nom_fichier);
	}
      num_cont_liste++;
    }
  }
  fclose(pfic);
}

void lecture_option_resul(char *nom_fichier, char *nom_variable, char *nom_fichier_val)
/* ------------------------------------------------------------------------------------
 *  Lecture du fichier contenant les noms des sorties optionnelles
 *
 * ------------------------------------------------------------------------------------ */ 
{
  FILE* pfic= NULL;
  char nom_var[TAILLE_CHAINE_NOM_FICHIER];
  char nom_fichier_out[TAILLE_CHAINE_NOM_FICHIER];
  char ligne[TAILLE_CHAINE_NOM_FICHIER];
  int clef_trouvee = 0;
  /* verification de l'emplacement memoire du fichier */
  if ((pfic = fopen(nom_fichier, "r")) == NULL) {
    printf("\n\n  ERREUR : Impossible d'ouvrir '%s'\n\n", nom_fichier);
    exit(0);
  }

  while(fgets(ligne, TAILLE_CHAINE_NOM_FICHIER, pfic) != NULL)
    {
      if ((ligne[0] != '#') && sscanf(ligne, "%s", nom_var) && (strcmp(nom_var, nom_variable) == 0))
	{
	  clef_trouvee = sscanf(ligne, "%s %s",nom_fichier_out, nom_fichier_val);	  
	}
    }
  fclose(pfic); 
  if (!clef_trouvee)
    {
      printf("erreur, la clef '%s' n'existe pas dans le fichier '%s'\n", nom_variable, nom_fichier);
    }
}

int lecture_option_resul_int(char *nom_fichier, char *nom_variable)
/* ------------------------------------------------------------------------------------
 * Lecture du fichier contenant les noms des sorties optionnelles
 *
 * ------------------------------------------------------------------------------------ */ 
{
  FILE* pfic= NULL;
  char nom_var[TAILLE_CHAINE_NOM_FICHIER];
  char nom_fichier_out[TAILLE_CHAINE_NOM_FICHIER];
  char ligne[TAILLE_CHAINE_NOM_FICHIER];
  int valeur;
  int clef_trouvee = 0;
  /* verification de l'emplacement memoire du fichier */
  if ((pfic = fopen(nom_fichier, "r")) == NULL) {
    printf("\n\n  ERREUR : Impossible d'ouvrir '%s'\n\n", nom_fichier);
    exit(0);
  }

  while(fgets(ligne, TAILLE_CHAINE_NOM_FICHIER, pfic) != NULL)
    {
      if ((ligne[0] != '#') && sscanf(ligne, "%s", nom_var) && (strcmp(nom_var, nom_variable) == 0))
	{
	  clef_trouvee = sscanf(ligne, "%s %d",nom_fichier_out, &valeur);	  
	}
    }
  if (!clef_trouvee)
    {
      printf("erreur, la clef '%s' n'existe pas dans le fichier '%s'\n", nom_variable, nom_fichier);
    }
  fclose(pfic);
  return valeur;
}

double lecture_option_resul_double(char *nom_fichier, char *nom_variable)
/* ------------------------------------------------------------------------------------
 * Lecture du fichier contenant les noms des sorties optionnelles
 *
 * ------------------------------------------------------------------------------------ */ 
{
  FILE* pfic= NULL;
  char nom_var[TAILLE_CHAINE_NOM_FICHIER];
  char nom_fichier_out[TAILLE_CHAINE_NOM_FICHIER];  
  char ligne[TAILLE_CHAINE_NOM_FICHIER];
  double valeur;
  int clef_trouvee = 0;
  /* verification de l'emplacement memoire du fichier */
  if ((pfic = fopen(nom_fichier, "r")) == NULL) {
    printf("\n\n  ERREUR : Impossible d'ouvrir '%s'\n\n", nom_fichier);
    exit(0);
  }

  while(fgets(ligne, TAILLE_CHAINE_NOM_FICHIER, pfic) != NULL)
    {
      if ((ligne[0] != '#') && sscanf(ligne, "%s", nom_var) && (strcmp(nom_var, nom_variable) == 0))
	{
	  clef_trouvee = sscanf(ligne, "%s %lf",nom_fichier_out, &valeur);
	}
    }
  if (!clef_trouvee)
    {
      printf("\n\n ERREUR : la clef '%s' n'existe pas dans le fichier '%s'\n", nom_variable, nom_fichier);
    }
  fclose(pfic);
  return valeur;
}

double val_max_descripteur(char *nom_fichier)
/* ------------------------------------------------------------------------------------
 * Ouverture et lecture de la premiere ligne d'un fichier descripteur
 * pour trouver le max
 * ------------------------------------------------------------------------------------ */ 
{
  double val_min;
  double val_max;
  int nbfac, nomax;
  FILE *pfic;
  
  /* verification de l'emplacement memoire du fichier */
  if ((pfic = fopen(nom_fichier, "r")) == NULL) {
    printf("\n\n  ERREUR : Impossible d'ouvrir '%s'\n\n", nom_fichier);
    exit(0);
  }
  /* lecture des infos en premiere ligne du fichier */
  fscanf(pfic, "%d %d %lf %lf", &nbfac, &nomax, &val_min, &val_max);
  return val_max;
}

int total_face(char *nom_fichier)
/* ------------------------------------------------------------------------------------
 * lecture du fichier "nom_fichier(.val)"pour evaluer le nombre total de faces
 * ------------------------------------------------------------------------------------ */ 
{
  int nb_F;
  int no_Fmax;
  double val_min, val_max;
  FILE *pfic;
  
  /* verification de l'emplacement memoire du fichier */
  if ((pfic = fopen(nom_fichier, "r")) == NULL) {
    printf("\n\n  ERREUR : Impossible d'ouvrir '%s'\n\n", nom_fichier);
    exit(0);
  }
  /* lecture des infos en premiere ligne du fichier */
  fscanf(pfic, "%d %d %lf %lf", &nb_F, &no_Fmax, &val_min, &val_max);
  /* fermeture du fichier */
  fclose(pfic);
  /* mise a jour */
  /*printf("Nombre total de faces : %d\n", nb_F) ; */
  return nb_F;
}

void analyse_face_contour(char *nom_fichier, int *no_face_max,
			  int *nb_contour_total, int *tab_no_face, int *tab_nb_contour_face)
/* ------------------------------------------------------------------------------------
 *  lecture du fichier "nom_fichier(.val)" pour evaluer :
 *  - le nombre total de contours
 *  - le nombre total de faces
 *  - le n de la face max
 *  remplissage des tableau de n de face, et nb de contour par face correspondant
 * ------------------------------------------------------------------------------------ */ 
{
  int nb_F;
  int no_face;
  int no_Fmax;
  int nb_contour;
  int *tab_cf, *tab_no;
  double val_min, val_max;
  int i, j;
  char c; /* pour la lecture du caractere f (identifiant face du fichier .val) */
  double *auxiliaire; /* adresse d'une var. aux. permettant de lire chq ligne portant la val numerique du descripteur */
  FILE *pfic; /* adresse du fichier */
  
  /* verification de l'emplacement memoire du fichier */
  if ((pfic = fopen(nom_fichier, "r")) == NULL) {
    printf("\n\n  ERREUR : Impossible d'ouvrir '%s'\n\n", nom_fichier);
    exit(0);
  }
  /* initialisation */
  *nb_contour_total = 0;
  /* lecture des infos en premiere ligne du fichier */
  if (fscanf(pfic, "%d %d %lf %lf", &nb_F, &no_Fmax, &val_min, &val_max) == 0)
    {
      printf("ERREUR analyse face contour\n");
    }
  /* allocation memoire des tableaux de 'n de face' et de 'nb de contours par face' */
  tab_no = allocation_tableau_int(nb_F);
  tab_cf = allocation_tableau_int(nb_F);
  /* boucle sur les ligne du fichier */
  /*printf("Detail de la geometrie :\n");	 */
  for (i = 0; i < nb_F; i++) {
    if (fscanf(pfic, "\n%c%d%d\n", &c, &no_face, &nb_contour) == EOF)
      {
	printf("ERREUR analyse face contour\n");
      }
    /*printf("----------------------\n"); */
    /*printf("Face %d  :  %d contours\n", no_face, nb_contour) ; */
    tab_no[i] = no_face;
    tab_cf[i] = nb_contour;
    *nb_contour_total += nb_contour;
    auxiliaire = (double *) malloc(nb_contour * sizeof(double));
    for (j = 0; j < nb_contour; j++) {
      /* lecture des lignes de descripteur sans rien stocker */
      if (fscanf(pfic, "%lf\n", auxiliaire + j)== EOF)
	{
	  printf("ERREUR analyse face contour\n");
	}
      /*printf("aux : %f\n",auxiliaire+j) ;   */
    }
    free(auxiliaire);
  }
  /*printf("----------------------\n"); */
  /* fermeture du fichier */
  fclose(pfic);
  /* mise a jour des resultats */
  *no_face_max = no_Fmax;
  /*tab_no_face = allocation_tableau_int(nb_F) ; */
  /*tab_nb_contour_face = allocation_tableau_int(nb_F) ; */
  for (i = 0; i < nb_F; i++) {
    tab_no_face[i] = tab_no[i];
    tab_nb_contour_face[i] = tab_cf[i];
  }
  /* impression infos */
  /*printf("\nNombre total de contours : %d", *nb_contour_total) ; */
  /*printf("\nNombre total de faces : %d", nb_F) ; */
  /*printf("N de la face max : %d\n", *no_face_max) ; */
  /*for (i = 0; i < nb_F ; i++)	printf("\ni = %d    face%d :    %d contours",i, tab_no_face[i], tab_nb_contour_face[i]) ; */
}

void lecture_fichier_T_noeuds_init(char *nom_fichier_matrice_noeuds_in,
				   int nb_niv, double *T2init, double *T4init, double *T5init,
				   double *T6init, double *T7init, double *T8init, double *T9init,
				   double *T12init, double *Tsolinit, double *Tairinit)
/* ------------------------------------------------------------------------------------
 *  ouverture et lecture d'un fichier (.txt) de l'ensemble des valeurs
 *  de temperatures et puissances nodales par niveau (matrice de valeurs) et
 *  stockage des valeurs dans des vecteurs (de dimension niveau) de variables
 *  individuelles correspondants
 * ------------------------------------------------------------------------------------ */ 
{
  FILE *pfic = NULL;
  int i = 0;
  int X = 0;
  double buf1, buf2;
  
  /* verification de l'emplacement memoire du fichier */
  if ((pfic = fopen(nom_fichier_matrice_noeuds_in, "r")) == NULL) {
    printf("\n\n  ERREUR : Impossible d'ouvrir '%s'\n\n",
	   nom_fichier_matrice_noeuds_in);
    exit(0);
  }
  
  while (X != EOF) {
    /* verification du nombre d'etages (trop ?) */
    if (i > nb_niv) {
      printf(
	     "\n\n  ERREUR : Nb de lignes de '%s' superieur au nombre de niveaux \n\n",
	     nom_fichier_matrice_noeuds_in);
      exit(0);
    }
    /* lecture et stockage des valeurs */
    X = fscanf(pfic, "%lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf",
	       T2init + i, T4init + i, T5init + i, T6init + i, T7init + i,
	       T8init + i, T9init + i, T12init + i, Tsolinit + i,
	       Tairinit + i, &buf1, &buf2);
    i++;
  }
  
  /* verification du nombre d'etages (pas assez ?) */
  if (i < nb_niv) {
    printf(
	   "\n\n  ERREUR : Nb de lignes de '%s' inferieur au nombre de niveaux \n\n",
	   nom_fichier_matrice_noeuds_in);
    exit(0);
  }
}

int test_tableau_val_positif(double *tableau, int dim, double *val_min,
			     int *nb_erreur)
/* ------------------------------------------------------------------------------------
 *  teste s'il y a des valeurs negatives dans un tableau de descripteurs
 *  renvoie 0 si au moins une des valeurs est <0
 *  renvoie 1 si toutes les valeurs sont >=0
 *  FORCE TOUTES LES VALEURS NEGATIVES A 0
 *  stocke la valeur la plus basse
 * ------------------------------------------------------------------------------------ */ 
{
  int test = 1;
  int i;
  int err = 0;

  *nb_erreur = 0;
  *val_min = tableau[0];
  for (i = 0; i < dim; i++) {
    if (tableau[i] < *val_min)
      *val_min = tableau[i];
    if (tableau[i] < 0) {
      tableau[i] = 0.0;
      err++;
      test = 0;
    }
  }
  *nb_erreur = err;
  return test;
}

int stocke_fichier_T_noeuds_out(char *nom_fichier_matrice_noeuds_out,
				int nb_niv, double *T2out, double *T4out, double *T5out, double *T6out,
				double *T7out, double *T8out, double *T9out, double *T12out,
				double *Tsolout, double *Tairout, double *Pconv, double *Plat)
/* ------------------------------------------------------------------------------------
 *  stockage des valeurs nodales (temperatures / puissances) calculees pour le
 *  modele de batiment dans un fichier .txt (matrice de valeurs par niveau)
 * ------------------------------------------------------------------------------------ */ 
{
  FILE *pf = NULL;
  int i = 0;
  int sauvOK = 1;
  
  if ((pf = fopen(nom_fichier_matrice_noeuds_out, "w")) == NULL) {
    sauvOK = 0;
  } else {
    for (i = 0; i < nb_niv; i++) {
      fprintf(pf, "%f %f %f %f %f %f %f %f %f %f %f %f\n", T2out[i],
	      T4out[i], T5out[i], T6out[i], T7out[i], T8out[i], T9out[i],
	      T12out[i], Tsolout[i], Tairout[i], Pconv[i], Plat[i]);
    }
    fclose(pf);
  }
  return sauvOK;
}

int stocke_fichier_val(char *nom_fichier, int nbfac, int nomax,
		       int nb_contour_total, int *numero_face, int *nb_cont_face, double *tab)
/* ------------------------------------------------------------------------------------
 *  permet de generer un descripteur "nom_fichier(.val)" a partir d'un tableau
 *  de valeurs
 * ------------------------------------------------------------------------------------ */ 
{
  FILE *pf;
  double mini, maxi;
  int i, k, num;
  int sauvOK = 1;
  
  if ((pf = fopen(nom_fichier, "w")) == NULL)
    sauvOK = 0;
  else {
    mini = maxi = tab[0];
    for (i = 0; i < nb_contour_total; i++) {
      if (tab[i] < mini)
	mini = tab[i];
      if (tab[i] > maxi)
	
	maxi = tab[i];
    }
    
    fprintf(pf, "%5d %5d %8.3f %8.3f\n", nbfac, nomax, mini, maxi);
    
    num = 0;
    for (i = 0; i < nbfac; i++) {
      fprintf(pf, "f%d %d\n", numero_face[i], nb_cont_face[i]);
      for (k = 0; k < nb_cont_face[i]; k++) {
	fprintf(pf, "    %8.3f\n", tab[num]);
	num++;
      }
    }
    fclose(pf);
  }
  return sauvOK;
}

void lecture_ff(FILE *pf_fform, float *factf, int ii, int nb_contour_total)
/* ------------------------------------------------------------------------------------
 *  lecture des facteurs de forme dans un fichier
 *  extraite de 'transitoire_h_option2.c'
 *  modifiee par J.Bouyer, decembre 2006
 * ------------------------------------------------------------------------------------ */ 
{
  int ok = 0;
  fseek(pf_fform, (ii * nb_contour_total) * sizeof(float), SEEK_SET);
  ok = fread(factf, sizeof(float), nb_contour_total, pf_fform);
  if (!ok)
    {
      printf("ERREUR lecture facteur de forme");
    }
}

void lecture_ff_mem(float *fform_mem, float *factf, int ii, int nb_contour_total)
/* ------------------------------------------------------------------------------------
 *  lecture des facteurs de forme dans un fichier
 *  extraite de 'transitoire_h_option2.c'
 *  modifiee par J.Bouyer, decembre 2006
 * ------------------------------------------------------------------------------------ */ 
{
  int i_cont;
    for (i_cont =0; i_cont < nb_contour_total; i_cont ++){
      factf[i_cont] = fform_mem[ii * nb_contour_total + i_cont];
    }
}


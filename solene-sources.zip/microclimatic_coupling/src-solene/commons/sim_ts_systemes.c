/*
 *  Copyright 2010-2013 Laurent Malys (CERMA, UMR 1563 AAU, CNRS /
 *                                  Ecole d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

#include "../includes/sim_ts.h"

void remplissage_matrice_modele_batiment(double *M, int dim, int nb_facette,
					 int nb_niv, double *niveau, int nb_paroi, double *id_paroi,
					 double *classe_paroi, double *surface, Sniveau *Sniv, double *in_air,
					 double dt, int *alpha, double *hc_ext, listeRCparoi *RCmur,
					 listeRCparoi *RCvit, listeRCparoi *RCtoit, listeRCparoi *RCplc_int,
					 listeRCparoi *RCplc_bas, listeRCparoi *RCint, double *Rcv_i,
					 double *Rrad_i, double *Rra, double *Cai, double Rsol, double Csol,
					 double *Cf, double *Ca, double *h_pa, double *h_ainf) 
/* ------------------------------------------------------------------------------------
 *  remplit la matrice [A] de resolution du systeme lineaire en fonction
 *  des variables physiques du modele de batiment
 *  2 valeurs de matrices : [A] en regime libre ou force :
 *  depend de la valeur de alpha regime force (alpha = 0) ou libre (alpha = 1)
 * ------------------------------------------------------------------------------------ */ 
{
  int i = 0, j = 0, n = 0; /* indices de passage entre la notation M(i,j) a la notation M(n) */
  int fac = 0; /* compteur de facette */
  int niv = 0; /* compteur d'etage */
  int id = 0; /* indice de reperage du nID de facette */
  
  int p, p_max, p_max_old; /* compteurs de positionnement dans la matrice */
  int offset_mur = 0, offset_vit = 0, offset_toit = 0, offset_niv = 0,
    offset_n5_RDC = 0; /* compteurs de positionnement dans la matrice (debuts de blocs) */
  double somme = 0; /* variable intremediaire permettant de sommer des variables pour un type de facettes */
  double Kc = 0, Kr = 0; /* variables intermediaires mises pour choisir entre les resistances au noeud 5 ou 12 */
  
  double h_r = 6; /* coefficient d echange radiatif entre les feuilles et le mur */
  
  /* boucle sur le nb de niveaux, remplissage des coefs en incrementant le nb de lignes */
  /* on raisonne par bloc ("murs exterieurs", "vitrages", "noeuds internes") */
  /* les blocs  "sol" et "toiture" sont traites a l'ext de la boucle */
  for (niv = 0; niv < nb_niv; niv++) {
    
    /*=============================== */
    /* BLOC MUR (1,1   1,2   ...   1,p   2) */
    /*=============================== */
    
    /* interface exterieur (bloc diagonal) */
    /*-------------------------------------------- */
    
    /* coefs successifs de la la digonale M( 1,p ; 1,p ) */
    p_max_old = i;
    offset_niv = p_max_old + 1;
    p = p_max_old;
    for (fac = 0; fac < nb_facette; fac++) {
      for (id = 0; id < nb_paroi; id++) {
	if (((int) niveau[fac] == niv)
	    && ((int) id_paroi[fac] == id)) {
	  if ((int) classe_paroi[fac] == 0){
	    i = 1 + p;
	    j = 1 + p;
	    n = (i - 1) * dim + (j - 1);
	    M[n] = surface[fac] * (hc_ext[fac] + (1 / RCmur[id].R)
				   + (RCmur[id].Ce / dt)); /* termes de la la digonale M( 1,p ; 1,p ) */
	    somme += surface[fac] * ((1 / RCmur[id].R) + (RCmur[id].Ci
							  / dt)); /* terme de sommation du coef diagonal M(2;2) */
	    p++;}
	  if ((int) classe_paroi[fac] == 11){
	    /* terme diagonal Tf */
	    i = 1 + p;
	    j = 1 + p;
	    n = (i - 1) * dim + (j - 1);
	    M[n] = surface[fac] * (h_r + h_pa[fac] + Cf[fac] / dt);
	    /* ligne Tf */
	    n = (i) * dim + (j - 1);
	    M[n] = - surface[fac] * h_pa[fac];
	    n = (i +1) * dim + (j - 1);
	    M[n] = -surface[fac] * h_r;
	    /* colonne Tf */
	    n = (i - 1) * dim + (j);
	    M[n] = - surface[fac] * h_pa[fac];
	    n = (i - 1) * dim + (j + 1);
	    M[n] = - surface[fac] * h_r;
	    p++;
	    
	    /* terme diagonal Ta */
	    i = 1 + p;
	    j = 1 + p;
	    n = (i - 1) * dim + (j - 1);
	    M[n] = surface[fac] * (h_ainf[fac] + h_pa[fac] + hc_ext[fac] + Ca[fac] / dt);
	    /* ligne Ta */
	    n = (i) * dim + (j - 1);
	    M[n] = - surface[fac] * hc_ext[fac];
	    /* colonne Ta */
	    n = (i - 1) * dim + (j);
	    M[n] = - surface[fac] * hc_ext[fac];
	    p++;

	    /* diagonale Ts_ext */
	    i = 1 + p;
	    j = 1 + p;
	    n = (i - 1) * dim + (j - 1);
	    M[n] = surface[fac] * (hc_ext[fac] + h_r + (1 / RCmur[id].R)
				   + (RCmur[id].Ce / dt)); /* termes de la la digonale M( 1,p ; 1,p ) */
	    somme += surface[fac] * ((1 / RCmur[id].R) + (RCmur[id].Ci
							  / dt)); /* terme de sommation du coef diagonal M(2;2) */
	    p++;
	  }
	}
      }
    }
    
    p_max = p;
    
    /* offset de la colonne 2 */
    i = 1 + p_max;
    j = 1 + p_max;
    offset_mur = j;
    n = (i - 1) * dim + (j - 1);
    
    /* coef diagonal complet M(2;2) */
    M[n] = somme + Sniv[niv].SURFACE_CL[0]  * ((1 / Rrad_i[0]) + (1
								 / Rcv_i[0]));
    somme = 0;
    
    /* coefs de la ligne2 M(2;p) et la colonne2 M(p;2) */
    p = p_max_old;
    for (fac = 0; fac < nb_facette; fac++) {
      for (id = 0; id < nb_paroi; id++) {
	if (((int) niveau[fac] == niv)
	    && ((int) id_paroi[fac] == id)) {	  
	  if ((int) classe_paroi[fac] == 0){
	    i = 1 + p_max;
	    j = 1 + p;
	    n = (i - 1) * dim + (j - 1);
	    M[n] = -surface[fac] * (1 / RCmur[id].R); /* ligne 2 */
	    n = (j - 1) * dim + (i - 1); /* on inverse le i et le j */
	    M[n] = -surface[fac] * (1 / RCmur[id].R); /* colonne 2 */
	    p++;
	  }
	  
	  if ((int) classe_paroi[fac] == 11){
	    i = 1 + p_max;
	    j = 3 + p;
	    n = (i - 1) * dim + (j - 1);
	    M[n] = -surface[fac] * (1 / RCmur[id].R); /* ligne 2 */
	    n = (j - 1) * dim + (i - 1); /* on inverse le i et le j */
	    M[n] = -surface[fac] * (1 / RCmur[id].R); /* colonne 2 */
	    p+=3;
	  }
	}
      }
    }
    /*=============================== */
    /* BLOC VITRAGE (3,1   3,2   ...   3,p   4) */
    /*=============================== */
    
    /* interface exterieur (bloc diagonal) */
    /*-------------------------------------------- */
    
    /* coefs successifs de la la digonale M( 3,p ; 3,p ) */
    p_max_old = p_max + 1;
    p = p_max_old;
    for (fac = 0; fac < nb_facette; fac++) {
      for (id = 0; id < nb_paroi; id++) {
	if (((int) niveau[fac] == niv)
	    && ((int) classe_paroi[fac] == 1)
	    && ((int) id_paroi[fac] == id)) {
	  i = 1 + p;
	  j = 1 + p;
	  n = (i - 1) * dim + (j - 1);
	  M[n] = surface[fac] * (hc_ext[fac] + (1 / RCvit[id].R)
				 + (RCvit[id].Ce / dt)); /* termes de la la digonale M( 1,p ; 1,p ) */
	  somme += surface[fac] * ((1 / RCvit[id].R) + (RCvit[id].Ci
							/ dt)); /* terme de sommation du coef diagonal M(2;2) */
	  p++;
	}
      }
    }
    
    p_max = p;
    
    /* offset de la colonne 4 */
    i = 1 + p_max;
    j = 1 + p_max;
    offset_vit = j;
    n = (i - 1) * dim + (j - 1);
    
    /* coef diagonal complet M(4;4) */
    M[n] = somme + Sniv[niv].SURFACE_CL[1] * ((1 / Rrad_i[1]) + (1
								 / Rcv_i[1]));
    somme = 0;
    
    /* coefs de la ligne2 M(4;p) et la colonne2 M(p;4) */
    p = p_max_old;
    for (fac = 0; fac < nb_facette; fac++) {
      for (id = 0; id < nb_paroi; id++) {
	if (((int) niveau[fac] == niv)
	    && ((int) classe_paroi[fac] == 1)
	    && ((int) id_paroi[fac] == id)) {
	  i = 1 + p_max;
	  j = 1 + p;
	  n = (i - 1) * dim + (j - 1);
	  M[n] = -surface[fac] * (1 / RCvit[id].R); /* ligne 2 */
	  n = (j - 1) * dim + (i - 1); /* on inverse le i et le j */
	  M[n] = -surface[fac] * (1 / RCvit[id].R); /* colonne 2 */
	  p++;
	}
      }
    }
    
    /*=============================== */
    /* BLOC INTERACTION MUR/VITRAGE <-> NOEUD 9 ET 10 */
    /*=============================== */
    
    /* interaction avec noeud 9 */
    
    i = offset_mur;
    j = offset_vit + 5;
    n = (i - 1) * dim + (j - 1);
    M[n] = - Sniv[niv].SURFACE_CL[0] * (1 / Rrad_i[0]);
    
    i = offset_vit;
    j = offset_vit + 5;
    n = (i - 1) * dim + (j - 1);
    M[n] = -Sniv[niv].SURFACE_CL[1] * (1 / Rrad_i[1]);
    
    /* interaction avec noeud 10 */
    
    i = offset_mur;
    j = offset_vit + 6;
    n = (i - 1) * dim + (j - 1);
    M[n] = -alpha[niv] * Sniv[niv].SURFACE_CL[0] * (1 / Rcv_i[0]);
    
    i = offset_vit;
    j = offset_vit + 6;
    n = (i - 1) * dim + (j - 1);
    M[n] = -alpha[niv] * Sniv[niv].SURFACE_CL[1] * (1 / Rcv_i[1]);
    
    /*=============================== */
    /* BLOC NOEUDS INTERIEURS (5, 6, 7, 8, 9, 10) */
    /*=============================== */
    
    p_max_old = p_max + 1;
    p = p_max_old;
    
    /* LIGNE 5 : noeud du plafond (ou de sous plancher-bas RDC) */
    /*---------------------------------------- */
    i = 1 + p;
    if (niv == 0)
      offset_n5_RDC = i; /*localisation du noeud 5 au RDC pour integrer en fin de matrice les coefs du noeud 5' (sous sol) */
    
    /* colonne 5 (plafond ou sol) */
    j = i;
    n = (i - 1) * dim + (j - 1);
    if (niv == 0)
      M[n] = Sniv[niv].SURFACE_CL[3] * ((1 / Rsol) + (RCplc_bas->Ce / dt)
					+ (1 / RCplc_bas->R)); /* cas du RDC */
    else
      M[n] = Sniv[niv].SURFACE_CL[3] * ((1 / Rrad_i[4]) + (1 / Rcv_i[4])
					+ (RCplc_int->Ce / dt) + (1 / RCplc_int->R)); /* cas d'un autre niveau */
    /* ATTENTION : les [RC]plf doivent etre pris au niveau N-1 */
    /* si on change les caracteristiques des plancher a chaque etage */
    /* Ici : meme plancher pour chaque etage */
    
    /* colonne 6 (plancher) */
    j = i + 1;
    n = (i - 1) * dim + (j - 1);
    if (niv == 0)
      M[n] = -Sniv[niv].SURFACE_CL[3] * (1 / RCplc_bas->R);
    else
      M[n] = -Sniv[niv].SURFACE_CL[3] * (1 / RCplc_int->R);
    
    if (niv != 0) {
      /* colonne 9 (Tmr) DU NIVEAU N-1 */
      j = offset_niv - 2;
      n = (i - 1) * dim + (j - 1);
      M[n] = -Sniv[niv].SURFACE_CL[3] * (1 / Rrad_i[4]);
      /* on revient sur le bloc du niveau precedent */
      /* colonne 5 NIVEAU N, ligne 9 NIVEAU N-1 */
      j = i;
      i = offset_niv - 2; /* inversion du i et du j */
      n = (i - 1) * dim + (j - 1);
      M[n] = -Sniv[niv].SURFACE_CL[3] * (1 / Rrad_i[4]);
      /* SURFACE_CL[3] PARCE que Splc(N+1) = Splf(N) */
      /* ATTENTION : ici, meme qualite de plancher et meme Rrad pour chaque etage */
      
      i = 1 + p;

      /* colonne 10 (Tair) DU NIVEAU N-1 */
      j = offset_niv - 1;
      n = (i - 1) * dim + (j - 1);
      M[n] = -alpha[niv] * Sniv[niv].SURFACE_CL[3] * (1 / Rcv_i[4]);
      /* on revient sur le bloc du niveau precedent */
      /* colonne 5 NIVEAU N, ligne 10 NIVEAU N-1 */
      j = i;
      i = offset_niv - 1; /* inversion du i et du j */
      n = (i - 1) * dim + (j - 1);
      M[n] = -Sniv[niv].SURFACE_CL[3] * (1 / Rcv_i[4]);
      /* SURFACE_CL[3] : Splc(N+1) = Splf(N) */
      /* Attention : ici, meme qualite de plancher pour chaque etage et meme Rrad */
    }
    i = 1 + p;
    
    /* pour l'interaction avec le noeud 5' -> voir la derniere partie de la fonction */
    

    /* LIGNE 6 : noeud du plancher */
    /*---------------------------------------- */
    i++;
    
    /* colonne 5 (plafond ou sol) */
    j = i - 1;
    n = (i - 1) * dim + (j - 1);
    if (niv == 0)
      M[n] = -Sniv[niv].SURFACE_CL[3] * (1 / RCplc_bas->R);
    else
      M[n] = -Sniv[niv].SURFACE_CL[3] * (1 / RCplc_int->R);
    
    /* colonne 6 (plancher) */
    j = i;
    n = (i - 1) * dim + (j - 1);
    if (niv == 0)
      M[n] = Sniv[niv].SURFACE_CL[3] * ((1 / Rrad_i[3]) + (1 / Rcv_i[3])
					+ (RCplc_bas->Ci / dt) + (1 / RCplc_bas->R));
    else
      M[n] = Sniv[niv].SURFACE_CL[3] * ((1 / Rrad_i[3]) + (1 / Rcv_i[3])
					+ (RCplc_int->Ci / dt) + (1 / RCplc_int->R));
    
    /* colonne 9 (Tmr) */
    j = i + 3;
    n = (i - 1) * dim + (j - 1);
    M[n] = -Sniv[niv].SURFACE_CL[3] * (1 / Rrad_i[3]);
    
    /* colonne 10 (Tair) */
    j = i + 4;
    n = (i - 1) * dim + (j - 1);
    M[n] = -alpha[niv] * Sniv[niv].SURFACE_CL[3] * (1 / Rcv_i[3]);
    
    /* LIGNE 7 : noeud interne des parois interieures */
    /*---------------------------------------- */
    i++;
    
    /* colonne 7 (interieur des parois int) */
    j = i;
    n = (i - 1) * dim + (j - 1);
    M[n] = Sniv[niv].SURFACE_CL[5] * ((RCint->Ci / dt) + (1 / RCint->R));
    
    /* colonne 8 (surface des parois int) */
    j = i + 1;
    n = (i - 1) * dim + (j - 1);
    M[n] = -Sniv[niv].SURFACE_CL[5] * (1 / RCint->R);
    
    /* LIGNE  8 : noeud de surface des parois interieures */
    /*---------------------------------------- */
    i++;
    
    /* colonne 7 (interieur des parois int) */
    j = i - 1;
    n = (i - 1) * dim + (j - 1);
    M[n] = -Sniv[niv].SURFACE_CL[5] * (1 / RCint->R);
    
    /* colonne 8 (surface des parois int) */
    j = i;
    n = (i - 1) * dim + (j - 1);
    M[n] = Sniv[niv].SURFACE_CL[5] * ((1 / Rrad_i[5]) + (1 / Rcv_i[5]) + (1
									  / RCint->R));
    
    /* colonne 9 (Tmr) */
    j = i + 1;
    n = (i - 1) * dim + (j - 1);
    M[n] = -Sniv[niv].SURFACE_CL[5] * (1 / Rrad_i[5]);
    
    /* colonne 10 (Tair) */
    j = i + 2;
    n = (i - 1) * dim + (j - 1);
    M[n] = -alpha[niv] * Sniv[niv].SURFACE_CL[5] * (1 / Rcv_i[5]);
    
    /* LIGNE 9 : noeud Tmr */
    /*------------------------------------ */
    i++;
    
    /* colonne 2 (surface int des murs) */
    j = offset_mur;
    n = (i - 1) * dim + (j - 1);
    M[n] = -Sniv[niv].SURFACE_CL[0] * (1 / Rrad_i[0]);
    
    /* colonne 4 (surface int des vitrages) */
    j = offset_vit;
    n = (i - 1) * dim + (j - 1);
    M[n] = -Sniv[niv].SURFACE_CL[1] * (1 / Rrad_i[1]);
    
    /* colonne 6 (plancher) */
    j = i - 3;
    n = (i - 1) * dim + (j - 1);
    M[n] = -Sniv[niv].SURFACE_CL[3] * (1 / Rrad_i[3]);
    
    /* colonne 8 (paroi int) */
    j = i - 1;
    n = (i - 1) * dim + (j - 1);
    M[n] = -Sniv[niv].SURFACE_CL[5] * (1 / Rrad_i[5]);
    
    /* colonne 9 (Tmr) */
    j = i;
    n = (i - 1) * dim + (j - 1);
    
    if (niv == nb_niv - 1)
      Kr = Sniv[niv].SURFACE_CL[2] / Rrad_i[2];
    else
      Kr = Sniv[niv].SURFACE_CL[4] / Rrad_i[4];
    
    M[n] = (Sniv[niv].SURFACE_CL[0] / Rrad_i[0]) + (Sniv[niv].SURFACE_CL[1]
						    / Rrad_i[1]) + Kr + (Sniv[niv].SURFACE_CL[3] / Rrad_i[3])
      + (Sniv[niv].SURFACE_CL[5] / Rrad_i[5]);
    
    Kr = 0;
    
    /* LIGNE 10 : noeud Tair int ou Pconv */
    /*------------------------------------ */
    i++;
    
    /* colonne 2 (surface int des murs) */
    j = offset_mur;
    n = (i - 1) * dim + (j - 1);
    M[n] = -Sniv[niv].SURFACE_CL[0] * (1 / Rcv_i[0]);
    
    /* colonne 4 (surface int des vitrages) */
    j = offset_vit;
    n = (i - 1) * dim + (j - 1);
    M[n] = -Sniv[niv].SURFACE_CL[1] * (1 / Rcv_i[1]);
    
    /* colonne 6 (plancher) */
    j = i - 4;
    n = (i - 1) * dim + (j - 1);
    M[n] = -Sniv[niv].SURFACE_CL[3] * (1 / Rcv_i[3]);
    
    /* colonne 8 (parois int) */
    j = i - 2;
    n = (i - 1) * dim + (j - 1);
    M[n] = -Sniv[niv].SURFACE_CL[5] * (1 / Rcv_i[5]);
    
    /* colonne 10 (Tair) */
    j = i;
    n = (i - 1) * dim + (j - 1);
    
    for (fac = 0; fac < nb_facette; fac++) {
      if (((int) niveau[fac] == niv) && ((int) in_air[fac] == 1)) {
	if (Rra[fac] > 0)
	  somme = somme + (1 / Rra[fac]);
	else
	  somme = 0;
	/*{ printf("\n\n  ERREUR : Probleme au niveau du debit d'air (facette[%d] ; niveau[%d])\n\n",fac,niv) ; exit(0) ; } */
      }
    }
    /*if (somme == 0)	{ printf("\n\n  ERREUR : Pas d'entrees d'air au niveau %d - Verifier descripteur\n\n",niv) ; exit(0) ; } */
    
    if (niv == nb_niv - 1)
      Kc = Sniv[niv].SURFACE_CL[2] / Rcv_i[2];
    else
      Kc = Sniv[niv].SURFACE_CL[4] / Rcv_i[4];
    
    M[n] = alpha[niv] * ((Sniv[niv].SURFACE_CL[0] / Rcv_i[0])
			 + (Sniv[niv].SURFACE_CL[1] / Rcv_i[1])
			 + (Sniv[niv].SURFACE_CL[3] / Rcv_i[3]) + Kc
			 + (Sniv[niv].SURFACE_CL[5] / Rcv_i[5]) + somme
			 + (Cai[niv] / dt)) - (1 - alpha[niv]);
    
    somme = 0;
    Kc = 0;
    
  } /* fin de la boucle sur le nb de niveaux */
  
  
  /*=============================== */
  /* BLOC TOITURE (11,1   11,2   ...   11,p   12) */
  /*=============================== */
  
  /* interface exterieur (noeud 11) (bloc diagonal) */
  /*-------------------------------------------- */
  
  /* coefs successifs de la la digonale M( 11,p ; 11,p ) */
  
  p_max_old = i;
  p = p_max_old;
  for (fac = 0; fac < nb_facette; fac++) {
    for (id = 0; id < nb_paroi; id++) {
      if ((int) id_paroi[fac] == id) {
	if ((int) classe_paroi[fac] == 2){
	  i = 1 + p;
	  j = 1 + p;
	  n = (i - 1) * dim + (j - 1);
	  M[n] = surface[fac] * (hc_ext[fac] + (1 / RCtoit[id].R) + (1
								     * RCtoit[id].Ce / dt)); /* termes de la la digonale M( 1,p ; 1,p ) */
	  somme += surface[fac] * ((1 / RCtoit[id].R) + (RCtoit[id].Ci
							 / dt)); /* terme de sommation du coef diagonal M(2;2) */
	  p++;
	}
	if ((int) classe_paroi[fac] == 12){
	  
	  /* terme diagonal Tf */
	  i = 1 + p;
	  j = 1 + p;
	  n = (i - 1) * dim + (j - 1);
	  M[n] = surface[fac] * (h_r + h_pa[fac] + Cf[fac] / dt);
	  /* ligne Tf */
	  n = (i) * dim + (j - 1);
	  M[n] = - surface[fac] * h_pa[fac];
	  n = (i +1) * dim + (j - 1);
	  M[n] = -surface[fac] * h_r;
	  /* colonne Tf */
	  n = (i - 1) * dim + (j);
	  M[n] = - surface[fac] * h_pa[fac];
	  n = (i - 1) * dim + (j + 1);
	  M[n] = - surface[fac] * h_r;
	  p++;
	  
	  /* terme diagonal Ta */
	  i = 1 + p;
	  j = 1 + p;
	  n = (i - 1) * dim + (j - 1);
	  M[n] = surface[fac] * (h_ainf[fac] + h_pa[fac] + hc_ext[fac] + Ca[fac] / dt);
	  /* ligne Ta */
	  n = (i) * dim + (j - 1);
	  M[n] = - surface[fac] * hc_ext[fac];
	  /* colonne Ta */
	  n = (i - 1) * dim + (j);
	  M[n] = - surface[fac] * hc_ext[fac];
	  p++;
	  
	  /* diagonale Ts_ext */
	  i = 1 + p;
	  j = 1 + p;
	  n = (i - 1) * dim + (j - 1);
	  M[n] = surface[fac] * (hc_ext[fac] + h_r + (1 / RCtoit[id].R)
				 + (RCtoit[id].Ce / dt)); /* termes de la la digonale M( 1,p ; 1,p ) */
	  somme += surface[fac] * ((1 / RCtoit[id].R) + (RCtoit[id].Ci
							 / dt)); /* terme de sommation du coef diagonal M(2;2) */
	  p++;
	  
	}
      }
    }
  }  
  p_max = p;
  
  /* offset de la colonne 4 */
  i = 1 + p_max;
  j = 1 + p_max;
  offset_toit = j;
  n = (i - 1) * dim + (j - 1);
  
  /* coef diagonal complet M(4;4) */
  M[n] = somme + Sniv[nb_niv - 1].SURFACE_CL[2] * ((1 / Rrad_i[2]) + (1
								      / Rcv_i[2]));
  somme = 0;
  
  /* coefs de la ligne2 M(4;p) et la colonne2 M(p;4) */
  p = p_max_old;
  for (fac = 0; fac < nb_facette; fac++) {
    for (id = 0; id < nb_paroi; id++) {
      if ((int) id_paroi[fac] == id) {
	if ((int) classe_paroi[fac] == 2) {
	  i = 1 + p_max;
	  j = 1 + p;
	  n = (i - 1) * dim + (j - 1);
	  M[n] = -surface[fac] * (1 / RCtoit[id].R); /* ligne 2 */
	  n = (j - 1) * dim + (i - 1); /* on inverse le i et le j */
	  M[n] = -surface[fac] * (1 / RCtoit[id].R); /* colonne 2 */
	  p++;
	}
	if ((int) classe_paroi[fac] == 12) {
	  i = 1 + p_max;
	  j = 3 + p;
	  n = (i - 1) * dim + (j - 1);
	  M[n] = -surface[fac] * (1 / RCtoit[id].R); /* ligne 2 */
	  n = (j - 1) * dim + (i - 1); /* on inverse le i et le j */
	  M[n] = -surface[fac] * (1 / RCtoit[id].R); /* colonne 2 */
	  p+=3;
	}	    
      }
    }
  }
  
  /* interface interieur (interaction noeud 9 et 10) */
  /*-------------------------------------------- */
  
  /* ligne 12 */
  
  /* colonne 9 (Tmr) */
  j = p_max_old - 1;
  n = (i - 1) * dim + (j - 1);
  M[n] = -Sniv[nb_niv - 1].SURFACE_CL[2] * (1 / Rrad_i[2]);
  /* colonne 10 (Tair) */
  j = p_max_old;
  n = (i - 1) * dim + (j - 1);
  /*M[n] = -alpha[niv] * Sniv[nb_niv-1].SURFACE_CL[2] * (1 / Rcv_i[2]); */
  M[n] = -alpha[nb_niv - 1] * Sniv[nb_niv - 1].SURFACE_CL[2] * (1 / Rcv_i[2]);
  
  /* retour a la ligne 9, colonne 12 */
  i = p_max_old - 1;
  j = offset_toit;
  n = (i - 1) * dim + (j - 1);
  M[n] = -Sniv[nb_niv - 1].SURFACE_CL[2] * (1 / Rrad_i[2]);
  
  /* retour a la ligne 10, colonne 12 */
  i = p_max_old;
  j = offset_toit;
  n = (i - 1) * dim + (j - 1);
  M[n] = -Sniv[nb_niv - 1].SURFACE_CL[2] * (1 / Rcv_i[2]);
  
  /*=============================== */
  /* neud 5' de la couche de sol (juste pour le niveau RDC) */
  /*=============================== */
  
  i = offset_toit + 1;
  
  /* colonne 5 (T sous dalle) */
  j = offset_n5_RDC;
  n = (i - 1) * dim + (j - 1);
  M[n] = -Sniv[0].SURFACE_CL[3] * (1 / Rsol);
  /*printf("\n 5 M[n] %d, %d,  %d, %d \n", i, j, n, M[n]); */

  /* derniere colonne (5' ->T'sol) */
  j = i;
  n = (i - 1) * dim + (j - 1);
  M[n] = Sniv[0].SURFACE_CL[3] * ((2 / Rsol) + (Csol / dt));
  /*printf("\n 5' T'sol M[n] %d, %d,  %d, %d \n", i, j, n, M[n]); */
 
  /* retour a la ligne 5, derniere colonne (5') */
  i = offset_n5_RDC;
  n = (i - 1) * dim + (j - 1);
  M[n] = -Sniv[0].SURFACE_CL[3] * (1 / Rsol);
  /*printf("\n 55' M[n] %d, %d,  %d, %d \n", i, j, n, M[n]); */
 }

void remplissage_vecteur_modele_batiment(double *V, 
					 int dim, 
					 int nb_facette,
					 int nb_niv, 
					 double *niveau, 
					 double nb_paroi, 
					 double *id_paroi,
					 double *classe_paroi, 
					 double *surface, 
					 Sniveau *Sniv, 
					 double *in_air,
					 double dt, 
					 int *alpha, 
					 double *hc_ext, 
					 double *Text, 
					 double *TSext, 
					 double *Flux_Latent, 
					 double *Flux_Latent_se,
					 double *T2, 
					 double *T4, 
					 double *T5, 
					 double *T6, 
					 double *T7, 
					 double *T8,
					 double *T9, double T10consigne, double *T10air_init, double *T12,
					 listeRCparoi *RCmur, listeRCparoi *RCvit, listeRCparoi *RCtoit,
					 listeRCparoi *RCplc_int, listeRCparoi *RCplc_bas, listeRCparoi *RCint,
					 double *Rcv_i, double *Rrad_i, double *Rra, double *Cai, double Rsol,
					 double Csol, double Tsol, double *Tsol_bis, double *flux_sol_abs,
					 double *GLO_Total_Net, double *Ft_mur, double *Ft_vit, double *Ft_plc,
					 double *Ft_plf, double *Ft_int, double *Ps_equip, double *Ps_occup,
					 double *Tse_veg_old, double *Ta_old, double *Cf, double *Ca, double *h_ainf, double *h_pa,
					 double *transmission, double *albedo
					 )
/* ------------------------------------------------------------------------------------
 *  remplit le vecteur [b] de resolution du systeme lineaire en fonction
 *  des variables physiques du modele de batiment
 *  2 valeurs de vecteur : [b] en regime libre ou force :
 *  depend de la valeur de alpha regime force (alpha = 0) ou libre (alpha = 1)
 * ------------------------------------------------------------------------------------ */ 
{
  int i = 0; /* indice de ligne du vecteur */
  int niv = 0; /* compteur de niveau */
  int fac = 0; /* compteur de facette */
  int id = 0; /* indice de reperage du nID de facette */
  double somme = 0, somme2 = 0; /* variables intermediaire permettant de sommer des variables pour un type de facettes */
  double Kc = 0; /* variable intermediaire mise pour choisir entre la resistance conv au noeud 5 ou 12 */
  
	
  /* boucle sur le nb de niveaux, remplissage des lignes correspondant au noeuds de calcul */
  /* les noeuds  "sol" et "toiture" sont traites a l'ext de la boucle */
  for (niv = 0; niv < nb_niv; niv++) {
    
    /* LIGNES 1,p (facettes de mur) */
    /*-------------------------------------------- */
    for (fac = 0; fac < nb_facette; fac++)
      for (id = 0; id < nb_paroi; id++)
	if (((int) niveau[fac] == niv)
	    && ((int) id_paroi[fac] == id)) {
	  
	  if ((int) classe_paroi[fac] == 0){
	    V[i] = surface[fac] * (hc_ext[fac] * Text[fac]
				   + (RCmur[id].Ce / dt) * TSext[fac]
				   + flux_sol_abs[fac] 
				   - GLO_Total_Net[fac]
				   - Flux_Latent[fac] - Flux_Latent_se[fac] /* modif laurent malys 05/2011: terme puit supplementaire facade et toitures vegetales */
				   );
	    somme += surface[fac] * (RCmur[id].Ci / dt);
	    i++;
	  }
	  
	  if ((int) classe_paroi[fac] == 11){
	    V[i] = surface[fac] * ((TSext[fac] * Cf[fac] / dt) 
				   +  (1 - transmission[fac] - albedo[fac]) * flux_sol_abs[fac] / (1-albedo[fac]) - GLO_Total_Net[fac] - Flux_Latent[fac]);
	    V[i+1] = surface[fac] * ((Ta_old[fac] * Ca[fac] / dt) + h_ainf[fac] * Text[fac]);
	    V[i+2] = surface[fac] * (RCmur[id].Ce * Tse_veg_old[fac] / dt 
				     + transmission[fac] * flux_sol_abs[fac] / (1-albedo[fac]) - Flux_Latent_se[fac]);
	    somme += surface[fac] * (RCmur[id].Ci / dt);
	    i+=3;
	  }
	}
    /* LIGNE 2 (noeud surf interne murs) */
    /*-------------------------------------------- */
    V[i] = somme * T2[niv] + Ft_mur[niv] + (1 - alpha[niv])
      * Sniv[niv].SURFACE_CL[0] * (1 / Rcv_i[0]) * T10consigne;
    i++;
    
    somme = 0;
    
    /* LIGNE 3,p (facettes de vitrage) */
    /*-------------------------------------------- */
    for (fac = 0; fac < nb_facette; fac++)
      for (id = 0; id < nb_paroi; id++)
	if (((int) niveau[fac] == niv)
	    && ((int) classe_paroi[fac] == 1)
	    && ((int) id_paroi[fac] == id)) {
	  V[i] = surface[fac] * (hc_ext[fac] * Text[fac]
				 + (RCvit[id].Ce / dt) * TSext[fac]
				 + flux_sol_abs[fac] - GLO_Total_Net[fac]);
	  somme += surface[fac] * (RCvit[id].Ci / dt);
	  i++;
	}
    
    /* LIGNE 4 (noeud surf interne des vitrages) */
    /*-------------------------------------------- */
    V[i] = somme * T4[niv] + Ft_vit[niv] + (1 - alpha[niv])
      * Sniv[niv].SURFACE_CL[1] * (1 / Rcv_i[1]) * T10consigne;
    i++;
    somme = 0;
    
    /* LIGNE 5 (noeud plafond (ou sous dalle plc pour RDC)) */
    /*-------------------------------------------- */
    if (niv == 0)
      V[i] = Sniv[niv].SURFACE_CL[3] * (RCplc_bas->Ce / dt) * T5[niv]; /* cas du RDC */
    else
      V[i] = Sniv[niv].SURFACE_CL[3] * (RCplc_int->Ce / dt) * T5[niv]
	+ Ft_plf[niv - 1] + (1 - alpha[niv])
	* Sniv[niv].SURFACE_CL[3] * (1 / Rcv_i[4]) * T10consigne; /* cas d'un autre niveau */
    /* ATTENTION : (Cplf->Ci)  et  (Ft_plf) pour le niveau N-1 */
    /* ATTENTION : T10consigne pour le niveau N-1, si les consignes de chauff/clim sont differentes a chaque etage, ici T10consigne idem a chaque etage */
    i++;
    
    /* LIGNE 6 (noeud plancher) */
    /*-------------------------------------------- */
    if (niv == 0)
      V[i] = Sniv[niv].SURFACE_CL[3] * (RCplc_bas->Ci / dt) * T6[niv]
	+ Ft_plc[niv] + (1 - alpha[niv]) * Sniv[niv].SURFACE_CL[3]
	* (1 / Rcv_i[3]) * T10consigne;
    else
      V[i] = Sniv[niv].SURFACE_CL[3] * (RCplc_int->Ci / dt) * T6[niv]
	+ Ft_plc[niv] + (1 - alpha[niv]) * Sniv[niv].SURFACE_CL[3]
	* (1 / Rcv_i[3]) * T10consigne;
    i++;
    
    /* LIGNE 7 (noeud int parois int) */
    /*-------------------------------------------- */
    V[i] = Sniv[niv].SURFACE_CL[5] * (RCint->Ci / dt) * T7[niv];
    i++;
    
    /* LIGNE 8 (noeud ext parois int) */
    /*-------------------------------------------- */
    V[i] = Ft_int[niv] + (1 - alpha[niv]) * Sniv[niv].SURFACE_CL[5] * (1
								       / Rcv_i[5]) * T10consigne;
    i++;
    
    /* LIGNE 9 (noeud Tmr) */
    /*-------------------------------------------- */

    /* toutes les puissances internes sur le noeud d'air */
    /*V[i] = 0 ; */

    /* puissances internes reparties sur les noeuds Tmr et Tair */
    V[i] = (0.5 * Ps_equip[niv]) + (0.5 * Ps_occup[niv]); 
    i++;
    
    /* LIGNE 10 : noeud Tair int ou Pconv */
    /*-------------------------------------------- */
    
    for (fac = 0; fac < nb_facette; fac++) {
      if (((int) niveau[fac] == niv) && ((int) in_air[fac] == 1)) {
	if (Rra[fac] > 0) {
	  somme = somme + (1 / Rra[fac]);
	  somme2 = somme2 + (Text[fac] / Rra[fac]);
	} else
	  /* pas de vetilation car pas d'occupants */
	  somme = 0;
	somme2 = 0;
	/*{ printf("\n\n  ERREUR : Probleme au niveau du debit d'air (facette[%d] ; niveau[%d])\n\n",fac,niv) ; exit(0) ; } */
      }
    }
    /*if (somme == 0 || somme2 == 0)	{ printf("\n\n  ERREUR : Pas d'entrees d'air au niveau %d - Verifier descripteur\n\n",niv) ; exit(0) ; } */
    
    if (niv == nb_niv - 1)
      Kc = Sniv[niv].SURFACE_CL[2] / Rcv_i[2];
    else
      Kc = Sniv[niv].SURFACE_CL[4] / Rcv_i[4];

    /* toutes les puissances internes sur le noeud d'air     */
    /*V[i] = somme2 +  Ps_equip[niv] + Ps_occup[niv] + ((Cai[niv] / dt) * T10air_init[niv]) - (1 - alpha[niv])*T10consigne*((Sniv[niv].SURFACE_CL[0] / Rcv_i[0] ) + (Sniv[niv].SURFACE_CL[1] / Rcv_i[1] ) + (Sniv[niv].SURFACE_CL[3] / Rcv_i[3] ) + Kc + (Sniv[niv].SURFACE_CL[5] / Rcv_i[5] ) + (Cai[niv] / dt) + somme ) ;  */

    /* puissances internes reparties sur les noeuds Tmr et Tair */
    V[i] = somme2 + (0.5 * Ps_equip[niv]) + (0.5 * Ps_occup[niv])
      + ((Cai[niv] / dt) * T10air_init[niv]) - (1 - alpha[niv])
      * T10consigne * ((Sniv[niv].SURFACE_CL[0] / Rcv_i[0])
		       + (Sniv[niv].SURFACE_CL[1] / Rcv_i[1])
		       + (Sniv[niv].SURFACE_CL[3] / Rcv_i[3]) + Kc
		       + (Sniv[niv].SURFACE_CL[5] / Rcv_i[5]) + (Cai[niv] / dt)
		       + somme); 
    i++;
    somme = 0;
    somme2 = 0;
    Kc = 0;
    
  } /* fin de boucle sur les niveaux */
  
  
  /* LIGNES 11,p (facettes de toiture) */
  /*-------------------------------------------- */
  for (fac = 0; fac < nb_facette; fac++){
    for (id = 0; id < nb_paroi; id++) {
      if ((int) id_paroi[fac] == id) {
	if ((int) classe_paroi[fac] == 2){ 
	  V[i] = surface[fac] * (hc_ext[fac] * Text[fac] + (RCtoit[id].Ce
							    / dt) * TSext[fac] + flux_sol_abs[fac]
				 - GLO_Total_Net[fac]);
	  somme += surface[fac] * (RCtoit[id].Ci / dt);
	  i++;
	}
	if ((int) classe_paroi[fac] == 12){
	  V[i] = surface[fac] * ((TSext[fac] * Cf[fac] / dt) 
				 +  (1 - transmission[fac] - albedo[fac]) * flux_sol_abs[fac] / (1-albedo[fac]) - GLO_Total_Net[fac] - Flux_Latent[fac]);
	  V[i+1] = surface[fac] * ((Ta_old[fac] * Ca[fac] / dt) + h_ainf[fac] * Text[fac]);
	  V[i+2] = surface[fac] * (RCtoit[id].Ce * Tse_veg_old[fac] / dt 
				   + transmission[fac] * flux_sol_abs[fac]/ (1-albedo[fac]) - Flux_Latent_se[fac]);
	  somme += surface[fac] * (RCtoit[id].Ci / dt);
	  i+=3;
	}
      }  
    }
  }   
  /* LIGNE 12 (noeud surf interne toiture) */
  /*-------------------------------------------- */
  /*V[i] = somme*T12[nb_niv-1] + Ft_plf[nb_niv-1] + (1 - alpha[niv])*Sniv[nb_niv-1].SURFACE_CL[2]*( 1 / Rcv_i[2] )*T10consigne ; */
  V[i] = somme * T12[nb_niv - 1] + Ft_plf[nb_niv - 1] + (1 - alpha[nb_niv - 1]) * Sniv[nb_niv - 1].SURFACE_CL[2] * (1/ Rcv_i[2]) * T10consigne;
  i++;
  somme = 0;
  
  /* LIGNE 5' (noeud Sol) */
  /*-------------------------------------------- */
  V[i] = Sniv[0].SURFACE_CL[3] * ((Tsol / Rsol) + (Csol * Tsol_bis[0] / dt));
}


void remplissage_matrice_modele_facetteVEG(double *M, int id, 
					   listeRCparoi *RCfacetteBAT, double hc_int, 
					   double hc_ext, double dt, 
					   double Cf, double Ca, double h_pa, double h_ainf)
/*------------------------------------------------------------------------------------
 * remplit la matrice [A] de resolution du systeme lineaire en fonction
 * des variables physiques du modele de facette d'enveloppe VEGETALE
 * des batiments urbains
 *
 * La surface de feuille est consideree comme la surface exterieure (Tse), 
 * deux nouveaux noeuds (Ta et Tse_veg) sont crees
 * En attendant, Ca, Cf, h_pa et h_ainf sont des constantes
 *------------------------------------------------------------------------------------ */ 
{
  double h_r = 6;

  M[0] = Cf/dt + h_pa + h_r;
  M[1] = -h_pa;
  M[2] = -h_r;
  M[3] = 0;

  M[4] = -h_pa;
  M[5] = Ca/dt + hc_ext + h_pa + h_ainf;
  M[6] = -hc_ext;
  M[7] = 0;

  M[8] = -h_r ;
  M[9] = -hc_ext;
  M[10] = RCfacetteBAT[id].Ce / dt + 1/RCfacetteBAT[id].R + h_r + hc_ext;
  M[11] = -1/RCfacetteBAT[id].R ; 

  M[12] = 0;
  M[13] = 0;
  M[14] = -1/RCfacetteBAT[id].R;
  M[15] = RCfacetteBAT[id].Ci / dt + 1/RCfacetteBAT[id].R + hc_int;
}

void remplissage_vecteur_modele_facetteVEG(double *V, int id,
					   listeRCparoi *RCfacetteBAT, double hc_int, double hc_ext, double dt,
					   double Fsol, double Fglo, double Text, double TSext_old,
					   double TSint_old, double Tint, 
					   double Ta_old, double Tse_veg_old,
					   double Flatent, double Flatent_se, /* pour 'Flux latent surface exterieure' */
					   double h_ainf, double Ca, double Cf, double transmission, double albedo)
/* ------------------------------------------------------------------------------------
 *  remplit le vecteur [b] de resolution du systeme lineaire en fonction
 *  des variables physiques du modele de facette d'enveloppe VEGETALE
 *  des batiments urbains
 * ------------------------------------------------------------------------------------ */ 
{
  V[0] = (TSext_old * Cf / dt) +  (1-transmission-albedo)*Fsol / (1-albedo) - Fglo - Flatent ;
  V[1] = (Ta_old * Ca / dt) + h_ainf *Text;
  V[2] = RCfacetteBAT[id].Ce*Tse_veg_old/dt + transmission * Fsol / (1-albedo) - Flatent_se;
  V[3] = (hc_int * Tint) + (TSint_old * RCfacetteBAT[id].Ci / dt);
  /*printf("%f\t%f\t%f\n",RCfacetteBAT[id].Ce, RCfacetteBAT[id].Ci, RCfacetteBAT[id].R);  */
}

void remplissage_vecteur_modele_facetteVEG_eau(double *V, double Tse_veg_old, double Teau, double Qeau)
/* ------------------------------------------------------------------------------------
 *  ajoute le terme puit correspondant a l energie sensible de l eau d arrosage
 *  dans le vecteur [b] de resolution du systeme lineaire
 * ------------------------------------------------------------------------------------ */ 
{
  V[2] = V[2] -  (Tse_veg_old-Teau) * Qeau * 4.184 / 3600;
}

void remplissage_matrice_modele_facetteVEG_2R3C(double *M, int id, 
					   listeRCparoi *RCfacetteBAT, double hc_int, 
					   double hc_ext, double dt, 
					   double Cf, double Ca, double h_pa, double h_ainf)
/* ------------------------------------------------------------------------------------
 *  remplit la matrice [A] de resolution du systeme lineaire en fonction
 *  des variables physiques du modele de facette d'enveloppe VEGETALE
 *  des batiments urbains
 *  
 *  La surface de feuille est consideree comme la surface exterieure (Tse), 
 *  deux nouveaux noeuds (Ta et Tse_veg) sont crees
 *  
 *  version 2R3C pour acces a la temperature dans le substrat (validation hepia)
 * ------------------------------------------------------------------------------------ */ 
{
  double h_r = 6;
  double C;
  double R;

  C = RCfacetteBAT[id].Ce + RCfacetteBAT[id].Ci;
  R = RCfacetteBAT[id].R/2;


  M[0] = Cf/dt + h_pa + h_r;
  M[1] = -h_pa;
  M[2] = -h_r;
  M[3] = 0;
  M[4] = 0;

  M[5] = -h_pa;
  M[6] = Ca/dt + hc_ext + h_pa + h_ainf;
  M[7] = -hc_ext;
  M[8] = 0;
  M[9] = 0;


  M[10] = -h_r ;
  M[11] = -hc_ext;
  M[12] = (C/10) / dt + 1/R + h_r + hc_ext;
  M[13] = -1/R ; 
  M[14] = 0;

  M[15] = 0;
  M[16] = 0;
  M[17] = -1/R;
  M[18] = (8*C/10) / dt + 2/R;
  M[19] = -1/R;

  M[20] = 0;
  M[21] = 0;
  M[22] = 0;
  M[23] = -1/R;
  M[24] = (C/10)/dt + 1/R + hc_int;

}

void remplissage_vecteur_modele_facetteVEG_2R3C(double *V, int id,
					   listeRCparoi *RCfacetteBAT, double hc_int, double hc_ext, double dt,
					   double Fsol, double Fglo, double Text, double TSext_old,
					   double TSint_old, double Tint, 
					   double Ta_old, double Tse_veg_old,
					   double Flatent, double Flatent_se, /* pour 'Flux latent surface exterieure' */
					   double h_ainf, double Ca, double Cf, double transmission, double albedo,
					   double Teau, double Qeau, double T3_old)
/* ------------------------------------------------------------------------------------
 *  remplit le vecteur [b] de resolution du systeme lineaire en fonction
 *  des variables physiques du modele de facette d'enveloppe VEGETALE
 *  des batiments urbains
 * 
 *  version 2R3C pour acces a la temperature dans le substrat (validation hepia)
 * ------------------------------------------------------------------------------------ */ 
{
  double C;
  double R;

  C = RCfacetteBAT[id].Ce + RCfacetteBAT[id].Ci;
  R = RCfacetteBAT[id].R/2;

  V[0] = (TSext_old * Cf / dt) +  (1-transmission-albedo)*Fsol - Fglo - Flatent ;
  V[1] = (Ta_old * Ca / dt) + h_ainf *Text;
  V[2] = (C/10)*Tse_veg_old/dt + transmission * Fsol - Flatent_se - (Tse_veg_old-Teau) * Qeau * 4.184 / 3600;
  V[3] = (T3_old * (8*C/10) / dt) ;
  V[4] = (hc_int * Tint) + (TSint_old * (C/10) / dt) - Fglo;  
  printf("%f\t%f\n", Flatent, Flatent_se);
  /*printf("%f\t%f\t%f\n",RCfacetteBAT[id].Ce, RCfacetteBAT[id].Ci, RCfacetteBAT[id].R);  */
}

void remplissage_matrice_modele_facetteBAT(double *M, int id,
					   listeRCparoi *RCfacetteBAT, double hc_int, double hc_ext, double dt)
/* ------------------------------------------------------------------------------------
 *  remplit la matrice [A] de resolution du systeme lineaire en fonction
 *  des variables physiques du modele de facette d'enveloppe
 *  des batiments urbains
 * ------------------------------------------------------------------------------------ */ 
{
  M[0] = hc_ext + (1 / RCfacetteBAT[id].R) + (RCfacetteBAT[id].Ce / dt);
  M[1] = -(1 / RCfacetteBAT[id].R);
  M[2] = -(1 / RCfacetteBAT[id].R);
  M[3] = hc_int + (1 / RCfacetteBAT[id].R) + (RCfacetteBAT[id].Ci / dt);
}

void remplissage_vecteur_modele_facetteBAT(double *V, int id,
					   listeRCparoi *RCfacetteBAT, double hc_int, double hc_ext, double dt,
					   double Fsol, double Fglo, double Text, double TSext_old,
					   double TSint_old, double Tint)
/* ------------------------------------------------------------------------------------
 *  remplit le vecteur [b] de resolution du systeme lineaire en fonction
 *  des variables physiques du modele de facette d'enveloppe
 *  des batiments urbains
 * ------------------------------------------------------------------------------------ */ 
{
  V[0] = Fsol - Fglo + (hc_ext * Text) + (TSext_old * RCfacetteBAT[id].Ce
					  / dt);
  V[1] = (hc_int * Tint) + (TSint_old * RCfacetteBAT[id].Ci / dt);
}


void remplissage_matrice_modele_sol(double *M, int id, double hc_ext,
				    listeRCparoi *RCsurf_sol, double Rsol, double Csol, double dt)
/* ------------------------------------------------------------------------------------
 *  remplit la matrice [A] de resolution du systeme lineaire en fonction
 *  des variables physiques du modele de facette de sol
 *  modele classique
 * ------------------------------------------------------------------------------------ */ 
{
  M[0] = hc_ext + (1 / (RCsurf_sol[id].R)) + ((RCsurf_sol[id].Ce) / dt);
  M[1] = -(1 / (RCsurf_sol[id].R));
  M[2] = 0;

  M[3] = -(1 / (RCsurf_sol[id].R));
  M[4] = (1 / (RCsurf_sol[id].R)) + (1 / Rsol) + ((RCsurf_sol[id].Ci) / dt);
  M[5] = -(1 / Rsol);

  M[6] = 0;
  M[7] = -(1 / Rsol);
  M[8] = (2 / Rsol) + (Csol / dt);
}

void remplissage_vecteur_modele_sol(double *V, int id, double TSext_old,
				    double T2_old, double T3_old, double Text, double Tref, double FluxSol,
				    double FluxGLONet, double Flatent, double hc_ext,
				    listeRCparoi *RCsurf_sol, double Rsol, double Csol, double dt)
/* ------------------------------------------------------------------------------------
 *  remplit le vecteur [b] de resolution du systeme lineaire en fonction
 *  des variables physiques du modele de facette d'enveloppe
 *  des batiments urbains
 * ------------------------------------------------------------------------------------ */ 
{
  V[0] = Text * hc_ext + TSext_old * ((RCsurf_sol[id].Ce) / dt) + FluxSol
    - FluxGLONet - Flatent;
  V[1] = T2_old * ((RCsurf_sol[id].Ci) / dt);
  V[2] = Tref * (1 / Rsol) + T3_old * (Csol / dt);
}


void remplissage_matrice_modele_sol_VEG(double *M, int id, double hc_ext,
					listeRCparoi *RCsurf_sol, double Rsol, double Csol, double dt,
					double Cf, double Ca, double h_pa, double h_ainf)
/* ------------------------------------------------------------------------------------
 *  remplit la matrice [A] de resolution du systeme lineaire en fonction
 *  des variables physiques du modele de facette de sol
 *  modele classique
 * ------------------------------------------------------------------------------------ */ 
{
  double h_r = 6;

  M[0] = Cf/dt + h_pa + h_r;
  M[1] = -h_pa;
  M[2] = -h_r;
  M[3] = 0;
  M[4] = 0;

  M[5] = -h_pa;
  M[6] = Ca/dt + hc_ext + h_pa + h_ainf;
  M[7] = -hc_ext;
  M[8] = 0;
  M[9] = 0;

  M[10] = -h_r ;
  M[11] = -hc_ext;
  M[12] = RCsurf_sol[id].Ce / dt + 1/RCsurf_sol[id].R + h_r + hc_ext;
  M[13] = -1/RCsurf_sol[id].R ;
  M[14] = 0;

  M[15] = 0;
  M[16] = 0;
  M[17] = -(1 / (RCsurf_sol[id].R));
  M[18] = (1 / (RCsurf_sol[id].R)) + (1 / Rsol) + ((RCsurf_sol[id].Ci) / dt);
  M[19] = -(1 / Rsol);

  M[20] = 0;
  M[21] = 0;
  M[22] = 0;
  M[23] = -(1 / Rsol);
  M[24] = (2 / Rsol) + (Csol / dt);
}

void remplissage_vecteur_modele_sol_VEG(double *V, int id, double TSext_old,
				    double T2_old, double T3_old, double Text, double Tref, double FluxSol,
					double FluxGLONet, 
					double Flatent, double Flatent_se, 
					double hc_ext,
					listeRCparoi *RCsurf_sol, double Rsol, double Csol, double dt,
					double Ta_old, double Tse_veg_old,
					double h_ainf, double Ca, double Cf, double transmission, double albedo)
/* ------------------------------------------------------------------------------------
 *  remplit le vecteur [b] de resolution du systeme lineaire en fonction
 *  des variables physiques du modele de facette d'enveloppe
 *  des batiments urbains
 * ------------------------------------------------------------------------------------ */ 
{
  
  V[0] = (TSext_old * Cf / dt) +  (1-transmission-albedo) * FluxSol / (1-albedo) - FluxGLONet - Flatent ;
  V[1] = (Ta_old * Ca / dt) + h_ainf *Text;
  V[2] = Tse_veg_old * ((RCsurf_sol[id].Ce) / dt) + transmission * FluxSol / (1-albedo) -  Flatent_se;
  V[3] = T2_old * ((RCsurf_sol[id].Ci) / dt);
  V[4] = Tref * (1 / Rsol) + T3_old * (Csol / dt);
}

#ifdef LINUX
void resolutionSystemeLineaire_LINUX(double *A, double *b, double *x, int n)
/*  COMPILATION : ACTIVER POUR LINUX - DESACTIVER POUR WINDOWS
 * ------------------------------------------------------------------------------------
 *  Utilisation des routines de la librairie LAPACK
 *  "clapack_dgesv" resoue un systeme lineaire [ mat(A) . vect(x) = vect(b) ] a (n) equations
 *  "dgesv" est basee sur BLAS de niveau 2 (operations matrices*vecteurs)
 * 		-> "man dgesv" pour plus de details
 *   vect(x) = vect(b) a la fin de l'operation
 *  cconservation des valeurs originales de mat(A) et vect(b)
 * ------------------------------------------------------------------------------------ */ 
{
  int nn = n * n;
  double *A_calcul = allocation_tableau_double(nn);
  double *b_calcul = allocation_tableau_double(n);
  int *pivots = allocation_tableau_int(n);
  
  memcpy(A_calcul, A, nn * sizeof(double));
  memcpy(b_calcul, b, n * sizeof(double));
  
  clapack_dgesv(CblasRowMajor, n, 1, A_calcul, n, pivots, b_calcul, n);
  
  memcpy(x, b_calcul, n * sizeof(double));
  
  free(A_calcul);
  free(b_calcul);
  free(pivots);
}
#endif

#ifdef WINDOWS
void resolutionSystemeLineaire_WINDOWS(double *A, double *B, double *X, int dim)
/*  COMPILATION : ACTIVER POUR WINDOWS - DESACTIVER POUR LINUX
 * ------------------------------------------------------------------------------------
 *  Utilisation des routines de la librairie CLAPACK
 *  "dgesv_" resoue un systeme lineaire [ mat(A) . vect(X) = vect(B) ] a (n) equations
 *  "dgesv" est basee sur BLAS de niveau 2 (operations matrices*vecteurs)
 * ------------------------------------------------------------------------------------ */ 
{
  int n ;			/* nb d'equations lineaires */
  int nrhs ;		/* nb de colonnes des matrices (vecteurs) B et X */
  int lda ;		/* dimension pricipale de la matrice A */
  int ldb ;		/* dimension pricipale de la matrice B */
  int *ipiv ;		/* vecteur des indices de pivots definissant la matrice de permutation */
  int info ;		/* variable d'info sur les calcul intermediaires, info doit etre =0 */
  
  int i, j, N, N_t, nn ;
  double *A_calcul, *B_calcul ;
  
  /* initialisation des variables */
  
  n = lda = ldb = dim ;
  nrhs = 1 ;
  nn = dim*dim ;
  A_calcul = allocation_tableau(nn) ;
  B_calcul = allocation_tableau(n) ;
  ipiv = allocation_tableau_int(n) ;
  
  /* remplissage du vecteur de calcul */
  memcpy(B_calcul, B, n * sizeof(double)) ;
  
  /* transposition de la matrice de calcul au format FORTRAN : A(l,c) -> A(c,l) */
  
  for (i = 0; i < dim; i++)
    for (j = 0; j < dim; j++)
      {
	N = i*dim + j ;
	N_t = j*dim + i ;
	A_calcul[N_t] = A[N] ;
      }
  
  /* resolution syteme */
  
  dgesv_(&n, &nrhs, A_calcul, &lda, ipiv, B_calcul, &ldb, &info) ;
  
  /* remplissage du vecteur de destination */
  
  memcpy(X, B_calcul, n * sizeof(double)) ;
  
  /* desallocation memoire */
  
  free(A_calcul) ;
  free(B_calcul) ;
  free(ipiv) ;
}
#endif

void vecteurT_vers_variablesT(double *V, int dim, int nb_facette, int nb_niv,
			      double *niveau, double nb_paroi, double *id_paroi,
			      double *classe_paroi, double *TSext, double *T2, double *T4,
			      double *T5, double *T6, double *T7, double *T8, double *T9,
			      double *inconnue_noeud_air_int, double *T12, double *Tsol_bis,
			      double *Tse_veg, double *Ta)
/* ------------------------------------------------------------------------------------
 *  permet de re-remplir les tableaux de temperatures de surfaces ext
 *  et les tableaux de temperatures de niveaux en fonction du vecteur
 *  resultat du calcul matriciel
 * ------------------------------------------------------------------------------------ */ 
{
  int i = 0; /* indice de ligne du vecteur */
  int niv = 0; /* compteur de niveau */
  int fac = 0; /* compteur de facette */
  int id = 0; /* indice de reperage du n ID de facette */
  
  
  for (niv = 0; niv < nb_niv; niv++) {
    
    /* LIGNES 1,p (facettes de mur) */
    /*-------------------------------------------- */
    for (fac = 0; fac < nb_facette; fac++)
      for (id = 0; id < nb_paroi; id++)
	if (((int) niveau[fac] == niv)
	    && ((int) id_paroi[fac] == id)) {
	  
	  if ((int) classe_paroi[fac] == 0){
	    TSext[fac] = V[i];
	    i++;
	  }
	  if ((int) classe_paroi[fac] == 11){
	    TSext[fac] = V[i];
	    Ta[fac] = V[i+1];
	    Tse_veg[fac] = V[i+2];
	    i+=3;
	  }
	}
    
    /* LIGNE 2 (noeud surf interne murs) */
    /*-------------------------------------------- */
    T2[niv] = V[i];
    i++;
    
    /* LIGNE 3,p (facettes de vitrage) */
    /*-------------------------------------------- */
    for (fac = 0; fac < nb_facette; fac++)
      for (id = 0; id < nb_paroi; id++)
	if (((int) niveau[fac] == niv)
	    && ((int) classe_paroi[fac] == 1)
	    && ((int) id_paroi[fac] == id)) {
	  TSext[fac] = V[i];
	  i++;
	}
    
    /* LIGNE 4 (noeud surf interne des vitrages) */
    /*-------------------------------------------- */
    T4[niv] = V[i];
    i++;
    
    /* LIGNE 5 (noeud plafond (ou sous dalle plc pour RDC)) */
    /*-------------------------------------------- */
    T5[niv] = V[i];
    i++;
    
    /* LIGNE 6 (noeud plancher) */
    /*-------------------------------------------- */
    T6[niv] = V[i];
    i++;
    
    /* LIGNE 7 (noeud int parois int) */
    /*-------------------------------------------- */
    T7[niv] = V[i];
    i++;
    
    /* LIGNE 8 (noeud ext parois int) */
    /*-------------------------------------------- */
    T8[niv] = V[i];
    i++;
    
    /* LIGNE 9 (noeud Tmr) */
    /*-------------------------------------------- */
    T9[niv] = V[i];
    i++;
    
    /* LIGNE 10 : noeud Tair int ou Pconv */
    /*-------------------------------------------- */
    inconnue_noeud_air_int[niv] = V[i];
    i++;
    
  } /* fin de boucle sur les niveaux */
  

  /* LIGNES 11,p (facettes de toiture) */
  /*-------------------------------------------- */
  for (fac = 0; fac < nb_facette; fac++){
    for (id = 0; id < nb_paroi; id++){
      if ((int) id_paroi[fac] == id) {
	if ((int) classe_paroi[fac] == 2){
	  TSext[fac] = V[i];
	  i++;
	  
	}
	if  ((int) classe_paroi[fac] == 12){
	  TSext[fac] = V[i];
	  Ta[fac] = V[i+1];
	  Tse_veg[fac] = V[i+2];
	  i+=3;
	}
      }
    }
  }
  /* LIGNE 12 (noeud surf interne toiture) */
  /*-------------------------------------------- */
  T12[nb_niv - 1] = V[i];
  i++;
  
  /* LIGNE 5' (noeud Sol) */
  /*-------------------------------------------- */
  Tsol_bis[0] = V[i];
  
}

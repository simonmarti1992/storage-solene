/*
 *  Copyright 2010-2013 Laurent Malys (CERMA, UMR 1563 AAU, CNRS /
 *                                  Ecole d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

#include "../includes/sim_ts.h"

double *allocation_tableau_double(int dim)
/* ------------------------------------------------------------------------------------
 * reserve une zone memoire de dim*(double) et initialize ses valeurs a 0
 * ------------------------------------------------------------------------------------ */
{
  double *tab = (double *) calloc(dim, sizeof(double));
  return tab;
}

int *allocation_tableau_int(int dim)
/* ------------------------------------------------------------------------------------
 * reserve une zone memoire de dim*(int) et initialize ses valeurs a 0
 * ------------------------------------------------------------------------------------ */
{
  int *tab = (int *) calloc(dim, sizeof(int));
  return tab;
}

float *allocation_tableau_float(int dim)
/* ------------------------------------------------------------------------------------
 * reserve une zone memoire de dim*(int) et initialize ses valeurs a 0
 * ------------------------------------------------------------------------------------ */
{
  float *tab = (float *) calloc(dim, sizeof(float));
  return tab;
}

paroi *allocation_struct_paroi(int n_paroi)
/* ------------------------------------------------------------------------------------
 * reserve une zone memoire de dim (struct)*paroi et initialize par defaut
 * definit la dimension des tableaux de prop. physiques en f de  n_couche
 * reserve une zone memoire de n_couche*(double) et initialize ses valeurs a 0
 * ------------------------------------------------------------------------------------ */
{
  paroi *P = (paroi *) calloc(n_paroi, sizeof(paroi));
  return P;
}

/*
 *  Copyright 2010-2013 Laurent Malys (CERMA, UMR 1563 AAU, CNRS /
 *                                  Ecole d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

#include "../includes/sim_ts.h"

int radiog(int im, int *nb_cont_face, int *numero_face, int nbfac,
	   int nb_contour_total, double *exitance_init, double *surf,
	   double *reflex, FILE *pf_fform, float *fform, int flag_arret,
	   double pourc, double *exitance)
/* ------------------------------------------------------------------------------------
 *  RADIOSITE GENERALISEE
 *  extraite de 'transitoire_h_options2.c', modifiee par J.Bouyer, janvier 2007
 *  Tableau d'entree: `exitance_init', tableau de sortie: 'exitance'
 *  Dans la bande solaire: mettre en entree la 1ere reflexion du flux solaire incident
 *  Dans l'IR: mettre en entree l'emission propre de chaque surface
 *  On recupere en sortie l'exitance (ou la radiosite) de chaque surface
 *  pour la bande du spectre consideree
 * ------------------------------------------------------------------------------------ */ 
{
  int face;
  int num_cont, contour;
  int iteration;
  int icont_liste_max = 0;
  int iface_max = 0;
  int icont_max = 0;
  double energie_totale;
  double a_distribuer;
  double a_distribuer_preced;
  double a_distribuer_max;
  double *delta_exitance;
  double fform_recip;
  double d_exitance;
  static int nb_iter_max_abs = 50000;
  int erreur = 0;
  
  /* Allocation memoire dynamique */
  delta_exitance = allocation_tableau_double(nb_contour_total);
  if (delta_exitance == NULL) {
    printf("*** Probleme allocation radiosite residuelle.\n");
    erreur = 1;
    return erreur;
  }
  
  /* INITIALISATIONS */
  
  /*for(contour=0;contour<nb_contour_total;contour++) */
  /*exitance[contour] = delta_exitance[contour] = exitance_init[contour]; */
  
  memcpy(exitance, exitance_init, nb_contour_total * sizeof(double));
  memcpy(delta_exitance, exitance_init, nb_contour_total * sizeof(double));
  
  energie_totale = 0.0;
  for (contour = 0; contour < nb_contour_total; contour++)
    energie_totale += delta_exitance[contour] * surf[contour];
  
  printf("\nEnergie totale a distribuer (W) : %f\n", energie_totale);
  
  a_distribuer_preced = energie_totale;
  a_distribuer = energie_totale;
  
  /* ITERATIONS */
  
  iteration = 1;
  while (iteration < nb_iter_max_abs) {
    /*printf("...iteration %d...\r",iteration);  */
    
    /* Recherche de l'element de flux maximal */
    a_distribuer_max = 0.0;
    num_cont = 0;
    for (face = 0; face < nbfac; face++) {
      for (contour = 0; contour < nb_cont_face[face]; contour++) {
	if (delta_exitance[num_cont] * surf[num_cont]
	    > a_distribuer_max) {
	  a_distribuer_max = delta_exitance[num_cont]
	    * surf[num_cont];
	  iface_max = face;
	  icont_max = contour + 1;
	  icont_liste_max = num_cont;
	}
	num_cont++;
      }
    }
    
    if (im)
      printf(
	     "\nFlux maxi (W) en provenance de la face %d, contour %d (no %d) : %5.2f\n",
	     numero_face[iface_max], icont_max, icont_liste_max + 1,
	     a_distribuer_max);
    
    /* lecture des ff[ii] */
    lecture_ff(pf_fform, fform, icont_liste_max, nb_contour_total);
    
    /* contribution de l'element de flux maximal, a tous les autres */
    for (num_cont = 0; num_cont < nb_contour_total; num_cont++) {
      
      fform_recip = fform[num_cont] * surf[icont_liste_max]
	/ surf[num_cont];
      /*if(fform_recip>1.) fform_recip=1.; reprend modif realisee dans radiosite */
      if (fform_recip > 1.) { /* recipro=1.; VOIR note algo eclairement, et note Fernand 24 avril 2002 */
	printf("recipro = %f\n", fform_recip);
      }
      
      d_exitance = reflex[num_cont] * delta_exitance[icont_liste_max]
	* fform_recip;
      delta_exitance[num_cont] += d_exitance;
      exitance[num_cont] += d_exitance;
    }
    delta_exitance[icont_liste_max] = 0.0;
    
    a_distribuer = 0.0;
    for (num_cont = 0; num_cont < nb_contour_total; num_cont++)
      a_distribuer += delta_exitance[num_cont] * surf[num_cont];
    
    if (im)
      printf("Energie non distribuee (W) : %f\n", a_distribuer);
    
    /* Sortie de boucle */
    /* Pas genial mais dependant des conventions adoptees dans versions precedentes */
    /* flag_arret = 2 impose en entree */
    if ((flag_arret == 2)
	&& (a_distribuer < (pourc * energie_totale / 100)))
      break;
    
    a_distribuer_preced = a_distribuer;
    iteration++;
  }
  /* fin de la boucle while */
  /* Les resultats a exploiter dans le corps du prog sont dans 'exitance' */
  
  free(delta_exitance);
  printf("Energie non distribuee (W) : %f\n", a_distribuer);
  return erreur;
}

void calc_flux_atm_intereflexion(double flux_atmosphere, double *emissivite,
				 double *surf, int nb_facette, int *nb_cont_face, int *numero_face,
				 int nbfac, FILE *pf_fform, float *fform, double *fciel, double *resu)
/* ------------------------------------------------------------------------------------
 *  estime le flux IR atmospherique recu par une facette apres des
 *  intereflexion dans la scene
 * ------------------------------------------------------------------------------------ */ 
{
  double *reflectivite;
  int i;
  int calcul_radiosite;
  int im; /* commande impression 0 : non / 1 : oui */
  int test_erreur; /* resultat de la commande 'radiog' */
  double *exitance_init; /* Exitances (ou radiosites) initiales */
  double *exitance; /* Exitances (ou radiosites) calculees */
  int flag_arret = 2; /* Arret quand moins de x% de l'energie initiale */
  double pourc = 2; /* Si flag_arret = 2, on s'arrete quand il reste moins de 0.1% de l'energie totale a distribuer */
  
  reflectivite = allocation_tableau_double(nb_facette);
  exitance_init = allocation_tableau_double(nb_facette);
  exitance = allocation_tableau_double(nb_facette);
  
  /* Initialisation densite de flux partant */
  calcul_radiosite = 0;
  for (i = 0; i < nb_facette; i++) {
    reflectivite[i] = 1 - emissivite[i];
    exitance_init[i] = reflectivite[i] * fciel[i] * flux_atmosphere;
    if (exitance_init[i])
      calcul_radiosite = 1; /* si la valeur d'exitance_init nest pas nulle, on peut lancer l'algo de radiosite */
    exitance[i] = 0.0;
  }
  
  /* Lancement iterations */
  if (calcul_radiosite) {
    im = 0;
    test_erreur = radiog(im, nb_cont_face, numero_face, nbfac, nb_facette,
			 exitance_init, surf, reflectivite, pf_fform, fform, flag_arret,
			 pourc, exitance);
    /* A ce stade : exitance = radiosite = densite de flux partant de chaque facette, dans la bande visible + PIR */
    for (i = 0; i < nb_facette; i++) {
      if (reflectivite[i] > 0)
	resu[i] = ((1 / reflectivite[i]) - 1.0) * exitance[i];
      else /* pas de reflexion sur cette facette */
	{
	  printf(
		 "\n\n  ERREUR : Les emissivites ne peuvent pas etre egales a 1\n\t--> modifier le descripteur\n\n Calcul de radiosite interrompu");
	  exit(0);
	  /*printf("\nFatm recu: %f",resu[i]); */
	}
    }
  }
  
  else /* alors, les emissivites de toutes les parois sont a 1, pas de calcul de radiosite */
    {
      printf("\n\tATTENTION : Toutes les reflectivites IR sont nulles\n\n"); /* TEST */
      for (i = 0; i < nb_facette; i++) {
	resu[i] = emissivite[i] * fciel[i] * flux_atmosphere;
	/* printf("\nFatm recu : %f",resu[i]); */
      }
    }
  
  free(reflectivite);
  free(exitance_init);
  free(exitance);
}

 double calc_GLO(int numero_contour_ref, int numero_contour_total, double fciel,
		double *Tse_pow4, FILE *pf_fform,
		float *fform,
		double *surface,
		double *emissivite, double *GLO_Ciel_Emis, double *GLO_Ciel_Recu,
		double *GLO_Ciel_Net, double *GLO_Scene_Emis, double *GLO_Scene_Recu,
		double *GLO_Scene_Net, double *GLO_Total_Emis, double *GLO_Total_Recu)
/* ------------------------------------------------------------------------------------
 *  caclul du rayonement IR thermique net echange en fonction de toutes les
 *  Ts des facettes et de l'environnment construit et du ciel
 *  mise a jour : le 12/02/2005 on change les emissivites en emissivite[numero_contour_ref]
 *  mise a jour : juillet 2005 on calcule l'ensemble des flux GLO echanges (emis, recu, total avec le ciel, la scene, total
 *  extraite de 'transitoire_h_option2.c', en l'etat
 *  modifiee par J.Bouyer, decembre 2006
 * ------------------------------------------------------------------------------------ */ 
{
  int b_calcul_GLO = 1;
  const double stefan = 5.67e-8; /* constante de stefan */
  int num_contour; /* pour boucler sur tous les contours */
  double GLO_Total_Net; /* variable retournee par la fonction */
  double somme_ff; /* somme des facteurs de forme avec la scene pour un contour */
 
  /* CALCUL DES FLUX GLO ECHANGES AVEC LE CIEL (GLO_Ciel_...) */
  
  /* ci-dessous : ancienne version, cas sans intereflexions IR */
  /*GLO_Ciel_Recu[numero_contour_ref] = fciel * emissivite[numero_contour_ref] * flux_atmosphere ; */
  /* maintenant le flux GLO_Ciel_Recu est calcule en externe */
  /* dans la procedure "calc_flux_atm_intereflexion" J.Bouyer et D.Groleau, 12/01/07 */
  
  /* modif laurent malys 12/2010  */
  /* GLO_Ciel_Emis[numero_contour_ref] = fciel * stefan */
  /* 		* emissivite[numero_contour_ref] * pow((Tse[numero_contour_ref] */
  /* 							+273.15 ,4) ; */
  GLO_Ciel_Emis[numero_contour_ref] = fciel * stefan
    * emissivite[numero_contour_ref] * Tse_pow4[numero_contour_ref];
   
  GLO_Ciel_Net[numero_contour_ref] = GLO_Ciel_Emis[numero_contour_ref]
    - GLO_Ciel_Recu[numero_contour_ref];
  
  /* CALCUL DES FLUX GLO ECHANGES AVEC LES AUTRES SURFACES URBAINES (GLO_Scene_...) */
  
  GLO_Scene_Net[numero_contour_ref] = 0.0; /* initialisation */

  if (b_calcul_GLO){
    lecture_ff(pf_fform, fform, numero_contour_ref, numero_contour_total); /* lecture des facteurs de forme avec le contour de reference */
    fform[numero_contour_ref] = 0.0; /* valeur du fform du contour sur lui-meme */
    somme_ff = 0.0; /* initialisation */
    for (num_contour = 0; num_contour < numero_contour_total; num_contour++) /* somme sur tous les contours */
      {
	/* ancienne version */
	/*GLO_Scene_Net[numero_contour_ref]  += stefan*fform[num_contour]*(emissivite[numero_contour_ref]*pow((Tse[numero_contour_ref]+273.15),4) - emissivite[num_contour]*pow((Tse[num_contour]+273.15),4));  */

	if (fform[num_contour] > 0){
	  GLO_Scene_Net[numero_contour_ref] += stefan * fform[num_contour]
	    * (emissivite[numero_contour_ref] * Tse_pow4[numero_contour_ref] - emissivite[num_contour] * Tse_pow4[num_contour] );
	} 
	
	/* correction le 12/01/07 pour traiter approximativement les interreflexion IR (J.Bouyer et D.Groleau) */
	/*  modif J.Bouyer 26/10/07 pour rigoureusement prendre en compte les surfaces de facettes (tres heterogenes en maillage adaptatif !!!) */
	/*GLO_Scene_Net[numero_contour_ref]  += stefan * (1/surface[num_contour]) * fform[num_contour] * (surface[numero_contour_ref]*emissivite[numero_contour_ref]*pow((Tse[numero_contour_ref]+273.15),4) - surface[num_contour]*pow((Tse[num_contour]+273.15),4));  */
	somme_ff += fform[num_contour]; 
      }
    /*GLO_Scene_Emis[numero_contour_ref] = stefan*emissivite[numero_contour_ref]* */
    /* ancienne version */
    /*((Tse[numero_contour_ref]+273.15),4); */
    GLO_Scene_Emis[numero_contour_ref] = somme_ff * stefan
      * emissivite[numero_contour_ref] * Tse_pow4[numero_contour_ref]; /* correction le 12/01/07 (J.Bouyer et D.Groleau) */
    GLO_Scene_Recu[numero_contour_ref] = GLO_Scene_Emis[numero_contour_ref]
      - GLO_Scene_Net[numero_contour_ref]; /* correction le 12/01/07 (J.Bouyer et D.Groleau) */
    
    /* CALCUL DES FLUX GLO ECHANGES AVEC TOUT L'ENVIRONNEMENT (GLO_Total_...) */
    
    GLO_Total_Emis[numero_contour_ref] = GLO_Ciel_Emis[numero_contour_ref]
      + GLO_Scene_Emis[numero_contour_ref];
    GLO_Total_Recu[numero_contour_ref] = GLO_Ciel_Recu[numero_contour_ref]
      + GLO_Scene_Recu[numero_contour_ref];
  }
  GLO_Total_Net = GLO_Ciel_Net[numero_contour_ref]
    + GLO_Scene_Net[numero_contour_ref];
  
  return GLO_Total_Net;
 }

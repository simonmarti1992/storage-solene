/*
 *  Copyright 2010-2013 Laurent Malys (CERMA, UMR 1563 AAU, CNRS /
 *                                  Ecole d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
 */

#include "../includes/sim_ts.h"

void calcul_surfaces(double *niveau, double *id_paroi, double *classe_paroi,
		     Sniveau *Sniv, double *surface, int nb_niv, int nb_paroi,
		     int nb_contour_total)
/* ------------------------------------------------------------------------------------
 *  permet de calculer les surfaces totales de murs ext, vitrage... par niveau
 * ------------------------------------------------------------------------------------ */ 
{
  int niv, id, cl, fac;
  double coef = 1;
  
  for (niv = 0; niv < nb_niv; niv++) {
    Sniv[niv].SURFACE_ID = allocation_tableau_double(nb_paroi);
    for (id = 0; id < nb_paroi; id++)
      for (fac = 0; fac < nb_contour_total; fac++)
	if (((int) niveau[fac] == niv) && (id_paroi[fac] == id))
	  Sniv[niv].SURFACE_ID[id] = Sniv[niv].SURFACE_ID[id]
	    + surface[fac]; /* surface indexee selon les descripteur 'id_paroi' */
  }
  
  for (niv = 0; niv < nb_niv; niv++) {
    Sniv[niv].SURFACE_CL = allocation_tableau_double(13);
    for (cl = 0; cl < 13; cl++){
      for (fac = 0; fac < nb_contour_total; fac++)
	if (((int) niveau[fac] == niv) && ((int) classe_paroi[fac]
					   == cl))
	  Sniv[niv].SURFACE_CL[cl] = Sniv[niv].SURFACE_CL[cl]
	    + surface[fac]; /* surface indexee selon les descripteur 'classe_paroi' */
    }
    Sniv[niv].SURFACE_CL[0] += Sniv[niv].SURFACE_CL[11]; /* modif laurent 09/2011 on ajoute la surface de facade vegetale  */
    Sniv[niv].SURFACE_CL[2] += Sniv[niv].SURFACE_CL[12];
  }
    
  /* ATTENTION : les relation (1) et (2) ne sont valables que pour les batiment de type prisme */
  /* (extrusions successives du niveau de base) sinon la valeur des planchers varie a chaque etage */
  /* prevoir une option de calcul pour les cas particuliers */
  
  /* ATTENTION : la relation (3) supose que la surface totale des paroi interieures est un multiple (coef) */
  /* des parois exterieures a l'etage courant */
  
  for (niv = 0; niv < nb_niv; niv++) {
    /* relation 1 */
    Sniv[niv].SURFACE_CL[3] = Sniv[nb_niv - 1].SURFACE_CL[2];
    /* relation 2 */
    Sniv[niv].SURFACE_CL[4] = Sniv[nb_niv - 1].SURFACE_CL[2];
    /* relation 3 */
    Sniv[niv].SURFACE_CL[5] = coef * (Sniv[niv].SURFACE_CL[0]
				      + Sniv[niv].SURFACE_CL[1]);
  }

  for (niv = 0; niv < nb_niv; niv++) { 
    for (cl = 0; cl < 12; cl++){ 
      printf(" \tniv: %d, cl:%d, surf:%f\n" , niv, cl, Sniv[niv].SURFACE_CL[cl]); 
    }
  }
}

void calcul_RCparoi_surfacique(paroi *P, listeRCparoi *RCparoi)
/*------------------------------------------------------------------------------------
 * permet de calculer les 3 parametres thermiques analogiques intrinseques (R , Ce , Ci)
 * des differents types de parois d'un batiment (mur, vitrage, toit, plancher, plafond)
 *------------------------------------------------------------------------------------ */ 
{
	/* declaration variables */
  int j; /* compteur de couche */
  int j_max = P->n; /* nb max de couches */
  
  double Rj; /* variable de calcul (voir these) */
  double Rj_1; /* variable de calcul (voir these) */
  double beta_j; /* variable de calcul (voir these) */
  
  double *R = allocation_tableau_double(j_max); /* resistances thermiques pour chaque couche */
  double *Ci = allocation_tableau_double(j_max); /* capacites thermiques int pour chaque couche */
  double *Ce = allocation_tableau_double(j_max); /* capacites thermiques ext pour chaque couche */
  
  double Req; /* resistance thermique equivalente calculee */
  double Ci_eq; /* capacite de surface interieure calculee */
  double Ce_eq; /* capacite de surface exterieure calculee */
  
  /* determination de Req */
  Req = 0;
  for (j = 0; j < j_max; j++) {
    R[j] = (P->e[j] / P->l[j]);
    Req = Req + R[j];
  }
  
  /* determination de Ce et Ci */
  Rj = 0;
  Rj_1 = 0;
  Ci_eq = 0;
  Ce_eq = 0;
  for (j = 0; j < j_max; j++) {
    Rj_1 = Rj;
    R[j] = (P->e[j] / P->l[j]);
    Rj = Rj + R[j];
    /* beta_j corrige : */
    beta_j = 0.5 * (Rj + Rj_1) / Req; 
    /* beta_j version polycopie : */
    /*beta_j = (0.5*Rj + Rj_1)/Req;		 */
    Ci[j] = P->r[j] * P->C[j] * P->e[j] * beta_j;
    Ce[j] = P->r[j] * P->C[j] * P->e[j] * (1 - beta_j);
    Ci_eq = Ci_eq + Ci[j];
    Ce_eq = Ce_eq + Ce[j];
  }
  
  /* attribution des valeurs dans les structures R_entite et C_entite */
  RCparoi->R = Req;
  RCparoi->Ci = Ci_eq;
  RCparoi->Ce = Ce_eq;
}

void calcul_Rint_surfacique(double hc_int, double hr_int, double *Rcv_i,
		double *Rrad_i)
/* ------------------------------------------------------------------------------------
 *  calcul des resistances convectives et radiatives en surface des parois
 * ------------------------------------------------------------------------------------ */ 
{
  /* ATTENTION : adapter chaque coefficient avec sa classe de paroi */
  *Rcv_i = 1 / hc_int;
  *Rrad_i = 1 / hr_int;
}

void calcul_proprietes_air_int(int nb_facette, int niv, double *niveau,
			       double *in_air, double taux_occup, double debit_hyg_indiv, double Splc,
			       double Hniv, double *Rra, double *Cai)
/* ------------------------------------------------------------------------------------
 *  calcul des proprietes resistives et capacitives de l'air au noeud
 *  de calcul 10 (bilan sur l'air interieur)
 * ------------------------------------------------------------------------------------ */ 
{
  double rho_air = 1.25; /* masse vol air (kg/m3) */
  double Cp_air = 1000; /* capacite thermique massique  (J/K.kg) */
  double qm_air_tot; /* debit d'air neuf total d'etage */
  int somme_in_air; /* somme des entrees d'air sur 1 etage */
  int i;
  
  /* NB : */
  /* pour calculer la surface au sol exploitable ou le volume ventile, on pondere */
  /* la surface de plancher par 95% pour tenir compte de la surface */
  /* occupee par les refends et parois interieures */
  
  
  /* Calcul des Cai : inertie du volume d'air interne */
  *Cai = rho_air * Cp_air * 0.95 * Splc * Hniv; /* rho * C * volume */

  /* Calcul des Rra : renouvellement d'air */
  somme_in_air = 0;
  qm_air_tot = taux_occup * debit_hyg_indiv * 0.95 * Splc * rho_air *2 / 3600; /*attention modif temp laurent (*2) */
  
  for (i = 0; i < nb_facette; i++)
    if (((int) niveau[i] == niv) && ((int) in_air[i] == 1))
      somme_in_air++;
  
  qm_air_tot = qm_air_tot / somme_in_air; /* repartition du debit total sur les differentes entrees */
  
  for (i = 0; i < nb_facette; i++) {
    if (((int) niveau[i] == niv) && ((int) in_air[i] == 1)) {
      if (qm_air_tot != 0)
	Rra[i] = 1 / (Cp_air * qm_air_tot);
      else {
	Rra[i] = -1.0; /* pas de ventilation (pas d'occupants) */
	printf("\nATTENTION : probleme de debit d'air neuf nul  -  Verifier le scenario d'occupation\n\n");
	/*exit(0); */
      }
    }
  }
}

void calcul_puissance_occupation(int saison, double surface, double taux_occup,
				 double ps_equip, double *Ps_equip, double *Ps_occup, double *Pl_occup)
/* ------------------------------------------------------------------------------------
 *  calcul les puissances sensibles et latente
 * ------------------------------------------------------------------------------------ */ 
{
  double Adu = 1.8; /* aire de Dubois (surface caorporelle) en m */
  
  /* puissance sensible et latentes d'un individu en ete */
  /* exprimees en W/m */
  /* conditions : activite 1.2 Met, Icl 0.5 clo, Top 25C, Vair 0.1 m/s */
  double ps_indiv_ete = 47/2.;
  double pl_indiv_ete = 21;
  
  /* puissance sensible et latentes d'un individu en hiver */
  /* exprimees en W/m */
  /* conditions : activite 1.2 Met, Icl 1 clo, Top 20C, Vair 0.1 m/s */
  double ps_indiv_hiver = 55/2.;
  double pl_indiv_hiver = 23;
  
  int ete = 0;
  int hiver = 1;
  
  if (saison == ete) {
    *Ps_occup = surface * taux_occup * Adu * ps_indiv_ete;
    *Pl_occup = surface * taux_occup * Adu * pl_indiv_ete;
  } else if (saison == hiver) {
    *Ps_occup = surface * taux_occup * Adu * ps_indiv_hiver;
    *Pl_occup = surface * taux_occup * Adu * pl_indiv_hiver;
	} else {
    printf(
	   "\nATTENTION : probleme au niveau de la definition de la saison : ete(0) hiver(1)\n\n");
    exit(0);
  }
  
  *Ps_equip = surface * ps_equip;
}

double calcul_HS(double Tair, double HR)
/* ------------------------------------------------------------------------------------
 *  calcul de l'humidite specifique en fonction de Tair et de l'humidite relative
 * ------------------------------------------------------------------------------------ */ 
{
  double p_sat; /* pression de vapeur saturante */
  double T_radian; /* temperature en kelvin */
  double HS; /* humidite specifique en kg(eau)/kg(air) */
  /* pression atmospherique (air ambiant) : */
  /* double p_air = 101325 ; */ 	

  
  T_radian = Tair * PI / 180.0; /* convertit en radians pour fonctions trigo */
  p_sat = 610.7 * pow((1 + sqrt(2) * sin(T_radian / 3)), 8.827); /* formule de Alt, cf. Guyot p.106 */
  HS = (0.622 * p_sat * HR) / (101325 - (0.378 * p_sat * HR));
  return HS;
}

double calcul_HR(double Tair, double HS)
/* ------------------------------------------------------------------------------------
 *  calcul de l'humidite relative en fonction de Tair et de l'humidite specifique
 * ------------------------------------------------------------------------------------ */ 
{
  double p_air = 101325; /* pression atmospherique (air ambiant) */
  double p_sat; /* pression de vapeur saturante */
  double T_radian; /* temperature celsius -> radians */
  double HR; /* humidite relative */
  
  T_radian = Tair * PI / 180.0; /* convertit en radians pour fonctions trigo */
  p_sat = 610.7 * pow((1 + sqrt(2) * sin(T_radian / 3)), 8.827); /* formule de Alt, cf. Guyot p.106 */
  HR = HS * p_air / (p_sat * (0.622 + 0.378 * HS)); /* inversion de la formule humid spe */
  return HR;
}

double bilan_vapeur_eau(double Tair_int, double surface, double taux_occup,
			double debit_hyg_indiv, double Pl_occup, double w_ext)
/* ------------------------------------------------------------------------------------
 *  permet de faire le bilan de charge latente a l'interieur du local en
 *  fonction de la quantite d'humlidite entrante
 * ------------------------------------------------------------------------------------ */ 
{
  double Platent; /* charge latente de conditionnement d'air (W) */
  double Lv = 2420000; /* chaleur latente de vaporisation de la vapeur d'eau (J/kg) */
  double w_int; /* consigne de masse de vapeur d'eau dans l'air interieur (kg_eau/kg_air) */
  double rho_air = 1.25; /* masse vol air (kg/m3) */
  double qm_air_sec; /* debit d'air sec dans le local (kg/s) */
  double HR = 0.5; /* 50% d'humidite relative (CONSIGNE IMPOSEE) */
  
  w_int = calcul_HS(Tair_int, HR); /* calcul de la masse d'humidite pour 50% d'humidite relative */
  qm_air_sec = taux_occup * debit_hyg_indiv * surface * rho_air / 3600;
  Platent = (qm_air_sec * Lv * (w_int - w_ext)) - Pl_occup;
  return Platent;
}

void calcul_flux_solaires_int(Sniveau *Sniv, int nb_facette, int nb_niv,
			      double *niveau, double *classe_paroi, double *flux_sol_dir,
			      double *flux_sol_diff, double *transmission, double *surface,
			      double abs_plc, double abs_vit, double *Ft_mur, double *Ft_vit,
			      double *Ft_plc, double *Ft_plf, double *Ft_int)
/* ------------------------------------------------------------------------------------
 *  permet de calculer les flux solaires transmis a l'interieur du batiment
 *  et leur repartition sur les differentes parois
 * ------------------------------------------------------------------------------------ */ 
{
  int i, j, niv;
  double Stot;
  double *Fsdir_transmis = allocation_tableau_double(nb_niv);
  double *Fsdiff_transmis = allocation_tableau_double(nb_niv);
  
  for (i = 0; i < nb_niv; i++)
    for (j = 0; j < nb_facette; j++)
      if (((int) niveau[j] == i) && ((int) classe_paroi[j] == 1)) /* cas d'une surface vitree au niveau courant */
	{
	  Fsdir_transmis[i] += transmission[j] * surface[j]
	    * flux_sol_dir[j];
	  Fsdiff_transmis[i] += transmission[j] * surface[j]
	    * flux_sol_diff[j];
	}
  
  for (niv = 0; niv < nb_niv; niv++) {
    Stot = Sniv[niv].SURFACE_CL[0] + Sniv[niv].SURFACE_CL[1]
      + Sniv[niv].SURFACE_CL[3] + Sniv[niv].SURFACE_CL[4] + (2
							     * Sniv[niv].SURFACE_CL[5]);
    Ft_plc[niv] = (abs_plc * Fsdir_transmis[niv])
      + (Sniv[niv].SURFACE_CL[3] / Stot) * (Fsdiff_transmis[niv] + (1
								    - abs_plc) * Fsdir_transmis[niv]);
    Ft_vit[niv] = (abs_vit * Sniv[niv].SURFACE_CL[1] / Stot)
      * (Fsdiff_transmis[niv] + (1 - abs_plc) * Fsdir_transmis[niv]);
    Ft_mur[niv] = (Sniv[niv].SURFACE_CL[0] / Stot) * (Fsdiff_transmis[niv]
						      + (1 - abs_plc) * Fsdir_transmis[niv]);
    Ft_plf[niv] = (Sniv[niv].SURFACE_CL[4] / Stot) * (Fsdiff_transmis[niv]
						      + (1 - abs_plc) * Fsdir_transmis[niv]);
    Ft_int[niv] = (2 * Sniv[niv].SURFACE_CL[5] / Stot)
      * (Fsdiff_transmis[niv] + (1 - abs_plc) * Fsdir_transmis[niv]);
  }
}

double calcul_Tref_profondeur(double z_ref, double j, double j_ref,
			      double moy_Tair, double max_Tair, double min_Tair, double lambda_sol,
			      double Cp_sol, double rho_sol)
/* ------------------------------------------------------------------------------------
 *  calcule une temperature souterraine de reference a une cote z donnee
 *  la temperature est consante pour un jour de ref et obeit a la loi de Kusuda et al.
 *  voir these J.Bouyer
 * ------------------------------------------------------------------------------------ */ 
{
  double alpha_sol;
  double T_ref;
  double A, B, C, D, frac1, frac2, frac3;
  
  alpha_sol = (lambda_sol / (rho_sol * Cp_sol)) * 24 * 3600; /* diffusivite thermique en m2/jour */
  
  A = moy_Tair;
  B = (max_Tair - min_Tair) / 2;
  frac1 = PI / (365 * alpha_sol);
  C = -z_ref * sqrt(frac1);
  frac2 = 2 * PI / 365;
  frac3 = 365 / (PI * alpha_sol);
  D = frac2 * (j - j_ref - (0.5 * z_ref * sqrt(frac3)));
  T_ref = A - (B * (exp(C)) * (cos(D)));
  
  return T_ref;
}

void calcul_proprietes_sol(double epaisseur, double rho, double Cp,
			   double lambda, double *Rsol, double *Csol)
/* ------------------------------------------------------------------------------------
 *  calcul de la resistance , capacite , et temperature limite pour la couche de sol
 * ------------------------------------------------------------------------------------ */ 
{
  *Rsol = 0.5 * epaisseur / lambda; /* la moitie de la resitance totale */
  *Csol = rho * Cp * epaisseur;
}


double calcul_flux_latent(double FluxSol, double FluxGLONet, double Tair,
			  double HS, double v, double f, double LAI)
/* ------------------------------------------------------------------------------------
 *  calcule du flux latent selon la methode de Penman-Monteith
 * ------------------------------------------------------------------------------------ */ 
{
	double Rnet; /* rayonnement total (sol+IR) net echange */
	double Ea; /* pouvoir evaporant de l'air */
	double e, e_sat; /* tension de vapeur et tension de vapeur saturante de l'air */
	double rho_air; /* masse volumique de l'air */
	double p_air, M_air, M_eau, cp_air, R_gaz, epsilon, Lv; /* variables physiques air, eau */
	double T_radian; /* temperature celsius -> radians */
	double HR; /* humidite relative, specifique */
	double fv; /* fonction vitesse de l'air */
	double h_veg; /* hauteur de la vegetation (gazon) */
	double r_aero, r_sto; /* resistance stomatique et aerodynamique */
	double delta; /* pente de la courbe de saturation */
	double gamma; /* constante psychrometrique */
	double resu;

	R_gaz = 8.314; /* cte gaz parfaits */
	p_air = 101325; /* pression atmospherique */
	M_air = 0.029; /* masse molaire air */
	M_eau = 0.018; /* masse molaire eau */
	epsilon = M_eau / M_air; /* rapport des masses molaires */
	cp_air = 1013; /* capacite thermique de l'air a pression constante */
	Lv = 2501000 - 2361 * Tair; /* chaleur latente de vaporisation */
	gamma = (cp_air * p_air) / (epsilon * Lv); /* constante psychrometrique */
	h_veg = 0.05; /* 5 cm de gazon */

	Rnet = FluxSol - FluxGLONet;

	/* modif laurent 9/2011 :  descripteur vitesse remplace inversion de la formule de Jayamaha */
	/* inversion de la relation de Jayamaha utilisee dans l'UDF de Fluent pour le flux convectif */
	/* v = ((hc - 5.85) / 1.7); */
 
	/* formulation these Oudin et FAO (pour Penman-Monteith) (h_ref gazon 12cm) */
	/*r_aero = (208 / v) ;	 */
						
	/* formulation these Oudin et FAO (pour Penman-Monteith) (h_ref gazon 12cm) */
	/*r_sto = 70 ;									 */

	/* formulation FAO (pour Penman-Monteith) */
	r_aero = (log((2 - ((2 / 3) * LAI/24)) / (0.123 * LAI/24)) * log((2
			- ((2 / 3) * LAI/24)) / (0.1 * 0.123 * LAI/24)) / (0.41 * 0.41 * v)); 

	/* formulation FAO (pour Penman-Monteith)  */
	/* r_aero = (log((2 - ((2 / 3) * h_veg)) / (0.123 * h_veg)) * log((2 
	   - ((2 / 3) * h_veg)) / (0.1 * 0.123 * h_veg)) / (0.41 * 0.41 * v)); */

	/* modification laurent 11-07-2011 LAI pour analyse de sensibilite (LAI=24*h_veg)  formulation FAO (pour Penman-Monteith) */
	r_sto = (100 / (0.5 * LAI)); 

	/* relation gaz parfaits */
	rho_air = ((M_air * p_air) / (R_gaz * (Tair + 273.15))); 

	/*formulation de base Monteith */
	/*fv = 0.35*(0.5 + v) ; */

	fv = ((rho_air * cp_air) / (r_aero * gamma)); /* formulation Penman-Monteith */
	T_radian = Tair * PI / 180.0; /* convertit en radians pour fonctions trigo */
	e_sat = 610.7 * pow((1 + sqrt(2) * sin(T_radian / 3)), 8.827); /* formule de Alt, cf. Guyot p.106 */
	HR = ((HS * p_air) / (e_sat * (0.622 + 0.378 * HS))); /* inversion de la formule humid spe */
	

  
	e = (HR * e_sat); /* tension de vapeur */
	Ea = fv * (e_sat - e);

	delta = (8.827 * 610.7 * sqrt(2) * ((1.0 / 3.0) * (PI / 180.0))) * cos(
			T_radian / 3) * pow((1 + sqrt(2) * sin(T_radian / 3)), 7.827); /* derivation de la formule de Alt */


	resu = f * (((Rnet * delta) + (gamma * Ea)) / (delta + (gamma * (1 + (r_sto
			/ r_aero)))));

	if (resu < 0.0) {
		resu = 0.0;
	}
	/* if (resu > 0.0){ */
	/*   printf("R%f d%f g%f E%f rs%f ra%f\n", Rnet, delta, gamma, Ea, r_sto, r_aero); */
	/*   printf("resu %f\n", resu); */
	/* } */


	return resu;
}

double Teq_soleil(paroi *tab_paroi, int no_paroi, double hc_ext, double Text,
		  double TSinit, double flux_sol_abs)
/* ------------------------------------------------------------------------------------
 *  calcul des temperatures equivalentes au soleil pour l'initialisation
 *  des temperatures de surfaces
 *  extraite de 'transitoire_h_option2.c', modifiee par J.Bouyer, decembre 2006
 * ------------------------------------------------------------------------------------ */ 
{
  double epaisseur, lambda;
  double Dx; /* pas d'espace */
  double K; /* conductance */
  double temp_eq; /* variable retournee */
  
  /* caracteristiques de la premiere couche */
  epaisseur = tab_paroi[no_paroi].e[0];
  lambda = tab_paroi[no_paroi].l[0];
  
  Dx = epaisseur / 2;
  K = lambda / Dx;
  temp_eq = ((hc_ext * Text) + (K * TSinit) + flux_sol_abs) / (hc_ext + K);
  
  return temp_eq;
}

double IR_ciel(double Tair)
/* ------------------------------------------------------------------------------------
 *  cacul des flux IR en fonction de le temperature d'air
 *  si ces flux ne sont pas donnes en entree
 *  extraite de 'transitoire_h_option2.c', en l'etat
 * ------------------------------------------------------------------------------------ */ 
{
  /* Calcul du flux IR maximum recu en provenance du ciel d'apres modele de Monteith (these J. Noilhan -> cf. these J.Vinet, CERMA) */
  return (double) (5.5 * Tair + 213);
}

#!/bin/python
'''
 *
 *  Copyright 2010-2013 Laurent Malys (CERMA, UMR 1563 AAU, CNRS /
 *                                  Ecole d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
'''

from main import *

import matplotlib.pyplot as plt
plt.interactive(True)

chemin_fichier_xml = '/home/laurent/Couplage/canyon_benjamin/canyon_benjamin.xml'
nom_commande =  '/home/laurent/solenetb/src/trunk/solene.thermo-radiatif.core/exe/simulation_Ts_EnergieBat.exe'

#initisalisation du cas
sim = SimulationCouplee(chemin_fichier_xml)

#creation de 'raccourcis'
sol = sim.SolCommand
senv = sim.solEnv
geo = sim.geom_sol

lst_ts = sim.TimeStep.liste_ts_sol

# creation des fichiers d'entree
senv.creer_descripteur_solaires()
senv.creer_descripteur_veg()

lst_h_niv = [5,3,3,3]
senv.creer_param_simulation_ener(4,
                                 lst_h_niveau = lst_h_niv,
                                 T_init = 20,
                                 hc = 10)

#///////////////////////////////////////////////////////////////////////////////////////////////
## ATTENTION astuce :
# le calcul ne fonctionne pas si le batiment n'est pas vitre
# on "transforme" magiquement un triangle par face de "mur" en "vitrage"

# numero de la famille murBatetude :
num_famille_mur = int(geo.familles['murBatetude'])

# liste des faces appartenant a la famille murBatetude
lst_face_mur = np.arange(geo.n_faces)[np.array(geo.faces.famille) == num_famille_mur]

# lecture des descripteurs concernes
no_classe = sim.lire_val('no_classe')
no_paroi = sim.lire_val('no_paroi')
trans_bat = sim.lire_val('transmittance_bat')

#modification des descripteurs pour le premier triangle de chaque face
for i_face in lst_face_mur:
    # numero du premier triangle de la face :
    num_triangle_0 = geo.faces.liste_triangles[i_face][0]
    # on change ses caracteristiques pour qu'il se 'transforme' en vitrage :
    no_classe[num_triangle_0] = 1
    no_paroi[num_triangle_0] = 1
    trans_bat[num_triangle_0] = 0.7

write_val(sol.carac['no_classe'], geo, no_classe)
write_val(sol.carac['no_paroi'], geo, no_paroi)
write_val(sol.carac['transmittance_bat'], geo, trans_bat)
# fin astuce
#///////////////////////////////////////////////////////////////////////////////////////////////////

# calcul solaire
sol.calculer_eclairements()

sol.calculer_fac_form_ciel()

# pas de temps zero : initialisation
senv.definir_meteo(0, veg = True)
sol.simulation_Ts_EnergieBat_new('init', 
                                 lst_ts[0],
                                 simulation_batiment = True,
                                 simulation_vegetation = True,
                                 meteo = True,
                                 nom_commande = nom_commande ,
                                 terminal = True)

#suite du calcul
for i in range(1, len(lst_ts)):
    senv.definir_meteo(i, veg = True)
    avant = lst_ts[i-1]
    apres = lst_ts[i]
    sol.simulation_Ts_EnergieBat_new(avant,
                                     apres,
                                     simulation_batiment = True,
                                     simulation_vegetation = True,
                                     meteo = True,
                                     nom_commande = nom_commande)
    print '\t sim_ts : de %s a %s' % (avant, apres)

# recupere la temperature pour les 4 etages 
Tint = senv.ret_Tint_n(4)

# on trace l'evolution des temperatures pour les 4 niveaux
for i, Tint_t in enumerate(Tint):
    plt.plot(Tint_t, label = 'RdC+%s' % i)

plt.legend()



# -*- coding: utf-8 -*-
'''
 *
 *  Copyright 2010-2013 Laurent Malys (CERMA, UMR 1563 AAU, CNRS /
 *                                  Ecole d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
'''

"""
Created on Fri Sep 17 15:35:16 2010

@author :
    Laurent Malys, Laboratoire CERMA, UMR 1563
    laurent.malys@cerma.archi.fr
"""

from main import *

# Chargement du cas 'tuto_couplage' dont les informations se trouvent dans
# le fichier 'tuto_couplage.xml'
#
# Il s'agit de charger des geometrie .cir triangulées et non triangluées et 
# d'importer les familles depuis un descripteur .val attribué aux faces
#
# COMMENT UTILISER CE TUTORIEL
# 1ere méthode : copier les commandes une à une dans un terminal ipython
#  -> permet de vérifier que les opérations fonctionnent
# 2ème méthode : lancer directement le script avec python (python tuto_couplage.py)
# ou dans ipyhon (ipython puis %run tuto_couplage.py)
#  -> déconseillé avec une grosse géométrie pour laquelle certaines opérations
# peuvent prendre beaucoup de temps

sim = SimulationCouplee(param_xml = '/home/laurent/Couplage/tuto_couplage.xml')

# importation de la meteo depuis un fihcier de la RT au format .csv
sim.importer_meteo(sim.chemin_fichier_meteo_RT)

raw_input('continuer ?')

# creation de raccourcis 
SolCom = sim.SolCommand
SolEnv = sim.solEnv
SatCom = sim.SatCommand



# INITIALISATION SOLAIRE SOLENE
# creation des descripteurs
# ATTENTION : les familles ne correspondent pas forcement si on utilise pas la geometrie non triangulee
SolEnv.creer_descripteur_solaires()

raw_input('continuer ?')

# calcul des flux solaires et des facteurs de formes
SolCom.calculer_luminance_ciel()

raw_input('continuer ?')

SolCom.calculer_flux_solaires()
# on peut utiliser les fichier meteos :
# SolCom.calculer_flux_solaires(meteo = True)
# il faut alors placer les fichier meteo dans le repertoire ciel
# (voir nommage au ligne 50/51 solCommand.py 'meteo_diffus_jj_mm.txt' et 'meteo_direct_jj_mm.txt')

SolCom.calculer_fac_form()
SolCom.calculer_fac_form_ciel()
SolEnv.supprimer_nan(SolCom.chemin_clo)
SolCom.calculer_radiosite()

raw_input('continuer sat ?')

SolEnv.supprimer_nan(SolCom.chemin_clo)     # suppression des valeurs 'nan'
                                            # dans les descripteurs CLO
                                            
# INITIALISATION SATURNE

# si elle n'est pas presente, il faut copier la geometrie Saturne dans le repertoire 
# MESH approprié !

SatCom.lancer_saturne_gui()

# enregister le fichier de configuration de Saturne
# réaliser les différents réglages s'ils ne sont pas fait
#        cas stationnaire
#        ajout d'un scalaire temperature en Celsius
#        choix du nombre d'iteration...
# réaliser le preprocess pour importer les familles
# supprimer les familles qui sont traités dans les subroutines
# a priori, toutes sauf le toit et le sol de la veine
#
# enregistrer puis fermer

# attendre que les operations sur l'interface soient finies
raw_input('continuer ?')

# ecriture des fichiers meteo qui sont lu par uslim pour fixer les conditions aux
# limites
SatCom.definir_meteo(sim.meteo_liste[0])

# creation des subroutines (ecriture du nom des familles, des chemin vers les 
# fichiers meteo.. etc...
SatCom.creer_usclim()
SatCom.creer_usvpst()  
SatCom.ecrire_subroutines()
# (aller verifier si les subroutines sont correctes)
raw_input('continuer ?')

# On choisit (arbitrairement) une température des murs à 40C et des hc à 20C
sim.creer_dat_constant(SatCom.nom_dat_Ts, 40)
sim.creer_dat_constant(SatCom.nom_dat_hcbis, 20)

raw_input('continuer ?')
# lancer la simulation d'initisalisation
SatCom.lancer_simulation()
# (la simulation se lance dans un autre terminal)


raw_input('continuer ?')
# INITIALISATION 'SIMULATION_TS' SOLENE
# creation des fichiers parametres (no_paroi.val, no_classe.val...)
SolEnv.creer_param_simulation_ts()

# choix d'une température initiale des murs de 40C
SolEnv.creer_T_init(40)

# création de la connectivité entre les fichiers .dat et les fichiers .val
sim.connection_dat2val(SatCom.nom_dat_Tair)

# récupération de la température de l'air et du hc issus de Saturne
sim.dat2val_lien(SatCom.nom_dat_Tair, SolCom.var['Tair'])
sim.dat2val_lien(SatCom.nom_dat_h_conv, SolCom.var['hc'])
raw_input('continuer ?')
# calcul de la température au premier pas de temps, avec la température T_init
# comme température initiale (fixée à 40 par SolEnv.creer_T_init(40))
SolCom.simulation_Ts('init', sim.TimeStep.liste_ts_sol[0])
raw_input('continuer ?')


# LANCEMENT DE LA SIMULATION
for no_suffixe in range(1,len(sim.TimeStep.liste_ts_sol)):
    suffixe_avant = sim.TimeStep.liste_ts_sol[no_suffixe-1]
    suffixe_apres = sim.TimeStep.liste_ts_sol[no_suffixe]
    sim.lancer_simul_couplee_un_temps_test(suffixe_avant, suffixe_apres)



# -*- coding: utf-8 -*-
'''
 *
 *  Copyright 2010-2013 Laurent Malys (CERMA, UMR 1563 AAU, CNRS /
 *                                  Ecole d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
'''

"""
Created on Fri May 28 14:26:22 2010

@author: laurent
"""

import geompy
import smesh


def mettre_en_boite(scene, arbre):
    scene=geompy.myStudy.FindObject(scene).GetObject()
    arbre=geompy.myStudy.FindObject(arbre).GetObject()
    
    boite = geompy.BoundingBox(scene)
    centre = [(boite[0] + boite[1])/2., (boite[2] + boite[3])/2., boite[4]]

    pt0 = geompy.MakeVertex(0,0,0)
    pt1 = geompy.MakeVertex(centre[0],centre[1],centre[2])
    scene=geompy.MakeTranslationTwoPoints(scene,pt1, pt0) 
    arbre=geompy.MakeTranslationTwoPoints(arbre, pt1, pt0)
    boite = geompy.BoundingBox(scene)

    dx = boite[1]-boite[0]
    dy = boite[3]-boite[2]

    dist = 0.7 * max(dy,dx)
    hauteur = 1.5 * boite[5]

    xyz = geompy.MakeVertex(-dist, -dist, 0)
    Xyz = geompy.MakeVertex( dist, -dist, 0)
    XYz = geompy.MakeVertex( dist,  dist, 0)
    xYz = geompy.MakeVertex(-dist,  dist, 0)
    xYZ = geompy.MakeVertex(-dist,  dist, hauteur)
    xyZ = geompy.MakeVertex(-dist, -dist, hauteur)
    XyZ = geompy.MakeVertex( dist, -dist, hauteur)
    XYZ = geompy.MakeVertex( dist,  dist, hauteur)

    Ayz = geompy.MakeEdge(xyz, Xyz)
    AYz = geompy.MakeEdge(xYz, XYz)
    AYZ = geompy.MakeEdge(xYZ, XYZ)
    AyZ = geompy.MakeEdge(xyZ, XyZ)
    
    Bxz = geompy.MakeEdge(xyz, xYz)
    BXz = geompy.MakeEdge(Xyz, XYz)
    BXZ = geompy.MakeEdge(XyZ, XYZ)
    BxZ = geompy.MakeEdge(xyZ, xYZ)

    Cxy = geompy.MakeEdge(xyz, xyZ)
    CXy = geompy.MakeEdge(Xyz, XyZ)
    CXY = geompy.MakeEdge(XYz, XYZ)
    CxY = geompy.MakeEdge(xYz, xYZ)


    wirey = geompy.MakeWire([Ayz,CXy,AyZ,Cxy])
    wireY = geompy.MakeWire([AYz,CXY,AYZ,CxY])

    wirex = geompy.MakeWire([Bxz,CxY,BxZ,Cxy])
    wireX = geompy.MakeWire([BXz,CXY,BXZ,CXy])

    wirez = geompy.MakeWire([Ayz,Bxz,AYz,BXz])
    wireZ = geompy.MakeWire([AyZ,BxZ,AYZ,BXZ])

    facex = geompy.MakeFace(wirex, 1)
    faceX = geompy.MakeFace(wireX, 1)
    facey = geompy.MakeFace(wirey, 1)
    faceY = geompy.MakeFace(wireY, 1)
    facez = geompy.MakeFace(wirez, 1)
    faceZ = geompy.MakeFace(wireZ, 1)
    
    shell = geompy.MakeShell([facex, faceX, facey, faceY, facez, faceZ])
    
    solid = geompy.MakeSolid([shell])

    scene_id = geompy.addToStudy(scene,'scene_centre')
    solid_id = geompy.addToStudy(solid,'boite1')

    scene_new = geompy.MakeCut(solid, scene)
    scene_bis = geompy.MakeCut(scene_new, arbre)
    
    scene_tot = geompy.MakeCompound([scene_bis, arbre])
    boite_trou_id = geompy.addToStudy(scene_tot, 'boite_trous')

    return scene_new
scene_new = mettre_en_boite('scene_bis', 'arbre')

#
#maillage_scene = smesh.Mesh(scene_new, "maillage_scene")
#subShapeList = geompy.SubShapeAll(scene, geompy.ShapeType["EDGE"])
#for edge in subShapeList:
#    cdg = geompy.MakeCDG(edge)
#    coords_cdg = geompy.PointCoordinates(cdg)
#    if coords_cdg[0] == min_x:
#        if coords_cdg[2] == 0
#    
#hyp = maillageEntree.Arithmetic1D(2,10)
#
#
#maillage_scene.Compute()






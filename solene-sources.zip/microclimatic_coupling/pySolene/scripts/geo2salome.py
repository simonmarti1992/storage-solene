#!/usr/bin/python
# -*- coding: utf-8 -*-
'''
 *
 *  Copyright 2010-2013 Laurent Malys (CERMA, UMR 1563 AAU, CNRS /
 *                                  Ecole d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
'''

"""
Principe : 
convertisseur du format .geo de gmsh vers le format de script python de salome.
--creer_script_from_geo()--

reutilise pour faire un convertisseur vers salome depuis le format de stockage interne 
de l'outil de couplage --geom2salome_extrude()--

"""

import geom
import numpy as np

def parser_ligne(ligne):
	nom, suite = ligne.split('(')
	num, suite = suite.split(')')
	suite = suite.split('{')[1]
	liste_brut = suite.split('}')[0]
	liste = liste_brut.split(',')
	for i in range(len(liste)):
		liste[i] = float(liste[i])
		
	elem = {'nom':nom, 'num':num, 'liste':liste}
	return elem
	
def creer_point(elem):
	creation = 'p%s = geompy.MakeVertex(%s, %s, %s)\n' % (elem['num'],
							      elem['liste'][0],
							      elem['liste'][1],
							      elem['liste'][2])
	declaration = 'id_p%s = geompy.addToStudy(p%s, "Vertex %s")' % (elem['num'],elem['num'],elem['num'],)
                                                                    
    #return '%s%s\n' % (creation, declaration)
	return creation

def creer_line(elem):
	creation = 'l%s = geompy.MakeLineTwoPnt(p%s, p%s)\n' % (elem['num'],
								int(elem['liste'][0]),
								int(elem['liste'][1]))

	declaration = 'id_l%s = geompy.addToStudy(l%s, "Line %s")' % (elem['num'],
								      elem['num'],
								      elem['num'])
	
    #return '%s%s\n' % (creation, declaration)
	return creation

def creer_wire(elem):
	liste_ligne = '['
	for ligne in elem['liste']:
		liste_ligne += 'l%s ,' % int(abs(ligne))
	
	liste_ligne = liste_ligne[:-2] + ']'	
	creation = 'w%s = geompy.MakeWire(%s)\n' % (elem['num'],
						    liste_ligne)
		
	return creation
	
def creer_face(elem):
	creation = 'f%s = geompy.MakeFace(w%s, 1)\n' % (elem['num'], int(elem['liste'][0]))
	return creation

def declarer_face(elem):
	declaration = 'id_f%s = geompy.addToStudy(f%s, "Plane %s")\n' % (elem['num'],
									 elem['num'],
									 elem['num'])
	return declaration

def creer_shell(elem):
	liste_face = '['
	for face in elem['liste']:
		liste_face += 'f%s ,' % int(abs(face))

	liste_face = liste_face[:-2] + ']'
	
	creation = 's%s = geompy.MakeShell(%s)\n' % (elem['num'],
						     liste_face)

	return creation

def creer_solid(elem):
	liste_shell = '['
	for shell in elem['liste']:
		liste_shell += 's%s ,' % int(abs(shell))
		
	liste_shell = liste_shell[:-2] + ']'
	creation = 'v%s = geompy.MakeSolid(%s)\n' % (elem['num'],
						     liste_shell)

	declaration = 'id_v%s = geompy.addToStudy(v%s, "Volum %s")\n' % (elem['num'],
									 elem['num'],
									 elem['num'])
	
	return '%s%s' % (creation, declaration)

def creer_prism(face, i, vector, h):
	creation = 'b%s = geompy.MakePrismVecH(%s, %s, %s)' % (i, face, vector, h)
	declaration = 'id_b%s = geompy.addToStudy(b%i, "Box %i")' % (i, i, i)
    
	return '%s\n%s\n' % (creation, declaration)

def geo2salome_ligne(ligne):
	try: 		
		elem = parser_ligne(ligne)
		if elem['nom'] == 'Point':
			return creer_point(elem)
		elif elem['nom'] == 'Line':
			return creer_line(elem)
		elif elem['nom'] == 'Line Loop':
			return creer_wire(elem)
		elif elem['nom'] == 'Plane Surface':
			return creer_face(elem)
		elif elem['nom'] == 'Surface Loop':
			return creer_shell(elem)
		elif elem['nom'] == 'Volume':
			return creer_solid(elem)
		else:
			return ''
	except:
		return ''

	
def creer_script_from_geo(fichier):
	texte = ''
	
	fichier = open(fichier)
	fichier = fichier.readlines()
	for ligne in fichier:
		texte+=geo2salome_ligne(ligne)
		
	return texte
	
def geom2salome_extrude(geom, h):
	"""
	creation d un script salome a partir de la geometrie dans le format interne (geom)
	et d une liste donnant les hauteurs correspondants aux toits (h)
	"""
	
	i_arete = 0
	txt = ''
	
	txt += 'pt_vec0 = geompy.MakeVertex(0, 0, 0)\n'
	txt += 'pt_vec1 = geompy.MakeVertex(0, 0, -1)\n'
	txt += 'vec_t = geompy.MakeVector(pt_vec0, pt_vec1)\n'
	
	for i_face in range(geom.n_faces):
		points_face = geom.faces.points[i_face]
		liste_aretes = []
		liste_nom_aretes = []

		for i_pt in range(len(points_face)):
			# on passe par un dictionnaire elem (pas tres pratique mais c est pour
			# reprendre tels quels les fonctions utilisees pour le format .geo :
			# creer_point(elem), etc)
			elem = {'nom':'Point', 
				'num':points_face[i_pt], 
				'liste':geom.points[np.array(points_face[i_pt])-1]}                    
			txt += creer_point(elem)
			
		# de meme pour les aretes, creation d'elements -line-
			liste_aretes.append({'nom':'Line', 
					     'num':i_arete, 
					     'liste' : [points_face[i_pt], points_face[i_pt-1]]})
			liste_nom_aretes.append(i_arete)
			i_arete += 1

		for arete in liste_aretes:
			txt += creer_line(arete)
				
				
		txt += creer_wire({'nom':'Line Loop', 'num':i_face, 'liste':liste_nom_aretes})
		txt += creer_face({'nom':'Plane Surface', 'num':i_face, 'liste':[i_face]})
		txt += creer_prism('f%s' % i_face, i_face, 'vec_t', geom.points[points_face[0]-1][2]+1)
        
	return txt	

def geom2salome_faces(geom):

	i_arete = 0
	txt = ''
	
	txt += 'pt_vec0 = geompy.MakeVertex(0, 0, 0)\n'
	txt += 'pt_vec1 = geompy.MakeVertex(0, 0, -1)\n'
	txt += 'vec_t = geompy.MakeVector(pt_vec0, pt_vec1)\n'
	
	for i_face in range(geom.n_faces):
		points_face = geom.faces.points[i_face]
		liste_aretes = []
		liste_nom_aretes = []

		for i_pt in range(len(points_face)):
			# on passe par un dictionnaire elem (pas tres pratique mais c est pour
			# reprendre tels quels les fonctions utilisees pour le format .geo :
			# creer_point(elem), etc)
			elem = {'nom':'Point', 
				'num':points_face[i_pt], 
				'liste':geom.points[np.array(points_face[i_pt])-1]}                    
			txt += creer_point(elem)
			
		# de meme pour les aretes, creation d'elements -line-
			liste_aretes.append({'nom':'Line', 
					     'num':i_arete, 
					     'liste' : [points_face[i_pt], points_face[i_pt-1]]})
			liste_nom_aretes.append(i_arete)
			i_arete += 1

		for arete in liste_aretes:
			txt += creer_line(arete)
				
				
		txt += creer_wire({'nom':'Line Loop', 'num':i_face, 'liste':liste_nom_aretes})
		txt += creer_face({'nom':'Plane Surface', 'num':i_face, 'liste':[i_face]})
		txt += declarer_face({'nom':'Plane Surface', 'num':i_face, 'liste':[i_face]})
        
	return txt	

def faceToBatVitrage(gg, h, i_bat, n_niveau, tx_vitrage):

	geom_faces = geom.Geom()
	dh = h[i_bat]/n_niveau
	dv = dh * tx_vitrage

	points_face = gg.faces.points[i_bat]
	n_pt = len(points_face)

	liste_points_toit = []
	for i_pt in range(len(points_face)):
		liste_points_toit.append(np.array(gg.points[np.array(points_face[i_pt])-1]))
	
	liste_points = [liste_points_toit]
	for i_niveau in range(n_niveau):
		liste_moins_un = liste_points[-1]
		liste_points_vitrage = np.copy(liste_moins_un)
		liste_points_etage = np.copy(liste_moins_un)
		for i_pt in range(len(liste_points_vitrage)):
			liste_points_vitrage[i_pt][2] = liste_moins_un[i_pt][2] - dv
			liste_points_etage[i_pt][2] = liste_moins_un[i_pt][2] - dh
		liste_points.append(liste_points_vitrage)
		liste_points.append(liste_points_etage)

	lst = []
	for i in range(len(liste_points)):
		for j in range(len(liste_points[i])):
			lst.append(liste_points[i][j])

	geom_faces.points = np.array(lst)
	geom_faces.n_points = len(lst)

	mat = []
	for i in range(len(liste_points)):
		mat.append(range(i*n_pt, (i+1)*n_pt))
		
	liste_face0 = []
	for i_pt in range(n_pt-1):
		liste_face0.append([mat[0][i_pt], mat[0][i_pt+1], mat[1][i_pt+1], mat[1][i_pt]])
	liste_face0.append([mat[0][-1], mat[0][0], mat[1][0], mat[1][-1]])
	liste_face0 = np.array(liste_face0)

	liste_face = []
	for i_face in range(len(liste_points)-1):
		liste_face.append(liste_face0 + i_face*n_pt)

	liste_face_bis = []
	for i in range(len(liste_face)):
		for j in range(len(liste_face[i])):
			liste_face_bis.append(liste_face[i][j])

	geom_faces.faces.liste_points = np.array(liste_face_bis)+1
	geom_faces.n_faces = len(liste_face_bis)

	return geom_faces


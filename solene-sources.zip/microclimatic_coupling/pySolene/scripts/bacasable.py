'''
 *
 *  Copyright 2010-2013 Laurent Malys (CERMA, UMR 1563 AAU, CNRS /
 *                                  Ecole d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
'''

def plot_i(i):
    res = np.float32(sim.resul_sol.extraire_evolution_triangle('Tse', i))
    plt.plot(lst_ann, res)
    
def minimize():
    val_min = 100000
    for i in range(sim.geom_sol.n_triangles):
        res = np.float32(sim.resul_sol.extraire_evolution_triangle('Tse', i))
        difff = ((res-taupe4)*(res-taupe4)).sum()
        if difff < val_min:
            val_min = difff
            print i, difff
            plt.plot(lst_ann, res)


def comp_nd(i):
    res = np.float32(sim.resul_sol.extraire_evolution_triangle(i))
    jour = tt>18
    difff_jour = ((res-tt)*(res-tt))[jour].sum()

               


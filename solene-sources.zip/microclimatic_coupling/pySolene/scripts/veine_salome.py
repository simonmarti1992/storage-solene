#!/usr/bin/python
# -*- coding: utf-8 -*-
'''
 *
 *  Copyright 2010-2013 Laurent Malys (CERMA, UMR 1563 AAU, CNRS /
 *                                  Ecole d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
'''

import geompy

nom_batiments = 'bat'

#param
dMx = 0.8
dMy = 0.8
Dx = 2
Dy = 2
Dz = 5

Xm = (bb[0]+bb[1])/2
Ym = (bb[2]+bb[3])/2
Zm = 0

def MakeVeine(geom):
	bb = geompy.BoundingBox(geom)
	Lx = abs(bb[1]-bb[0])/2		
	Ly = abs(bb[3]-bb[2])/2
	H = abs(bb[5]-bb[4])
	
	Mxy = geompy.MakeVertex(Xm-dMx * Lx, Ym-dMy * Ly, 0)
	MXy = geompy.MakeVertex(Xm+dMx * Lx, Ym-dMy * Ly, 0)
	MXY = geompy.MakeVertex(Xm+dMx * Lx, Ym+dMy * Ly, 0)
	MxY = geompy.MakeVertex(Xm-dMx * Lx, Ym+dMy * Ly, 0)
	
	L_Mx = geompy.MakeLineTwoPnt(Mxy, MxY)
	L_MX = geompy.MakeLineTwoPnt(MXy, MXY)
	L_My = geompy.MakeLineTwoPnt(Mxy, MXy)
	L_MY = geompy.MakeLineTwoPnt(MxY, MXY)
	
	W_M = geompy.MakeWire([L_Mx, L_MX, L_My, L_MY])
	sol_bat = geompy.MakeFace(W_M, 1)
	
	xyz = geompy.MakeVertex(Xm-Dx * Lx, Ym-Dy * Ly, 0)
	Xyz = geompy.MakeVertex(Xm+Dx * Lx, Ym-Dy * Ly, 0)
	XYz = geompy.MakeVertex(Xm+Dx * Lx, Ym+Dy * Ly, 0)
	xYz = geompy.MakeVertex(Xm-Dx * Lx, Ym+Dy * Ly, 0)
	xYZ = geompy.MakeVertex(Xm-Dx * Lx, Ym+Dy * Ly, Dz * H)
	xyZ = geompy.MakeVertex(Xm-Dx * Lx, Ym-Dy * Ly, Dz * H)
	XyZ = geompy.MakeVertex(Xm+Dx * Lx, Ym-Dy * Ly, Dz * H)
	XYZ = geompy.MakeVertex(Xm+Dx * Lx, Ym+Dy * Ly, Dz * H)
	
	Ayz = geompy.MakeLineTwoPnt(xyz, Xyz)
	AYz = geompy.MakeLineTwoPnt(xYz, XYz)
	AYZ = geompy.MakeLineTwoPnt(xYZ, XYZ)
	AyZ = geompy.MakeLineTwoPnt(xyZ, XyZ)
	
	Bxz = geompy.MakeLineTwoPnt(xyz, xYz)
	BXz = geompy.MakeLineTwoPnt(Xyz, XYz)
	BXZ = geompy.MakeLineTwoPnt(XyZ, XYZ)
	BxZ = geompy.MakeLineTwoPnt(xyZ, xYZ)
	
	Cxy = geompy.MakeLineTwoPnt(xyz, xyZ)
	CXy = geompy.MakeLineTwoPnt(Xyz, XyZ)
	CXY = geompy.MakeLineTwoPnt(XYz, XYZ)
	CxY = geompy.MakeLineTwoPnt(xYz, xYZ)
	
	W_x = geompy.MakeWire([Bxz, CxY, BxZ, Cxy])
	x = geompy.MakeFace(W_x, 1)
	W_X = geompy.MakeWire([BXz, CXY, BXZ, CXy])
	X = geompy.MakeFace(W_X, 1)
	
	W_y = geompy.MakeWire([Ayz, Cxy, AyZ, CXy])
	y = geompy.MakeFace(W_y, 1)
	W_Y = geompy.MakeWire([AYz, CxY, AYZ, CXY])
	Y = geompy.MakeFace(W_Y, 1)
	
	W_z = geompy.MakeWire([Ayz, Bxz, AYz, BXz])
	z = geompy.MakeFace(W_z, 1)
	W_Z = geompy.MakeWire([AyZ, BxZ, AYZ, BXZ])
	Z = geompy.MakeFace(W_Z, 1)

	sol = geompy.MakeCut(z, sol_bat)

	shell = geompy.MakeShell([x, X, y, Y, sol, sol_bat, Z])
	solid = geompy.MakeSolid([shell])

	return solid


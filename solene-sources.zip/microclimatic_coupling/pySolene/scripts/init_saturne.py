#!/bin/python
'''
 *
 *  Copyright 2010-2013 Laurent Malys (CERMA, UMR 1563 AAU, CNRS /
 *                                  Ecole d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
'''

#scipt saturne

sim.familles.importer_from_xml(sim.chemin_familles_xml)
sim.SatCommand.recuperer_listes_from_famille(sim.familles)
sim.SatCommand.copier_geometrie(sim.chemin_geometrie)
sim.SatCommand.ecrire_subroutines()
sim.SatCommand.chemins['conf_xml'] = sim.SatCommand.chemins['data'] +'/canyon_prelim_vent.xml'
sim.SatCommand.creer_param_xml()
sim.SatCommand.changer_nb_processeurs(2)
sim.SatCommand.definir_meteo(sim.meteo_liste[0])

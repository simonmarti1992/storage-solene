'''
 *
 *  Copyright 2010-2013 Laurent Malys (CERMA, UMR 1563 AAU, CNRS /
 *                                  Ecole d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
'''

from main import *

commande_h_norm = 'h = 5.85 + 1.7 * v'

def ret_h(v):
    exec(commande_h_norm)
    return h


def lire_profil(nom_fichier):
    ff = open(nom_fichier)
    ff = ff.readlines()
    for i in range(len(ff)):
        ff[i] = ff[i].split()

    ff = np.float32(ff)
    profil = ff.transpose()

    return profil

def ret_v0_from_profil(profil, geometrie):
    """
    retourne les valeurs des vitesses pour chaque triangle 
    en fonction d un profil vertical de vent
    """
    v0 = np.zeros(geometrie.n_triangles)
    z = geometrie.triangles.cdg.transpose()[2]

    for i in range(len(z)):
        v0[i] = interpol_multiline(z[i], profil[0], profil[1])

    v10 = interpol_multiline(10, profil[0], profil[1])

    return v0/v10

def h_from_v(v):
    return ret_h(v0*v)

nom_xml = '/home/laurent/Couplage/immeuble_68_coarse/immeuble_68_coarse.xml'
sim = SimulationCouplee(nom_xml)
geo = sim.geom_sol
nom_fichier_profil = '/home/laurent/Simulations/Magdalena/ProfilV'
    
profil = lire_profil(nom_fichier_profil)
v0 = ret_v0_from_profil(profil, geo)



#!/usr/bin/python
# -*- coding: utf-8 -*-
'''
 *
 *  Copyright 2010-2013 Laurent Malys (CERMA, UMR 1563 AAU, CNRS /
 *                                  Ecole d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
'''

"""
Script de conversion de fichiers SOLENE vers PARAVIEW

.cir (geometrie) et .val (donnees) vers .vtu

Created on Thu Jul 22 18:03:27 2010

@author :
    Laurent Malys, Laboratoire CERMA, UMR 1563
    laurent.malys@cerma.archi.fr
"""

import os
from optparse import OptionParser

from vtkFile import VtkFile
from solFile import read_cir, read_val

usage = "python sol2vtk.py [options] geometrie.cir val1 val2 ... sortie.vtu"
parser = OptionParser(usage=usage)
                  
parser.add_option("-a", "--export-all", action = 'store_true',
                  dest="mode_tout", default=False,
                  help="exporte tous les val vers vtu")
                  
parser.add_option("-r", "--directory", action = 'store',
                  dest="directory", default=False,
                  help="exporte tous les val dans le repertoire -directory- vers vtu")  

help_time_mode =\
"""
creer des fichiers dependants du temps,       
argument = nombre d'elements de temps separe par '_'       
ex: radical_21_6_12H00.val : nombre d'elements = 3
"""

parser.add_option("-t", "--time-mode",
                  dest="time_mode", 
                  help=help_time_mode)
                  


parser.add_option("-n", "--variable-name",
                  dest="variable_name")

(options, args) = parser.parse_args()


def return_args_directory(directory):
    """
    return -geometrie- and -list_val- present in -directory-
    """
    list_fichier = os.listdir(directory)
    list_cir = []
    list_val = []
    for fichier in list_fichier:
        if fichier[-4:] == '.cir':
            list_cir.append(fichier)
        elif fichier[-4:] == '.val':
            list_val.append(os.path.join(directory, fichier))
            
    if len(list_cir) > 1:
        print 'plusieurs geometries disponibles :'
        for no_cir in range(len(list_cir)):
            print '\t [%s] %s' % (no_cir, list_cir[no_cir])
        no_cir = int(raw_input("numero geometrie cir ?"))
        geometrie = os.path.join(directory, list_cir[no_cir])
    elif len(list_cir) == 0:
        print 'pas de geometrie cir trouvee dans le repertoire'
    else :
        geometrie = os.path.join(directory, list_cir[0])
        
    return geometrie, list_val
    
def split_radical_suffix(file_name, n_date = 3):
    """
    split the -file name- in 2 part according to the number of date 
    elements
    """
    file_name = file_name.split('_')
    
    suffix = ''
    for date in range(n_date, 0, -1):
        suffix += '_' + file_name[-date]
    suffix = suffix[1:]
        
    radical = ''    
    for word in file_name[:-n_date]:
        radical += word + '_'
    radical = radical[:-1]
    return radical, suffix
    
def get_suffix_list(list_val, n_date = 3):
    """
    get the list of suffixes and sort 
    """
    suffix_list = []
    for val in list_val:
        suffix_list.append(split_radical_suffix(val, n_date = n_date)[1])
    suffix_list = list(set(suffix_list))
    suffix_list.sort()
    
    return suffix_list

geometrie = args[0]
list_val = args[1:-1]
sortie    = args[-1]

if sortie[-4:] == '.vtu':
    sortie = sortie[:-4]

if options.directory:
    geometrie, list_val = return_args_directory(options.directory)
            
if options.mode_tout:
    geometrie, list_val = return_args_directory('.')
    
geom = read_cir(name = geometrie)
    
if options.time_mode:
    n_date = int(options.time_mode)
    list_suffix = get_suffix_list(list_val, n_date = n_date)
    no_vtk = 0
    for suffix in list_suffix:
        print suffix
        vtk_name = '%s_%s.vtu' % (sortie, no_vtk)
        vtk = VtkFile(vtk_name, geom = geom)
        for val in list_val:
            if suffix in val:
                data_name = split_radical_suffix(val, n_date = n_date)[0]
                data_value =read_val(name = val, geom = geom)
                
                vtk.ajouter_donnee(data_value, data_name)
        vtk.close_xml()
        no_vtk += 1
    print list_suffix
        
else:
    vtk = VtkFile(sortie + '.vtu', geom = geom)
    for val in list_val:
        data_name = os.path.split(val)[-1]
        data_name = data_name[:-4]
        
        data_value = read_val(val, geom = geom)
        
        vtk.ajouter_donnee(data_value, data_name)
    vtk.close_xml()
        
        
    

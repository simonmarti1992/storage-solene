'''
 *
 *  Copyright 2010-2013 Laurent Malys (CERMA, UMR 1563 AAU, CNRS /
 *                                  Ecole d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
'''

"""
OBSOLETE : tout est dans -main.py-
"""


import geom
import hdfFile
import solFile
import solEnv
import solCommand
import satCommand
import utils
import data
import main
import vtkFile
import famille
import numpy

nom_cas = 'donnees'

"""
fonctions
"""
def test_convergence(iter_old, iter):
    """
    effectue le test de convergence entre les fichiers iter_old et iter (.val)
    renvoie true si cv
    """
    
    ecart_max = 1.0
    ecart_moy = 0.1
    
    val_iter_old = solFile.ValFile(iter_old)
    val_iter_old.lire()
    iter_old_valeur = val_iter_old.extraire_val()
    
    val_iter = solFile.ValFile(iter)
    val_iter.lire()
    iter_valeur = val_iter.extraire_val()
    
    if max(abs(iter_valeur - iter_old_valeur)) > ecart_max:
        return False
    
    if numpy.mean(abs(iter_valeur - iter_old_valeur)) > ecart_moy:
        return False
   
    return True

    

"""
recuperation des donnees geometriques et donnees/parametres entree
"""


sim = main.SimulationCouplee(nom_cas) # nom du cas dont il existe deja un .cpl
simulSol = sim.SimulSol
geom_sol = sim.geom_sol

simulSat = sim.SimulSat
geom_sat = sim.geom_med


for carac in carac_transitoire:
    if carac.init == True :
        sim.solEnv.creer_descripteur(carac.nom)



"""
initialisation du calcul CFD
"""

# lancer une calcul Saturne avec options
    # modeles physiques
    # nombre d'iterations
    # 


"""
initialisation du calcul Solene
"""



"""
debut de la boucle sur les pas de tps
"""

for timestep in list_timestep :
    suffixe = list_timestep_sol[timestep]
    print "pas de temps %s" % suffixe


    """
    debut de la boucle d'iteration
    """

def convergence_timestep(time_step):

    iteration = 0
    convOK = 0
    while not convOK :
        os.rename(iter, iter_old)
        simulSol.simulation_solene(timestep)
        
        # test convergence TSurface
                
        convOK= test_convergence(iter_old, iter)
        iteration += 1
        
        if not convOK :
            val2dat(simulSol.nom_val_Ts, simulSat.nom_dat_Ts, geom_solene)
            val2dat(simulSol.nom_val_Flatent, simulSat.nom_dat_Flatent, geom_solene)
            val2dat(simulSol.nom_val_Fradiatif, simulSat.nom_dat_Fradiatif, geom_solene)
            
            # en option, conserver les liens geometriques pour utiliser geom ?
            
            simulSat.simulation_transport_saturne()
            
            dat2val(simulSat.nom_dat_Tair, simulSol.nom_val_Tair, geom_solene)
            dat2val(simulSat.nom_dat_hc, simulSol.nom_val_hc, geom_solene)
            dat2val(simulSat.nom_dat_Wair, simulSol.nom_val_Wair, geom_solene)
        
        else :
            print "les temperatures sont convergees !"



"""
stockage des donnees a post traiter
"""

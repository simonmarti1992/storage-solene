'''
 *
 *  Copyright 2010-2013 Laurent Malys (CERMA, UMR 1563 AAU, CNRS /
 *                                  Ecole d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
'''

import os
import sys
import time
from utils import lire_fichier_tab
import numpy as np
from pylab import *

def parse_listing(f):
    tt = open(f, 'r').readlines()
    noms_var = 'Pressure', 'VelocityX', 'VelocityY','VelocityZ','TurbEner','Dissip','TempC','scalar1'
    conv = {}
    for i in noms_var:
        conv[i] = []
    for i in tt:
        for cle, it in conv.items():
            if 'c  %s'%cle in i:
                it.append(float(i.split()[-2]))
    return conv

def parse_energy(f):
    yy = lire_fichier_tab(f)
    ener = np.float32(yy[2])
    diff = [0]
    for i in range(1,len(ener)):
        diff.append(ener[i] - ener[i-1])
    return diff


def is_over(f):
    if 'END OF CALCULATION' in open(f).read():
        return True
    else:
        return False
    
def ploplot(conv, diff):
    subplot(211)
    plot(diff)
    yscale('log')
    plt.grid()
    subplot(212)
    yscale('log')
    grid()
    for cle, it in conv.items():
        plot(it, label = cle)
        
def update(listing, energy):
    diff = parse_energy(energy)
    conv = parse_listing(listing)
    clf()
    ploplot(conv, diff)
    draw()

nom_cas = sys.argv[1]
listing = os.path.join(nom_cas, 'listing')
energy = os.path.join(nom_cas, 'energy.hst')
date_old = time.time()
interactive(True)
plot(0,0)
show()

if len(sys.argv)==3:
    while 1:
        update(listing, energy)
        time.sleep(2)
else:
    while not is_over(listing):
        print 'toto'
        date = os.path.getmtime(listing) 
        if date>date_old:
            print 'tata'
            date_old = date
            update(listing, energy)
        time.sleep(2)

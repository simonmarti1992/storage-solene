# -*- coding: utf-8 -*-
'''
 *
 *  Copyright 2010-2013 Laurent Malys (CERMA, UMR 1563 AAU, CNRS /
 *                                  Ecole d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
'''

"""
Created on Fri Jun 11 18:42:07 2010

@author: laurent
"""

import sys
import os
import getopt

from numpy import *

from geom import *
from solFile import *
from data import *

geometrie = sys.argv[1]
chemin_dat = sys.argv[2]
chemin_val = sys.argv[3]

cir = CirFile(geometrie)
cir.lire()
cir.extraire_geom_triangle()

cir.geom.calculer_cdg()

con_dat_val, lst_val = recuperer_xyz_val(chemin_dat, cir.geom)

val = ValFile(chemin_val, geom = cir.geom)
val.ecrire_descripteur_cont(lst_val)

'''
 *
 *  Copyright 2010-2013 Laurent Malys (CERMA, UMR 1563 AAU, CNRS /
 *                                  Ecole d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
'''

import numpy as np
from solFile import *
from main import *
from random import random
import math
import marshal

lst_param = 'L LAI k alb a_h_veg b_h_veg a_h_ainf capacite run_off porosite lambd alpha_lat epaisseur'.split()

def ret_lsd(a, b):
    return np.sqrt((np.array(a)-np.array(b))**2).mean()


class HepiaWall():
    def __init__(self, sim, L, LAI, k, albedo, init_meteo = True):
        self.sim = sim
        self.lst_tr = [28, 29, 38, 48]
        self.param = {}
        self.param['L'] = L
        self.param['LAI'] = LAI
        self.param['k'] = k
        self.param['alb'] = albedo
        if init_meteo:
            self.irrig = self.sim.extraire_meteo('Irrig_Tot(2)')
            self.drainage = self.sim.extraire_meteo('Drain_Tot(1)')
            self.Teau = self.sim.extraire_meteo('Teau')

        # param sensibilite
        self.param['a_h_veg'] = 1.0
        self.param['b_h_veg'] = 4.0
        self.param['a_h_ainf'] = 0.5
        self.param['capacite'] = 3500
        self.param['run_off'] = 0.2
        self.param['porosite'] = 0.2
        self.param['lambd'] = 1
        self.param['alpha_lat'] = 0.5
        self.param['epaisseur'] = 0.07

        self.bool_veg = self.sim.solEnv.ret_bool_carac('latent')

    def get_T_ref(self, Tveg, Tsub):
        self.Tveg = Tveg
        self.Tsub = Tsub

    def def_param(self):
        #self.param['a_h_veg'] = 0.5 + 1.5*random()
        #self.param['b_h_veg'] = 3 + 4.0 * random()
        #self.param['a_h_ainf'] = 0.7 * random()
        self.param['alb'] = 0.1 + 0.4 * random()
        self.param['k'] = 0.5 + 0.7 * random()
        self.param['LAI'] = 1 + 3 * random()
        self.param['capacite'] = 1500 + 4000*random()
        self.param['run_off'] = 0.4 * random()
        self.param['alpha_lat'] = random()
        self.param['epaisseur'] = 0.05 + 0.15 * random()
        #self.param['porosite'] = 0.4 * random()
        #self.param['lambd'] = 0.5 + 1.5 * random()

    def def_param_dic(self, dic):
        for p in lst_param:
            if dic.has_key(p):
                self.param[p] = dic[p]

    def res(self, var, i):
        return self.sim.resul_sol.extraire_evolution_triangle(var,i)

    def save_resu(self, nom, retour = False, lsd = False):
        dic_resu = {}
        dic_resu['L'] = self.param['L']
        dic_resu['LAI'] = self.param['LAI']
        dic_resu['k'] = self.param['k']
        dic_resu['alb'] = self.param['alb']
        dic_resu['a_h_veg']  = self.param['a_h_veg']
        dic_resu['b_h_veg'] = self.param['b_h_veg']
        dic_resu['a_h_ainf'] = self.param['a_h_ainf']
        dic_resu['capacite'] = self.param['capacite']
        dic_resu['run_off'] = self.param['run_off']
        dic_resu['porosite'] =  self.param['porosite']
        dic_resu['lambd'] =  self.param['lambd']
        dic_resu['alpha_lat'] = self.param['alpha_lat']
        dic_resu['epaisseur'] = self.param['epaisseur']
        dic_resu['Tn1'] = self.res('Tn1', 28).tolist()
        dic_resu['Tn3'] = self.res('Tn3', 28).tolist()
        dic_resu['Tse'] = self.res('Tse', 28).tolist()
        dic_resu['Ta'] = self.res('Ta', 28).tolist()
        dic_resu['Tse_veg'] = self.res('Tse_veg', 28).tolist()
        dic_resu['GLO_Total_Net'] = self.res('GLO_Total_Net', 28).tolist()
        dic_resu['flux_latent'] = self.res('flux_latent', 28).tolist()
        dic_resu['stock'] = self.dic_stock[28].tolist()
        dic_resu['drain'] = self.dic_drain[28].tolist()
        dic_resu['ccc'] = self.ccc
        if lsd:
            dic_resu['lsd_veg'] = ret_lsd(self.Tveg, dic_resu['Tse'])
            dic_resu['lsd_sub'] = ret_lsd(self.Tsub, dic_resu['Tn3'])
            dic_resu['lsd'] = dic_resu['lsd_sub'] + dic_resu['lsd_veg']
        fichier_resu = open(nom, 'wb')
        marshal.dump(dic_resu, fichier_resu)
        fichier_resu.close()
        fichier_resu = None
        if retour:
            return dic_resu
        else:
            dic_resu = None

    def def_carac_veg_scene(self):
        geo = self.sim.geom_sol
        lst_carac = self.sim.SolCommand.carac
        bool_veg = self.bool_veg
        
        Ca_val =np.zeros(geo.n_triangles)
        Cf_val = np.zeros(geo.n_triangles)
        LAI_val =np.zeros(geo.n_triangles) + 1
        tau_val = read_val(lst_carac['transmittance_GLO'], geo)
        alb_val = read_val(lst_carac['albedo'], geo) 
        
        Ca_val[bool_veg] = 1200 * self.param['L']
        Cf_val[bool_veg] = 2400 * self.param['LAI']
        LAI_val[bool_veg] = self.param['LAI']
        tau_val[bool_veg] = math.exp(-self.param['k']*self.param['LAI'])
        alb_val[bool_veg] = self.param['alb']
        
        write_val(lst_carac['Ca'], geo, Ca_val)
        write_val(lst_carac['Cf'], geo, Cf_val)
        write_val(lst_carac['LAI'], geo, LAI_val)
        write_val(lst_carac['transmittance_GLO'], geo, tau_val)
        write_val(lst_carac['albedo'], geo, alb_val)        

    def def_meteo_veg_scene(self, i):
        geo = self.sim.geom_sol
        lst_carac = self.sim.SolCommand.carac
        lst_var = self.sim.SolCommand.var
        bool_veg = self.bool_veg
        
        v_val = self.sim.solEnv.ret_v_sat(i)
        hc_val = 5.7 + 3.8 * v_val
        h_pa_val = np.zeros(geo.n_triangles)
        h_ainf_val = np.zeros(geo.n_triangles)
    
        hc_val[bool_veg] = v_val * self.param['a_h_veg'] + self.param['b_h_veg']
        h_pa_val[bool_veg] = self.ret_h_pa(v_val * self.param['a_h_ainf'])
        h_ainf_val[bool_veg] = self.ret_h_ainf(v_val * self.param['a_h_ainf'])
        
        write_val(lst_var['hc'], self.sim.geom_sol, hc_val)
        write_val(lst_carac['h_pa'], self.sim.geom_sol, h_pa_val)
        write_val(lst_carac['h_ainf'], self.sim.geom_sol, h_ainf_val)
        write_val(lst_carac['v'], self.sim.geom_sol, v_val)
        
    ## caracteristique de la vegetation 
    def def_carac_veg(self):
        geo = self.sim.geom_sol
        lst_var = self.sim.SolCommand.var
        
        Ca_val =np.zeros(geo.n_triangles)
        Cf_val = np.zeros(geo.n_triangles)
        LAI_val =np.zeros(geo.n_triangles) + 1
        tau_val = np.zeros(geo.n_triangles)
        alb_val = read_val(self.sim.SolCommand.carac['albedo'], geo) 
        for tr in self.lst_tr:
            Ca_val[tr] = 1200 * self.param['L']
            Cf_val[tr] = 2400 * self.param['LAI']
            LAI_val[tr] = self.param['LAI']
            tau_val[tr] = math.exp(-self.param['k']*self.param['LAI'])
            alb_val[tr] = self.param['alb']
        write_val(self.sim.SolCommand.carac['Ca'], geo, Ca_val)
        write_val(self.sim.SolCommand.carac['Cf'], geo, Cf_val)
        write_val(self.sim.SolCommand.carac['LAI'], geo, LAI_val)
        write_val(self.sim.SolCommand.carac['transmittance_GLO'], geo, tau_val)
        write_val(self.sim.SolCommand.carac['albedo'], geo, alb_val)

    ## parametres influence par la vegetation
    def def_meteo_veg(self, i):
        geo = self.sim.geom_sol
        lst_var = self.sim.SolCommand.var
        
        ts = self.sim.TimeStep.liste_ts_sol[i]
        ts_moins_un = self.sim.TimeStep.liste_ts_sol[i-1]
        v_meteo = self.sim.meteo_liste[i]['v']
        T_meteo = self.sim.meteo_liste[i]['T']

        Tint = np.zeros(self.sim.geom_sol.n_triangles) + 18
        Tint[self.sim.geom_sol.triangles.famille == -5] = T_meteo
        write_val('%s_%s'% (self.sim.SolCommand.var['Tn2'], ts), self.sim.geom_sol, Tint)
        write_val('%s_%s'% (self.sim.SolCommand.var['Tn2'], ts_moins_un), self.sim.geom_sol, Tint)

        hc_val = np.zeros(self.sim.geom_sol.n_triangles) + 5.85 + 1.7 * v_meteo
        h_pa_val = np.zeros(geo.n_triangles)
        h_ainf_val = np.zeros(geo.n_triangles)
        v_val = np.zeros(geo.n_triangles) + 1
        for tr in self.lst_tr:
            hc_val[tr] = v_meteo * self.param['a_h_veg'] + self.param['b_h_veg']
            h_pa_val[tr] = self.ret_h_pa(v_meteo * self.param['a_h_ainf'])
            h_ainf_val[tr] = self.ret_h_ainf(v_meteo * self.param['a_h_ainf'])
            v_val[tr] = v_meteo * self.param['a_h_ainf']
        write_val(self.sim.SolCommand.var['hc'], self.sim.geom_sol, hc_val)
        write_val(self.sim.SolCommand.carac['h_pa'], self.sim.geom_sol, h_pa_val)
        write_val(self.sim.SolCommand.carac['h_ainf'], self.sim.geom_sol, h_ainf_val)
        write_val(self.sim.SolCommand.carac['v'], self.sim.geom_sol, v_val)
        
    def ret_h_ainf(self, v):
        return self.ret_R(v)*self.param['L']*1000/3600
    
    def ret_R(self, v):
        return 125 + (1000 - 125) * v /10

    def ret_h_pa(self, v):
        return 2 * self.param['LAI'] * 1200 / self.ret_re(v)
    
    def ret_re(self, v):
        return (1174+0.1)**0.5 / (207*v)**0.25

    def ret_transmittance(self):
        return math.exp(-self.param['k']*self.param['LAI'])
    
    ## analyse flux

    def get_var(nom_var, n_ts = None):
        if n_ts:
            return read_val('%s_%s'%(self.sim.SolCommand.var[nom_var], n_ts), self.sim.geom_sol)
        else:
            return read_val(self.sim.SolCommand.var[nom_var], self.sim.geom_sol)

    def get_carac(self, nom_carac):
        return read_val(self.sim.SolCommand.carac[nom_carac], self.sim.geom_sol)

    ## Flux
    def ret_flux_scene(self, i):
        dic_flux = {}
        for p in self.param.keys():
            self.param[p] = dic_resu[p]
        # init
        dic_flux['clo_surf'] = []
        dic_flux['clo_veg'] = []
        dic_flux['glo_surf'] = []
        dic_flux['glo_veg'] = []
        dic_flux['lat_surf'] = []
        dic_flux['lat_veg'] = []
        dic_flux['conv_surf'] = []
        dic_flux['conv_veg'] = []
        dic_flux['conv_pa'] = [] 
        tau = self.get_carac('transmittance_GLO')[i]
        albedo = self.get_carac('albedo')[i]
        hr = 6
        for t in range(len(self.sim.SolCommand.liste_ts_sol)):
            ts = self.sim.SolCommand.liste_ts_sol[t]
            sol_tot = self.get_var('flux_sol_total', n_ts = ts)[i]
            f_lat = self.get_var('flux_latent',n_ts = ts)[i]
            tse = self.get_var('Tse', n_ts = ts)[i]
            tse_veg = self.get_var('Tse_veg', n_ts = ts)[i]
            ta = self.get_var('Ta', n_ts = ts)[i]
            
            Tair = self.sim.meteo_liste[ts]['T']
            v_val = self.sim.solEnv.ret_v_sat(ts)[i]
            hc_val = v_val * self.param['a_h_veg'] + self.param['b_h_veg']
            h_pa  = self.ret_h_pa(v_val * self.param['a_h_ainf'])
            h_ainf = self.ret_h_ainf(v_val * self.param['a_h_ainf'])

            dic_flux['clo_surf'].append(tau * sol_tot)
            dic_flux['clo_veg'].append((1-tau-albedo) * sol_tot)
            dic_flux['glo_veg'].append(self.get_var('GLO_Total_Net', n_ts = ts)[i])
            dic_flux['glo_surf'].append(hr* (tse - tse_veg))
            dic_flux['lat_surf'].append((1-self.param['alpha_lat']) * f_lat)
            dic_flux['lat_veg'].append(self.param['alpha_lat'] * f_lat)
            dic_flux['conv_veg'].append(h_ainf * (Tair - ta))
            dic_flux['conv_surf'].append(hc * (ta - tse_veg))
            dic_flux['conv_pa'].append(h_pa * (tse - ta))
      
        # bilan
        dic_flux['clo_surf'] = np.array(dic_flux['clo_surf']) 
        dic_flux['clo_veg'] = np.array(dic_flux['clo_veg'])
        dic_flux['glo_surf'] = np.array(dic_flux['glo_surf'])
        dic_flux['glo_veg'] = np.array(dic_flux['glo_veg'])
        dic_flux['conv_surf'] = np.array(dic_flux['conv_surf'])
        dic_flux['conv_veg'] = np.array(dic_flux['conv_veg'])
        dic_flux['conv_pa'] = np.array(dic_flux['conv_pa'])
        dic_flux['bilan_surf'] = -dic_flux['clo_surf']-dic_flux['glo_surf']-dic_flux['conv_surf']-dic_flux['lat_surf']
        dic_flux['bilan_veg'] = -dic_flux['clo_veg'] - dic_flux['glo_veg'] - dic_flux['conv_veg'] - dic_flux['lat_veg'] + dic_flux['conv_surf'] + dic_flux['glo_surf']
        return dic_flux



    def ret_flux(self, dic_resu):
        dic_flux = {}
        for p in self.param.keys():
            self.param[p] = dic_resu[p]
        # clo
        dic_flux['clo_surf'] = []
        dic_flux['clo_veg'] = []
        tau = self.ret_transmittance()
        for i in range(len(self.sim.SolCommand.liste_ts_sol)):
            dic_flux['clo_surf'].append(tau * self.sim.meteo_liste[i]['Gv'])
            dic_flux['clo_veg'].append((1-tau-self.param['alb']) * self.sim.meteo_liste[i]['Gv'])
        # GLO
        hr = 6
        dic_flux['glo_surf'] = []
        dic_flux['glo_veg'] = dic_resu['GLO_Total_Net']
        for i in range(len(self.sim.SolCommand.liste_ts_sol)):
            dic_flux['glo_surf'].append(hr* (dic_resu['Tse'][i] - dic_resu['Tse_veg'][i]))
        # lat
        dic_flux['lat_surf'] = (1-self.param['alpha_lat']) * np.array(dic_resu['flux_latent'])
        dic_flux['lat_veg'] = self.param['alpha_lat'] * np.array(dic_resu['flux_latent'])
        # conv
        dic_flux['conv_surf'] = []
        dic_flux['conv_veg'] = []
        dic_flux['conv_pa'] = []
        for i in range(len(self.sim.SolCommand.liste_ts_sol)):
            h_ainf = self.ret_h_ainf(self.sim.meteo_liste[i]['v'] * self.param['a_h_ainf'])
            dic_flux['conv_veg'].append(h_ainf * (self.sim.meteo_liste[i]['T'] - dic_resu['Ta'][i]))
            hc = self.sim.meteo_liste[i]['v'] * self.param['a_h_veg'] + self.param['b_h_veg']
            dic_flux['conv_surf'].append(hc * (dic_resu['Ta'][i] - dic_resu['Tse_veg'][i]))
            h_pa = self.ret_h_pa(self.sim.meteo_liste[i]['v'] * self.param['a_h_ainf'])
            dic_flux['conv_pa'].append(h_pa * (dic_resu['Tse'][i] - dic_resu['Ta'][i]))
        # bilan
        dic_flux['clo_surf'] = np.array(dic_flux['clo_surf']) 
        dic_flux['clo_veg'] = np.array(dic_flux['clo_veg'])
        dic_flux['glo_surf'] = np.array(dic_flux['glo_surf'])
        dic_flux['glo_veg'] = np.array(dic_flux['glo_veg'])
        dic_flux['conv_surf'] = np.array(dic_flux['conv_surf'])
        dic_flux['conv_veg'] = np.array(dic_flux['conv_veg'])
        dic_flux['conv_pa'] = np.array(dic_flux['conv_pa'])
        dic_flux['bilan_surf'] = -dic_flux['clo_surf']-dic_flux['glo_surf']-dic_flux['conv_surf']-dic_flux['lat_surf']
        dic_flux['bilan_veg'] = -dic_flux['clo_veg'] - dic_flux['glo_veg'] - dic_flux['conv_veg'] - dic_flux['lat_veg'] + dic_flux['conv_surf'] + dic_flux['glo_surf']
        return dic_flux

    ## bilan hydrique
    def fevapFromStock(self, saturation):
        fevap = np.zeros(self.sim.geom_sol.n_triangles)
        for i in self.lst_tr:
            fevap[i] = saturation*0.8
        write_val(self.sim.SolCommand.carac['evaporation'], self.sim.geom_sol, fevap)

    def def_mat_cap(self, saturation):
        rhoc_s = 1350
        rhoc_w = 4185
        capacite = (1-self.param['porosite']) * rhoc_s + self.param['porosite'] * saturation* rhoc_w
        self.sim.familles.materiaux['beton1']['conductivite'] = self.param['lambd']
        self.sim.familles.materiaux['beton2']['conductivite'] = self.param['lambd']
        self.sim.familles.materiaux['beton1']['capacite_thermique'] = capacite
        self.sim.familles.materiaux['beton2']['capacite_thermique'] = capacite
        self.sim.familles.materiaux['beton1']['masse_volumique'] = 1000
        self.sim.familles.materiaux['beton2']['masse_volumique'] = 1000
        self.sim.familles.familles['facade'].couches[0][1] = self.param['epaisseur']/2.
        self.sim.familles.familles['facade'].couches[1][1] = self.param['epaisseur']/2.
        self.sim.solEnv.creer_fichier_paroi()
        return capacite

    ## simulations
    def lancer_simul_veg_eau(self):
        tt = Chrono('simulation_ts_veg', self.sim.nom_cas)
        lst_ts = self.sim.SolCommand.liste_ts_sol


        self.dic_stock = None
        self.dic_drain = None
        self.ccc = None

        # initialisation
        self.dic_stock = {}
        self.dic_drain = {}
        stock = {}
        stock_max = {}
        self.ccc = []
        for i in self.lst_tr:
            self.dic_stock[i] = np.zeros(len(lst_ts))
            self.dic_drain[i] = np.zeros(len(lst_ts))
            stock_max[i] = self.param['capacite']
            stock[i] = 0 

        for ts in range(1, len(lst_ts)):
            Teau_ts = 0
            Qeau = 0
            avant = lst_ts[ts-1]
            apres = lst_ts[ts]
            self.def_meteo_veg(ts)
            self.sim.solEnv.definir_meteo(ts, def_vit = False)
            h_i = self.sim.meteo[apres]['v'] * 1.7 + 5.85

            # bilan hydrique
            Teau_ts = self.Teau[ts]
            Qeau =  self.irrig[ts] + self.drainage[ts]
            #Qeau = 0
            for i in self.lst_tr:
                stock[i] += self.irrig[ts]*(1-self.param['run_off'])
                self.dic_drain[i][ts] += self.irrig[ts]*self.param['run_off']
                if stock[i] >stock_max[i]:
                    self.dic_drain[i][ts] += stock[i] - stock_max[i]
                    stock[i] = stock_max[i]
            saturation  = float(stock[28])/float(stock_max[28])
            cap = self.def_mat_cap(saturation)
            self.ccc.append(cap)
            self.fevapFromStock(saturation)

            # simulation
            Tn3_avant = '%s_%s'%(self.sim.SolCommand.var['Tn3'], avant)
            Tn3_apres = '%s_%s'%(self.sim.SolCommand.var['Tn3'], apres)
            self.sim.SolCommand.simulation_Ts_veg_sens(avant,
                                                       apres,
                                                       meteo = True,
                                                       nom_commande = 'simulation_Ts_VEG_sens_hepia_2',
                                                       args_plus=[Teau_ts, Qeau, self.param['alpha_lat'], Tn3_avant, Tn3_apres, h_i])
            flux_lat = read_val('%s_%s' % (self.sim.SolCommand.var['flux_latent'], apres), self.sim.geom_sol)
            for i in self.lst_tr:
                stock[i] -= flux_lat[i] * 3600/2257
                if stock[i] < 0:
                    stock[i] = 0
                self.dic_stock[i][ts] = stock[i]
        self.sim.solEnv.recuperer_resultat(['Tse', 'Tn1', 'Tn3', 'Ta', 'Tse_veg', 'flux_latent', 'GLO_Total_Net'])
        self.sim.SolCommand.fichier_sortie.close()
        os.remove(self.sim.SolCommand.chemin_fichier_sortie)
        self.sim.SolCommand.fichier_sortie = None
        self.sim.SolCommand.fichier_sortie = open(self.sim.SolCommand.chemin_fichier_sortie, 'w') 
        tt.fin()
      

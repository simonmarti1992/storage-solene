#!/usr/bin/python
# -*- coding: utf-8 -*-
'''
 *
 *  Copyright 2010-2013 Laurent Malys (CERMA, UMR 1563 AAU, CNRS /
 *                                  Ecole d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
'''

"""@package solScripts
Gestion des scripts externes liés à solene :
convertisseurs, opérations géométriques

Created on Fri Nov  5 13:14:03 2010

@author :
    Laurent Malys, Laboratoire CERMA, UMR 1563
    laurent.malys@cerma.archi.fr

"""
import os
import subprocess
import numpy as np

from utils import *
from solFile import *
from geom import *

import geo2salome

# import geo2salome

def sol_convert(fichier_sol, fichier_geo, type = 'GEO'):
    """
    multiconvertisseur
    choix possibles pour type : NATIVE, STL, CIRMesh, CIR, VTU, VTUMesh, GEO, GEOMesh
    """
    
    com = ['java',
           '-jar',
           '/opt/solene/convertisseur/engine-0.0.2-jar-with-dependencies.jar',
           '-input',
           fichier_sol,
           '-type',
           type,
           '-output',
           fichier_geo]
           
    subprocess.call(com)
    
def salome_convert(fichier_geo, fichier_python):
    """
    converti un fichier geo en script pour creer la geometrie sous salome
    """
    texte = geo2salome.creer_script_from_geo(fichier_geo)
    ecrire_fichier(fichier_python, texte)
    
def bati_sur_sol(fichier_in, fichier_out, sol = None, z = 0):
    
    if not sol:
        sol = os.path.join(os.environ['SLN_TEMP'], 'solTEMP.cir')
        creer_sol(fichier_in, sol, z = z)
    

    if sol[-4:] == '.cir':
        sol = sol[:-4]
    if fichier_in[-4:] == '.cir':
        fichier_in = fichier_in[:-4]
    if fichier_out[-4:] == '.cir':
        fichier_out = fichier_out[:-4]
            

        
    com = ['bati_sur_sol',
           sol,
           fichier_in,
           fichier_out]
           
    print com
           
    subprocess.call(com)
    
def bati_sur_sol_boite(fichier_in, fichier_out, z = 0):

        
    facade = os.path.join(os.environ['SLN_TEMP'], 'facadesTEMP.cir')
    bas_boite = os.path.join(os.environ['SLN_TEMP'], 'bas_boiteTEMP.cir')
    
    bati_sur_sol(fichier_in, facade)
    creer_bas_boite(fichier_in, bas_boite, z = z)
    concatfic([fichier_in, facade, bas_boite], fichier_out)

    
def creer_bas_boite(fichier_toit, fichier_out, z = 0):
    toit = read_cir(fichier_toit, faces = True)
    for i_point in range(toit.n_points):
        toit.points[i_point][2] = z
        
    write_cir(fichier_out, geom = toit, faces = True)
    
    
def concatfic(liste_fichier, fichier_out):
    com = ['concatfic',
           '-m']
           
    for fichier in liste_fichier:
        if fichier[-4:] == '.cir':
            fichier = fichier[:-4]
        com.append(fichier)
        
    if fichier_out[-4:] == '.cir':
        fichier_out = fichier_out[:-4]
        
    com.append(fichier_out)
    
    subprocess.call(com)
    
def creer_sol(fichier_geom, fichier_sol, z = 0):
    """
    cree un sol en fonction des limites de la geometrie
    """
    
    geom = read_cir(fichier_geom, faces = True)
    points = geom.points.transpose()
    
    sol = Geom()
    x = min(points[0])-10
    X = max(points[0])+10
    y = min(points[1])-10
    Y = max(points[1])+10
    sol.points = np.array([[x, y, 0], 
                           [x, Y, 0], 
                           [X, Y, 0], 
                           [X, y, 0]])
                           
    sol.faces.points = [[1,2,3,4]]
    
    sol.n_faces = 1
    sol.n_points = 4
    sol.faces.normale = np.array([[0,0,1]])

    
    write_cir(fichier_sol, geom = sol, faces = True)
    
    
def translater_toit(nom_fichier, 
                    nom_fichier_hauteur = None,  
                    fichier_sortie = None):
    """
    translate la géométrie pour la ramener proche de l'origine (par défaut)
    ou de vec_depl (si renseigné)
    """
    
    if nom_fichier[-4:] == '.cir':
        nom_fichier_sol = nom_fichier[:-4]
        
    if not fichier_sortie:
        fichier_sortie = nom_fichier_sol
        
    else:
        if fichier_sortie[-4:] == '.cir':
            fichier_sortie = fichier_sortie[:-4]
        
    geom = read_cir(nom_fichier, faces = True)
    
    # callage x et y
    points = geom.points.transpose()
    minx = min(points[0])
    miny = min(points[1])
    
    # hauteur du sol
    if nom_fichier_hauteur:
        h_sol = calculer_hsol(nom_fichier, nom_fichier_hauteur)
        minz = h_sol.mean()
    else:
        minz = 0
        
    com = ['translation',
            nom_fichier_sol,
            str(-minx),
            str(-miny),
            str(-minz),
            fichier_sortie]
               
    subprocess.call(com)
        
def aplanir_toit(fichier_in, fichier_out = None):
    geom = read_cir(fichier_in, faces = True)
    geom.aplanir_toit()
    write_cir(fichier_in, geom, faces = True)
    

def calculer_hsol(nom_toits, nom_hauteur_bat):
    
    geom_toit = read_cir(nom_toits, faces = True)
        
    hauteur_bat = open(nom_hauteur_bat)
    hauteur_bat = hauteur_bat.readlines()
    
    h_sol = []
    s_max = []
    for i_face in range(geom_toit.n_faces):
        zz = geom_toit.points[np.array(geom_toit.faces.points[i_face])-1].transpose()[2]
        h_sol.append(max(zz) - float(hauteur_bat[i_face]))
        
#    points = []
#    for i_face in range(geom_toit.n_faces):
#        for i_point in geom_toit.faces.points[i_face]:
#            point = geom_toit.points[i_point-1]
#            point[2] = h_sol[i_face]
#            
#            points.append(point)
#            
#    texte = ''
#    for i_point in range(len(points)):
#        ligne = 'Point(%s) = {%s, %s, %s};\n' % (i_point+1, 
#                                                points[i_point][0],
#                                                points[i_point][1],
#                                                points[i_point][2])
#        texte += ligne
#                                                
#    ecrire_fichier('sol.geo', texte)
#    
#    texte = ''
#    for i in range(geom_toit.n_faces):
#        texte += '%s %s %s\n' % (float(hauteur_bat[i]), s_max[i], h_sol[i])
#        
#    ecrire_fichier('tab_h', texte)
    
    return np.array(h_sol)
        

'''
 *
 *  Copyright 2010-2013 Laurent Malys (CERMA, UMR 1563 AAU, CNRS /
 *                                  Ecole d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
'''

from solFile_trou import *
from vtkFile import *
import shutil, errno
import os
import subprocess
import numpy as np
from utils import *
from solFile import *
from geom import *
from xmlFile import *


def creer_geom(empreinte_bati_shp, nom_dossier_shp, champ_hauteur, nom_scene_cir, s_maille =20) :
    """
    Prepare geometry for solene simulation .cir format : nom_scene_cir
    from BD_Topo data : empreinte_bati_shp in the folder : nom_dossier_shp
    with elevation field : champ_hauteur
    """
    
    creer_dossier("vtu/")
    creer_dossier("cir/")
    chemin_bati_shp =nom_dossier_shp+"/"+empreinte_bati_shp+".shp"
    chemin_bati_cir= "cir/"+empreinte_bati_shp+".cir"
    chemin_sol_cir= "cir/"+empreinte_bati_shp+"_sol.cir"
    chemin_scene_cir ="cir/"+ nom_scene_cir+".cir"
    chemin_scence_cir_triangule_face = "cir/"+ nom_scene_cir
    chemin_scene_tri_cir ="cir/"+ nom_scene_cir+"_tri.cir"
    chemin_scene_vtu="vtu/"+nom_scene_cir+".vtu"
    chemin_scene_tri_vtu="vtu/"+nom_scene_cir+"_tri.vtu"
    chemin_normale_vtu="vtu/"+nom_scene_cir+"_normale.vtu"
    
    extrude_bati(chemin_bati_shp, champ_hauteur, chemin_bati_cir)
    translation(chemin_bati_cir)
    creer_sol_trou(chemin_bati_cir,chemin_sol_cir)
    supprimer_sol_bati(chemin_bati_cir)
    liste_concatfic=[chemin_bati_cir,chemin_sol_cir]
    concatfic(liste_concatfic,chemin_scene_cir ) 
    triangule_face(chemin_scence_cir_triangule_face , s_maille)
    
    scene = read_cir(chemin_scene_cir, faces=True)
    write_vtu_face(scene, chemin_scene_vtu)
    scene_tri = read_cir( chemin_scene_tri_cir )
    write_vtu(chemin_scene_tri_vtu, scene_tri, np.zeros(scene_tri.n_triangles))
    vtk = VtkFile(chemin_normale_vtu, geom =  scene_tri)
    normales = scene_tri.triangles.normale.transpose()
    vtk.ajouter_donnee(normales[0], 'x')
    vtk.ajouter_donnee(normales[1], 'y')
    vtk.close_xml()

    return chemin_scene_cir

    
def extrude_bati(empreinte_bati_shp, champ_hauteur, nom_bati_cir) :
    """
    Extrude buildings from a .shp file : Empreinte_bati_shp 
    and name of the heigth field : champ_hauteur
    Caution : hauteur must be a double type
    """
    com = ["./extrude.sh", empreinte_bati_shp,
	  champ_hauteur, nom_bati_cir]
             
    retcode = subprocess.call(com)
    return retcode


def translation(fichier_in):
    """
    translate the geom .cir
    """
    geom = read_cir(fichier_in, faces = True)
    # Translation (x-xmin) (y-ymin)
    points_transpose = geom.points.transpose()
    points_transpose[0] -= min(points_transpose[0])
    points_transpose[1] -= min(points_transpose[1])
    geom.points = points_transpose.transpose()
    geom.faces.liste_trous = [[]]*geom.n_faces
    write_cir(fichier_in, geom, faces = True)

    return fichier_in

def creer_sol_trou(geom_bati,geom_sol):
    """
    create ground surface from building foot prints
    """
    geom = read_cir(geom_bati, faces = True)
    pts = geom.points.transpose()
    lst_points = []
    lst_trous = []
    lst_points.append(np.array([min(pts[0])-5, min(pts[1])-5, 0]))
    lst_points.append(np.array([min(pts[0])-5, max(pts[1])+5, 0]))
    lst_points.append(np.array([max(pts[0])+5, max(pts[1])+5, 0]))
    lst_points.append(np.array([max(pts[0])+5, min(pts[1])-5, 0]))
    lst_faces = [[1,2,3,4]]
    n_pt = 5
    for i_face in range(geom.n_faces):
	if geom.faces.normale[i_face][2] == 1:
		nouveau_trou = []
		for pt in geom.faces.points[i_face]:
			lst_points.append(geom.points[pt-1])
			nouveau_trou.append(n_pt)
			n_pt += 1
		lst_trous.append(nouveau_trou)
		

    sol = Geom()
    sol.points = np.array(lst_points)
    sol.n_points = len(sol.points)
    sol.n_faces = len(lst_faces)
    sol.faces.points = lst_faces
    sol.faces.liste_trous = [lst_trous]
    print sol.faces.liste_trous
    sol.faces.normale = np.array([[0,0,1]])
    for j in range(sol.n_points):
	sol.points[j][2] = 0


    write_cir_trou(geom_sol, sol, faces = True)
    
    return geom_sol

def supprimer_sol_bati(geom_bati):
    """
    Suppress bulding floor 
    """
    geom = read_cir(geom_bati, faces = True)

    lst_points = []
    lst_faces = []
    n_pt = 1
    for i_face in range(geom.n_faces):
	if geom.faces.normale[i_face][2]  != -1:
		nouvelle_face = []
		for pt in geom.faces.points[i_face]:
			lst_points.append(geom.points[pt-1])
			nouvelle_face.append(n_pt)
			n_pt += 1
		lst_faces.append(nouvelle_face)
		

    bati = Geom()
    bati.points = np.array(lst_points)
    bati.n_points = len(bati.points)
    bati.n_faces = len(lst_faces)
    bati.faces.points = lst_faces
    bati.faces.liste_trous = [[]]*bati.n_faces
    bati.faces.normale=[[0,0,0]]*bati.n_faces
    j=0
    for i_face in range(geom.n_faces):
	if geom.faces.normale[i_face][2]  != -1:
		bati.faces.normale[j]=geom.faces.normale[i_face]
		j=j+1
		


    write_cir(geom_bati, bati, faces = True)
    
    return geom_bati


def triangule_face(nom_geom, s_maille = 20):
    """
    Triangular mesh of the geometry .cir 
    call the external command : 'triangule_face'
    with mesh surface argument = 20 m2
    """
    nom_geom_tri= nom_geom+"_tri"
    com = ['triangule_face',
          nom_geom, nom_geom_tri,
          str(s_maille)]
             
    retcode = subprocess.call(com)
    return retcode
    
    
def concatfic(liste_fichier, fichier_out):
    com = ['concatfic',
           '-m']
           
    for fichier in liste_fichier:
        if fichier[-4:] == '.cir':
            fichier = fichier[:-4]
        com.append(fichier)
        
    if fichier_out[-4:] == '.cir':
        fichier_out = fichier_out[:-4]
        
    com.append(fichier_out)
    
    subprocess.call(com)
    
def creer_dossier(f):
    d = os.path.dirname(f)
    if not os.path.exists(d):
        os.makedirs(d)


def copier(src, dst):
    try:
        shutil.copytree(src, dst)
    except OSError as exc: # python >2.5
        if exc.errno == errno.ENOTDIR:
            shutil.copy(src, dst)
        else: raise
  


def calculer_surface(nom_geom, surface_val):
    """
    """
    com = ['surf_cont', nom_geom, surface_val] 
    
    retcode = subprocess.call(com)
    return retcode

def creer_descripteur_null(nom_geom,null_val):
    """
    """
    surface_val="surf"
    calculer_surface(nom_geom, surface_val)
    nom_geom_tri= nom_geom+"_tri"
    com = ['val_op_val',
          surface_val, "-" , surface_val,
          null_val]
    retcode = subprocess.call(com)
    return retcode
    
    
def initialisation_dossier(nom_chemin_init_simulation,nom_chemin_dossier_solene) : 
	nom_chemin_cir =nom_chemin_dossier_solene+"cir/"
	nom_chemin_vtu =nom_chemin_dossier_solene+"vtu/"
	nom_chemin_cas = nom_chemin_dossier_solene+"cas_en_cours/"
	nom_chemin_resultat ="resultats/"
	nom_initialisation = nom_chemin_dossier_solene+"import/"
	os.chdir(nom_chemin_dossier_solene)
	if os.path.exists(nom_initialisation) == False :
		copier(nom_chemin_init_simulation, nom_initialisation)
	if os.path.exists(nom_chemin_dossier_solene+"extrude.sh") == False :
		copier(nom_initialisation+"extrude.sh",nom_chemin_dossier_solene+"extrude.sh")
		copier(nom_initialisation+"lib",nom_chemin_dossier_solene+"lib")
	return nom_chemin_init_simulation

	
def initialisation_cas(nom_chemin_dossier_solene) : 
	nom_chemin_cas = nom_chemin_dossier_solene+"cas_en_cours/"
	creer_dossier(nom_chemin_cas)
	nom_initialisation = nom_chemin_dossier_solene+"import/"
	if os.path.exists(nom_chemin_cas+"param.xml") == False :
		copier(nom_initialisation+"param.xml",nom_chemin_cas+"param.xml")
		copier(nom_initialisation+"famille.xml",nom_chemin_cas+"famille.xml")
		copier(nom_initialisation+"materiau.xml",nom_chemin_cas+"materiau.xml")
		copier(nom_initialisation+"meteo",nom_chemin_cas+"meteo")
		copier(nom_initialisation+"meteo",nom_chemin_cas+"simulSat")

	xml = XmlFile(nom_chemin_cas +'param.xml')
	xml.definir_champ('param_couplage/chemin_cas', data = nom_chemin_cas )
	xml.definir_champ('param_couplage/initialisation_cir_ou_med', data="cir_tr" )
	xml.definir_champ('param_couplage/chemin_familles_xml', data=nom_chemin_cas+"famille.xml" )
	xml.definir_champ('param_couplage/chemin_materiau_xml', data= nom_chemin_cas+"materiau.xml")
	xml.definir_champ('param_couplage/chemin_fichier_meteo', data=nom_chemin_cas+"meteo/meteo" )
	xml.definir_champ('param_couplage/type_fichier_meteo', data= "ONEVU" )
	xml.definir_champ('param_couplage/chemin_familles_val', data= nom_chemin_cas+"famille.val" )
	
	return nom_chemin_cas +'param.xml'
	
def calculer_SVF(sol, svf, geo, lst_carac) :
	if os.path.exists(lst_carac['surface']) == False :
		sol.calculer_surface()
	if os.path.exists(lst_carac['ffSky']) == False :
		sol.calculer_fac_form_ciel()
	surface= read_val(lst_carac['surface'], geom=geo)
	ffSky= read_val(lst_carac['ffSky'], geom=geo)
	sum_ffSky=0
	sum_ponderee=0
	for j in range(len(surface)):
			sum_ponderee=surface[j]*ffSky[j]
			sum_ffSky=sum_ffSky+sum_ponderee
	svf=sum_ffSky/sum(surface)
	return svf
	
def calculer_albedo_simplifie(sol, albedo_simplifie, geo, lst_carac) :
	if os.path.exists(lst_carac['surface']) == False :
		sol.calculer_surface()
	if os.path.exists(lst_carac['ffSky']) == False :
		sol.calculer_fac_form_ciel()
	surface= read_val(lst_carac['surface'], geom=geo)
	ffSky= read_val(lst_carac['ffSky'], geom=geo)
	albedo= read_val(lst_carac['albedo'], geom=geo)
	sum_ffSky=0
	sum_ponderee=0
	for j in range(len(surface)):
			sum_ponderee=surface[j]*ffSky[j]*albedo[j]
			sum_ffSky=sum_ffSky+sum_ponderee
	albedo_simplifie=sum_ffSky/sum(surface)
	return albedo_simplifie

def calculer_flux_sol_total(sol,var,geo):
        """
        realise la somme des flux directs et diffus pour obtenir le flux
        total. Utilise val_op_val
        """
        for suffix in sol.liste_ts_sol:
		flux_sol_direct = read_val(sol.var['flux_sol_direct'] + '_' + suffix, geom=geo)
		flux_sol_diffus = read_val(sol.var['flux_sol_diffus'] + '_' + suffix, geom=geo)
		flux_sol_total = flux_sol_direct+ flux_sol_diffus
		write_val(sol.var['flux_sol_total'] + '_' + suffix, geo, flux_sol_total)
                                                 
        return sol.var['flux_sol_total']



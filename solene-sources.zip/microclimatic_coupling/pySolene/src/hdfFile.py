#!/usr/bin/python
# -*- coding: utf-8 -*-
'''
 *
 *  Copyright 2010-2013 Laurent Malys (CERMA, UMR 1563 AAU, CNRS /
 *                                  Ecole d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
'''

"""@package hdfFile
Définition des classes HdfFile, MedFile et CplFile

@author :
    Laurent Malys, Laboratoire CERMA, UMR 1563
    laurent.malys@cerma.archi.fr

"""
import numpy as np

import tables
import os

from utils import Chrono
from geom import *


parallel_domain = 'CHA/parallel domain/MAI.TE4/                  -1                  -1/Fluid volume/CO'



def array_to_table(vec, n):
    """ transforme les array de dim1 issues des .med en array de dim2
    avec des vecteurs contenant 'n' valeurs 
    """

    table = vec.reshape(n, len(vec)/n).transpose()
    return table
    


def table_to_array(table):
    """
    transforme les tables de shape (n_tetras, nPoints) 
    en array de dimension1
    """

    if type(table) == np.ndarray:
        a = table.transpose().flatten()
    
    return a

def liste_to_arrays(liste):
    """
    cree un dataset compose de d'un array 'valeur' et d'un array 'offset'
    pour stocker les elements d'une liste de liste longueur variable
    
    ex : 
        liste   = [[1,2,3], [4,5], [6,7,8]]
            donne :
        valeurs = [1,2,3,4,5,6,7,8]
        regle   = [3,2,3]  
    """
    regle = np.zeros(len(liste))
    valeurs = []

    for i in range(len(liste)):
        regle[i] = len(liste[i])
        if regle[i] == 0:
            valeurs.append(0)
        else:
            for j in liste[i]:
                valeurs.append(j)

    valeurs=np.array(valeurs)
    return regle, valeurs

def arrays_to_liste(regle, valeur):
    """
    renvoi une liste de listes avec un nombre d'elements variables en fonction
    d'un array 'valeur' contenant les valeurs et d'un array 'offset' contenant
    les regles pour repartir ces valeurs entre les elements
    """
    liste = []
    index = 0
    for i in range(len(regle)):
        ligne = []
        for j in range(int(regle[i])):
            ligne.append(valeur[index])
            index += 1
        liste.append(ligne)

    return liste

def tab_to_str(tab_nom):
	cpt=0
	nom = ''
	while tab_nom[cpt] != ' ':
		nom += tab_nom[cpt]
		cpt+=1
	return nom

class HdfFile:
    """
    Classe pour manipuler les fichier de type .hdf : .med (salome, saturne) 
    et .cpl (format peronnel)
    """
    def __init__(self, nom, geom = None):
        self.nom = nom
	self.fichier_existe = False
        if geom:
            self.geom = geom
        
	
        if os.path.isfile(nom):
	    self.fichier_existe = True
            self.hdf = tables.openFile(nom,'a')
        else:
            self.hdf = tables.openFile(nom,'w')
            
    def _path_to_table(self, chemin, n):
        """
        recupere l'array du noeud -chemin- et le transforme en table de dim2
        contenant n valeurs
        """
        noeud = self.hdf.getNode(chemin).read()
        return array_to_table(noeud, n)

class MedFile(HdfFile):
    """
    Classe de manipulation des fichiers .med cree par salome ou gmsh et utilise
    par Saturne
    """


    def __init__(self, nom):
        self.nom = nom
        self.hdf = tables.openFile(nom)
        
        self.points = ''
        self.pointsTE4 = ''
        self.familleTE4 = ''
        self.pointsTR3 = ''
        self.familleTR3 = ''
        self.pointsSE2 = ''
        self.familleSE2 =  ''
        self.liste_famille = ''
        self.extraire_version()
		
    def extraire_version(self):
        infos_generales = self.hdf.getNode('/INFOS_GENERALES')
        self.med_version_maj = self.hdf.getNodeAttr(infos_generales, 'MAJ')
        self.med_version_min = self.hdf.getNodeAttr(infos_generales, 'MIN')
        self.med_version_rel = self.hdf.getNodeAttr(infos_generales, 'REL')
        self.med_version = [self.med_version_maj,self.med_version_min, self.med_version_rel]
	
    def extraire_geom(self):
        
        """
        extrait la geometrie depuis le fichier med
        recupere les informations sur les aretes, les triangles, les tetraedres
        et leurs familles respectives
        """

        chrono = Chrono('extraire_geom', 'hdfFile')

        self.extraire_chemins()
        
        if len(self.hdf.listNodes('/ENS_MAA')) == 1:
            print '\t ce fichier est bien un fichier de maillage\n'

            self.geom = Geom()
            self.geom.points = self._path_to_table(self.points, 3)

            self.geom.n_points = len(self.geom.points)

            try:
                self.geom.tetras.points = self._path_to_table(self.pointsTE4, 4)
                self.geom.tetras.famille = self.hdf.getNode(self.familleTE4).read()
            except:  
                self.geom.tetras.points = np.array([])
                self.geom.tetras.familles = np.array([])

            self.geom.triangles.points = self._path_to_table(self.pointsTR3, 3)
            self.geom.triangles.famille = self.hdf.getNode(self.familleTR3).read()

            self.geom.segments.points = self._path_to_table(self.pointsSE2,2)
            self.geom.segments.famille = self.hdf.getNode(self.familleSE2).read()
    
            self.geom.n_segments = len(self.geom.segments.points)
            self.geom.n_triangles = len(self.geom.triangles.points)
            self.geom.n_tetras = len(self.geom.tetras.points)
            print "\tnombre d\'éléments : %s" % self.geom.n_tetras
  
            print "\tnombre de segments : %s" % self.geom.n_segments
            print "\tnombre de triangles : %s" % self.geom.n_triangles

            if self.med_version_maj == 2:
                if self.med_version_min == 3 and self.med_version_rel == 6:
                    self.extraire_familles_2_3_6()
                elif self.med_version_min == 3 and self.med_version_rel == 4:
                    self.extraire_familles_2_3_4()
            elif self.med_version_maj == 3:
                self.extraire_familles_2_3_6()
        else:
            print '\t !ce fichier n est pas un med geometrie!'

            
        chrono.fin()

        return self.geom

    def extraire_chemins(self):
        if self.med_version_maj == 2:
            noeud_maillage = self.hdf.listNodes('/ENS_MAA')[0]
            print '\t nom de la geometrie dans .med:', noeud_maillage
            self.nom_maillage = noeud_maillage._v_pathname.split('/')[-1]
            
            self.points = '/ENS_MAA/%s/NOE/COO' % self.nom_maillage
            
            self.pointsTE4 = '/ENS_MAA/%s/MAI/TE4/NOD' % self.nom_maillage
            self.familleTE4 = '/ENS_MAA/%s/MAI/TE4/FAM' % self.nom_maillage
            
            self.pointsTR3 = '/ENS_MAA/%s/MAI/TR3/NOD' % self.nom_maillage
            self.familleTR3 = '/ENS_MAA/%s/MAI/TR3/FAM' % self.nom_maillage
            
            self.pointsSE2 = '/ENS_MAA/%s/MAI/SE2/NOD' % self.nom_maillage
            self.familleSE2 =  '/ENS_MAA/%s/MAI/SE2/FAM' % self.nom_maillage
            
            self.liste_famille = '/ENS_MAA/%s/FAS/ELEME' % self.nom_maillage

        elif self.med_version_maj == 3:
            noeud_maillage = self.hdf.listNodes('/ENS_MAA')[0]
            self.nom_maillage = noeud_maillage._v_pathname.split('/')[-1]
            noeud_sous_maillage = self.hdf.listNodes('/ENS_MAA/%s'%self.nom_maillage)[0]
            
            self.chemin_maillage = noeud_sous_maillage._v_pathname

            self.points = '%s/NOE/COO' % self.chemin_maillage
            
            self.pointsTE4 = '%s/MAI/TE4/NOD' % self.chemin_maillage
            self.familleTE4 = '%s/MAI/TE4/FAM' % self.chemin_maillage
            
            self.pointsTR3 = '%s/MAI/TR3/NOD' % self.chemin_maillage
            self.familleTR3 = '%s/MAI/TR3/FAM' % self.chemin_maillage
            
            self.pointsSE2 = '%s/MAI/SE2/NOD' % self.chemin_maillage
            self.familleSE2 =  '%s/MAI/SE2/FAM' % self.chemin_maillage

            self.liste_famille = '/FAS/%s/ELEME' % self.nom_maillage
        
    def extraire_dic_familles_2_3_4(self):
        lst_nodes = self.hdf.listNodes(self.liste_famille)
        dic_fam = {}
        lst_nom_familles = []
        for node in lst_nodes:
            if node._v_children.has_key('GRO'):
                gro = node._v_children['GRO']
                if gro._v_children.has_key('NOM'):
                    tab_nom = gro._v_children['NOM'].read()
                    nom = tab_to_str(tab_nom)
                    if nom not in lst_nom_familles:
                        lst_nom_familles.append(nom)
                if 'NUM' in node._v_attrs._v_attrnames:
                    fam_num = node._f_getAttr('NUM')
                    dic_fam[fam_num] = nom
        self.lst_nom_familles = lst_nom_familles
        self.lien_num_fam = dic_fam
	
    def extraire_familles_2_3_4(self):
        self.extraire_dic_familles_2_3_4()
        for i in range(len(self.lst_nom_familles)):
            self.geom.familles[self.lst_nom_familles[i]] = i
        for i in range(self.geom.n_triangles):
            fam_old = self.geom.triangles.famille[i]
            nom_fam = self.lien_num_fam[fam_old]
            self.geom.triangles.famille[i] = self.geom.familles[nom_fam]
        for i in range(self.geom.n_tetras):
            fam_old = self.geom.tetras.famille[i]
            nom_fam = self.lien_num_fam[fam_old]
            self.geom.tetras.famille[i] = self.geom.familles[nom_fam]        

		
    def extraire_familles_2_3_6(self):
        for key in self.hdf.listNodes(self.liste_famille):
            key = key._v_pathname.split('/')[-1].split('_')
            print '\t\tfamille %s, id %s' % (key[-1], key[1])
            self.geom.familles[key[-1]] = key[1]
		

    def extraire_temperature(self):
        if self.med_version_maj == 3:
            chemin = self.hdf.listNodes('/CHA/TempC')[0]._v_pathname + '/MAI.TE4/MED_NO_PROFILE_INTERNAL'
            #chemin = '/CHA/TempC/00000000000000000018-0000000000000000001/MAI.TE4/MED_NO_PROFILE_INTERNAL'
            #chemin = '/CHA/TempC/00000000000000000101-0000000000000000001/MAI.TE4/MED_NO_PROFILE_INTERNAL'
        else:
            chemin = '/CHA/TempC/MAI.TE4/                   5                  -1/Volume fluide'
        noeud = self.hdf.listNodes(chemin)[0]
        return noeud.read()

    def extraire_vitesse(self):
        if self.med_version_maj == 3:
            chemin = self.hdf.listNodes('/CHA/Velocity')[0]._v_pathname + '/MAI.TE4/MED_NO_PROFILE_INTERNAL'
            #chemin = '/CHA/Velocity/00000000000000000018-0000000000000000001/MAI.TE4/MED_NO_PROFILE_INTERNAL'
        else:
            chemin = '/CHA/Vitesse/MAI.TE4/                   5                  -1/Volume fluide'
        noeud = self.hdf.listNodes(chemin)[0]
        return noeud.read()

    def extraire_donnee(self):
        """
        cree deux dictionnaires contenant les donnees surfaciques 
        et volumiques
 
        """
        lst_champs = self.hdf.listNodes('CHA')
        nom_champs = []
        for ch in lst_champs:
            nom_champs.append(ch._v_name)
        CHA2D = {}
        for champ in champs:
            try:
                CHA2D[champ] = self.hdf['CHA/'+champ+'/MAI.TR3/                 100                  -1/Boundary/CO']
                print 'importation donnee 2D : %s' % champ
            except:
                print 'pas de donnee 2d pour le champ %s' % champ
            
        CHA3D = {}
        for champ in champs:
            try:
                tt = str(self.hdf['/CHA/'+champ+'/MAI.TE4'].keys())[2:-2]
                chemin = '/CHA/'+champ+'/MAI.TE4/'+tt+'/Fluid volume/CO'
                print chemin
            except:
                print 'pas de chemin'
            try:
                CHA3D[champ] = self.hdf[chemin]
                print 'importation donnee 3D : %s' % champ
            except:
                print 'pas de donnee 3d pour le champ %s' % champ
            
        self.CHA2D = CHA2D
        self.CHA3D = CHA3D


class CplFile(HdfFile):

    def enregistrer_geom(self, face = True):
        """
        enregistrer la geometrie dans le format perso .cpl
        
        Ce format permet de ne pas recalculer les connectivites qui ne sont 
        pas conservees dans les fichiers .med et .cir
        """
        print '\n\t MODULE hdfFile.py'
        print '\t enregistrement de la geometrie %s' % self.geom.nom
        print '\t dans le fichier %s' % self.nom
        print 
        
        self.face = face
        
        if self.fichier_existe:
            print '\t -> le fichier existe et sera écrasé'
            os.remove(self.nom)
            self.hdf = tables.openFile(self.nom,'w')
        
        self.hdf.createGroup('/','geom')
        self.hdf.createGroup('/geom','triangles')

        self.hdf.createGroup('/geom','tetras')
        
        # points
        self.hdf.createArray('/geom','points',
                           table_to_array(self.geom.points))
                           
        # familles
        self.hdf.createGroup('/geom','familles')
        for famille in self.geom.familles:
            self.hdf.createArray('/geom/familles',famille,
                                 self.geom.familles[famille])
                
        # triangles
        self.hdf.createArray('/geom/triangles','points', 
                                table_to_array(self.geom.triangles.points))
        try:
            self.hdf.createArray('/geom/triangles','normale',
                                 table_to_array(self.geom.triangles.normale))
        except:
            print 'pas de normales aux triangles (?)'
            
        try:
            self.hdf.createArray('/geom/triangles','cdg',
                                 table_to_array(self.geom.triangles.cdg))
        except:
            print 'pas de centre de gravite aux triangles (?)'
 
       	if len(self.geom.triangles.connectivite_triangles)>0:
            try:
                self.creer_dataset_regle('/geom/triangles/connectivite_triangles',
                                   self.geom.triangles.connectivite_triangles)
            except:
                print '\t pas de connectivite triangles'

	if len(self.geom.triangles.connectivite_tetra)>0:
            try:
                self.hdf.createArray('/geom/triangles','connectivite_tetras',
                                 self.geom.triangles.connectivite_tetra)
            except:
                print '\t pas de connectivite tetras'
            
        try:
            self.hdf.createArray('/geom/triangles','famille',
                                 self.geom.triangles.famille)
        except:
            print 'pas de famille pour les triangles'

        # faces
        self.hdf.createGroup('/geom','faces')
        
        if self.face:

            
            self.creer_dataset_regle('/geom/faces/points',
                                     self.geom.faces.points)
            self.hdf.createGroup('/geom/faces','liste_trous')

            if len(self.geom.faces.liste_trous) == 0:
                self.geom.faces.liste_trous = [[]]*self.geom.n_faces
            for i in range(len(self.geom.faces.liste_trous)):
                if len(self.geom.faces.liste_trous[i]) != 0:
                    self.creer_dataset_regle('/geom/faces/liste_trous/t' + str(i),
                                             self.geom.faces.liste_trous[i])
                else:
                    self.hdf.createArray('/geom/faces/liste_trous', 't' + str(i),
                                         np.array([0]))
        try:
            self.hdf.createArray('/geom/faces','famille',
                             self.geom.faces.famille)
        except:
            print '\t -> pas de familles de faces'
            
        try:
            self.creer_dataset_regle('/geom/faces/liste_triangles',
                               self.geom.faces.liste_triangles)
        except:
            print '\t ->pas de liste de triangles'

        # éléments
	if self.geom.n_tetras > 0:
            try:
                self.hdf.createArray('/geom/tetras','points',
                                     table_to_array(self.geom.tetras.points)) 
                self.hdf.createArray('/geom/tetras','cdg',
                                        table_to_array(self.geom.tetras.cdg))   
                self.hdf.createArray('/geom/tetras','famille',
                                     self.geom.tetras.famille)
            except:
                print '\t pas de donnees volumiques'
            
        self.hdf.close()


    def charger_geom(self, face = True):
        """
        charge la geometrie stockee dans un format .cpl
        elle peut etre volumique ou surfacique (enveloppe) et peut ou non 
        disposer d'informations sur les connectivites
        """

        self.face = face

        print '\n\t MODULE hdfFile.py'
        print '\t chargement de la geometrie, stockée dans le fichier ' 
        print '\t\t -%s -'% self.nom
        self.geom = Geom(nom='')
        self.geom.points = self._path_to_table('/geom/points', 3)
        self.geom.n_points = len(self.geom.points)



        # familles
        self.geom.familles = {}
        for famille in self.hdf.listNodes('/geom/familles'):
            nom_famille = famille._v_pathname.split('/')[-1]
            valeur = famille.read()
            self.geom.familles[nom_famille] = valeur

        # triangles
        self.geom.triangles.points = self._path_to_table('/geom/triangles/points',3)
        try:
            self.geom.triangles.cdg = self._path_to_table('/geom/triangles/cdg',3)
        except:
            print '\t -> pas de centre de gravite pour les triangles'
            
        try:
            self.geom.triangles.normale = self._path_to_table('/geom/triangles/normale',3)
        except:
            print '\t -> pas de normale pour les triangles'

        try:
            self.geom.triangles.connectivite_triangles = \
                self.extraire_dataset_regle('/geom/triangles/connectivite_triangles')
        except:
            print '\t -> pas de connectivite triangle'
            
        try:
            self.geom.triangles.connectivite_tetra = \
               self.hdf.getNode('/geom/triangles/connectivite_tetras').read()
        except:
            print '\t pas de connectivite tetras'
            
        try:
            self.geom.triangles.famille = \
                self.hdf.getNode('/geom/triangles/famille').read()
        except:
            print '\t pas des familles pour les triangles'
            
        self.geom.n_triangles = len(self.geom.triangles.points)

        # faces
        try:
            self.geom.faces.liste_triangles = self.extraire_dataset_regle(
                '/geom/faces/liste_triangles')
        except:
            print '\t ->pas de liste de triangles'
        
        self.geom.n_faces = len(self.geom.faces.liste_triangles)
        
        try:
            self.geom.faces.points = self.extraire_dataset_regle(
                '/geom/faces/points')
            self.geom.n_faces = len(self.geom.faces.points)
            
            self.geom.faces.liste_trous = [0]*self.geom.n_faces
            for i in range(self.geom.n_faces):
                if type(self.hdf.getNode('/geom/faces/liste_trous/t'+str(i))) == tables.array.Array:
                    self.geom.faces.liste_trous[int(i)] = []
    
                else:
                    self.geom.faces.liste_trous[int(i)] = self.extraire_dataset_regle(
                        '/geom/faces/liste_trous/t'+str(i))
                        

    
            self.geom.faces.famille = self.hdf.getNode('/geom/faces/famille').read()
    
            
            self.geom.n_faces = len(self.geom.faces.points)
            
            no_triangle = []
            for face in range(self.geom.n_faces):
                no_triangle.append(self.geom.faces.liste_triangles[face][0])
                
            normale = self.geom.triangles.normale[no_triangle]
            self.geom.faces.normale = normale
        except:
            print '\t ->pas d informations sur les faces'
            
        try:
            self.geom.faces.famille = self.hdf.getNode('/geom/faces/famille').read()
        except:
            print '\t -> pas de familles de face'

        # tetras
        try:
            self.geom.tetras.points = self._path_to_table('/geom/tetras/points',4)
            self.geom.tetras.cdg = self._path_to_table('/geom/tetras/cdg',3)
            self.geom.tetras.famille = self.hdf.getNode('/geom/tetras/famille').read()
            self.geom.n_tetras = len(self.geom.tetras.points)
        except:
            print '\t -> pas de donnees volumiques'


    def creer_dataset_regle(self, nom, liste):
        """
        creer un 'dataset' pour des listes de listes de longueur variable
        avec un array contenant les valeurs et un array contenant les offsets
        
        pour chaque element de la liste, l'offset defini quelles valeurs font 
        partie de cet element
        """
        connect = liste_to_arrays(liste)
        
        nom_bis = os.path.split(nom)
        self.hdf.createGroup(nom_bis[0], nom_bis[1])
        self.hdf.createArray(nom,'regle',connect[0])
        self.hdf.createArray(nom,'valeurs', connect[1])
    
    def extraire_dataset_regle(self, nom):
        """
        recupere une liste de liste de longueur variable stockee dans un dataset
        (dataset : donnee forme d'un array 'valeurs' et d'un array 'offset'
        """
        regle = self.hdf.getNode(nom + '/regle').read()
        valeurs = self.hdf.getNode(nom + '/valeurs').read()

        return arrays_to_liste(regle, valeurs)
        
    
        


    


        

        

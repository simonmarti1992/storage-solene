#!/usr/bin/python
# -*- coding: utf-8 -*-
'''
 *
 *  Copyright 2010-2013 Laurent Malys (CERMA, UMR 1563 AAU, CNRS /
 *                                  Ecole d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
'''

"""@package satCommand
Définition d'une classe SatCommand de contrôle 
des simulations de Saturne

Version 0.02
04/04/2013

@author :
    Laurent Malys, Laboratoire CERMA, UMR 1563
    laurent.malys@cerma.archi.fr
"""

import os
import time
import matplotlib
import xml.dom.minidom

import matplotlib.pyplot
import subprocess
import numpy as np

from utils import ecrire_fichier, lst2str, couper_ligne_f77
from xmlFile import XmlFile

#import satSubroutines

CS_VERSION = 3

PLT = matplotlib.pyplot

JOIN = os.path.join
CHEMIN_TMP_SATURNE = JOIN('/home', os.environ['USER'], 'tmp_Saturne')

## FAMILLES_PAROI_VEINE = 'nord, sud, est, ouest'
## FAMILLES_SURFACE_ARBRE = 'arbreext'
## FAMILLES_MURS = 'bat, solbat, solair'

PARAM_METEO = ['T', 'v', 'direction', 'w']

ICI = os.path.split(__file__)[0]

F_USCLIM = open(os.path.join(ICI, 'satsubroutines', 'usclim.f90'), 'r')
USCLIM = F_USCLIM.read()
F_USCLIM.close()

F_CS_SOURCETERMS = open(os.path.join(ICI, 'satsubroutines', 'cs_user_source_terms.f90'), 'r')
CS_SOURCETERMS = F_CS_SOURCETERMS.read()
F_CS_SOURCETERMS.close()

F_CS_BOUNDARY = open(os.path.join(ICI, 'satsubroutines', 'cs_user_boundary_conditions.f90'), 'r')
CS_BOUNDARY = F_CS_BOUNDARY.read()
F_CS_BOUNDARY.close()

F_CS_POSTPROCESS = open(os.path.join(ICI, 'satsubroutines', 'cs_user_postprocess_var.f90'), 'r')
CS_POSTPROCESS = F_CS_POSTPROCESS.read()
F_CS_POSTPROCESS.close()

F_USTSKE = open(os.path.join(ICI, 'satsubroutines', 'ustske.f90'), 'r')
USTSKE = F_USTSKE.read()
F_USTSKE.close()

F_USTSNS = open(os.path.join(ICI, 'satsubroutines', 'ustsns.f90'), 'r')
USTSNS = F_USTSNS.read()
F_USTSNS.close()

F_USVPST = open(os.path.join(ICI, 'satsubroutines', 'usvpst.f90'), 'r')
USVPST = F_USVPST.read()
F_USVPST.close()

F_SATURNE_XML = open(os.path.join(ICI, 'satsubroutines', 'saturne2.xml'), 'r')
SATURNE_2_XML = F_SATURNE_XML.read()
F_SATURNE_XML.close()

F_SATURNE_XML = open(os.path.join(ICI, 'satsubroutines', 'saturne3.xml'), 'r')
SATURNE_3_XML = F_SATURNE_XML.read()
F_SATURNE_XML.close()



def parser_listing(fichier_listing):
    """
    parse le fichier listing et renvoi une liste de dictionnaires
    contenant chacun les informations relatives a un pas de temps 
    """
    
    listing = open(fichier_listing,'r')
    listing_lignes = listing.readlines()
    time_step = 0
    liste_ts = []
    dic_ts = {}
    for ligne in listing_lignes:
        tab = ligne.split()
                
        if len(tab)>0 and tab[0] == 'INSTANT':
            if time_step != 0:
                liste_ts.append(dic_ts)
            dic_ts = {}
            time_step +=  1
            dic_ts['TimeStep'] = time_step
                
        elif len(tab)>0 and tab[0] == 'c':
            dic = parse_listing_tab(ligne)

                        
            var = dic['Variable'].split()
            if len(var) == 1:
                dic_var = var[0]
            else:
                dic_var = ''
                for i in range(len(var)):
                    dic_var +=  str(var[i])
            dic['Variable'] = dic_var
            dic_ts['conv_'+dic['Variable']] = dic

        elif len(tab)>1 and tab[0] == 'v':
            dic = parse_listing_tab(ligne)
            dic_ts[dic['Variable']] = dic

        elif len(tab)>6 and tab[0] == 'CPU':
            dic_ts['CPU time'] = float(tab[7])

        elif 'END OF CALCULATION' in ligne:
            print 'fin du calcul'
            
    return liste_ts
    
def parse_listing_lignes(nouvelles_lignes, timestep):
    """
    re-fonction de parsing de listing (la troisieme)
    qui fonctionne avec SatCommand.suivre_simulation()
    """
    sim_continu = True
    nouveau_pas = False
    lst_retour = []
    dic_ts = {}
    for ligne in nouvelles_lignes:
        tab  =  ligne.split()
        
        if len(tab)>0 and tab[0] == 'INSTANT':
            if timestep > 0:
                lst_retour.append(dic_ts)
            dic_ts = {}
            timestep +=  1
            dic_ts['TimeStep'] = timestep
            nouveau_pas  =  True

        elif len(tab)>0 and tab[0] == 'c':
            dic = parse_listing_tab(ligne)

            var = dic['Variable'].split()
            if len(var) == 1:
                dic_var = var[0]
            else:
                dic_var = ''
                for i in range(len(var)):
                    dic_var +=  str(var[i])
            dic['Variable'] = dic_var
            dic_ts['conv_'+dic['Variable']] = dic

        elif len(tab)>1 and tab[0] == 'v':
            dic = parse_listing_tab(ligne)
            dic_ts[dic['Variable']] = dic

        elif len(tab)>7 and tab[0] == 'CPU':
            dic_ts['CPU time'] = float(tab[7])

        elif 'END OF CALCULATION' in ligne:
            sim_continu = False
            
    return lst_retour, nouveau_pas, sim_continu

def parse_listing_tab(ligne):
    """
    parse les lignes de tableau (convergence,  variable)
        retourne un dictionnaire
    parse les lignes de CPU TIME
        retourne un vercteur dim2
    parse les lignes INSTANT
        retourne une un entier
    """
    tab = ligne.split()
    
    if len(tab) == 0:
        print 'erreur : ligne vide!'
        dic_ligne = None

    if tab[0] == 'c':
        dic_ligne = {}
        dic_ligne['Variable'] = str(ligne[3:15])
        dic_ligne['Rhs norm'] = float(ligne[15:27])
        dic_ligne['N_iter'] = int(ligne[28:35])
        try:
            dic_ligne['Norm. residual']  =  float(ligne[37:49])
        except ValueError:
            dic_ligne['Norm. residual']  =  str(ligne[37:49])

        try:
            dic_ligne['derive']  =  float(ligne[51:63])
        except ValueError:
            dic_ligne['derive']  =  str(ligne[51:63])

    elif tab[0] == 'v':
        dic_ligne = {}
        dic_ligne['Variable']  =  str(ligne[3:15])
        dic_ligne['Min value']  =  float(ligne[15:27])
        dic_ligne['Max value']  =  float(ligne[28:41])
        dic_ligne['Min clip']  =  str(ligne[42:52])
        dic_ligne['Max clip']  =  str(ligne[53:63])

    elif tab[0] == 'CPU':
        dic_ligne = [int(tab[6]), float(tab[7])]
    elif tab[0] == 'INSTANT':
        dic_ligne = tab[5]
    else:
        dic_ligne = None
        print "erreur : ne peut pas parser cette ligne!"

    return dic_ligne

def plot_convergence(liste_timestep, 
                     liste_variables = None, 
                     grandeur = 'derive'):

    """
    trace la courbe d'evolution des variables fichier "listing"
    """
    legende = []
    yyy = []
    
    if not liste_variables:
        liste_variables = ['Pression', 
                           'VitesseX', 
                           'VitesseY', 
                           'VitesseZ', 
                           'EnerTurb', 
                           'Dissip']

    for variable in liste_variables:
        lst_y = []
        nom_conv = 'conv_'+variable
        for i in range(len(liste_timestep)-1):
            
            lst_y.append(liste_timestep[i][nom_conv][grandeur])
        legende.append(nom_conv)
        yyy.append(lst_y)
    draw_graph(yyy, legende)

def draw_graph(yyy, legende):
    """
    trace le vecteur yyy dans PLT
    """
    yyy = np.array(yyy)
    PLT.interactive(True) #Permet d'être en mode dynamique
    PLT.figure(2) #tu met ici un numéro de figure, 
                #ca permet de gérer plusieur graphique
    PLT.clf() #clear figure

    PLT.semilogy()
    PLT.plot(yyy.transpose())
#    PLT.xlim(0, len(yyy[0]))
    PLT.legend(legende)  
    PLT.draw()

def trouver_chemin_cas(nom_cas, case1):
    """
    trouve le chemin de la derniere simulation realisee 
    pour le cas nomCas
    """
    liste_rep = os.listdir(CHEMIN_TMP_SATURNE)
    dernier_rep = ''
    liste_time = []
    liste_time_bis = []

    ce_mois = time.localtime()[1]

    for i in range(len(liste_rep)):
        if nom_cas in liste_rep[i] and \
        int(liste_rep[i][-8:-6])  ==  ce_mois:
            liste_time.append(str(liste_rep[i][-8:]))
            liste_time_bis.append(int(liste_rep[i][-6:]))


    temps_max_bis = max(liste_time_bis)
    temps_max = liste_time[liste_time_bis.index(temps_max_bis)]
    
    dernier_rep = JOIN(CHEMIN_TMP_SATURNE, nom_cas+'.'+case1+'.'+temps_max)
    
    return dernier_rep
    
def tester_convergence(liste, largeur_bande, ecart_max):
    """
    test convergence à retravailler
    """
    liste = np.array(liste)
    for i in range(largeur_bande, len(liste)):
        bande = liste[i-largeur_bande:i]
        if tester_convergence_bande(bande, ecart_max):
            return i

def tester_convergence_bande(bande, ecart_max):
    """
    test convergence a retravailler
    """
    bande = np.array(bande)
    bande_mean = bande.mean()
    bande_min = min(bande)
    bande_max = max(bande)
    if abs(bande_mean - bande_min) < ecart_max * bande_mean and\
        abs(bande_max - bande_mean) < ecart_max * bande_mean:
        print bande_mean, bande_min, bande_max
        return True
    else:        
        return False

def convertir_time_step(liste_timestep):
    """
    transforme la liste de dictionnaires en dictionnaire de liste 
    """
    liste_conv = []
    for cle in liste_timestep[0].keys():
        if cle[0:4] == 'conv':
            liste_conv.append(cle)

    dic_ts = {'TimeStep':[],
              'CPU time':[]}
    for conv in liste_conv:
        dic_ts[conv] = []
            
    for timestep in liste_timestep:
        dic_ts['TimeStep'].append(timestep['TimeStep'])
        dic_ts['CPU time'].append(timestep['CPU time'])
        
        for conv in liste_conv:
            dic_ts[conv].append(timestep[conv]['derive'])
        
    return dic_ts

class SatCommand:
    """
    Classe de controle des simulations saturne
    """
    def __init__(self, 
                 chemin_sim, 
                 nom_cas,
                 creer = False,
                 case = 'CASE1'):

        self.nom_cas = nom_cas.upper()

        self.case1 = case

        # chemin vers l'arborescence de saturne
        self.chemins = {}
        self.chemins['sim'] = chemin_sim
        self.chemins['case'] = os.path.abspath(JOIN(self.chemins['sim'],
                                  self.nom_cas.upper()))
        self.chemins['mesh'] = JOIN(self.chemins['case'], 'MESH')
        self.chemins['data'] = JOIN(self.chemins['case'], self.case1, 'DATA')
        self.chemins['thch'] = JOIN(self.chemins['data'], 'THCH')
        self.chemins['resu'] = JOIN(self.chemins['case'], self.case1 ,'RESU')
        self.chemins['scripts'] = JOIN(self.chemins['case'], self.case1, 
                                       'SCRIPTS')
        self.chemins['src'] = JOIN(self.chemins['case'], self.case1, 'SRC')
        
        self.chemins['echange'] = JOIN(self.chemins['resu'], 'echange')
        self.chemins['runcase'] = JOIN(self.chemins['scripts'], 'runcase')
        self.chemins['listpre'] = JOIN(self.chemins['mesh'], 'listpre')
        
        self.chemins['conf_xml'] = JOIN(self.chemins['data'], 'param.xml')
        self.chemins['tmp'] = ''
        self.chemins['listing'] = None        

        self.chemins['geometrie'] = ''
        
        # chemin des fichiers meteo
        self.param_meteo = PARAM_METEO
        
        # nommage des fichiers de sortie pour le couplage
        self.nom_dat = {}
        self.nom_dat['Tair'] = JOIN(self.chemins['echange'], 'temperature')
        self.nom_dat['Vair'] = JOIN(self.chemins['echange'], 'vitesse')
        self.nom_dat['h_conv'] = JOIN(self.chemins['echange'], 'h_conv')
        self.nom_dat['hcbis'] = JOIN(self.chemins['data'],'hc_bis')
        self.nom_dat['hs'] = JOIN(self.chemins['echange'],'hs')
        self.nom_dat['Ts'] = JOIN(self.chemins['data'],'T_mur')
        self.nom_dat['Flatent'] = JOIN(self.chemins['data'], 'Flatent')
        self.nom_dat['Flux_rad_arbre'] = JOIN(self.chemins['data'], 'Flux_rad_arbre')
        self.nom_dat['Fsensible'] = JOIN(self.chemins['data'], 'Fsensible')

        # gestion de listing et suivi des simulations

        self.conf_xml = XmlFile()

        self.simu = None
        self.start_time = ''
        self.restart = ''    
        
        self.convergence_vitesse = []
        self.timestep = []
        self.total_lignes = [0, 0]

        self.liste_timestep = []
        self.fichierlignes = []
        self.trace = 1
        
        self.iteration = 200
        
        # subroutines
        #self.usclim_perso = satSubroutines.usclim
        #self.usvpst_perso = satSubroutines.usvpst
       
        self.usclim_perso = USCLIM
        self.usvpst_perso = USVPST
        self.ustsns_perso = USTSNS
        self.ustske_perso = USTSKE

        self.cs_boundary_perso = CS_BOUNDARY
        self.cs_sourceterms_perso = CS_SOURCETERMS
        self.cs_postprocess_perso = CS_POSTPROCESS

        if CS_VERSION == 3:
            self.saturne_xml_perso = SATURNE_3_XML
        else:
            self.saturne_xml_perso = SATURNE_2_XML
        
        # definition des familles pour les subroutines
        self.sat_familles = {}
        # self.sat_familles['sat_inlet'] = FAMILLES_PAROI_VEINE
        # self.sat_familles['sat_sym'] = []
        # self.sat_familles['sat_wall'] = []
        # self.sat_familles['surface_arbre'] = FAMILLES_SURFACE_ARBRE
        # self.sat_familles['murs'] = FAMILLES_MURS
        
        if creer or not os.path.isdir(self.chemins['case']):
            self.creer_cas()

    def trouver_xml(self, nom_xml = None):
        """
        cherche le fichier de configuration xml dans le repertoire -data-
        demande une intervention de l'utilisateur sur plusieurs fichiers xml 
        sont présents
        """
        if not nom_xml:
            liste_fichier_data = os.listdir(self.chemins['data'])
            liste_xml = []
            for fichier in liste_fichier_data:
                if fichier[-4:] == '.xml':
                    liste_xml.append(fichier)
            if len(liste_xml) == 1:
                nom_xml = liste_xml[0]
            elif len(liste_xml) == 0:
                print 'aucun fichier xml dans -DATA-'

            else : 
                print 'plusieurs fichiers xml dans -DATA-: '
                for i in range(len(liste_xml)):
                    print '\t', i+1, liste_xml[i]
                chemin_user = str(raw_input("nom ou numero ?"))
                try:
                    chemin_user = int(chemin_user)
                    nom_xml = liste_xml[int(chemin_user)-1]
                except ValueError:
                    if nom_xml in liste_xml:
                        nom_xml = chemin_user

        if nom_xml:                            
            self.chemins['conf_xml'] = JOIN(self.chemins['data'], nom_xml)
            self.conf_xml = XmlFile(self.chemins['conf_xml'])
        else:
            self.chemins['conf_xml'] = None

    def creer_cas(self):
        """
        creation du cas s'il n'existe pas : 
            repertoire principale
            + toute l'arborescente avec l'executable : code_saturne create
        """
        
        print '\n  CREATION DU CAS SATURNE'
        ici = os.path.realpath(os.path.curdir)
        try:
            if not os.path.isdir(self.chemins['sim']):
                os.mkdir(self.chemins['sim'])
                print '\t creation repertoire -simulSat-'
                print '\t -> ', self.chemins['sim']
        except OSError:
            print '\t ! probleme creation repertoire -simulsat-'

        if not os.path.isdir(self.chemins['mesh']):
            print '\t creation de l arborescence de Saturne'
            print '\t -> SHELL: "code_saturne create -s %s"' % self.nom_cas
            print '.'*30
            os.chdir(self.chemins['sim'])
            subprocess.call(['code_saturne', 'create', '-s', self.nom_cas])
            print '.'*30
            print '\t -> fin SHELL: "code_saturne create -s %s"' % self.nom_cas
            print
            os.makedirs(self.chemins['echange'])
            
        else:
            liste_mesh = os.listdir(self.chemins['mesh'])
            liste_mesh_med = []
            for mesh in liste_mesh:
                if me5B5B5Bsh[-4:] == '.med':
                    liste_mesh_med.append(mesh)
            if len(liste_mesh_med) == 1:
                self.chemins['geometrie'] = JOIN(self.chemins['mesh'], 
                                                 liste_mesh_med[0])
        os.chdir(ici)

    def copier_geometrie(self, chemin_geometrie, check = False):
        """
        copie la geometrie -chemin_geometrie- dans le répertoire -MESH-
        de l'arborescence de -simulSat-
        """
        print '\t copier la geometrie dans MESH'
        self.chemins['geometrie'] = JOIN(self.chemins['mesh'], 
                                         os.path.split(chemin_geometrie)[1])

        mesh_exist = os.path.isfile(self.chemins['geometrie'])

        if mesh_exist:
            print "\t -> geometrie med deja présente dans -simulSat-"
            print "\t -> le cas SATURNE est deja cree"
            if check:
                ecraser = str(raw_input("\t -> écraser (o/n)?"))
            else:
                ecraser = 'n'
                
            if ecraser == 'o' or ecraser == 'y':
                ecraser = True
            else:
                ecraser = False
        
        if not mesh_exist or ecraser :
            
            print '\t -> SHELL: "cp %s\n\t %s"' % (chemin_geometrie, 
                                                   self.chemins['mesh'])
            com = ['cp', 
                   chemin_geometrie, 
                   self.chemins['mesh']]
            subprocess.call(com)
        
        nom_geometrie = chemin_geometrie.split('/')[-1]
        self.chemins['geometrie'] = self.chemins['mesh']+'/'+ nom_geometrie

    def definir_meteo(self, dic_meteo):
        """
        exporte les fichiers meteos par variable
        """
        for param in self.param_meteo:
            if param == 'v' and dic_meteo[param] == 0:
                val_param = 1.5
            elif param == 'w':
                val_param = dic_meteo[param]/1000
            else:
                val_param = dic_meteo[param]
            chemin_fichier = JOIN(self.chemins['data'], param)
            ecrire_fichier(chemin_fichier, str(float(val_param)))

    def definir_param_meteo(self, nom_param, valeur):
        """
        ecrit la valeur dans le fichier meteo de -nom_param-
        """
        chemin_fichier = JOIN(self.chemins['data'], nom_param)
        ecrire_fichier(chemin_fichier, str(valeur))

    def recuperer_listes_from_famille(self, famille):
        self.sat_familles = famille.exporter_familles_saturne()

    def creer_usclim_old(self):
        """
        cree le fichier usclim en remplacant le nom des familles correspondantes
        """
        
        for param in self.param_meteo:
            self.usclim_perso = self.usclim_perso.replace('$$nom_fichier_%s' % param, 
                                    JOIN(self.chemins['data'], param))
                                    
        self.usclim_perso = self.usclim_perso.replace('$$familles_sat_inlet', 
                                                  self.sat_familles['sat_inlet'])
        self.usclim_perso = self.usclim_perso.replace('$$familles_murs', 
                                                      self.sat_familles['murs'])
        self.usclim_perso = self.usclim_perso.replace('$$nom_dat_hcbis', 
                                                      self.nom_dat['hcbis'])
        self.usclim_perso = self.usclim_perso.replace('$$nom_dat_Tmur', 
                                                      self.nom_dat['Ts'])

    def creer_usclim(self):
        """
        cree le fichier usclim, complete avec :
            - le chemin vers le repertoire DATA
            - le nom des familles correspondes (sat_inlet et murs)
        """
        self.usclim_perso = self.usclim_perso.replace('$$chemin_data', 
                                                      self.chemins['data'])

        self.usclim_perso = self.usclim_perso.replace('$$familles_sat_inlet',
                                                      lst2str(self.sat_familles['sat_inlet']))

        self.usclim_perso = self.usclim_perso.replace('$$familles_murs',
                                                      lst2str(self.sat_familles['murs']+self.sat_familles['sat_wall']))

        self.usclim_perso = self.usclim_perso.replace('$$familles_sat_sym',
                                                      lst2str(self.sat_familles['sat_sym']))


    def creer_cs_boundary(self):
        """
        cree le fichier usclim, complete avec :
            - le chemin vers le repertoire DATA
            - le nom des familles correspondes (sat_inlet et murs)
        """
        self.cs_boundary_perso = self.cs_boundary_perso.replace('$$chemin_data', 
                                                      couper_ligne_f77(self.chemins['data']))

        self.cs_boundary_perso = self.cs_boundary_perso.replace('$$familles_sat_inlet',
                                    couper_ligne_f77(lst2str(self.sat_familles['sat_inlet'])))

        str_fam_murs = lst2str(self.sat_familles['murs']+self.sat_familles['sat_wall'])
        self.cs_boundary_perso = self.cs_boundary_perso.replace('$$familles_murs',
                                                        couper_ligne_f77(str_fam_murs))
        
        self.cs_boundary_perso = self.cs_boundary_perso.replace('$$familles_sat_sym',
                                                      lst2str(self.sat_familles['sat_sym']))


    def creer_usvpst(self):
        """
        renseigne : 
            les noms des fichiers de sortie :
                $$nom_fichier_temperature_dat
                $$nom_fichier_vitesse_dat
                $$nom_fichier_h_conv_dat
            la liste des familles communes solene et saturne
                $$familles_solene
        """
        #usvpst_perso = satSubroutines.usvpst
        usvpst_perso = self.usvpst_perso
        usvpst_perso = usvpst_perso.replace('$$chemin_echange',
                                            self.chemins['echange'])
        usvpst_perso = usvpst_perso.replace('$$familles_murs', 
                                            lst2str(self.sat_familles['murs']))
        usvpst_perso = usvpst_perso.replace('$$familles_surface_arbre', 
                                            lst2str(self.sat_familles['surface_arbre']))
                                            
        self.usvpst_perso = usvpst_perso

    def creer_cs_postprocess(self):
        """
        renseigne : 
        les noms des fichiers de sortie :
        $$nom_fichier_temperature_dat
        $$nom_fichier_vitesse_dat
        $$nom_fichier_h_conv_dat
        la liste des familles communes solene et saturne
        $$familles_solene
        """
        cs_postprocess_perso = self.cs_postprocess_perso
        cs_postprocess_perso = cs_postprocess_perso.replace('$$chemin_echange',
                                            couper_ligne_f77(self.chemins['echange']))
        cs_postprocess_perso = cs_postprocess_perso.replace('$$familles_murs', 
                              couper_ligne_f77(lst2str(self.sat_familles['murs'])))
        cs_postprocess_perso = cs_postprocess_perso.replace('$$familles_surface_arbre', 
                              couper_ligne_f77(lst2str(self.sat_familles['surface_arbre'])))
                                            
        self.cs_postprocess_perso = cs_postprocess_perso


    def creer_ustsns(self):
        self.ustsns_perso = self.ustsns_perso.replace('$$familles_volume_arbre',
                                                      lst2str(self.sat_familles['volume_arbre']))

    def creer_ustske(self):
        self.ustske_perso = self.ustske_perso.replace('$$familles_volume_arbre',
                                                      lst2str(self.sat_familles['volume_arbre']))

    def creer_cs_sourceterms(self):
        self.cs_sourceterms_perso = self.cs_sourceterms_perso.replace('$$chemin_data', 
                                                      couper_ligne_f77(self.chemins['data']))
        self.cs_sourceterms_perso = self.cs_sourceterms_perso.replace('$$familles_volume_arbre',
                                                   lst2str(self.sat_familles['volume_arbre']))
        self.cs_sourceterms_perso = self.cs_sourceterms_perso.replace('$$familles_murs',
                                   couper_ligne_f77(lst2str(self.sat_familles['murs'])))
        self.cs_sourceterms_perso = self.cs_sourceterms_perso.replace('$$familles_surface_arbre',
                              couper_ligne_f77(lst2str(self.sat_familles['surface_arbre'])))
                                            

    def ecrire_subroutines(self):
        """
        cree les differentes routines utilateurs 
        en renseignant les familles
        """
        if CS_VERSION < 3:
            self.creer_usclim()
            nom_usclim = JOIN(self.chemins['src'], 'usclim.f90')
            ecrire_fichier(nom_usclim, self.usclim_perso)
            
            self.creer_usvpst()
            nom_usvpst = JOIN(self.chemins['src'], 'usvpst.f90')
            ecrire_fichier(nom_usvpst, self.usvpst_perso)
            
            self.creer_ustsns()
            nom_ustsns = JOIN(self.chemins['src'], 'ustsns.f90')
            ecrire_fichier(nom_ustsns, self.ustsns_perso)
            
            self.creer_ustske()
            nom_ustske = JOIN(self.chemins['src'], 'ustske.f90')
            ecrire_fichier(nom_ustske, self.ustske_perso)
        elif CS_VERSION == 3:
            self.creer_cs_boundary()
            nom_cs_boundary = JOIN(self.chemins['src'], 'cs_user_boundary_conditions.f90')
            ecrire_fichier(nom_cs_boundary, self.cs_boundary_perso)
            
            self.creer_cs_sourceterms()
            nom_cs_sourceterms = JOIN(self.chemins['src'], 'cs_user_source_terms.f90')
            ecrire_fichier(nom_cs_sourceterms, self.cs_sourceterms_perso)

            self.creer_cs_postprocess()
            nom_cs_postprocess = JOIN(self.chemins['src'], 'cs_user_postprocess_var.f90')
            ecrire_fichier(nom_cs_postprocess, self.cs_postprocess_perso)

    ### ACCES AUX EXECUTABLES SATURNE
    def lancer_saturne_gui(self):
        """
        lance l'interface graphique de saturne et charge le fichier
        de configuration xml s'il existe
        """
        self.trouver_xml()
        if self.chemins['conf_xml']:
            if CS_VERSION != 3:
                subprocess.Popen(['code_saturne',
                                  'gui',
                                  '-f',
                                  self.chemins['conf_xml']])
            else:
                subprocess.Popen(['code_saturne',
                                  'gui',
                                  self.chemins['conf_xml']])
        else:
            subprocess.Popen(['code_saturne',
                              'gui'])

    def lancer_preprocess(self):
        """
        execute le preprocesseur de saturne avec l'executable cs_preprocess
        """
        com = ['cs_preprocess',
               '--reorient',
               self.chemins['geometrie'],
               '--log',
               self.chemins['listpre']]
               
        subprocess.call(com)
	
    def lancer_simulation(self, terminal = True):
        """
        lance la simulation saturne dans un terminal
        """
        ici = os.path.realpath(os.curdir)
        
        if CS_VERSION == 3:
            start_time = '%d%.2d%.2d-%.2d%.2d'%time.localtime()[:5]
        else:
            start_time = '%.2d%.2d%.2d%.2d'%time.localtime()[1:5]
                        

        # si une simulation a deja ete lancee avec le meme identifiant
        if start_time == self.start_time:
            while('%0.2d'%time.localtime()[4] == start_time[-2:]):
                time.sleep(1)

        if CS_VERSION == 3:
            self.start_time = '%d%.2d%.2d-%.2d%.2d'%time.localtime()[:5]
        else:
            self.start_time = '%.2d%.2d%.2d%.2d'%time.localtime()[1:5]
        
        if CS_VERSION:
            os.chdir(self.chemins['data'])
            nom_param = os.path.split(self.chemins['conf_xml'])[1]   
            if terminal:
                com = ['gnome-terminal', '-e', 'code_saturne run -p %s'%nom_param, '&']
            else:
                com = ['code_saturne', 'run', '-p', nom_param, '&']
            self.simu = subprocess.Popen(com)
            os.chdir(ici)
        else:
            if terminal:
                com = ['gnome-terminal', '-e', self.chemins['runcase'], '&']
            else:
                com = [self.chemins['runcase']]
                
            self.simu = subprocess.Popen(com)

    ### SUIVI DES SIMULATIONS
    def print_listing(self):
        """
        affiche le fichier listing dans un terminal
        avec la commande cat
        """
        self.trouver_listing()
        com = ['cat', self.chemins['listing']]
        
        subprocess.call(com)
        
    def trouver_listing(self):
        """
        trouve le fichier listing dans le repertoire temporaire de saturne
        """
        if CS_VERSION == 3:
            self.chemins['listing'] = JOIN(self.chemins['resu'], self.start_time, 'listing')
        else:
            chemin_tmp = trouver_chemin_cas(self.nom_cas, self.case1)
            self.chemins['tmp'] = chemin_tmp
            self.chemins['listing'] = JOIN(chemin_tmp, 'listing')

    def lire_listing(self):
        """
        lit et parse le fichier listing
        """
        if not self.chemins['listing']:
            self.trouver_listing()
        listing_fichier = open(self.chemins['listing'])
        listing_lignes = listing_fichier.readlines()
        listing_fichier.close()
        
        self.liste_timestep = self.parser_listing(listing_lignes)

    def parser_listing(self, listing_lignes):
        """
        parse le fichier listing et renvoi une liste de dictionnaires
        contenant chacun les informations relatives a un pas de temps
        """
        time_step = 0
        liste_ts = []
        dic_ts = {}
        for ligne in listing_lignes:
            tab = ligne.split()
                    
            if len(tab)>0 and tab[0] == 'INSTANT':
                if time_step != 0:
                    liste_ts.append(dic_ts)
                dic_ts = {}
                time_step +=  1
                dic_ts['TimeStep'] = time_step
                
            elif len(tab)>0 and tab[0] == 'c':
                dic = parse_listing_tab(ligne)

                var = dic['Variable'].split()
                if len(var) == 1:
                    dic_var = var[0]
                else:
                    dic_var = ''
                    for i in range(len(var)):
                        dic_var +=  str(var[i])
                dic['Variable'] = dic_var
                dic_ts['conv_'+dic['Variable']] = dic

            elif len(tab)>1 and tab[0] == 'v':
                dic = parse_listing_tab(ligne)
                dic_ts[dic['Variable']] = dic

            elif len(tab)>6 and tab[0] == 'CPU':
                dic_ts['CPU time'] = float(tab[7])

            elif 'END OF CALCULATION' in ligne:
                print 'fin du calcul'
                self.trace = 0
        return liste_ts
        
    def tracer_listing(self, liste_variable = None):
        """
        trace l'evolution de la convergence des variables contenues dans 
        liste_variable
        """
        self.lire_listing()
        if not liste_variable:
            plot_convergence(self.liste_timestep)
        else:
            plot_convergence(self.liste_timestep, 
                             liste_variables = liste_variable)

    def tracer_listing_continu(self, 
                               rafraichissement = 30, 
                               liste_variable = None):
        """
        trace l'evolution en continu de la convergence des variables 
        contenues dans liste_variable
        """
        while self.trace:
            self.tracer_listing(liste_variable = liste_variable)
            time.sleep(rafraichissement)
    
    def tester_convergence(self, liste_variables, largeur, ecart_max):
        """
        teste la convergence
        (pas tres stable, a revoir)
        """
        dic_ts = convertir_time_step(self.liste_timestep)
        is_ok = 1
        for variable in liste_variables:
            is_ok *= tester_convergence_bande(dic_ts[variable][-largeur:], 
                                                  ecart_max)
        return bool(is_ok)

    def tester_convergence_bis(self, 
                               variable, 
                               largeur_bande = 15, 
                               ecart_max = 0.08):
        """
        teste la convergence
        (pas tres stable, a revoir)
        """
        dic_ts = convertir_time_step(self.liste_timestep)
        liste_variable = dic_ts[variable]
        return tester_convergence(liste_variable, largeur_bande, ecart_max)

    def suivre_simulation(self,
                           time_simul = None, 
                           fn_nv_timestep = None):
        """
        extrait les donnees extraites du fichier listing 
        a la volee et trace 
        
        a chaque nouveau pas de temps, execute la fonction fn_nv_timestep()
        """
        if time_simul:
            rep_tmp = '%s.%s.%s' % (self.nom_cas, self.case1, time_simul)
            self.chemins['tmp'] = JOIN(CHEMIN_TMP_SATURNE, rep_tmp)
        else:
            if CS_VERSION != 3:
                self.chemins['tmp'] = trouver_chemin_cas(self.nom_cas, self.case1)
        self.trouver_listing()
        fichier = open(self.chemins['listing'], 'r')
        nouveau_pas = False
        timestep = 0
        xxx = True
        lst_dic_ts = []
        while xxx:
            nouvelles_lignes = fichier.readlines()
            nouveau_pas = False
            nv_dic, nouveau_pas, xxx = parse_listing_lignes(nouvelles_lignes, timestep)
            if len(nouvelles_lignes)==0:
                time.sleep(10)
            for dic_ts in nv_dic:
                lst_dic_ts.append(dic_ts)
            if nouveau_pas and timestep > 1:
                print timestep
                if fn_nv_timestep:
                    fn_nv_timestep()

    def verifier_convergence(self, valeur):
        """
        test convergence a retravailler
        """
        if len(self.liste_timestep) > 3:
            derive = []
            liste_cle = ['conv_VitesseX', 
                        'conv_VitesseY', 
                        'conv_VitesseZ',
                        'conv_TempC',
                        'conv_EnerTurb']
            for cle in liste_cle:
                derive.append(self.liste_timestep[-1][cle]['derive'])
            print max(derive), liste_cle[derive.index(max(derive))]
            if max(derive) < valeur:
                self.stopper_simulation()

    def tracer_convergence(self):
        """
        suivre la simulation en tracant la convergence
        (pas tres stable)
        """
        self.suivre_simulation(fn_nv_timestep = plot_convergence(self.liste_timestep))

    def stopper_simulation(self, pas_de_temps = 1):
        """
        arrete la simulation au pas n en editant 
        le fichier ficstp dans le repertoire temporaire 
        de la simulation
        """
        texte = '\n'+str(pas_de_temps)
        if CS_VERSION == 3:
            chemin_fichier = '%s/%s/control_file'%(self.chemins['resu'], self.start_time)
        else:
            chemin_fichier = self.chemins['tmp']+'/ficstp'
        fichier = open(chemin_fichier, 'w')
        fichier.write(texte)
        fichier.close()


    ### CONFIGURATION SATURNE

    def creer_param_xml(self, case = None, study = None, mesh = None):
        if not case:
            case = self.case1
        if not study:
            study = self.nom_cas
        if not mesh:
            if self.chemins['geometrie'] != '':
                mesh = os.path.split(self.chemins['geometrie'])[1]
        
        f_saturne_xml = open(self.chemins['conf_xml'], 'w')
        f_saturne_xml.write(self.saturne_xml_perso)
        f_saturne_xml.close()
        self.conf_xml = XmlFile(self.chemins['conf_xml'])
        self.conf_xml.definir_champ('Code_Saturne_GUI', attribut = 'case', valeur_attribut = case)
        self.conf_xml.definir_champ('Code_Saturne_GUI', attribut = 'study', valeur_attribut = study)
        self.conf_xml.definir_champ('Code_Saturne_GUI/solution_domain/meshes_list/mesh',
                                    attribut = 'name',
                                    valeur_attribut = mesh)
        self.conf_xml.definir_champ('Code_Saturne_GUI/solution_domain/meshes_list/mesh',
                                    attribut = 'reorient',
                                    valeur_attribut = 'on')



    def changer_nb_processeurs(self, nb_processeurs):
        if CS_VERSION == 3:
            self.conf_xml.definir_champ('calculation_management/n_procs', data = str(nb_processeurs))
        else:
            self.changer_nb_processeurs_CS2(nb_processeurs)

    def choisir_format_postprocess(self, med_ou_ensight):
        if med_ou_ensight == 'ensight':
            self.conf_xml.definir_champ('analysis_control/output/writer/format', 
                                        attribut = 'name', 
                                        valeur_attribut = 'ensight')
            self.conf_xml.definir_champ('analysis_control/output/writer/format', 
                                        attribut = 'options', 
                                        valeur_attribut = 'binary')
        elif med_ou_ensight == 'med':
            self.conf_xml.definir_champ('analysis_control/output/writer/format', 
                                        attribut = 'name', 
                                        valeur_attribut = 'med')
            self.conf_xml.definir_champ('analysis_control/output/writer/format', 
                                        attribut = 'options', 
                                        valeur_attribut = '')
        else:
            print 'choisir med ou ensight'

    def changer_nb_processeurs_CS2(self, nb_processeurs):
        f_runcase = open(self.chemins['runcase'],'r')
        t_runcase = f_runcase.readlines()
        f_runcase.close()
        for i in range(len(t_runcase)):
            if t_runcase[i][:6] == 'PARAM=':
                t_runcase[i] = 'PARAM=%s\n' % os.path.split(self.chemins['conf_xml'])[1]
            if t_runcase[i][:5] == 'MESH=':
                t_runcase[i] = 'MESH=%s\n' % os.path.split(self.chemins['geometrie'])[1]
            if t_runcase[i][:17] == 'COMMAND_REORIENT=':
                t_runcase[i] = 'COMMAND_REORIENT=--reorient\n'    
            if t_runcase[i][:21] == 'NUMBER_OF_PROCESSORS=' :
                t_runcase[i] = 'NUMBER_OF_PROCESSORS=%s\n' % nb_processeurs
        txt = ''
        for i in t_runcase:
            txt += i
        f_runcase = open(self.chemins['runcase'],'w')
        f_runcase.write(txt)
        f_runcase.close()
        
    def changer_nb_iteration(self, iteration = None):
        """
        modifie le nombre d'iteration dans le fichier de configuration xml
        """        
        if iteration:
            self.iteration = iteration
        if CS_VERSION == 3:
            champ_iterations = 'analysis_control/time_parameters/iterations'
        else:
            champ_iterations = 'analysis_control/steady_management/iterations'
        
        self.conf_xml.definir_champ(champ_iterations,
                               data = str(self.iteration))

    def ajouter_iterations(self, iteration_plus):
        """
        ajoute des iterations dans le fichier de condiguration xml
        """
        if CS_VERSION == 3:
            champ_iterations = 'analysis_control/time_parameters/iterations'
        else:
            champ_iterations = 'analysis_control/steady_management/iterations'
        
        iteration = int(self.conf_xml.lire_champ(champ_iterations))
        self.iteration = iteration + iteration_plus
        self.changer_nb_iteration()
        
        print '\t%s iterations ajoutees,' % iteration_plus,
        print 'total : %s iterations' % self.iteration

    def supprimer_restart(self):
        if CS_VERSION == 3:
            self.conf_xml.supprimer_champ('Code_Saturne_GUI/calculation_management/start_restart/restart')

    def definir_restart(self, restart = None):
        if CS_VERSION == 3:
            self.definir_restart_CS3(restart = restart)
        else:
            self.definir_restart_CS2(restart = restart)

    def definir_restart_CS3(self, restart = None):
        """
        utilise la fonction restart de saturne pour commencer la prochaine 
        simulation a partir des resultats d'une simulation precedente

        pour code_saturne gen3
        """

        if restart:
            if len(restart) == 13:
                ch_restart = JOIN(self.chemins['resu'], restart, 'checkpoint')
            else:
                ch_restart = restart
        else:
            ch_restart = JOIN(self.chemins['resu'], self.start_time, 'checkpoint')

        if not os.path.exists(ch_restart):
            print 'ch_restart n existe pas'
            return 1

        champ_restart = 'Code_Saturne_GUI/calculation_management/start_restart/restart'
        doc = xml.dom.minidom.parse(self.chemins['conf_xml'])
        if len(doc.getElementsByTagName('start_restart')) == 0:
            self.conf_xml.definir_champ(champ_restart)
 
        self.conf_xml.definir_champ(champ_restart,
                                    attribut = 'path',
                                    valeur_attribut = ch_restart)
        return 0

    def definir_restart_CS2(self, restart = None):
        """
        utilise la fonction restart de saturne pour commencer la prochaine 
        simulation a partir des resultats d'une simulation precedente

        pour code_saturne gen2
        """
        if restart:
            if len(restart) ==8:
                self.restart = 'RESTART.'+restart
            else:
                self.restart = restart
        else:
            self.restart = 'RESTART.'+self.start_time

        doc = xml.dom.minidom.parse(self.chemins['conf_xml'])
        if len(doc.getElementsByTagName('start_restart')) == 0:
            print 'le noeud -start_restart- n existe pas...'
        
        champ_restart = 'calcul_management/start_restart/restart'
        self.conf_xml.definir_champ(champ_restart,
                                    attribut = 'status',
                                    valeur_attribut = 'on')
                                    
        champ_current_restart = 'calcul_management/start_restart/restart'
        self.conf_xml.definir_champ(champ_current_restart,
                                    data = self.restart)
        subprocess.call(['rm',
                         '-r',
                         '-f',
                         JOIN(self.chemins['data'], 'RESTART')]) 
        
        subprocess.call(['cp', 
                         '-r', 
                         JOIN(self.chemins['resu'], self.restart),
                         self.chemins['data']])
                         
        subprocess.call(['mv',
                         JOIN(self.chemins['data'], self.restart),
                         JOIN(self.chemins['data'], 'RESTART')]) 

    def definir_freeze(self, valeur = True):
        """
        True : fixe les champs de vitesse pour les prochaines simulations
        (plus de resolution de l'ecoulement)
        
        False : reactive le calcul des champs de vitesse pour les prochaines
        simulations
        """
        if valeur:
            valeur_attribut = 'on'
        else:
            valeur_attribut = 'off'

        if CS_VERSION == 3:
            champ_freeze = 'Code_Saturne_GUI/calculation_management/start_restart/frozen_field'
        else:
            champ_freeze = 'calcul_management/start_restart/frozen_field'
        self.conf_xml.definir_champ(champ_freeze,
                               attribut = 'status',
                               valeur_attribut = valeur_attribut)

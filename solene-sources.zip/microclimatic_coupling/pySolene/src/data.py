#!/usr/bin/python
# -*- coding: utf-8 -*-
'''
 *
 *  Copyright 2010-2013 Laurent Malys (CERMA, UMR 1563 AAU, CNRS /
 *                                  Ecole d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
'''

## @package data
#Définition d'une classe Data

"""
--- Version 0.01 ---

@author :
    Laurent Malys, Laboratoire CERMA, UMR 1563
    laurent.malys@cerma.archi.fr


"""
from numpy import *
from geom import *
from utils import *
from vtkFile import *


def enlever_nan(donnee):
    """
    remplace les -nan- par des 0 dans -donnee-
    utiliser pour réparer les boulettes de solene qui cree des nan la nuit
    """
    for i in range(len(donnee)):
        val = donnee[i]
        if str(val) == 'nan':
            print val
            donnee[i] = 0
            
    return donnee

class Data:
    def __init__(self, nom='', geom = None, type = '2D'):
        self.nom = nom
        self.fname = ''
        if geom:
            self.geom = geom
            self.definir_type(type = type)
        else:
            self.geom = Geom()
            self.n_elem = 0
            
        self.type = ''
        self.liste_ts = []
        self.data = {}

    def definir_type(self, type='2D'):

        self.type = type
        if type == '2D':
            self.n_elem = self.geom.n_triangles
        elif type == '3D':
            self.n_elem = self.geom.n_tetras
        else :
            print 'type de donnee = 1D ou 2D'
            

    def ajouter_donnee(self, t, donnee, nom_donnee):
        if len(donnee) == self.n_elem:
            if 'NaN' in donnee.tolist():
                print t, nom_donnee
                donnee = enlever_nan(donnee)
            try:
                self.data[t][nom_donnee]=donnee
            except:
                self.data[t] = {}
                self.data[t][nom_donnee]=donnee
                
        else :
            print 'la longueur ne correspond pas : \n\t nElem=%s, len(donnee)=%s' % (self.nElem, len(donnee))

    def exporter_vtk(self, nom_fichier, liste_variable = None):
        if liste_variable :
            liste_v = liste_variable
        else : 
            liste_v = self.data[0].keys()
            
        for ts in self.data.keys():
            vtk = VtkFile(nom_fichier + '_' + str(ts) +'.vtu', geom=self.geom)
            vtk.ecrire_vtu()
            for var in liste_v:
                vtk.ajouter_donnee(self.data[ts][var], var) 
            vtk.close_xml()
            
    def calculer_evolution_moyenne(self, variable):
        sortie = []
        for t in range(len(self.data.keys())):
            sortie.append(self.data[t][variable].mean())
        return float32(sortie)
    
    def extraire_evolution_triangle(self, variable, i_triangle):
        sortie = []
        for t in range(len(self.data.keys())):
            sortie.append(self.data[t][variable][i_triangle])
        return float32(sortie)
        
    def extraire_evolution_triangle_multi(self, liste_variable, i_triangle):
        sortie = {}
        for var in liste_variable:
            sortie[var] = self.extraire_evolution_triangle(var, i_triangle)
            
        return sortie

    def extraire_evolution_triangles(self, lst_variables, lst_triangles):
        sortie = {}
        for i in lst_triangles:
            for var in lst_variables:
                sortie['%s_%s'%(i,var)] = self.extraire_evolution_triangle(i, var)
        return sortie

    def extraire_monitoring(self, i_triangle):
        
        return 
    
#class Resu:

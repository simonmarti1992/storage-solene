#!/usr/bin/python
# -*- coding: utf-8 -*-
'''
 *
 *  Copyright 2010-2013 Laurent Malys (CERMA, UMR 1563 AAU, CNRS /
 *                                  Ecole d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
'''

"""@package solProcess
======================================================================
= =                       solProcess.py                           = =
======================================================================

Définition d'une classe SolProcess d'executions de processus solene

Version 0.02

@author :
    Laurent Malys, Laboratoire CERMA, UMR 1563
    laurent.malys@cerma.archi.fr
    
création : 11/09/2013
"""

import os
import time

from utils import Chrono, ecrire_fichier
from solFile import *


class SolProcess():
    """
    """
    def __init__(self,
                 pysolene_main):
        self.sim = pysolene_main

    def calculer_eclairements(self, fichier_meteo = None):
        if not fichier_meteo:
            self.sim.SolCommand.calculer_luminance_ciel()

        self.sim.SolCommand.calculer_flux_solaires(fichier_meteo = fichier_meteo)
        if not os.path.exists(self.sim.SolCommand.facform+'.fac'):
            self.sim.SolCommand.calculer_fac_form()
        self.sim.SolCommand.calculer_radiosite()
    
        

#!/usr/bin/python
# -*- coding: utf-8 -*-
'''
 *
 *  Copyright 2010-2013 Laurent Malys (CERMA, UMR 1563 AAU, CNRS /
 *                                  Ecole d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
'''

"""@package main
MAIN

@author :
    Laurent Malys, Laboratoire CERMA, UMR 1563
    laurent.malys@cerma.archi.fr
"""

# modules generiques python
import os
import numpy as np
import xml.dom.minidom
import subprocess
import time

# modules noyau solenetb
from utils import Chrono, ecrire_fichier, norm
from xmlFile import get_data
from famille import Familles, CARAC_CLASSE, importer_familles_xml
from data import Data
from timeStep import TimeStep, demander_interval
from geom import Geom
import meteo as meteo_obj

# modules Solene
from solCommand import SolCommand
from solFile import write_val, read_val, read_cir, write_cir
from solEnv import SolEnv, InterpolVal

# modules Saturne et hdf
from satCommand import SatCommand
from hdfFile import MedFile, CplFile
from vtkFile import VtkFile, write_vtu

# import logging
# logging.basicConfig(filename='myapp.log', level=logging.INFO)
# logger = logging.getLogger(__name__)
# formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

# ch = logging.StreamHandler()
# ch.setLevel(logging.DEBUG)
# ch.setFormatter(formatter)
# logger.addHandler(ch)

JOIN = os.path.join

#famille_face = ['arbreext',
#                'bat',
#                 'solair',
#                 'solbat']
#
#famille_tetra = ['air', 
#                 'arbre']
#
#familles_solene = ['arbreext',
#                   'bat',
#                   'solair',
#                   'solbat']
#                   
#familles_solene_saturne = 'bat, solair, solbat'
#                   
#METEO = {}
#METEO[0]={'v_meteo':5.,
#          'direction_meteo':0,
#          'T_meteo':30.}
          
INTERVAL = [8, 7, 10, 00, 9, 7, 16, 00, 1, 0]

def recuperer_xyz_val(nom_fichier, geom):
    """
    renvoi :
        la connectivite de .dat vers le numero du triangle de la geometrie
        le .dat dans l'ordre des triangles correpondant a la geometrie
    """
    cdg = geom.triangles.cdg
    cdg = cdg.transpose()
    fichier_dat = open(nom_fichier, 'r')
    dat_lignes = fichier_dat.readlines()
    dat = []
    
    for ligne in dat_lignes:
        dat.append(ligne.split())
        
    dat = np.float32(np.array(dat))
    con = {}
    con_inv = {}
    for i in range(len(dat)):
        i_dat = dat[i]
        lien = _trouver_cdg_xyz(i_dat, cdg)
        con[i] = lien
        con_inv[lien] = i
        
#    if len(con) == len(dat):
#        lst_val = np.zeros(geom.n_triangles)
#        array_val = dat.transpose()[3]
#        for i in range(len(dat)):
#            lst_val[con[i]] = array_val[i]
#            
#    else:
#        lst_val = None
    fichier_dat.close()
    return con, con_inv, #lst_val

def _trouver_cdg_xyz(i_dat, liste_cdg):
    """
    renvoi le numero du triangle dans la liste -cdg- correspondant a la valeur
    du -i_dat- du dat
    """

    epsilon = 0.05
    liste_0 = np.arange(len(liste_cdg[0]))
    liste_x = liste_0[abs(liste_cdg[0]-i_dat[0]) < epsilon]
    liste_y = liste_x[abs(liste_cdg[1][liste_x]-i_dat[1]) < epsilon]
    liste_z = liste_y[abs(liste_cdg[2][liste_y]-i_dat[2]) < epsilon]

        
    if len(liste_z) == 1:
        return liste_z[0]
        
    elif len(liste_z) == 0:
        print 'cdg non trouvé', i_dat
        return None
    else:
        print 'plusieurs points confondus'
        print 'changer epsilon?'
        return None
        

def test_convergence(iter_old, iter_new):
    """
    effectue le test de convergence entre les fichiers iter_old et iter (.val)
    renvoie true si cv
    """
    
    ecart_max = 1.0
    ecart_moy = 0.1
    
    iter_old_valeur = np.array(read_val(name = iter_old))
    iter_valeur = np.array(read_val(name = iter_new))
    
    if max(abs(iter_valeur - iter_old_valeur)) > ecart_max:
        return False
    
    if np.mean(abs(iter_valeur - iter_old_valeur)) > ecart_moy:
        return False
   
    return True
    
def return_interval(fichier_xml):
    """
    renvoi l'interval de simulation sous forme d'une liste
    """
    interval = []
    lst_nom_champ = ['debut_jour',
                 'debut_mois',
                 'debut_heure',
                 'debut_minutes',
                 'fin_jour',
                 'fin_mois',
                 'fin_heure',
                 'fin_minutes',
                 'pas_heure',
                 'pas_minutes']
                 
    for nom_champ in lst_nom_champ:
        interval.append(int(get_data(fichier_xml, nom_champ)))
        
    return interval
    
                 

class SimulationCouplee:
    """
    Contrôle du couplage solene-saturne 
    """
    def __init__(self, 
                 param_xml = None,
                 chemin_sim = None,
                 nom_cas = None,
                 init = True):
                     
        self.dic_val2dat = {}
        self.dic_dat2val = {}

        self.chemin_param_xml = param_xml
             
        #logger.info('test')
    
        self.n_proc_saturne = 1

        if param_xml:            
            self.fic_param_xml = xml.dom.minidom.parse(param_xml)
            chemin_cas = get_data(self.fic_param_xml, 'chemin_cas')
            chemin_sim = os.path.split(chemin_cas)[0]
            nom_cas = os.path.split(chemin_cas)[1]
            
            interval = return_interval(self.fic_param_xml)

            self.chemin_familles_xml = get_data(self.fic_param_xml, 'chemin_familles_xml')
            self.chemin_familles_val = get_data(self.fic_param_xml, 'chemin_familles_val')
            self.chemin_materiaux_xml = get_data(self.fic_param_xml, 'chemin_materiaux_xml')
            self.chemin_geometrie = get_data(self.fic_param_xml, 'chemin_geometrie_saturne')
            try:
                self.nom_geometrie = os.path.split(self.chemin_geometrie)[1]
            except:
                pass
                
            self.initialisation = get_data(self.fic_param_xml, 'initialisation_cir_ou_med')
            self.chemin_geometrie_solene_triangle = get_data(self.fic_param_xml, 'chemin_geometrie_solene_triangle')
            self.chemin_geometrie_solene_face = get_data(self.fic_param_xml, 'chemin_geometrie_solene_face')
            self.reconstruction_geom = bool(get_data(self.fic_param_xml, 'reconstruction_geom'))
            self.chemin_fichier_meteo = get_data(self.fic_param_xml, 'chemin_fichier_meteo')
            self.type_fichier_meteo = get_data(self.fic_param_xml, 'type_fichier_meteo')
            try:
                self.n_proc_saturne = int(get_data(self.fic_param_xml, 'n_proc_saturne'))
            except:
                pass

        self.nom_cas = nom_cas
        self.chemin_cas = JOIN(chemin_sim, nom_cas)

        print '\n  == INITIALISATION SIMULATION COUPLEE == '
        print '\t repertoire de travail: ', chemin_sim
        print '\t nom du cas: ', nom_cas
        
        
        if not os.path.isdir(self.chemin_cas):
            print " \t creation -chemin_cas- %s" % self.chemin_cas
            os.makedirs(self.chemin_cas)
        
        else : 
            print "\t %s existe deja" % self.chemin_cas
            
        self.sauvegarde = JOIN(chemin_sim, nom_cas, 'sauvegarde')
        if not os.path.isdir(self.sauvegarde):
            os.makedirs(self.sauvegarde)
            print " \t creation chemin -sauvegarde-"
            
        self.sauvegarde_geom_med = JOIN(self.sauvegarde, 'geom_med.cpl')
        self.sauvegarde_geom_sol = JOIN(self.sauvegarde, 'geom_sol.cpl')
        
        self.temp = JOIN(self.chemin_cas, 'temp')
        if not os.path.isdir(self.temp):
            os.makedirs(self.temp)
            print " \t creation chemin -temp-"
            
        self.post = JOIN(self.chemin_cas, 'post')
        if not os.path.isdir(self.post):
            os.makedirs(self.post)
            print " \t creation chemin -post-"
            
        # initialisation des modules de commande de Solene et Saturne
        chemin_simulSol = JOIN(self.chemin_cas, 'simulSol')
        chemin_simulSat = JOIN(self.chemin_cas, 'simulSat')
        
        self.SolCommand = SolCommand(chemin_simulSol,
                                     nom_cas)
        self.SatCommand = SatCommand(chemin_simulSat,
                                     nom_cas)
                                 
        self.geom_sol = Geom()
        self.geom_med = Geom()
        self.geom_sol_masque = Geom()
        self.familles = Familles()

        self.solEnv = SolEnv(self.SolCommand, self.geom_sol) 
        
        # choix des intervalles de simulations
        self.TimeStep = TimeStep()

        self.meteo_liste = []
        self.meteo = {}
        if interval:
            self.definir_liste_ts(interval)
        try:
            self.importer_meteo(self.chemin_fichier_meteo, 
                                type_meteo = self.type_fichier_meteo)
            self.SolCommand.definir_meteo_dic(self.meteo_liste)
        except:
            print 'probleme importation meteo'
            
        self.lien_dat_val = {}
        self.lien_val_dat = {}
        
        self.resul_sol = Data()
        self.resul_sat = Data()
        
        self.resul = []
        
        self.dic_num_fac = {}
        
        if init:
            if self.initialisation == 'cir':
                self.initialiser_couplage_cir(face = True)
            elif self.initialisation == 'cir_tr':
                self.initialiser_couplage_cir(face = False)
            elif self.initialisation == 'med':
                self.initialiser_med(nom_geometrie = self.chemin_geometrie)
            elif self.initialisation == 'non':
                print 'pas d\'initialisation'

#========================================#
#          Gestion session               #
#========================================#
        
    def initialiser_couplage_cir(self, face = True):
        """
        initialisation dans le cas de l'utilisation de geometrie .cir
        -> pas d'import depuis .med ni de reconstruction
        """
        
        scene_cir = self.chemin_geometrie_solene_triangle
        masque_cir = self.chemin_geometrie_solene_face

        self.familles = importer_familles_xml(self.chemin_familles_xml)
      
        self.familles.importer_materiaux_from_xml(self.chemin_materiaux_xml)
        
        try:
            self.SatCommand.copier_geometrie(self.chemin_geometrie)
        except:
            print 'initialiser_couplage_cir: probleme importation geometrie'

        if os.path.isfile(scene_cir):
            if os.path.isfile(self.sauvegarde_geom_sol):
                print '\n chargement de la geometrie solene depuis .cpl'
                self.charger_cpl('sol')
                
            elif os.path.isfile(masque_cir):
                print 'IMPORTATION DE LA GEOMETRIE SOLENE DEPUIS .cir'
                if face:
                    print '\t recuperation de la geometrie triangulee et des masques'
                    self.geom_sol = read_cir(scene_cir,
                                             mask = masque_cir)
                    self.geom_sol.recuperer_normale_face()
                    
                else:
                    print '\t recuperation de la geometrie triangulee sans les masques'
                    self.geom_sol = read_cir(scene_cir)
                                             
                self.geom_sol.triangles.famille = read_val(self.chemin_familles_val, 
                                                               self.geom_sol)
                self.geom_sol.trouver_familles()
                self.geom_sol.familles = self.familles.exporter_dic_sol()
                self.geom_sol.calculer_cdg()

                if face:
                    self.enregistrer_sim_solene()
                    self.exporter_geom_solene()
                else:
                    self.enregistrer_sim_solene()
                    subprocess.call(['cp', 
                                     scene_cir, 
                                     self.SolCommand.scene_cir + '.cir'])
                    subprocess.call(['cp', 
                                     masque_cir, 
                                     self.SolCommand.masque_cir + '.cir'])
                
                    
                print '\t extraction de la geometrie triangulee'
                print '\t avec contour des faces depuis .cir:' 
                print '\t', scene_cir
                print '\t', masque_cir
                print 
                print '\t enregistrement en .cpl'

            else:
                print masque_cir, 'n existe pas ?'
                try:
                    self.geom_sol = read_cir(scene_cir)
                    print 'extraction de la geometrie triangulee depuis .cir:' 
                    print '\t', scene_cir
                except:
                    print 'probleme extraction geometrie solene depuis cir :'
                    print '\t', scene_cir       
                
        else:
            print scene_cir, 'n existe pas ?'  

        
        self.resul_sol = Data(geom = self.geom_sol, type = '2D')
        
        self.familles.attribuer_num_familles(self.geom_sol.familles)
       
        
        self.solEnv = SolEnv(self.SolCommand, 
                             self.geom_sol, 
                             familles = self.familles,
                             data = self.resul_sol, 
                             timeStep = self.TimeStep) 
                             
        
    def initialiser_med(self, 
                    nom_geometrie=None,
                    reconstruction = True):
        """
        initialisation avec couplage : 
        le cas echeant, reconstruction de la geometrie med 
        et creation des .cir scene et masques de solene
        """
    
        print
        print "  CREATION DE L'ENVIRONNEMENT DE COUPLAGE"
        print

        
        if nom_geometrie:
            self.SatCommand.copier_geometrie(self.chemin_geometrie)
        else:
            if self.reconstruction_geom:
                try:
                    self.SatCommand.copier_geometrie(self.chemin_geometrie)
                except:
                    print 'renseigner la geometrie dans param.xml'

        if os.path.isfile(self.sauvegarde_geom_med):
            self.charger_cpl('sat')
        else:
            geom_med = MedFile(self.SatCommand.chemins['geometrie'])
            try:
                self.geom_med = geom_med.extraire_geom()
            except:
                print 'l\'importation depuis med a echoue \n-- suppression du fichier dans MESH'
                os.remove(self.SatCommand.chemins['geometrie'])
            
        self.familles = importer_familles_xml(self.chemin_familles_xml)
        self.familles.importer_materiaux_from_xml(self.chemin_materiaux_xml)  
        self.familles.attribuer_num_familles(self.geom_med.familles)
        self.familles.importer_materiaux_from_xml(self.chemin_materiaux_xml)
            
        if os.path.isfile(self.sauvegarde_geom_sol):
            self.charger_cpl('sol')
        else:
            print '\t -> il faut extraire la geometrie solene'
            
            # RECONSTRUCTION GEOMETRIE MED ET EXPORT GEOMETRIE CIR
        
            if reconstruction:
                self.geom_med.reconstruire_geom()
                self.extraire_geom_solene()
                self.exporter_geom_solene()
                self.enregistrer_sim()
            else:
                print "Attention : la geometrie n est pas chargee"

        self.dic_num_fac = self.geom_med.familles
        
        self.resul_sol = Data(geom = self.geom_sol, type = '2D')
        self.resul_sat = Data(geom = self.geom_med, type = '3D')
        
        print "\t creation de l'environnement solene"
        
        self.solEnv = SolEnv(self.SolCommand, 
                             self.geom_sol, 
                             data = self.resul_sol, 
                             timeStep =self.TimeStep,
                             familles = self.familles) 
                             
        self.solEnv.definir_meteo_liste(self.meteo_liste)
        

    def maj_famille(self, maj_fichier_param = False):
        """
        mise a jour des familles en cas de modification du fichier famille.xml
        """
        self.familles.importer_from_xml(self.chemin_familles_xml)
        self.familles.attribuer_num_familles(self.geom_sol.familles)

        if maj_fichier_param:
            self.solEnv.creer_param_simulation_ts()
        

    def definir_liste_ts(self, interval = None):
        """
        change la periode simulation 
        
        Attention : pour que toutes les valeurs correctes soient conservees, 
        il faut que la nouvelle periode soit incluse dans la precedente
        (todo)
        """
        if interval == None:
            interval = demander_interval()
            
        self.TimeStep.definir_liste_ts(interval)
        self.SolCommand.definir_liste_jours(self.TimeStep.liste_jours)
        self.SolCommand.liste_ts_sol = self.TimeStep.liste_ts_sol
            
    def charger_cpl(self, sat_ou_sol):
        """
        recupere les geometrie saturne et solene sauvegardées 
        au format cpl
            sat_ou_sol:string ('sat' ou 'sol')
        """
        print '\n\t recuperation de la geometrie %s au format -.cpl-' % sat_ou_sol
        if sat_ou_sol == 'sat':
            geom_cpl = CplFile(self.sauvegarde_geom_med)
            geom_cpl.charger_geom()
            self.geom_med = geom_cpl.geom
            self.geom_med.nom = 'geom_med'

            
        elif sat_ou_sol == 'sol':
            geom_cpl = CplFile(self.sauvegarde_geom_sol)
            geom_cpl.charger_geom()
            self.geom_sol = geom_cpl.geom
            self.geom_sol.nom = 'geom_sol'
            
    def importer_meteo(self, fichier_meteo, type_meteo = 'RT'):
        """
        importer les donnees meteo depuis un fichier meteo
        
        parse suivant les regles definies dans meteo.py d'apres le 
        type de fichier meteo (string : type_meteo)
        """
        
        if type_meteo == 'RT':
            meteo_tout = meteo_obj.parser_fichier_meteo_RT(fichier_meteo)
        elif type_meteo == 'ONEVU':
            meteo_tout = meteo_obj.parser_fichier_meteo_ONEVU(fichier_meteo)
        elif type_meteo == 'HEPIA':
            meteo_tout = meteo_obj.parser_fichier_meteo_HEPIA(fichier_meteo)
        elif type_meteo == 'Khaled':
            meteo_tout = meteo_obj.parser_fichier_meteo_khaled(fichier_meteo)
        elif type_meteo == 'ILYES':
            meteo_tout = meteo_obj.parser_fichier_meteo_ILYES(fichier_meteo)
        liste_meteo = []
        dic_meteo = {}
        
        for heure_s in self.TimeStep.liste_ts:
            liste_meteo.append(meteo_tout[int(heure_s/3600)-1])
            
        ## Ajouter direction si elle n'est pas renseigné comme dans la RT
        if type == 'RT':
            for i in range(len(liste_meteo)):
                liste_meteo[i]['direction'] = 0
            
        for i in range(len(self.TimeStep.liste_ts_sol)):
            dic_meteo[self.TimeStep.liste_ts_sol[i]] = liste_meteo[i]
    
        self.meteo_liste = liste_meteo
        self.meteo = dic_meteo
        #print 'importation meteo ok'

    def initialiser_saturne_old(self):
        """
        initialisation de saturne :
        renseignement des classes dans les fichiers de configuration
        ecriture des fichiers meteo
        ecritures des fichiers de configuration
        """
        
        lst_fam_classe = self.familles.renvoyer_liste_famille_classes
        
        self.SatCommand.familles_paroi_veine = lst_fam_classe('paroi_veine', chaine = True)
        self.SatCommand.familles_surface_arbre = lst_fam_classe('surface_arbre', chaine = True)
        self.SatCommand.familles_murs = lst_fam_classe(['sol',
                                                        'batiments',
                                                        'toit',
                                                        'vitrage',
                                                        'mur'],
                                                        chaine = True)
        
        self.SatCommand.definir_meteo(self.meteo_liste[0])
        self.SatCommand.creer_usvpst()
        self.SatCommand.creer_usclim()
        self.SatCommand.ecrire_subroutines()

    def initialiser_saturne(self):
        """
        initialisation de saturne
        """
        self.SatCommand.recuperer_listes_from_famille(self.familles)
        self.SatCommand.ecrire_subroutines()
        self.SatCommand.creer_param_xml()
        if self.n_proc_saturne > 1:
            self.SatCommand.changer_nb_processeurs(self.n_proc_saturne)
        self.creer_dat_constant(self.SatCommand.nom_dat['Fsensible'], 0.0)
        self.creer_dat_constant(self.SatCommand.nom_dat['Flatent'], 0.0)
        ecrire_fichier(os.path.join(self.SatCommand.chemins['data'], 'z0'), '10.0')


#========================================#
#           *utiles                      #
#========================================#

    def lire_val(self, nom_var, ts = None):
        """
        renvoie la valeur d'une variable -nom_var- au pas de temps -ts-
        """
        if nom_var in self.SolCommand.var.keys():
            if ts:
                nom_fichier = '%s_%s.val' % (self.SolCommand.var[nom_var], ts)
            else:
                nom_fichier = '%s.val' % (self.SolCommand.var[nom_var])
        if nom_var in self.SolCommand.carac.keys():
            nom_fichier = '%s.val' % (self.SolCommand.carac[nom_var])
        if os.path.isfile(nom_fichier):
            return read_val(nom_fichier, self.geom_sol)

#========================================#
#           Initialisation               #
#========================================#

    def extraire_geom_solene(self):
        """
        cree la geometrie -geom_sol- extraite de la geometrie med
        """
        liste_num = []
        liste_num_masque = []
        for fam in self.familles.familles.keys():
            famille = self.familles.familles[fam]
            if CARAC_CLASSE[famille.classe]['solene'] :
                #print famille.nom, famille.num
                liste_num_masque.append(famille.num)
                if CARAC_CLASSE[famille.classe]['emissivite']:
                    liste_num.append(famille.num)

        #print liste_num
        #print liste_num_masque
                
#        liste_num = self._creer_liste_famille_numero(familles_solene)

        self.geom_sol = self.geom_med.creer_sous_geom(nom = 'geom_sol',
                                                      liste_famille = liste_num)
        self.geom_sol_masque = self.geom_med.creer_sous_geom(nom= 'geom_sol_masque',
                                                             liste_famille = liste_num_masque)
                                                  
    def enregistrer_sim(self):
        """
        enregistre les donnees geometriques obtenues apres pre-process
        au forma cpl (sol et med triangulees)
        """
        geom_sol_cpl = CplFile(self.sauvegarde_geom_sol, self.geom_sol)
        geom_sol_cpl.enregistrer_geom()
        
        geom_med_cpl = CplFile(self.sauvegarde_geom_med, self.geom_med)
        geom_med_cpl.enregistrer_geom()
        
    def enregistrer_sim_solene(self):
        """
        enregistre les donnees geometriques obtenues apres pre-process
        au forma cpl (solene triangle et solene face)
        """
        geom_sol_cpl = CplFile(self.sauvegarde_geom_sol, self.geom_sol)
        if self.initialisation == 'cir_tr':
            geom_sol_cpl.enregistrer_geom(face = False)
        else:
            geom_sol_cpl.enregistrer_geom()
	
    def exporter_geom_solene(self):
        """
        cree les fichier cir triangule et non triangules
        """
        write_cir(name = self.SolCommand.masque_cir, 
                  geom = self.geom_sol,
                  faces = True)
        
        write_cir(name = self.SolCommand.scene_cir,
                  geom = self.geom_sol,
                  faces = False)
                  
#    def _creer_liste_famille_numero(self, liste):
#        """
#        cree la liste des numeros correspondant à une liste au format
#        texte
#        """
#        liste_famille = self.familles.familles.keys()
#        liste_numero = []
#        for nom_famille in liste:
#            if nom_famille in liste_famille:
#                liste_numero.append(int(self.familles.familles[nom_famille].num))
#            else :
#                "= la famille -%s- n'est pas dans la base" % nom_famille
#                
#        return liste_numero
        
    def creer_dat_constant(self, nom_dat, valeur):
        """
        creation dat uniforme
        """
        texte = ('%s\n' % valeur) * self.geom_sol.n_triangles
        if self.n_proc_saturne == 1:
            ecrire_fichier(nom_dat, texte)
        else:
            for i in range(self.n_proc_saturne):
                ecrire_fichier("%s_%s"%(nom_dat, i), texte)

    def connection_dat2val(self, fichier_dat):
        """
        a l'aide d'un fichier .dat quelconque, retrouve le lien entre
        les cdg du dat et les patchs de la geometrie solene
        """
        if self.n_proc_saturne == 1:
            con, con_inv = recuperer_xyz_val(fichier_dat, 
                                             geom = self.geom_sol)
        
            self.lien_dat_val = con
            self.lien_val_dat = con_inv
        else:
            self.connection_dat2val_multipro_bis(fichier_dat, self.n_proc_saturne)
        
    def connection_dat2val_multipro(self, fichier_dat, n):
        """
        a l'aide d'un ensemble de fichiers .dat issus d'une simulation 
        multiprocesseur, retrouve le lien entre
        les cdg du dat et les patchs de la geometrie solene
        """
        if fichier_dat[-4:] == '.dat':
            fichier_dat = fichier_dat[:-4]
        
        for i in range(n):
            nom_fichier = '%s_%s.dat' % (fichier_dat, i+1)
            dic_lien, dic_inv_lien = recuperer_xyz_val(nom_fichier, 
                                                       self.geom_sol)
            self.dic_dat2val[i+1] = dic_lien
            for j in dic_inv_lien.keys():
                self.dic_val2dat[j] = [i+1, dic_inv_lien[j]]
            
    def connection_dat2val_multipro_bis(self, fichier_dat, n):
        """
        a l'aide d'un ensemble de fichiers .dat issus d'une simulation 
        multiprocesseur, retrouve le lien entre
        les cdg du dat et les patchs de la geometrie solene
        """
        for j in range(self.geom_sol.n_triangles):
            self.dic_val2dat[j] = []
            
        if fichier_dat[-4:] == '.dat':
            fichier_dat = fichier_dat[:-4]
        for i in range(n):
            nom_fichier = '%s_%s' % (fichier_dat, i)
            dic_lien, dic_inv_lien = recuperer_xyz_val(nom_fichier, 
                                                       self.geom_sol)
            self.dic_dat2val[i+1] = dic_lien
            for j in dic_inv_lien.keys():
                self.dic_val2dat[j].append([i+1, dic_inv_lien[j]])
            
    
    def dat2val_lien(self, fichierdat, fichierval, return_val = False):
        """
        converti un fichier dat en val en utilisant le lien cree par 
        self.connection_dat2val()
        """
        dat = open(fichierdat,'r')
        datlignes = dat.readlines()
        val_valeurs = np.zeros(self.geom_sol.n_triangles)
        
        for i in range(len(datlignes)):
            ligne = datlignes[i]
            ligne_val = ligne.split()
            val_valeurs[self.lien_dat_val[i]] = ligne_val[3]
            
        write_val(name = fichierval, 
                  geom = self.geom_sol, 
                  data = val_valeurs)
        if return_val:
            return val_valeurs
        
    def dat2val_multipro(self, 
                         fichier_dat, 
                         fichier_val, 
                         n_proc, 
                         return_val = False):
        """
        converti plusieurs fichier dat en val en utilisant le lien cree par
        self.connection_dat2val_multipro()
        """
        if fichier_dat[-4:] == '.dat':
            fichier_dat = fichier_dat[:-4]

        val_valeurs = [0] * self.geom_sol.n_triangles
        
        for i in range(n_proc):
            fichier = '%s_%s' % (fichier_dat, i)
            fichier = open(fichier)
            fichier = fichier.readlines()
            for no_dat in range(len(fichier)):
                no_val = self.dic_dat2val[i+1][no_dat]
                val_valeurs[no_val] = fichier[no_dat].split()[3]
                
        write_val(name = fichier_val,
                  geom = self.geom_sol,
                  data = val_valeurs)
        if return_val:
            return val_valeurs
            
    def dat2val(self, fichier_dat, fichier_val, return_val = False):
        if self.n_proc_saturne == 1:
            return self.dat2val_lien(fichier_dat, fichier_val, return_val = return_val)
        else:
            return self.dat2val_multipro(fichier_dat, fichier_val, self.n_proc_saturne, return_val = return_val)


        
    def val2dat_lien(self, fichier_val, fichier_dat, xyz_cdg = False):
        """
        converti un fichier val en dat en utilisant le lien cree par 
        self.connection_dat2val()
        """
        val_valeurs = read_val(name = fichier_val, geom = self.geom_sol)
        
        lien_val_dat = self.lien_val_dat
        dat_cdg = [''] * (len(val_valeurs) + 1)
        cdg = self.geom_sol.triangles.cdg
        
        for i in range(len(val_valeurs)):
            i_dat = lien_val_dat[i]
            
            ligne = ''
            if xyz_cdg:
                for j in range(3):
                    ligne += str(round(cdg[i][j], 2)) + '\t'
            ligne += str(val_valeurs[i])    
            dat_cdg[i_dat] = ligne
            
        chaine_dat = ''
        for i in range(len(dat_cdg)):
            chaine_dat += dat_cdg[i] + '\n'
            
        ecrire_fichier(fichier_dat, chaine_dat)
        
    def val2dat_multipro(self, 
                         fichierval, 
                         fichierdat, 
                         n_proc, 
                         xyz_cdg = False):
        """
        converti un fichier val en dat en utilisant le lien cree par 
        self.connection_dat2val_multipro()
        """
        
        if fichierdat[-4:] == '.dat':
            fichierdat = fichierdat[-4:]
        
        val_valeurs = read_val(name = fichierval, geom = self.geom_sol)
        
        dic_val2dat = self.dic_val2dat
        cdg = self.geom_sol.triangles.cdg
        
        dic_dat = {}
        dic_cdg = {}
        for i in range(n_proc):
            dic_dat[i+1] = {}
        
        for i in range(len(val_valeurs)):
            dat_i = dic_val2dat[i]
            dic_dat[dat_i[0][0]][dat_i[0][1]] = val_valeurs[i]
            if len(dat_i)>1:
                for j in dat_i[1:]:
                    dic_dat[j[0]][j[1]] = val_valeurs[i]
            #dic_dat[dic_val2dat[i][0]][dic_val2dat[i][1]] = cdg[i]
            
        for i in range(n_proc):
            nom_fichier = '%s_%s' % (fichierdat, i)
            chaine_fichier = ''
            for no_dat in dic_dat[i+1].keys():
                if xyz_cdg:
                    for j in range(3):
                        chaine_fichier += str(round(dic_cdg[i+1][no_dat][j], 2)) + '\t'
                chaine_fichier += str(dic_dat[i+1][no_dat])
                chaine_fichier += '\n'
                
            ecrire_fichier(nom_fichier, chaine_fichier)
                
    def val2dat(self, fichier_val, fichier_dat):
        if self.n_proc_saturne == 1:
            self.val2dat_lien(fichier_val, fichier_dat)
        else:
            self.val2dat_multipro(fichier_val, fichier_dat, self.n_proc_saturne)

    def val2dat_old(self, fichierval, fichierdat):
        """
        converti un fichier val en dat en utilisant le lien cree par 
        self.connection_dat2val()
        """
        valeurs = read_val(name = fichierval, geom = self.geom_sol)
        dat = ''
        for i in range(len(valeurs)):
            for j in range(3):
                dat += str(self.geom_sol.triangles.cdg[i][j]) + ' '
            dat += str(valeurs[i]) + '\n'
            
        ecrire_fichier(fichierdat, dat)

    def simulation_Ts_Enegie_Bat_c(self, 
                                   init = True,
                                   meteo = True, 
                                   defTair = True,
                                   defw = True,
                                   defh = False,
                                   nom_commande = 'simulation_Tsurface_EnergieBat_laurent',
                                   ):
        """
        Execute simulation_Ts_EnergieBat pour toute la periode de simulation
        """
                                       
        chrono = Chrono('simulation_ts_energie_bat', 'main')
        liste_ts = self.TimeStep.liste_ts_sol
        
        if init:
            suff_avant = 'init'
            suff_apres = liste_ts[0]
            
            if defTair:
                write_val(self.SolCommand.var['Tair'],
                          self.geom_sol, 
                          self.SolCommand.dic_meteo[suff_apres]['T'])
                          
            if defw:
                write_val(self.SolCommand.var['HR'],
                          self.geom_sol,
                          self.SolCommand.dic_meteo[suff_apres]['w']/1000.)
                          
            if defh:
                write_val(self.SolCommand.var['hc'],
                          self.geom_sol,
                          defh(self.SolCommand.dic_meteo[suff_apres]['v']))

            print 'calcul de %s à %s' % (suff_avant, suff_apres)
            self.SolCommand.simulation_Ts_Energie_Bat(suff_avant, 
                                                      suff_apres, 
                                                      meteo = meteo,
                                                      nom_commande = nom_commande)


        for i in range(1, len(liste_ts)):
            suff_avant = liste_ts[i-1]
            suff_apres = liste_ts[i]
            
            if defTair:
                write_val(self.SolCommand.var['Tair'],
                          self.geom_sol, 
                          self.SolCommand.dic_meteo[suff_apres]['T'])
                          
            if defw:
                write_val(self.SolCommand.var['HR'],
                          self.geom_sol,
                          self.SolCommand.dic_meteo[suff_apres]['w']/1000.)
                          
            if defh:
                write_val(self.SolCommand.var['hc'],
                          self.geom_sol,
                          defh(self.SolCommand.dic_meteo[suff_apres]['v']))


            print 'calcul de %s à %s' % (suff_avant, suff_apres)
            self.SolCommand.simulation_Ts_Energie_Bat(suff_avant, 
                                                      suff_apres, 
                                                      meteo = meteo,
                                                      nom_commande = nom_commande)

        chrono.fin()

    def exporter_geom_vtk(self, nom_vtk, geom_choix):
        """
        exporte la geometrie au format .vtk
        """
        chemin_vtk = JOIN(self.post, nom_vtk)
        vtk = VtkFile(chemin_vtk, geom = geom_choix)
        
        vtk.close_xml()

    def extraire_meteo(self, nom_var):
        """
        renvoi les valeurs de la variable nom_var pendant la periode 
        d'etude sous forme d'un array
        """
        met = np.zeros(len(self.TimeStep.liste_ts_sol))
        for i in range(len(self.TimeStep.liste_ts_sol)):
            met[i] = self.meteo[self.TimeStep.liste_ts_sol[i]][nom_var]
        return met
    
    def coupler_saturne_mrt(self, chemin_resul_sat, i_ts, albedo = 0.3, temperature = True):
        self.solEnv.importer_geom_confort()
        self.solEnv.geom_sol_confort.calculer_cdg()
        self.interpol_sat = InterpolVal(self.solEnv.geom_sol_confort.triangles.cdg, 
                                        self.geom_med.tetras.cdg, 
                                        type_data = 'med')
        med_sat = MedFile(chemin_resul_sat)
        temperature_sat = med_sat.extraire_temperature()
        vitesse_sat_brute = med_sat.extraire_vitesse()
        vitesse_sat_brute = vitesse_sat_brute.reshape(3, len(vitesse_sat_brute)/3)
        vitesse_sat = []
        for v in vitesse_sat_brute.transpose():
            vitesse_sat.append(norm(v))

        vitesse_sat = np.float32(vitesse_sat)

        temperature_geo_sol = self.interpol_sat.interpoler(temperature_sat)
        vitesse_geo_sol = self.interpol_sat.interpoler(vitesse_sat)

	if temperature:
		self.solEnv.creer_param_confort(i_ts, 
						albedo=albedo, 
						vitesse_air = vitesse_geo_sol, 
						temperature_air = temperature_geo_sol)
	else:
		self.solEnv.creer_param_confort(i_ts, 
						albedo=albedo, 
						vitesse_air = vitesse_geo_sol)

    def sol2sat(self, i_ts, n_it_sat = 100):
        ts = self.TimeStep.liste_ts_sol[i_ts]
        v = self.lire_val
        Tse = v('Tse', ts)
        Ta = v('Ta', ts)
        Tair = v('Tair')
        hc = v('hc')
        bool_veg = self.solEnv.carac_val['bool_veg']
        h_ainf = v('h_ainf')
        Fsens = hc * (Tse - Tair)
        Fsens[bool_veg] = (h_ainf * (Ta - Tair))[bool_veg]
        Fsens += v('flux_rad_arbre', ts)
        
        nom_Fsens_val = '%s_%s.val' % (self.SolCommand.var['flux_convectif'], ts) 
        write_val(nom_Fsens_val, self.geom_sol, Fsens)

        self.val2dat(nom_Fsens_val, self.SatCommand.nom_dat['Fsensible'])
        self.val2dat(self.SolCommand.var['flux_latent']+'_'+ ts+'.val', self.SatCommand.nom_dat['Flatent'])

        self.SatCommand.definir_restart()
        self.SatCommand.ajouter_iterations(n_it_sat)
        self.SatCommand.lancer_simulation(terminal = False)
        time.sleep(10)
        self.SatCommand.suivre_simulation()


    def sat2sol(self, i_ts):
        lst_ts = self.TimeStep.liste_ts_sol
        self.dat2val(self.SatCommand.nom_dat['Tair'], self.SolCommand.var['Tair'])
        self.dat2val(self.SatCommand.nom_dat['hs'], self.SolCommand.var['HR'])
        self.SolCommand.simulation_Ts_EnergieBat_new(lst_ts[i_ts-1],
									lst_ts[i_ts],
									simulation_batiment = False,
									simulation_vegetation = True,
									meteo = True,
									terminal = True)
									
    def init_couplage(self, i_ts, ref_sim_sat):
        lst_ts = self.TimeStep.liste_ts_sol
        self.SatCommand.trouver_xml()
        self.SatCommand.definir_restart(ref_sim_sat)
        self.connection_dat2val(self.SatCommand.nom_dat['hs'])
        self.SatCommand.definir_freeze()
        self.solEnv.definir_meteo(i_ts, veg = True)
        self.SolCommand.simulation_Ts_EnergieBat_new(lst_ts[i_ts-1], 
						lst_ts[i_ts],
						simulation_batiment = False,
						simulation_vegetation = True,
						meteo = True,
						terminal = True)

 

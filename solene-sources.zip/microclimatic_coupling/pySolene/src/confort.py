'''
 *
 *  Copyright 2010-2013 Laurent Malys (CERMA, UMR 1563 AAU, CNRS /
 *                                  Ecole d'Architecture de Nantes, France.)
 *
 *  This file is part of SOLENE.
 *
 *  SOLENE is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  SOLENE is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with SOLENE. If not, see <https://www.gnu.org/licenses/>.
'''

import numpy as np
from utils import *

def ret_lim_up(cat, x):
    return 0.33*x+18.8 +cat +1

def ret_lim_down(cat, x):
    return 0.33*x+18.8 -cat -1

def ret_lim_cat_up(cat, x):
    if x < 10:
        gg = ret_lim_up(cat, 10)
    elif x > 30:
        gg = ret_lim_up(cat, 30)
    else :
        gg = ret_lim_up(cat, x)
    return gg

def ret_lim_cat_down(cat, x):
    if x < 15:
        gg = ret_lim_down(cat, 15)
    elif x > 30:
        gg =  ret_lim_down(cat, 30)
    else:
        gg =  ret_lim_down(cat, x)
    return gg

def ret_cat(x, y):
    lst_cat=[4]
    for i in range(1,4):
        if y < ret_lim_cat_up(i, x):# and y > ret_lim_cat_down(i, x):
            lst_cat.append(i)
    return min(lst_cat)

def ret_pourcent_cat(lst_Tint, lst_Tgliss):
    ll = len(lst_Tint)
    if len(lst_Tgliss) != ll:
        print 'les listes ne font pas la meme taille'
    lst_classe = np.zeros(4)
    for i in range(ll):
        lst_classe[ret_cat(lst_Tgliss[i], lst_Tint[i])-1] +=1
    return lst_classe*100.0/ll

def plot_cat(plt):
    xx = np.arange(40)
    #
    cat_I = 0.33*xx+18.8-2
    cat_I[xx<15] = cat_I[xx==15]
    cat_I[xx>30] = cat_I[xx==30]
    #
    cat_I2 = 0.33*xx+18.8+2
    cat_I2[xx<10] = cat_I2[xx==10]
    cat_I2[xx>30] = cat_I2[xx==30]
    #
    cat_II = 0.33*xx+18.8-3
    cat_II[xx<15] = cat_II[xx==15]
    cat_II[xx>30] = cat_II[xx==30]
    #
    cat_II2 = 0.33*xx+18.8+3
    cat_II2[xx>30] = cat_II2[xx==30]
    cat_II2[xx<10] = cat_II2[xx==10]
    #
    cat_III = 0.33*xx+18.8-4
    cat_III[xx<15] = cat_III[xx==15]
    cat_III[xx>30] = cat_III[xx==30]
    #
    cat_III2 = 0.33*xx+18.8+4
    cat_III2[xx<10] = cat_III2[xx==10]
    cat_III2[xx>30] = cat_III2[xx==30]
    #
    lines = []
    labels = []
    lines.append(plt.plot(xx, cat_I, 'g'))
    labels.append('Cat I')
    lines.append(plt.plot(xx, cat_II, 'b'))
    labels.append('Cat II')
    lines.append(plt.plot(xx, cat_III, 'r'))
    labels.append('Cat III')
    plt.plot(xx, cat_I2, 'g')
    plt.plot(xx, cat_II2, 'b')
    plt.plot(xx, cat_III2, 'r')
    return lines, labels
    #plt.legend(['cat I', 'cat II', 'cat III'])
    
# for i in  [0]:
#     plt.subplot(221)
#     plot_cat(plt)
#     for i in range(4):
#         plt.plot(Tair_g[-168:], senv.dic_cas['cas0_couplage']['Tint'][i][-168:], 'rx')
#     plt.title('bat nu, scene nu')
#     plt.subplot(222)
#     plot_cat(plt)
#     for i in range(4):
#         plt.plot(Tair_g[-168:], senv.dic_cas['fac_veg_fix']['Tint'][i][-168:], 'bx')
#     plt.title('bat veg, scene nu')
#     plt.subplot(223)
#     plot_cat(plt)
#     for i in range(4):
#         plt.plot(Tair_g[-168:], senv.dic_cas['fac_veg_indirect']['Tint'][i][-168:], 'yx')
#     plt.title('bat nu, scene veg')
#     plt.subplot(224)
#     plot_cat(plt)
#     for i in range(4):
#         plt.plot(Tair_g[-168:], senv.dic_cas['fac_veg_fix']['Tint'][i][-168:], 'gx')
#     plt.title('bat veg, scene veg')
#     for pl in [221, 222, 223, 224]:
#         plt.subplot(pl)
#         plt.grid()
#         plt.xlim(16,24)
#         plt.ylim(18, 32)

class ConfortAdapt:
    def __init__(self, sim, plt = None):
        self.sim = sim
        self.senv = sim.solEnv
        self.geom =sim.geom_sol
        if plt:
            self.plt = plt

    def get_Tgliss(self):
        Tair = self.sim.extraire_meteo('T')
        Tair_m = h2j(Tair)/24
        Tgliss_j = Tair_m.copy()
        for i in range(1, len(Tair_m)):
            Tgliss_j[i] = (1-0.8) * Tair_m[i-1] + 0.8 * Tgliss_j[i-1]
        Tgliss_h = []
        for i in Tgliss_j:
            for j in range(24):
                Tgliss_h.append(i)
        self.Tgliss = Tgliss_h

    def ret_pourcent_cat(self, cas, tot = False):
        TT = self.senv.dic_cas[cas]['Tint']
        pc_cat = []
        mm = np.zeros(4)
        for et in range(len(TT)):
            pc_cat_i = ret_pourcent_cat(TT[et], self.Tgliss)
            pc_cat.append(pc_cat_i)
            mm += pc_cat_i
        pc_cat.append(mm/len(TT))
        if tot:
            return mm
        else:
            return pc_cat

    def plot_cat(self, cas, plt = None):
        if plt:
            use_plt = plt
        else:
            use_plt = self.plt
        pc_et = self.ret_pourcent_cat(cas)
        pc_et = np.float32(pc_et)
        pc_et = pc_et.transpose()
        b1 = use_plt.barh([1.1, 2.1, 3.1, 4.1, 5.1, 6.1], np.ones(6) * 100, color = 'red', label = 'cat IV')
        b2 = use_plt.barh([1.1, 2.1, 3.1, 4.1, 5.1, 6.1], pc_et[0] + pc_et[1] + pc_et[2], color='orange', label = 'cat III')
        b3 = use_plt.barh([1.1, 2.1, 3.1, 4.1, 5.1, 6.1], pc_et[0] + pc_et[1], color='green', label = 'cat II')
        b4 = use_plt.barh([1.1, 2.1, 3.1, 4.1, 5.1, 6.1], pc_et[0], color='blue', label = 'cat I')
        use_plt.yticks([1.5,2.5,3.5,4.5,5.5,6.5],['rdc+0', 'rdc+1', 'rdc+2','rdc+3', 'rdc+4' , 'tous'])
        use_plt.legend(loc= 3)

    def plot_cat_scat(self, cas, plt = None):
        TT = self.senv.dic_cas[cas]['Tint']
        if plt:
            use_plt = plt
        else:
            use_plt = self.plt 
        lines, labels = plot_cat(use_plt)
        for i in range(len(TT)):
            lines.append(use_plt.plot(self.Tgliss, TT[i], 'x'))
            labels.append('rdc+%s'%i)
        use_plt.legend(lines, labels)
        
        
              
#     plt.savefig(sim.post+'/Confort.pdf')
#     plt.savefig(sim.post+'/Confort.tex')
#     plt.savefig(sim.post+'/Confort.svg')
# from matplotlib import rcParams
# rcParams.keys()
# rcParams['font.serif']
# rcParams['font.family']
# rcParams['tex.usetex']
# rcParams['text.usetex']
# rcParams['text.usetex'] = True
# plt.legend()
# plt.clf()
# plt.plot(xx, yy2, 'r')
# plt.xlabel('test latex')
# plt.xlabel('$\alpha$')

# plt.ylabel('$\alpha$')
# rcParams.keys()
# rcParams['font.family']
# rcParams['font.family'] = 'serif'
# plt.ylabel('$\alpha$')
# plt.ylabel('toto')
# plt.clf()
# plot_cat(plt)
# rcParams['serif']
# rcParams.keys()
# rcParams['text.fontstyle']
# rcParams['font.serif']
# rcParams['font.roman']
# rcParams['font.serif'].append('LMRoman10')
# plt.clf()
# plot_cat(plt)
# plt.clf()
# rcParams['font.serif'].invert()
# rcParams['font.serif'].inverse()
# rcParams['font.serif'].reverse()
# plot_cat(plt)
# plt.legend(['test 01243'])
# plt.xlabel('test latex \Latex')

# plt.xlabel('test latex')
# plt.ylabel('test latex')
# plt.clf()
# plot_cat(plt)
# plot_cat(plt)
# plt.xlabel('test latex')
# Tair = extraire_meteo('T')
# plt.clf()
# plt.subplot(311)
# plt.plot(Tair, 'k', label = 'T meteo')
# plt.subplot(312)
# plt.plot(Tair, 'k', label = 'T meteo')
# plt.subplot(313)
# plt.plot(Tair, 'k', label = 'T meteo')
# plt.subplot(311)
# plt.title('Temperature interieure RdC+2')
# plt.plot(senv.dic_cas['cas0_couplage']['Tint'][2], 'r', label = 'bat nu, facades nues, couplage')
# plt.plot(senv.dic_cas['fac_veg_indirect']['Tint'][2], 'r--', label = 'bat nu, facades veg, couplage')
# plt.plot(senv.dic_cas['fac_veg_couplage']['Tint'][2], 'g', label = 'bat veg, facades veg, couplage')
# plt.plot(senv.dic_cas['fac_veg_fix']['Tint'][2], 'g--', label = 'bat veg, facades nues, sans couplage')
# lst_ts = sol.liste_ts_sol
# lab_x = []
# range_x = []
# for i in range(len(lst_ts)):
#     ts = lst_ts[i]
#     if '00H00' in ts:
#         range_x.append(i)
#         lab_x.append('%s/%s'%(ts.split('_')[0], ts.split('_')[1]))
# plt.xticks(range_x, lab_x)
# plt.grid()
# plt.xlim(24*4-1, 300-37)
# plt.subplot(312)
# plt.plot(senv.dic_cas['cas0_couplage']['Tint'][4], 'r', label = 'bat nu, facades nues, couplage')
# plt.plot(senv.dic_cas['fac_veg_indirect']['Tint'][4], 'r--', label = 'bat nu, facades veg, couplage')
# plt.plot(senv.dic_cas['fac_veg_couplage']['Tint'][4], 'g', label = 'bat veg, facades veg, couplage')
# plt.plot(senv.dic_cas['fac_veg_fix']['Tint'][4], 'g--', label = 'bat veg, facades nues, sans couplage')
# plt.xticks(range_x, lab_x)
# plt.xlim(24*4-1, 300-37)
# plt.grid()
# plt.title('Temperature interieure RdC+4')
# plt.subplot(313)
# plt.plot(senv.dic_cas['cas0_couplage']['Tmean'], 'r', label = 'bat nu, facades nues, couplage')
# plt.plot(senv.dic_cas['fac_veg_indirect']['Tmean'], 'r--', label = 'bat nu, facades veg, couplage')
# plt.plot(senv.dic_cas['fac_veg_couplage']['Tmean'], 'g', label = 'bat veg, facades veg, couplage')
# plt.plot(senv.dic_cas['fac_veg_fix']['Tmean'], 'g--', label = 'bat veg, facades nues, sans couplage')
# plt.xticks(range_x, lab_x)
# plt.xlim(24*4-1, 300-37)
# plt.grid()
# for cle, it in senv.dic_cas.items():
#     TT2 = it['Tint'].transpose()
#     it['Tmean'] = []
#     for i in TT2:
#         it['Tmean'].append(i.mean())
#     it['Tmean'] = np.array(it['Tmean'])
    

# Tair = extraire_meteo('T')
# plt.clf()
# plt.subplot(311)
# plt.plot(Tair, 'k', label = 'T meteo')
# plt.subplot(312)
# plt.plot(Tair, 'k', label = 'T meteo')
# plt.subplot(313)
# plt.plot(Tair, 'k', label = 'T meteo')
# plt.subplot(311)
# plt.title('Temperature interieure RdC+2')
# plt.plot(senv.dic_cas['cas0_couplage']['Tint'][2], 'r', label = 'bat nu, facades nues, couplage')
# plt.plot(senv.dic_cas['fac_veg_indirect']['Tint'][2], 'r--', label = 'bat nu, facades veg, couplage')
# plt.plot(senv.dic_cas['fac_veg_couplage']['Tint'][2], 'g', label = 'bat veg, facades veg, couplage')
# plt.plot(senv.dic_cas['fac_veg_fix']['Tint'][2], 'g--', label = 'bat veg, facades nues, sans couplage')
# lst_ts = sol.liste_ts_sol
# lab_x = []
# range_x = []
# for i in range(len(lst_ts)):
#     ts = lst_ts[i]
#     if '00H00' in ts:
#         range_x.append(i)
#         lab_x.append('%s/%s'%(ts.split('_')[0], ts.split('_')[1]))
# plt.xticks(range_x, lab_x)
# plt.grid()
# plt.xlim(24*4-1, 300-37)
# plt.subplot(312)
# plt.plot(senv.dic_cas['cas0_couplage']['Tint'][4], 'r', label = 'bat nu, facades nues, couplage')
# plt.plot(senv.dic_cas['fac_veg_indirect']['Tint'][4], 'r--', label = 'bat nu, facades veg, couplage')
# plt.plot(senv.dic_cas['fac_veg_couplage']['Tint'][4], 'g', label = 'bat veg, facades veg, couplage')
# plt.plot(senv.dic_cas['fac_veg_fix']['Tint'][4], 'g--', label = 'bat veg, facades nues, sans couplage')
# plt.xticks(range_x, lab_x)
# plt.xlim(24*4-1, 300-37)
# plt.grid()
# plt.title('Temperature interieure RdC+4')
# plt.subplot(313)
# plt.plot(senv.dic_cas['cas0_couplage']['Tmean'], 'r', label = 'bat nu, facades nues, couplage')
# plt.plot(senv.dic_cas['fac_veg_indirect']['Tmean'], 'r--', label = 'bat nu, facades veg, couplage')
# plt.plot(senv.dic_cas['fac_veg_couplage']['Tmean'], 'g', label = 'bat veg, facades veg, couplage')
# plt.plot(senv.dic_cas['fac_veg_fix']['Tmean'], 'g--', label = 'bat veg, facades nues, sans couplage')
# plt.xticks(range_x, lab_x)
# plt.xlim(24*4-1, 300-37)
# plt.grid()
# plt.title('Temperature interieure moyenne')
# plt.savefig(sim.post+'/test.pdf')
# txt = ''
# for i in In:
#     txt += i
    

